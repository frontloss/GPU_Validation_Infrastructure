#pragma once
#include <ntdef.h>
#include "igdkmd_patcher\igdkmd_intc.h"
#include "ddrw\ddrw_displayargs.h"
#include "ddrw\ddrw_displayargsinternal.h"

#pragma warning( disable: 4214 )
#pragma warning( disable: 4201 )

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//NOTE: Any change in the interrrupt args structure below has to be reflected in the enum definitions above.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Interrupt Args structure
// Interrupt Args structure
typedef struct _SB_INTERRUPT_ARGS
{
    INTERRUPT_OPERATION eOperation; // Data structure for interrupt operations
    DDU32 ulPrivateData; // Private Interrupt Data. This will not be used in ILK and GT since enabling/disabling of all interrupts has become much simpler..

    DDU32 PlatformUsesGen11InterruptArchitecture : 1; // Let Event handler code know that all non-display engines are handled by new Selector methods
    DDU32 SelectorInterruptsOccurred : 1; // New for Gen11+  ::  This bit means one of the hierarchical interrupts (has to use selector register) has occurred and needs to be handled by GEN11+ handler
    DDU32 LegacyInterruptsOccurred : 1; // New for Gen11+  ::  This bit means use the IntArgs below for handling the interrupts

    DD_IN BOOLEAN HierarchicalInterruptService : 1; // This bit means request for Hirearchial Interrupt services

    DD_IN DDU32 ulEngineClass;                           // Can re-use ulValue in union
    DD_IN DDU32 ulEngineIntrpt;                          // Can re-use ulValue1 in union

    union
    {
        DDU32 ulValue;
        struct
        {
            //1. Hot Plug Interrupts Definitions - Starts Here

            DDU32    bIntegratedCRTInterrupt : 1;    // Bit 0
            DDU32    ulReservedBit : 1;    // Bit 1
            DDU32    bInterruptReserved1 : 1;    // Bit 2
            DDU32    bInterruptReserved2 : 1;    // Bit 3 //From Gen6 onwards,no need to register for this event as sDVO on Port C is disabled..
            DDU32    bIntDP_HDMIAInterrupt : 1;    // Bit 4  //New Introduction from ILK onwards
            DDU32    bIntDP_HDMIBInterrupt : 1;    // Bit 5
            DDU32    bIntDP_HDMICInterrupt : 1;    // Bit 6
            DDU32    bIntDP_HDMIDInterrupt : 1;    // Bit 7
            DDU32    bIntDP_HDMIA_SPInterrupt : 1;    // Bit 8 //New Introduction from ILK onwards
            DDU32    bIntDP_HDMIB_SPInterrupt : 1;    // Bit 9
            DDU32    bIntDP_HDMIC_SPInterrupt : 1;    // Bit 10
            DDU32    bIntDP_HDMID_SPInterrupt : 1;    // Bit 11

                                                      //1. Hot Plug Interrupts Definitions - Ends Here

                                                      //2. Render Geyserville Interrupts Definitions - Starts Here

                                                      //Render Geyserville Interrupts common till ILK Platform
            DDU32    bRen_Gey_SoftwareCommandCompleteInterrupt : 1; // bit 12 // Render GeyserVille Interrupt
            DDU32    bRen_Gey_EvaluatedFrequencyChangeInterrupt : 1; // bit 13 // Render GeyserVille Interrupt

                                                                     //New Render Geyserville Interrupts exists only in ILK
            DDU32    bRen_Gey_AvgBusyThreshold : 1; // bit 14 // Render GeyserVille Interrupt
            DDU32    bRen_Gey_ContinuousBusyThreshold : 1; // bit 15 // Render GeyserVille Interrupt

                                                           //Render Geyserville Common between ILK and GT
            DDU32    bRen_Gey_UpEvaluationIntervalInterrupt : 1; // bit 16 // Render GeyserVille Interrupt
            DDU32    bRen_Gey_DownEvaluationIntervalInterrupt : 1; // bit 17 // Render GeyserVille Interrupt

                                                                   //Render Geyserville Introduced from GT
            DDU32    bRen_Gey_Controller_Disable_StateInterrupt : 1; // bit 18 // Render GeyserVille Interrupt

                                                                     //2. Render Geyserville Interrupts Definitions - Ends Here

                                                                     //3. Basic Render Interrupt Definitions - Starts Here

            DDU32    bDebugInterrupt : 1; // Bit 19 Gen4 Onwards
            DDU32    bPipeControlNotifyInterrupt : 1; // Bit 20 Gen4 Onwards
            DDU32    bRenderUserInterrupt : 1; // Bit 21 Render Cmd UI
            DDU32    bRenderMMIOSyncFlushStatus : 1; // Bit 22
            DDU32    bRenderWatchDogCounterExcd : 1; // Bit 23 //ILK Onwards
            DDU32    bRenderASContextSwitch : 1; // Bit 24 //ILK Onwards
            DDU32    bRenderPageFault : 1; // Bit 25 //ILK Onwards

                                           //3. Basic Render Interrupt Definitions - Ends Here

                                           //4. Media/Video Interrupt Definitions - Starts Here
            DDU32    bVideoUserInterrupt : 1; // Bit 26 Gen4 Onwards
            DDU32    bVideoDecPipelineCntrExceed : 1; // Bit 27 Gen4 Onwards..Same as Video Command Streamer WatchDog Counter Exceeded in GT
                                                      //Following are valid from GT
            DDU32    bVideoMIFlush_DWNotify : 1; // Bit 28
            DDU32    bVideoMMIOSyncFlushStatus : 1; // Bit 29
            DDU32    bVideoASContextSwitch : 1; // Bit 30
            DDU32    bVideoPageFault : 1; // Bit 31

                                          //4. Media/Video Interrupt Definitions - Ends Here
        };
    };

    union
    {
        DDU32 ulValue1;
        struct
        {
            //5. Remaining Power Conservation Interrupt Starts here
            DDU32    bLBPC_PipeAInterrupt : 1;    // Bit 0 - crestline and after. Doesnt exist from ILK Onwards
            DDU32    bLBPC_PipeBInterrupt : 1;    // Bit 1 - crestline and after. Doesnt exist from ILK Onwards
            DDU32    bDPST_HistInterrupt : 1;    // Bit 2 - crestline and after
            DDU32    bDPST_PhaseInInterrupt : 1;    // Bit 3 - crestline and after

                                                    //Valid from GT Onwards
            DDU32    bPCUDriverMBEvent : 1; // Bit 4
            DDU32    bPCRenderFreqDownwardDuringRC6Timeout : 1; // Bit 5
            DDU32    bPC_RPUpThresholdIntr : 1; // Bit 6
            DDU32    bPC_RPDownThresholdIntr : 1; // Bit 7

                                                  //5. Remaining Power Conservation Interrupt Ends here

                                                  //6. Blitter Interrupts from GT Onwards Starts here

            DDU32    bBlitterASContextSwitch : 1; // Bit 8
            DDU32    bBlitterMIFlush_DWNotify : 1; // Bit 9
            DDU32    bBlitterMMIOSyncFlushStatus : 1; // Bit 10
            DDU32    bBlitterMI_User_Interrupt : 1; // Bit 11
            DDU32    bBlitterPageFault : 1; // Bit 12
                                            //6. Blitter Interrupts from GT Onwards Ends here

                                            //7. Misc Interrupts Category Starts here
            DDU32    bVSync_PipeAInterrupt : 1;    // Bit 13 //Not Required
            DDU32    bVSync_PipeBInterrupt : 1;    // Bit 14 //Not Required
            DDU32    bVBlank_PipeAInterrupt : 1;    // Bit 15
            DDU32    bVBlank_PipeBInterrupt : 1;    // Bit 16
            DDU32    bGSESystemLevel : 1;    // Bit 17  Valid from ILK Replacement for ASLE Interrupt
            DDU32    bVblankTPV : 1;    // BIT 18 //Used for TPV Vblank Interrupt
            DDU32    bASLEInterrupt : 1;    // Bit 19  Need to remove Once MP Cleans up the ASLE INterrupt Stuff
            DDU32    bAllFirstLevelInterrupts : 1;    // BIT 20 //Used for Enabling/Disabling of Interrupts..

                                                      //7. Misc Interrupts Category Ends here

                                                      //8. New added Interrupts
            DDU32    bSpritePlaneAFlipDoneInterrupt : 1;    // BIT 21 //Used for Enabling/Disabling of Sprite Plane A Flip Done Interrupt..
            DDU32    bSpritePlaneBFlipDoneInterrupt : 1;    // BIT 22 //Used for Enabling/Disabling of Sprite Plane B Flip Done Interrupt..

            DDU32    bVSync_PipeCInterrupt : 1;    // BIT 23
            DDU32    bVBlank_PipeCInterrupt : 1;    // BIT 24
            DDU32    bSpritePlaneCFlipDoneInterrupt : 1;    // BIT 25

            DDU32    bAudioHDCPRequestInterruptA : 1;    // BIT 26 //Audio HDCP request for transcoder A
            DDU32    bAudioHDCPRequestInterruptB : 1;    // BIT 27 //Audio HDCP request for transcoder B
            DDU32    bAudioHDCPRequestInterruptC : 1;    // BIT 28 //Audio HDCP request for transcoder C
            DDU32    bAudioHDCPRequestInterrupt : 1;    // BIT 29 //Audio HDCP request for pre ilk platforms

            DDU32   bPerfMonBufferHalfFullInterrupt : 1;    // BIT 30

            DDU32   ulReserved_Bit31 : 1;    // Bit 31
        };
    };

    union
    {
        DDU32 ulValue2;
        struct
        {
            // This sections contains error/debug status bits
            DDU32 bFIFOUnderrun_PipeAInterrupt : 1; // bit 0
            DDU32 bCRC_Error_PipeAInterrupt : 1; // bit 1
            DDU32 bCRC_Done_PipeAInterrupt : 1; // bit 2

            DDU32 bFIFOUnderrun_PipeBInterrupt : 1; // bit 3
            DDU32 bCRC_Error_PipeBInterrupt : 1; // bit 4
            DDU32 bCRC_Done_PipeBInterrupt : 1; // bit 5

            DDU32 bFIFOUnderrun_PipeCInterrupt : 1; // bit 6
            DDU32 bCRC_Error_PipeCInterrupt : 1; // bit 7
            DDU32 bCRC_Done_PipeCInterrupt : 1; // bit 8

                                                // VE (Video Enhancement) Interrupt Definitions - Starts Here - Valid from Gen7_5 (HSW+) onward
            DDU32 bVEUserInterrupt : 1; // bit 9
            DDU32 bVEMMIOSyncFlushStatus : 1; // bit 10
            DDU32 bVECmdParserMasterError : 1; // bit 11
            DDU32 bVEMIFlush_DWNotify : 1; // bit 12
                                           // VE (Video Enhancement) Interrupt Definitions - Ends Here

                                           // other interrupt bits that don't fit into the previous dwords
            DDU32 bRenderParityError : 1; // Bit 13 Gen7 Onwards

            DDU32 bVideoPavpUnsolicitedAttack : 1; // Bit 14 Gen7 Onwards

                                                   //Below are valid from BDW
            DDU32 bVideoUserInterrupt2 : 1; // Bit 15
            DDU32 bVideoDecPipelineCntrExceed2 : 1; // Bit 16
            DDU32 bVideoMIFlush_DWNotify2 : 1; // Bit 17
            DDU32 bVideoMMIOSyncFlushStatus2 : 1; // Bit 18
            DDU32 bVideoASContextSwitch2 : 1; // Bit 19
            DDU32 bVideoPageFault2 : 1; // Bit 20
            DDU32 bVideoPavpUnsolicitedAttack2 : 1; // Bit 21

            DDU32 bGuCSHIMError : 1;    // bit 22
            DDU32 bGuCDMAINTError : 1;    // bit 23
            DDU32 bGuCDMADone : 1;    // bit 24
            DDU32 bGuCDoorBellRang : 1;    // bit 25
            DDU32 bGuCIOMMUSentMsgtoGuc : 1;    // bit 26
            DDU32 bGuCSemaphoreSignaled : 1;    // bit 27
            DDU32 bGuCDisplayEventRecieved : 1;    // bit 28
            DDU32 bGuCExecutionError : 1;    // bit 29
            DDU32 bGuCInterruptToHost : 1;    // bit 30

            DDU32 bCSTRInvalidTileDetection : 1;    // bits 31
        };
    };

    union
    {
        DDU32 ulValue3;
        struct
        {
            // This sections contains VEC/WiDi interrupts
            DDU32 bVECSContextSwitchInterrupt : 1; // bit 0
            DDU32 bVECSWaitOnSemaphore : 1; // bit 1
            DDU32 bWDBoxInterrupt : 1; // bit 2
            DDU32 bDPST_HistInterruptPipeB : 1;// bit 3
            DDU32 bDPST_PhaseInInterruptPipeB : 1; // bit 4
            DDU32 bDPST_HistInterruptPipeC : 1;// bit 5
            DDU32 bDPST_PhaseInInterruptPipeC : 1; // bit 6

            DDU32 bPipeA_Plane1FlipDoneInterrupt : 1; //bit 7
            DDU32 bPipeA_Plane2FlipDoneInterrupt : 1; //bit 8
            DDU32 bPipeA_Plane3FlipDoneInterrupt : 1; //bit 9

            DDU32 bPipeB_Plane1FlipDoneInterrupt : 1; //bit 10
            DDU32 bPipeB_Plane2FlipDoneInterrupt : 1; //bit 11
            DDU32 bPipeB_Plane3FlipDoneInterrupt : 1; //bit 12

            DDU32 bPipeC_Plane1FlipDoneInterrupt : 1; //bit 13
            DDU32 bPipeC_Plane2FlipDoneInterrupt : 1; //bit 14
            DDU32 bPipeC_Plane3FlipDoneInterrupt : 1; //bit 15

            DDU32 bPipeA_Plane1FlipQueueEmptyInterrupt : 1; //bit 16
            DDU32 bPipeA_Plane2FlipQueueEmptyInterrupt : 1; //bit 17
            DDU32 bPipeA_Plane3FlipQueueEmptyInterrupt : 1; //bit 18

            DDU32 bPipeB_Plane1FlipQueueEmptyInterrupt : 1; //bit 19
            DDU32 bPipeB_Plane2FlipQueueEmptyInterrupt : 1; //bit 20
            DDU32 bPipeB_Plane3FlipQueueEmptyInterrupt : 1; //bit 21

            DDU32 bPipeC_Plane1FlipQueueEmptyInterrupt : 1; //bit 22
            DDU32 bPipeC_Plane2FlipQueueEmptyInterrupt : 1; //bit 23
            DDU32 bPipeC_Plane3FlipQueueEmptyInterrupt : 1; //bit 24

            DDU32 bDEMiscSVMWaitDescriptorCompleted : 1; // bit 25
            DDU32 bDEMiscSVMVTDFault : 1; // bit 26
            DDU32 bDEMiscSVMPRQEvent : 1; // bit 27

            DDU32 bPipeA_Plane4FlipDoneInterrupt : 1; // bit 28
            DDU32 bPipeB_Plane4FlipDoneInterrupt : 1; // bit 29
            DDU32 bPSR2GTCLockLoss : 1; // bit 30
            DDU32 bVECSWatchDogCounterExcd : 1; // bit 31
        };
    };
    union
    {
        DDU32 ulValue4;
        struct
        {
            DDU32 bMIPIAInterrupt : 1; // bit 0
            DDU32 bMIPICInterrupt : 1; // bit 1
            DDU32 bLPEPipeAInterrupt : 1; // bit 2
            DDU32 bLPEPipeBInterrupt : 1; // bit 3

            DDU32 bISPInterrupt : 1; // bit 4
            DDU32 bVEDBlockInterrupt : 1; // bit 5
            DDU32 bVEDPowerInterrupt : 1; // bit 6
            DDU32 bPipeA_Plane4FlipQueueEmptyInterrupt : 1; // bit 7

            DDU32 bPipeB_Plane4FlipQueueEmptyInterrupt : 1; // bit 8
            DDU32 bLPEPipeCInterrupt : 1; // bit 9
            DDU32 bGTPMCoreToUncoreTrapInterrupt : 1; //bit 10
            DDU32 bWDBoxEndofFrameInterrupt : 1; //bit 11 corresponds to WDBOX_END_OF_FRAME_INTERRUPT = 0X800, in INTERRUPT_UNION_VALUE_4

            DDU32 bIntDP_HDMIEInterrupt : 1; // Bit 12// skl ddi - e hot plug interrupt
            DDU32 bIntDP_HDMIE_SPInterrupt : 1; // Bit 13
            DDU32 bRenderTDLRetryInterrupt : 1; // bit 14
            DDU32 bPinningContextSwitch : 1; // Bit 15
            DDU32 bPinningUserInterrupt : 1; // Bit 16
            DDU32 bDEMisc_WDCombinedInterrupt : 1; // bit 17 corresponds to DEMISC_WD_COMBINED_INTERRUPT  = 0x20000, in INTERRUPT_UNION_VALUE_4

            DDU32 bPipeA_Underrun : 1; // bit 18
            DDU32 bPipeB_Underrun : 1; // bit 19
            DDU32 bPipeC_Underrun : 1; // bit 20
            DDU32 bPipeC_Plane4FlipDoneInterrupt : 1; // bit 21
            DDU32 bInvalidGTTPageTableEntry : 1; // bit 22
            DDU32 bInvalidPageTableEntryData : 1; // bit 23
            DDU32 bVSync_PipeDInterrupt : 1; // BIT 24
            DDU32 bVBlank_PipeDInterrupt : 1; // BIT 25
            DDU32 bIntDP_HDMIFInterrupt : 1; // Bit 26// ddi - f hot plug interrupt
            DDU32 ulReserved_Bits31_27 : 5; // bits 31:27
        };
    };
    union
    {
        DDU32 ulValue5;
        struct
        {
            DDU32 PipeA_Plane1GTTFaultStatus : 1; //bit 0
            DDU32 PipeA_Plane2GTTFaultStatus : 1; //bit 1
            DDU32 PipeA_Plane3GTTFaultStatus : 1; //bit 2
            DDU32 PipeA_Plane4GTTFaultStatus : 1; //bit 3
            DDU32 PipeA_CursorGTTFaultStatus : 1; //bit 4

            DDU32 PipeB_Plane1GTTFaultStatus : 1; //bit 5
            DDU32 PipeB_Plane2GTTFaultStatus : 1; //bit 6
            DDU32 PipeB_Plane3GTTFaultStatus : 1; //bit 7
            DDU32 PipeB_Plane4GTTFaultStatus : 1; //bit 8
            DDU32 PipeB_CursorGTTFaultStatus : 1; //bit 9

            DDU32 PipeC_Plane1GTTFaultStatus : 1; //bit 10
            DDU32 PipeC_Plane2GTTFaultStatus : 1; //bit 11
            DDU32 PipeC_Plane3GTTFaultStatus : 1; //bit 12
            DDU32 PipeC_Plane4GTTFaultStatus : 1; //bit 13
            DDU32 PipeC_CursorGTTFaultStatus : 1; //bit 14

            DDU32 IntDP_HDMIB_SCDCInterrupt : 1; //bit 15
            DDU32 IntDP_HDMIC_SCDCInterrupt : 1; //bit 16
            DDU32 IntDP_HDMID_SCDCInterrupt : 1; //bit 17
            DDU32 IntDP_HDMIE_SCDCInterrupt : 1; //bit 18
            DDU32 IntDP_HDMIF_SCDCInterrupt : 1; //bit 19

            DDU32 bPipeA_Plane5FlipDoneInterrupt : 1; // bit 20
            DDU32 bPipeA_Plane6FlipDoneInterrupt : 1; // bit 21
            DDU32 bPipeA_Plane7FlipDoneInterrupt : 1; // bit 22
            DDU32 bPipeB_Plane5FlipDoneInterrupt : 1; // bit 23
            DDU32 bPipeB_Plane6FlipDoneInterrupt : 1; // bit 24
            DDU32 bPipeB_Plane7FlipDoneInterrupt : 1; // bit 25
            DDU32 bPipeC_Plane5FlipDoneInterrupt : 1; // bit 26
            DDU32 bPipeC_Plane6FlipDoneInterrupt : 1; // bit 27
            DDU32 bPipeC_Plane7FlipDoneInterrupt : 1; // bit 28
            DDU32 bPipeD_Plane5FlipDoneInterrupt : 1; // bit 29
            DDU32 bPipeD_Plane6FlipDoneInterrupt : 1; // bit 30
            DDU32 bPipeD_Plane7FlipDoneInterrupt : 1; // bit 31
        };
    };
    union
    {
        DDU32 ulValue6;
        struct
        {
            DDU32 PipeA_Plane5GTTFaultStatus : 1; //bit 0
            DDU32 PipeA_Plane6GTTFaultStatus : 1; //bit 1
            DDU32 PipeA_Plane7GTTFaultStatus : 1; //bit 2
            DDU32 PipeB_Plane5GTTFaultStatus : 1; //bit 3
            DDU32 PipeB_Plane6GTTFaultStatus : 1; //bit 4
            DDU32 PipeB_Plane7GTTFaultStatus : 1; //bit 5
            DDU32 PipeC_Plane5GTTFaultStatus : 1; //bit 6
            DDU32 PipeC_Plane6GTTFaultStatus : 1; //bit 7
            DDU32 PipeC_Plane7GTTFaultStatus : 1; //bit 8
            DDU32 PipeD_Plane5GTTFaultStatus : 1; //bit 9
            DDU32 PipeD_Plane6GTTFaultStatus : 1; //bit 10
            DDU32 PipeD_Plane7GTTFaultStatus : 1; //bit 11
            DDU32 bPipeD_Plane1FlipDoneInterrupt : 1; //bit 12
            DDU32 bPipeD_Plane2FlipDoneInterrupt : 1; //bit 13
            DDU32 bPipeD_Plane3FlipDoneInterrupt : 1; //bit 14
            DDU32 bPipeD_Plane4FlipDoneInterrupt : 1; //bit 15
            DDU32 PipeD_Plane1GTTFaultStatus : 1; //bit 16
            DDU32 PipeD_Plane2GTTFaultStatus : 1; //bit 17
            DDU32 PipeD_Plane3GTTFaultStatus : 1; //bit 18
            DDU32 PipeD_Plane4GTTFaultStatus : 1; //bit 19
            DDU32 PipeD_CursorGTTFaultStatus : 1; //bit 20
            DDU32 PipeD_DPST_HistInterrupt : 1;// bit 21
            DDU32 bCRC_Error_PipeDInterrupt : 1; // bit 22
            DDU32 bCRC_Done_PipeDInterrupt : 1; // bit 23
            DDU32 bPipeD_Underrun : 1; // bit 24
            DDU32 bAudioHDCPRequestInterruptD : 1; // bit 25
            DDU32 IntDP_HDMIA_SCDCInterrupt : 1; // bit 26
            DDU32 PIPEA_VRRDoubleBufferUpdate : 1; // bit 27
            DDU32 PIPEB_VRRDoubleBufferUpdate : 1; // bit 28
            DDU32 PIPEC_VRRDoubleBufferUpdate : 1; // bit 29
            DDU32 PIPED_VRRDoubleBufferUpdate : 1; // bit 30
            DDU32 ulReserved_Bits31_ulValue6 : 1; // bits 31
        };
    }; // TODO: map new events 5 6
} SB_INTERRUPT_ARGS, *PSB_INTERRUPT_ARGS;




typedef struct _DD_GET_VBT
{
    DDU8 *pVbtData;           // VBT Data from Opregion
} DD_GET_VBT;


/* 
** Structure to store function RVA during initialization. The RVA
** will used to restore back the original function during driver unload
*/
typedef struct _PATCHCONTEXT
{   
    PTR_T  NotifyISR_RVA;
    PTR_T  ReadDDC_RVA;
    PTR_T  AuxAccess_RVA;    
    PTR_T  DisplayHotPlugAPort_RVA;
    PTR_T  DisplayHotPlugBPort_RVA;
    PTR_T  DisplayHotPlugCPort_RVA;
    PTR_T  DisplayHotPlugDPort_RVA;
    PTR_T  DisplayHotPlugEPort_RVA;    
}IGDKMD_RVA_CONTEXT, *PIGDKMD_RVA_CONTEXT;


/*
** Structure to hold orginal function pointer of the interested 
** function in igdkmd driver.
*/
typedef struct _IGDKMD_FUNC_INTERFACE_1 {
    VOID(*DisplayHotPlugPortADpc)(PVOID pHwDev);
    VOID(*DisplayHotPlugPortBDpc)(PVOID pHwDev);
    VOID(*DisplayHotPlugPortCDpc)(PVOID pHwDev);
    VOID(*DisplayHotPlugPortDDpc)(PVOID pHwDev);
    VOID(*DisplayHotPlugPortEDpc)(PVOID pHwDev);
    ULONG(*ReadDDC)(PVOID pDHLContext, PVOID pArg);
    ULONG(*AuxAccess)(PVOID pDHLContext, PVOID pArg);
    ULONG(*NotifyIsr)(PVOID pHwDev, PVOID pIntArgs);    
}IGDKMD_FUNC_INTERFACE, *PIGDKMD_FUNC_INTERFACE;


/*
** Structure to hold the stub function pointer of the interested 
** function in igdkmd driver.
*/
typedef struct _IGDKMD_HOOKS_INTERFACE_1 {
    ULONG(*ReadDDC)(PVOID pDHLContext, PDD_READ_DDC_ARGUMENTS pIntArg);
    ULONG(*AuxAccess)(PVOID pDHLContext, PDD_AUX_ARGUMENTS pIntArgs);
    NTSTATUS(*NotifyIsr)(PVOID pHwDev, PSB_INTERRUPT_ARGS pIntArgs);    
}IGDKMD_PROXY_INTERFACE, *PIGDKMD_PROXY_INTERFACE;

PIGDKMD_FUNC_INTERFACE igdkmd_funcptr_table;
PIGDKMD_PROXY_INTERFACE proxy_funcptr_table;
PIGDKMD_RVA_CONTEXT igdkmd_rva_table;

//DFT related API
VOID Call_HotPlugUnPlug_DPC(ULONG port);

// Cleanup API used during driver unload
VOID TearDown_DDRW_Hooks();

#pragma warning( default: 4214 )
#pragma warning( default: 4201 )