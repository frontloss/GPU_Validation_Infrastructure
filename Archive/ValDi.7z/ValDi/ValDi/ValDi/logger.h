#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <ntdef.h>

#define KMT_U2A_BUFFER_SIZE 1024

// @TODO: Temporary fixed size for PoC.
#define TXTBUFFERSIZE 0x4000000
#define MAX_CHUNK_SIZE 128

VOID vLog(const char* txt);

#define PACKLOG(...)\
{\
    CHAR txtBuff[128];\
    _snprintf(txtBuff, 127, __VA_ARGS__);\
    vLog(txtBuff);\
}

#define DLOG(...)\
{\
    KdPrintEx((DPFLTR_IHVDRIVER_ID, DPFLTR_INFO_LEVEL,    __VA_ARGS__));\
}


#define PLOG(...)\
{\
    KdPrintEx((DPFLTR_IHVDRIVER_ID, DPFLTR_INFO_LEVEL,    __VA_ARGS__));\
    PACKLOG(__VA_ARGS__);\
}


#define WLOG(...)\
{\
    KdPrintEx((DPFLTR_IHVDRIVER_ID, DPFLTR_WARNING_LEVEL, __VA_ARGS__));\
    PACKLOG(__VA_ARGS__);\
}

#define ELOG(...)\
{\
    KdPrintEx((DPFLTR_IHVDRIVER_ID, DPFLTR_ERROR_LEVEL,   __VA_ARGS__));\
    PACKLOG(__VA_ARGS__);\
}

#define ADD_DLOG(txt)\
{\
    CHAR ftxt[VALDI_MAX_TXT_MARKER_LENGTH + 2];\
    strcpy(ftxt, "#");\
    strcat(ftxt, txt);\
    addDirectToLog(ftxt, (USHORT)strlen(ftxt));\
}

#define VERBOSE_LOG
#ifdef VERBOSE_LOG
#define VLOG(...)\
{\
    KdPrintEx((DPFLTR_IHVDRIVER_ID, DPFLTR_INFO_LEVEL, __VA_ARGS__));\
}
#else
#define VLOG(...)
#endif

//@TODO: Temporary solution - static memory block for log caching. 
//       No mechanism for overrun prevention for now.
//       
typedef struct _TXTBUFFER
{
    UCHAR         buffer[TXTBUFFERSIZE];
    volatile ULONG         endSection;
}TXTBUFFER, *PTXTBUFFER;

typedef struct __tB {
    UCHAR                  dbgMarker[17];
    volatile PVOID         currP;
    volatile ULONG         lockFlag;
    volatile LONG          chunkCount;
    PTXTBUFFER              logBuffer;
    volatile ULONG         overflowFlag;
    volatile ULONG         droppedCRCFlag;
}_tB, *P_tB;

extern _tB txtBuffer;

extern volatile VOID(*addToLog)(const char* fname, USHORT strbytes, PVOID* addrList, ULONG* sizesList, ULONG listLength);
VOID _addToLog(const char* fname, USHORT strbytes, PVOID* addrList, ULONG* sizesList, ULONG listLength);
VOID _dummy_addToLog(const char* fname, USHORT strbytes, PVOID* addrList, ULONG* sizesList, ULONG listLength);
VOID addDirectToLog(const char* txt, USHORT strbytes);

// Helper function to log buffer to log file
VOID LogToFile(PTXTBUFFER p, PIO_STATUS_BLOCK ioStatusBlock);

VOID ValDiSuspendTracing();
VOID ValDiResumeTracing();
VOID ValDiRestartTracing();
VOID ValDiFinalizeTracing();

VOID Setup_Logger();
VOID TearDown_Logger();