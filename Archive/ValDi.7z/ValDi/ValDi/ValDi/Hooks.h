#pragma once
#include "globals.h"
#include "Dispmprt.h"
#include "Driver.h"

#define DTYPE_STR    0xA
#define DTYPE_BIN    0x2
#define DTYPE_BIN4BB 0x3
#define DTYPE_DEC    0x4

extern ULONG enableWaterMarkCorruptions;

INT igdkmd_patcher(PPATCHED_MODINFO modInfo);
INT igdkmd_patcher_cleanup();


///////////////////////////////////////////////////////////////////////////////////////////////////
//HOOKING STATISTICS
///////////////////////////////////////////////////////////////////////////////////////////////////
extern VALDI_HOOK_STATS hStats;


//Internal igdkmd functions
INT igdkmd_getAdapterInfo(INT infoType, ULONG infoDataSize, PVOID targetBufferPtr);
INT igdkmd_readMMIOData(ULONG addr, PVOID data, ULONG size);
INT igdkmd_writeMMIOData(ULONG addr, PVOID data, ULONG size);

extern BOOLEAN(*igdkmd_KmReadMMIO_Data)(PVOID, ULONG, PVOID, ULONG);
extern BOOLEAN(*igdkmd_KmWriteMMIO_Data)(PVOID, ULONG, PVOID, ULONG);


extern PDXGKDDI_QUERYADAPTERINFO              igdkmd_DxgkDdiQueryAdapterInfo;
extern PDXGKDDI_ADD_DEVICE                    igdkmd_DxgkDdiAddDevice;
extern PDXGKDDI_INTERRUPT_ROUTINE             igdkmd_DxgkDdiInterruptRoutine;
extern PDXGKDDI_COMMITVIDPN                   igdkmd_DxgkDdiCommitVidPn;
extern PDXGKDDI_START_DEVICE                  igdkmd_DxgkDdiStartDevice;
extern PVOID                                  igdkmd_hwContext;
extern PDXGKDDI_UPDATEACTIVEVIDPNPRESENTPATH  igdkmd_DxgkDdiUpdateActiveVidPnPresentPath;
extern PDXGKDDI_CONTROLINTERRUPT              igdkmd_DxgkDdiControlInterrupt;


NTSTATUS  __hooked_DxgkDdiControlInterrupt(
    _In_ const HANDLE              hAdapter,
    _In_ const DXGK_INTERRUPT_TYPE InterruptType,
    _In_       BOOLEAN             Enable
);

extern NTSTATUS(*igdkmd_GfxSetSourceVisibility_16)(PVOID pHwDev, PVOID args);

extern NTSTATUS(*native_DxgkInitialize)(PDRIVER_OBJECT, PUNICODE_STRING, PDRIVER_INITIALIZATION_DATA);
extern NTSTATUS __hooked_DxgkInitialize(_In_ PDRIVER_OBJECT DriverObject,
	_In_ PUNICODE_STRING RegistryPath,
	_In_ PDRIVER_INITIALIZATION_DATA DriverInitializationData);

NTSTATUS(*igdkmd_DxgkInitializeDisplayOnlyDriver)(PDRIVER_OBJECT, PUNICODE_STRING, PKMDDOD_INITIALIZATION_DATA);
extern NTSTATUS __hooked_DxgkInitializeDisplayOnlyDriver(
	_In_ PDRIVER_OBJECT DriverObject,
	_In_ PUNICODE_STRING RegistryPath,
	_In_ PKMDDOD_INITIALIZATION_DATA DriverInitializationData);

extern USHORT igdkmd_NotifyPowerState_Args_size;
extern ULONG(*igdkmd_NotifyPowerState)(PVOID pThis, PVOID pArgs);
ULONG __hooked_igdkmd_NotifyPowerState(PVOID pThis, PVOID pArgs);

extern USHORT igdkmd_BlankVideo_Args_size;
extern ULONG(*igdkmd_BlankVideo)(PVOID pThis, PVOID pArgs);
ULONG __hooked_igdkmd_BlankVideo(PVOID pThis, PVOID pArgs);

extern USHORT pipeId__SB_MODE_ARGS;
extern ULONG(*igdkmd_SetMode)(PVOID pThis, PVOID pSetModeArgs);
ULONG __hooked_igdkmd_SetMode(PVOID this, PVOID pSetModeArgs);

extern ULONG(*igdkmd_NotifyModeSetComplete)(PVOID pThis, PVOID pSetModeArgs);
ULONG __hooked_igdkmd_NotifyModeSetComplete(PVOID this, PVOID pSetModeArgs);

extern USHORT DisplayPwrSetArgs_Size;
extern ULONG(*igdkmd_SetDisplayPowerState)(PVOID pThis, PVOID pDisplayPwrSetArgs);
ULONG __hooked_igdkmd_SetDisplayPowerState(PVOID this, PVOID pDisplayPwrSetArgs);

extern VOID(*report_SoftSync)(ULONG pipeId);
VOID __dummy_report_SoftSync(ULONG pipeId);
VOID __report_SoftSync(ULONG pipeId);

VOID __report_Underrun(const char* msg, USHORT strbytes, ULONG pipeId);

VOID __report_FlipDone(ULONG pipeId, ULONG planeId);
VOID __report_FlipQueueEmpty(ULONG pipeId, ULONG planeId);

VOID __report_pipeCRC(ULONG pipeId);

VOID intSrv();

extern PVOID(*igdkmd_GetHALInterface)();
extern ULONG(*igdkmd_NotifyIsr_DDRW)(PVOID pHwDev, PVOID pIntArgs);