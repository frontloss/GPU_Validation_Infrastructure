#pragma once

#include <ntddk.h>

PVOID kmalloc(SIZE_T size);
PVOID kmallocP(SIZE_T size);
PVOID kcalloc(SIZE_T size, SIZE_T numOfElements);
PVOID krealloc(PVOID ptr, SIZE_T oldSize,  SIZE_T newSize);
VOID  kfree(PVOID free);
