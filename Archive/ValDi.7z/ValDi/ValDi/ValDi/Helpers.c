#include <Ntifs.h>
#include "Helpers.h"
#include "kmem.h"
#include <ntimage.h>
#include "Driver.h"

////////////////////////////////////////////////////////////////////////////////////////////////////
struct CV_INFO_PDB70
{
    ULONG          magic;
    GUID           signature;       // unique identifier 
    ULONG          age;             // an always-incrementing value 
    _Field_z_ char  path[MAX_PATH];  // zero terminated string with the name of the PDB file 
};

BOOLEAN GetFileGUID(PUNICODE_STRING p_modPath, BYTE* pguid, ULONG* age)
{
    OBJECT_ATTRIBUTES  objAttr;

    HANDLE             handle;
    NTSTATUS           ntstatus;
    IO_STATUS_BLOCK    ioStatusBlock;
    PVOID              buff;
    FILE_STANDARD_INFORMATION fInfo;
    BOOLEAN            retV = FALSE;
    //LARGE_INTEGER      byteOffset;

    InitializeObjectAttributes(&objAttr, p_modPath, OBJ_CASE_INSENSITIVE | OBJ_KERNEL_HANDLE, NULL, NULL);

    ntstatus = ZwCreateFile(&handle, GENERIC_READ, &objAttr, &ioStatusBlock, NULL, FILE_ATTRIBUTE_NORMAL, 0, FILE_OPEN, FILE_SYNCHRONOUS_IO_NONALERT, NULL, 0);

    if (!NT_SUCCESS(ntstatus))
        goto __EXIT_ERR;

    ntstatus = ZwQueryInformationFile(handle, &ioStatusBlock, &fInfo, sizeof(FILE_STANDARD_INFORMATION), FileStandardInformation);

    if (!NT_SUCCESS(ntstatus))
        goto __EXIT_CLOSE;

    buff = kmalloc((SIZE_T)fInfo.EndOfFile.QuadPart);
    if (!buff)
        goto __EXIT_CLOSE;

    //byteOffset.HighPart = -1;
    //byteOffset.LowPart = FILE_USE_FILE_POINTER_POSITION;

    ntstatus = ZwReadFile(handle, NULL, NULL, NULL, &ioStatusBlock, buff, (ULONG)fInfo.EndOfFile.QuadPart, NULL, NULL);


    if (!NT_SUCCESS(ntstatus))
        goto __EXIT_CLOSE;

    retV = GetImageGUID(buff, (ULONG)fInfo.EndOfFile.QuadPart, pguid, age, TRUE);

    kfree(buff);
    ZwClose(handle);
    return retV;

__EXIT_CLOSE:
    ZwClose(handle);
__EXIT_ERR:
    age = 0;
    RtlZeroMemory(pguid, 16);
    return FALSE;
}

BOOLEAN GetImageGUID(PVOID ImageBase, ULONG ImageSize, BYTE* pguid, ULONG* age, BOOLEAN fill_gap)
{
    ASSERT(pguid);
    ASSERT(age);

    *age = 0;
    RtlZeroMemory(pguid, 16);

    if (((PTR_T)ImageBase == FAKE_ADDRESS) || (ImageBase == NULL))
        return FALSE;

    IMAGE_DOS_HEADER     const * pDosHeader = (IMAGE_DOS_HEADER*)ImageBase;
    if (0x5A4D != pDosHeader->e_magic)
    {
        return FALSE;
    }

    IMAGE_NT_HEADERS     const * pNtHeaders = (IMAGE_NT_HEADERS*)((BYTE*)ImageBase + pDosHeader->e_lfanew);
    IMAGE_DATA_DIRECTORY const * rgDataDirectory = NULL;

    if (pNtHeaders->OptionalHeader.Magic == IMAGE_NT_OPTIONAL_HDR32_MAGIC)
        rgDataDirectory = ((IMAGE_OPTIONAL_HEADER32 const *)&pNtHeaders->OptionalHeader)->DataDirectory;
    else
        rgDataDirectory = ((IMAGE_OPTIONAL_HEADER64 const *)&pNtHeaders->OptionalHeader)->DataDirectory;

    IMAGE_DATA_DIRECTORY const * pDebugDataDirectory = &rgDataDirectory[IMAGE_DIRECTORY_ENTRY_DEBUG];

    ULONG DebugRVA = pNtHeaders->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_DEBUG].VirtualAddress;
    if (DebugRVA == 0)
    {
        return FALSE;
    }

    PIMAGE_SECTION_HEADER pSectionHeader = IMAGE_FIRST_SECTION(pNtHeaders);
    for (size_t i = 0; i<pNtHeaders->FileHeader.NumberOfSections; ++i)
    {
        PIMAGE_SECTION_HEADER s = pSectionHeader + i;
        if (DebugRVA >= s->VirtualAddress && DebugRVA < s->VirtualAddress + s->SizeOfRawData)
        {
            pSectionHeader = s;
            break;
        }
    }

    if (fill_gap)
    {
        ULONG gap = pSectionHeader->VirtualAddress - pSectionHeader->PointerToRawData;
        *(PTR_T*)&ImageBase -= gap;
    }

    IMAGE_DEBUG_DIRECTORY const *rgDebugEntries = (IMAGE_DEBUG_DIRECTORY const *)((BYTE*)ImageBase + pDebugDataDirectory->VirtualAddress);
    ULONG cbDebugEntries = pDebugDataDirectory->Size;
    if (cbDebugEntries < sizeof(IMAGE_DEBUG_DIRECTORY))
        return FALSE;

    if (cbDebugEntries % sizeof(IMAGE_DEBUG_DIRECTORY) != 0)
        return FALSE;

    int cEntries = cbDebugEntries / sizeof(IMAGE_DEBUG_DIRECTORY);
    for (int i = 0; i < cEntries; i++)
    {
        if ((PTR_T)(&rgDebugEntries[i]) + sizeof(rgDebugEntries[i]) >= ((PTR_T)ImageBase + ImageSize))
        {
            return FALSE;
        }

        if (rgDebugEntries[i].Type != IMAGE_DEBUG_TYPE_CODEVIEW)
        {
            continue;
        }

        if (rgDebugEntries[i].AddressOfRawData == 0)
        {
            continue;
        }

        ULONG rvaOfRawData = rgDebugEntries[i].AddressOfRawData;
        ULONG cbDebugData = rgDebugEntries[i].SizeOfData;
        if (cbDebugData < (size_t)(&((struct CV_INFO_PDB70*)0)->magic) + sizeof(((struct CV_INFO_PDB70*)0)->magic))
        {
            continue;
        }

        const ULONG CV_SIGNATURE_RSDS = 0x53445352;
        struct CV_INFO_PDB70 * pPdb70 = (struct CV_INFO_PDB70 *)((BYTE*)ImageBase + rvaOfRawData);
        if ((PTR_T)(pPdb70)+cbDebugData >= ((PTR_T)ImageBase + ImageSize))
        {
            return FALSE;
        }

        if (pPdb70->magic != CV_SIGNATURE_RSDS)
        {
            continue;
        }

        if (cbDebugData > sizeof(struct CV_INFO_PDB70))
            return FALSE;

        if (cbDebugData < (PTR_T)((struct CV_INFO_PDB70*)0)->path + sizeof(char))
            return FALSE;

        RtlCopyMemory(pguid, &pPdb70->signature, sizeof(GUID));
        *age = pPdb70->age;

        return TRUE;
    }

    return FALSE;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID GetBaseFileName(IN PUNICODE_STRING pIn, OUT PUNICODE_STRING pOut)
{
    UNICODE_STRING curr = *pIn;
    UNICODE_STRING rem;

    for (;;)
    {
        
        FsRtlDissectName(curr, pOut, &rem);
        if (rem.Length == 0)
            break;
        curr = rem;
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void stripToBaseName(char* istr)
{
    char *ptr = strrchr(istr, '\\');
    if (ptr != NULL)
        strcpy(istr, ptr + 1);
};

///////////////////////////////////////////////////////////////////////////////////////////////////
PSYMBOLINFO GetModSymbol(PPATCHED_MODINFO modInfo, const PCHAR symName)
{
    unsigned int i;

    if (!modInfo)
        return NULL;

    for (i = 0; i < modInfo->symInfoSize; i++)
    {
        if (!strcmp(modInfo->symInfo[i].shortName, symName))
        {
            return &modInfo->symInfo[i];
        }
    }

    return NULL;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
char* u2a(PCUNICODE_STRING u, char* a, int alen)
{
    int c = 0;

    RtlZeroMemory(a, alen);

    if (u->Length < 2)
        return a;

    if (!alen)
        return NULL;

    do
    {
        a[c] = *((char*)(u->Buffer) + 2 * c);
        c++;
    } while ((2 * c < u->Length) && (c < alen) && (a[c - 1] != '\0'));

    return a;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID GenDumpName(PUNICODE_STRING uString)
{
    LARGE_INTEGER timeStamp;
    KeQueryTickCount(&timeStamp);

    UNICODE_STRING ucb;
    WCHAR ucb_buff[34] = { 0 };
    ucb.Buffer = ucb_buff;
    ucb.Length = 0;
    ucb.MaximumLength = 34;

    const WCHAR baseName[] = L"\\??\\c:\\trace_";
    const WCHAR extS[] = L".valdi";

    uString->Length = 0;
    if (uString->MaximumLength <= wcslen(baseName)*2 + 32 + 2)
    {
        uString->Buffer = krealloc(uString->Buffer, uString->MaximumLength, wcslen(baseName)*2 + wcslen(extS) * 2 + 32 + 2);
        uString->MaximumLength = (USHORT)wcslen(baseName)*2 + 32 + 2;
        uString->Length = uString->MaximumLength;
        RtlZeroMemory(uString->Buffer, uString->MaximumLength);
    }

    RtlInt64ToUnicodeString(timeStamp.QuadPart, 16, &ucb);
    wcscpy(uString->Buffer, baseName);
    wcscat(uString->Buffer, ucb_buff);
    wcscat(uString->Buffer, extS);


    uString->Length = (USHORT)wcslen(baseName) * 2 + (USHORT)wcslen(extS) * 2;
    uString->Length += ucb.Length;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
ULONGLONG GetTimeStamp()
{
    LARGE_INTEGER  currTimeStamp;
    LARGE_INTEGER  currFreq;

    currTimeStamp = KeQueryPerformanceCounter(&currFreq);
    currTimeStamp.QuadPart *= 1000000;
    currTimeStamp.QuadPart += currFreq.QuadPart / 2;
    currTimeStamp.QuadPart /= currFreq.QuadPart;
    return currTimeStamp.QuadPart;
}

