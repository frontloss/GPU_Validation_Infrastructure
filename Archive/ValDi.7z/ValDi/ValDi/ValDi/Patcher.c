#include "globals.h"
#include "Driver.h"
#include "Patcher.h"
#include "Helpers.h"
#include "kmem.h"
#include "DFT.h"
#include <stdlib.h>
#include "logger.h"

extern VALDI_PATCH_STORE patchStore;

const char PREVALDI_MAGIC[] = PREVALDI_MAGIC_STR;

//@TODO: Default VSM localization is the same as the SYS module.
//       A customization to be added.

///////////////////////////////////////////////////////////////////////////////////////////////////
int LoadVSM(PPATCHED_MODINFO pModInfo, UNICODE_STRING pathToMod)
{
    OBJECT_ATTRIBUTES  objAttr;
    LARGE_INTEGER      byteOffset;
    HANDLE             handle;
    NTSTATUS           ntstatus;
    IO_STATUS_BLOCK    ioStatusBlock;
    BYTE               buffer[sizeof(SYMBOLINFO)];
    ULONG              count = 0;
    UNICODE_STRING     pathToVSM;

    pathToVSM.Length = 0;
    pathToVSM.MaximumLength = max(pathToMod.Length, MAX_PATH);
    pathToVSM.Buffer = kcalloc(sizeof(WCHAR), pathToVSM.MaximumLength);
    RtlCopyMemory(pathToVSM.Buffer, pathToMod.Buffer, pathToMod.Length);
    WCHAR* pw = wcsrchr(pathToVSM.Buffer, L'.');
    if (pw) *pw = L'\0';
    wcscat(pathToVSM.Buffer, L".VSM");

    PLOG("Loading VSM file: %S\n", pathToVSM.Buffer);
    InitializeObjectAttributes(&objAttr, &pathToVSM, OBJ_CASE_INSENSITIVE | OBJ_KERNEL_HANDLE, NULL, NULL);
    ntstatus = ZwCreateFile(&handle, GENERIC_READ, &objAttr, &ioStatusBlock, NULL, FILE_ATTRIBUTE_NORMAL, 0, FILE_OPEN, FILE_SYNCHRONOUS_IO_NONALERT, NULL, 0);
    if (!NT_SUCCESS(ntstatus))
    {
        UNICODE_STRING baseName;
        GetBaseFileName(&pathToMod, &baseName);
        wcscpy(pathToVSM.Buffer, L"\\SystemRoot\\System32\\drivers\\");
        wcscat(pathToVSM.Buffer, baseName.Buffer);
        WCHAR* pw2 = wcsrchr(pathToVSM.Buffer, L'.');
        if (pw) *pw2 = L'\0';
        wcscat(pathToVSM.Buffer, L".VSM");
        pathToVSM.Length = (USHORT)(wcslen(pathToVSM.Buffer) * sizeof(WCHAR));

        ELOG("Could not open the VSM file - trying legacy path %S ...\n", pathToVSM.Buffer);

        OBJECT_ATTRIBUTES  objAttr2;
        InitializeObjectAttributes(&objAttr2, &pathToVSM, OBJ_CASE_INSENSITIVE | OBJ_KERNEL_HANDLE, NULL, NULL);
        ntstatus = ZwCreateFile(&handle, GENERIC_READ, &objAttr, &ioStatusBlock, NULL, FILE_ATTRIBUTE_NORMAL, 0, FILE_OPEN, FILE_SYNCHRONOUS_IO_NONALERT, NULL, 0);
        if (!NT_SUCCESS(ntstatus))
        {
            ELOG("Could not open the VSM file %S\n", pathToVSM.Buffer);
            return -1;
        }
    }

    byteOffset.LowPart = byteOffset.HighPart = 0;	
    ntstatus = ZwReadFile(handle, NULL, NULL, NULL, &ioStatusBlock, buffer, sizeof(PREVALDI_MAGIC), &byteOffset, NULL);
    if (RtlCompareMemory(buffer, PREVALDI_MAGIC, sizeof(PREVALDI_MAGIC)-1) != sizeof(PREVALDI_MAGIC)-1)
    {
        ELOG("VSM invalid magic.\n");
        goto __EXIT_WITH_ERROR;
    }
    byteOffset.LowPart += sizeof(PREVALDI_MAGIC)-1;

    ntstatus = ZwReadFile(handle, NULL, NULL, NULL, &ioStatusBlock, buffer, sizeof(GUID), &byteOffset, NULL);
    if (RtlCompareMemory(buffer, &pModInfo->guid, sizeof(GUID)) != sizeof(GUID))
    {
        ELOG("Module GUID mismatch.\n");
        goto __EXIT_WITH_ERROR;
    }
    byteOffset.LowPart += sizeof(GUID);

    ntstatus = ZwReadFile(handle, NULL, NULL, NULL, &ioStatusBlock, buffer, sizeof(ULONG), &byteOffset, NULL);
    if (*(ULONG*)buffer != pModInfo->age )
    {
        ELOG("Module age mismatch.\n");
        goto __EXIT_WITH_ERROR;
    }
    byteOffset.LowPart += sizeof(ULONG);

    ntstatus = ZwReadFile(handle, NULL, NULL, NULL, &ioStatusBlock, &count, sizeof(ULONG), &byteOffset, NULL);
    if (count > MAX_SYMINFO_COUNT)
    {
        ELOG("Invalid SYMINFO count.\n");
        goto __EXIT_WITH_ERROR;
    }
    byteOffset.LowPart += sizeof(ULONG);

    //@TODO: Cleanup to be addeed.
    pModInfo->symInfoSize = count;
    pModInfo->symInfo = kcalloc(sizeof(SYMBOLINFO), count);

    while ((ZwReadFile(handle, NULL, NULL, NULL, &ioStatusBlock, buffer, sizeof(SYMBOLINFO), &byteOffset, NULL) == STATUS_SUCCESS) && (--count < MAX_SYMINFO_COUNT))
    {
        RtlCopyMemory(&pModInfo->symInfo[count], buffer, sizeof(SYMBOLINFO));
        byteOffset.LowPart += sizeof(SYMBOLINFO);
    }
    
    ZwClose(handle);
    kfree(pathToVSM.Buffer);
    return 0;

__EXIT_WITH_ERROR:
    ZwClose(handle);
    kfree(pathToVSM.Buffer);
    return -1;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
int CommitPatchPoint(PPATCHPOINT pp)
{
    //@OPEN: Currenlty, only a direct jump is implemented. This impose a silent assumtion that the distance
    //between hook and target is < 2GB.
    //If this assumption is not valid, a trampoline mechanism need to be added in the debug INT3(CC) section.
    if (!igdkmd_patchOfThePatches)
        return -1;

    PTR_T opPtr = (PTR_T)pp->vaPatchPoint + pp->patchPointSize;
    //ULONGLONG offset = (PTR_T)pp->vaDestination - opPtr;
    ULONGLONG offset = igdkmd_patchOfThePatches - opPtr;
    BYTE instrPtr[8];
    PVOID ptr = (PVOID)pp->vaPatchPoint;

    RtlCopyMemory(&instrPtr, (PVOID)(pp->vaPatchPoint), pp->patchPointSize);
    RtlCopyMemory(&pp->orgData, instrPtr, sizeof(instrPtr));
    RtlFillMemory(&instrPtr, pp->patchPointSize, 0x90);
    instrPtr[0] = 0xE8;
    RtlCopyMemory((BYTE*)instrPtr + 1, &offset, 4);
    PTR_T dwOldCR0 = __readcr0();
    __writecr0(dwOldCR0&~(1 << 16));
    unsigned int i;

    * (ULONG*)igdkmd_patchOfThePatches = 0xFFFFB848;
    *(ULONGLONG*)(igdkmd_patchOfThePatches + 2) = (ULONGLONG)pp->vaDestination;
    *(ULONG*)(igdkmd_patchOfThePatches + 10) = 0xFFFFE0FF;

    for (i = 0; i < pp->patchPointSize; i++)
        *((BYTE*)ptr + i) = instrPtr[i];
    __writecr0(dwOldCR0);

    if (patchStore.next_idx < 10 && patchStore.patch_count > 0)
    {
        igdkmd_patchOfThePatches = patchStore.igdkmd_patch_point_list[patchStore.next_idx];
        patchStore.next_idx += 1;
    }
    return 0;
}
