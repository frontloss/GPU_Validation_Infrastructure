#pragma once
#include "globals.h"
#include <Aux_klib.h>

////////////////////////////////////////////////////////////////////////////////////////////////////

int CommitPatchPoint(PPATCHPOINT pp);
FPACTHER_T GetPatchingRule(const char* forThisModule);
int LoadVSM(PPATCHED_MODINFO pModInfo, UNICODE_STRING pathToMod);

