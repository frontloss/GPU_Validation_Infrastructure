#include <wdm.h>
#include <stdio.h>
#include <ntdef.h>

#include "config.h"
#include "logger.h"


// Configuration path for ValDi
DECLARE_GLOBAL_CONST_UNICODE_STRING(ValDiConfigPath, L"\\Registry\\Machine\\SYSTEM\\CurrentControlSet\\Services\\ValDi\\Parameters");

WCHAR                       regpath_buffer[MAX_PATH] = { 0 };
UNICODE_STRING              regPath = { 0, MAX_PATH * 2,  regpath_buffer };

INT                                __option_trace_with_pipe_CRC_done = 1;
INT                                __option_trace_pipe_underruns = 1;
INT                                __option_trace_MMIO = 1;
INT                                __option_scrumbler_reset = 1;
INT                                __option_mask_ints = 1;
INT                                __option_locky_look_enabled = 0;
INT                                __option_trace_flip = 0;
INT                                __option_mmio_timings = 0;


////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
VOID LoadConfiguration()
{
    NTSTATUS status;
    RTL_QUERY_REGISTRY_TABLE paramTable[2];
    ULONG defaultUData;

    PLOG("Reading ValDi configuration:\n");

    //Trace by CRC done INT
    defaultUData = __option_trace_with_pipe_CRC_done;
    RtlZeroMemory(paramTable, sizeof(paramTable));
    paramTable[0].Flags = RTL_QUERY_REGISTRY_DIRECT;
    paramTable[0].Name = L"TraceByCRCDoneInt";
    paramTable[0].EntryContext = &defaultUData;
    paramTable[0].DefaultData = &defaultUData;
    paramTable[0].DefaultType = REG_DWORD;
    paramTable[0].DefaultLength = sizeof(defaultUData);
    status = RtlQueryRegistryValues(RTL_REGISTRY_ABSOLUTE, ValDiConfigPath.Buffer, paramTable, NULL, NULL);
    PLOG("Key:%S  |Status:%lX |Value: %d\n", paramTable[0].Name, status, defaultUData);
    __option_trace_with_pipe_CRC_done = defaultUData;

    //Trace MMIO writes
    defaultUData = __option_trace_MMIO;
    RtlZeroMemory(paramTable, sizeof(paramTable));
    paramTable[0].Flags = RTL_QUERY_REGISTRY_DIRECT;
    paramTable[0].Name = L"TraceMMIOAccess";
    paramTable[0].EntryContext = &defaultUData;
    paramTable[0].DefaultData = &defaultUData;
    paramTable[0].DefaultType = REG_DWORD;
    paramTable[0].DefaultLength = sizeof(defaultUData);
    status = RtlQueryRegistryValues(RTL_REGISTRY_ABSOLUTE, ValDiConfigPath.Buffer, paramTable, NULL, NULL);
    PLOG("Key:%S  |Status:%lX |Value: %d\n", paramTable[0].Name, status, defaultUData);
    __option_trace_MMIO = defaultUData;

#if 0 
    //Scrumbler reset
    defaultUData = __option_scrumbler_reset;
    RtlZeroMemory(paramTable, sizeof(paramTable));
    paramTable[0].Flags = RTL_QUERY_REGISTRY_DIRECT;
    paramTable[0].Name = L"ScrumblerReset";
    paramTable[0].EntryContext = &defaultUData;
    paramTable[0].DefaultData = &defaultUData;
    paramTable[0].DefaultType = REG_DWORD;
    paramTable[0].DefaultLength = sizeof(defaultUData);
    status = RtlQueryRegistryValues(RTL_REGISTRY_ABSOLUTE, ValDiConfigPath.Buffer, paramTable, NULL, NULL);
    PLOG("Key:%S  |Status:%lX |Value: %d\n", paramTable[0].Name, status, defaultUData);
    __option_scrumbler_reset = defaultUData;	
#endif

    //Underrun ints
    defaultUData = __option_trace_pipe_underruns;
    RtlZeroMemory(paramTable, sizeof(paramTable));
    paramTable[0].Flags = RTL_QUERY_REGISTRY_DIRECT;
    paramTable[0].Name = L"TracePipeUnderruns";
    paramTable[0].EntryContext = &defaultUData;
    paramTable[0].DefaultData = &defaultUData;
    paramTable[0].DefaultType = REG_DWORD;
    paramTable[0].DefaultLength = sizeof(defaultUData);
    status = RtlQueryRegistryValues(RTL_REGISTRY_ABSOLUTE, ValDiConfigPath.Buffer, paramTable, NULL, NULL);
    PLOG("Key:%S  |Status:%lX |Value: %d\n", paramTable[0].Name, status, defaultUData);
    __option_trace_pipe_underruns = defaultUData;

    //Mask ints
    defaultUData = __option_mask_ints;
    RtlZeroMemory(paramTable, sizeof(paramTable));
    paramTable[0].Flags = RTL_QUERY_REGISTRY_DIRECT;
    paramTable[0].Name = L"MaskDebugInts";
    paramTable[0].EntryContext = &defaultUData;
    paramTable[0].DefaultData = &defaultUData;
    paramTable[0].DefaultType = REG_DWORD;
    paramTable[0].DefaultLength = sizeof(defaultUData);
    status = RtlQueryRegistryValues(RTL_REGISTRY_ABSOLUTE, ValDiConfigPath.Buffer, paramTable, NULL, NULL);
    PLOG("Key:%S  |Status:%lX |Value: %d\n", paramTable[0].Name, status, defaultUData);
    __option_mask_ints = defaultUData;


    //MMIO timings
    defaultUData = __option_mmio_timings;
    RtlZeroMemory(paramTable, sizeof(paramTable));
    paramTable[0].Flags = RTL_QUERY_REGISTRY_DIRECT;
    paramTable[0].Name = L"TraceMMIOTimings";
    paramTable[0].EntryContext = &defaultUData;
    paramTable[0].DefaultData = &defaultUData;
    paramTable[0].DefaultType = REG_DWORD;
    paramTable[0].DefaultLength = sizeof(defaultUData);
    status = RtlQueryRegistryValues(RTL_REGISTRY_ABSOLUTE, ValDiConfigPath.Buffer, paramTable, NULL, NULL);
    PLOG("Key:%S  |Status:%lX |Value: %d\n", paramTable[0].Name, status, defaultUData);
    __option_mmio_timings = defaultUData;

    //FlipDone flags
    defaultUData = __option_trace_flip;
    RtlZeroMemory(paramTable, sizeof(paramTable));
    paramTable[0].Flags = RTL_QUERY_REGISTRY_DIRECT;
    paramTable[0].Name = L"TraceFlipEvents";
    paramTable[0].EntryContext = &defaultUData;
    paramTable[0].DefaultData = &defaultUData;
    paramTable[0].DefaultType = REG_DWORD;
    paramTable[0].DefaultLength = sizeof(defaultUData);
    status = RtlQueryRegistryValues(RTL_REGISTRY_ABSOLUTE, ValDiConfigPath.Buffer, paramTable, NULL, NULL);
    PLOG("Key:%S  |Status:%lX |Value: %d\n", paramTable[0].Name, status, defaultUData);
    __option_trace_flip = defaultUData;

#if 0
    //LockyLook flags
    defaultUData = __option_locky_look_enabled;
    RtlZeroMemory(paramTable, sizeof(paramTable));
    paramTable[0].Flags = RTL_QUERY_REGISTRY_DIRECT;
    paramTable[0].Name = L"LockyLookEnabled";
    paramTable[0].EntryContext = &defaultUData;
    paramTable[0].DefaultData = &defaultUData;
    paramTable[0].DefaultType = REG_DWORD;
    paramTable[0].DefaultLength = sizeof(defaultUData);
    status = RtlQueryRegistryValues(RTL_REGISTRY_ABSOLUTE, ValDiConfigPath.Buffer, paramTable, NULL, NULL);
    PLOG("Key:%S  |Status:%lX |Value: %d\n", paramTable[0].Name, status, defaultUData);
    __option_locky_look_enabled = defaultUData;

    PUNICODE_STRING pun = &alt_uniDumpFilePath;

    //Trace file path
    UNICODE_STRING defaultSValue;
    RtlInitUnicodeString(&defaultSValue, NULL);
    RtlZeroMemory(paramTable, sizeof(paramTable));
    paramTable[0].Flags = RTL_QUERY_REGISTRY_DIRECT;
    paramTable[0].Name = L"TraceFilePath";
    paramTable[0].EntryContext = &defaultSValue;
    paramTable[0].DefaultData = &defaultSValue;
    paramTable[0].DefaultType = REG_SZ;
    paramTable[0].DefaultLength = defaultSValue.Length;
    status = RtlQueryRegistryValues(RTL_REGISTRY_ABSOLUTE, ValDiConfigPath.Buffer, paramTable, NULL, NULL);
    PLOG("Key:%S  |Status:%lX |Value: %wZ\n", paramTable[0].Name, status, defaultSValue);
    RtlCopyUnicodeString(pun, &defaultSValue);
#endif
}

