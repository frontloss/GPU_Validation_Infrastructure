#pragma once
#include "../globals.h"
#include "../Driver.h"



INT GfxValStubBridgeInit(PTR_T base);
NTSTATUS  ServiceGfxValStub(PIRP Irp);