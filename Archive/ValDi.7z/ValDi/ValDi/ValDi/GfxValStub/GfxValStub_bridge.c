#include "GfxValStub_bridge.h"
#include "../Helpers.h"
#include "../Hooks.h"
#include "../logger.h"

/*
NTSTATUS(*igdkmd_GfxValStub_FrameWork_EnableFramewrok)(PVOID pHwDev, PVOID pDisplayFeature) = NULL;
NTSTATUS(*igdkmd_GfxValStub_FrameWork_DisableFramewrok)(PVOID pHwDev, PVOID pDisplayFeature) = NULL;

NTSTATUS(*igdkmd_GfxValStub_FrameWork_EnableFeature)(PVOID pHwDev, PVOID pDisplayFeature) = NULL;
NTSTATUS(*igdkmd_GfxValStub_FrameWork_DisableFeature)(PVOID pHwDev, PVOID pDisplayFeature) = NULL;
*/

NTSTATUS(*igdkmd_GfxValStub_DisplayFeatureHandler)(PVOID pHwDev, PVOID pDisplayFeature) = NULL;

///////////////////////////////////////////////////////////////////////////////////////////////////
NTSTATUS __GfxValStub_DisplayFeatureHandler(PVOID pDisplayFeature)
{
    return igdkmd_GfxValStub_DisplayFeatureHandler(igdkmd_hwContext, pDisplayFeature);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
INT GfxValStubBridgeInit(PTR_T base)
{
    /*
    PSYMBOLINFO PSI_GfxValStub_FrameWork_EnableFramewrok = GetModSymbol(igdkmd_patcher_modInfoPtr, "GfxValStub_FrameWork_EnableFramewrok");
    if (!PSI_GfxValStub_FrameWork_EnableFramewrok) { ELOG("[GfxValStub_FrameWork_EnableFramewrok] symbol info not complete.\n"); return -1; }
    F_ASSIGN(igdkmd_GfxValStub_FrameWork_EnableFramewrok = base + PSI_GfxValStub_FrameWork_EnableFramewrok->rva;)

    PSYMBOLINFO PSI_GfxValStub_FrameWork_DisableFramewrok = GetModSymbol(igdkmd_patcher_modInfoPtr, "GfxValStub_FrameWork_DisableFramewrok");
    if (!PSI_GfxValStub_FrameWork_DisableFramewrok) { ELOG("[GfxValStub_FrameWork_DisableFramewrok] symbol info not complete.\n"); return -1; }
    F_ASSIGN(igdkmd_GfxValStub_FrameWork_DisableFramewrok = base + PSI_GfxValStub_FrameWork_DisableFramewrok->rva;)


    PSYMBOLINFO PSI_GfxValStub_FrameWork_EnableFeature = GetModSymbol(igdkmd_patcher_modInfoPtr, "GfxValStub_FrameWork_EnableFeature");
    if (!PSI_GfxValStub_FrameWork_EnableFeature) { ELOG("[GfxValStub_FrameWork_EnableFeature] symbol info not complete.\n"); return -1; }
    F_ASSIGN(igdkmd_GfxValStub_FrameWork_EnableFeature = base + PSI_GfxValStub_FrameWork_EnableFeature->rva;)

    PSYMBOLINFO PSI_GfxValStub_FrameWork_DisableFeature = GetModSymbol(igdkmd_patcher_modInfoPtr, "GfxValStub_FrameWork_DisableFeature");
    if (!PSI_GfxValStub_FrameWork_DisableFeature) { ELOG("[GfxValStub_FrameWork_DisableFeature] symbol info not complete.\n"); return -1; }
    F_ASSIGN(igdkmd_GfxValStub_FrameWork_DisableFeature = base + PSI_GfxValStub_FrameWork_DisableFeature->rva;)
    */

    PSYMBOLINFO PSI_GfxValStub_DisplayFeatureHandler = GetModSymbol(igdkmd_patcher_modInfoPtr, "GfxValStub_DisplayFeatureHandler");
    if (!PSI_GfxValStub_DisplayFeatureHandler) { ELOG("[GfxValStub_DisplayFeatureHandler] symbol info not complete.\n"); return -1; }
    F_ASSIGN(igdkmd_GfxValStub_DisplayFeatureHandler = base + PSI_GfxValStub_DisplayFeatureHandler->rva;);

    return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
NTSTATUS ServiceGfxValStub(PIRP Irp)
{
    PVOID    pOut = (PVOID)MmGetSystemAddressForMdlSafe(Irp->MdlAddress, NormalPagePriority);
//	PVOID    pIn = (PVOID)Irp->AssociatedIrp.SystemBuffer;

//	PIO_STACK_LOCATION ioStack = IoGetCurrentIrpStackLocation(Irp);

    if (igdkmd_hwContext)
    {
        NTSTATUS res = __GfxValStub_DisplayFeatureHandler(pOut);
        //RtlCopyMemory(pOut, pIn, ioStack->Parameters.DeviceIoControl.InputBufferLength);
        return res;
    }

    return STATUS_UNSUCCESSFUL;
}
