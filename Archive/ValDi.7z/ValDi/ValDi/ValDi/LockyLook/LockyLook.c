#include "LokcyLook.h"

#include "../kmem.h"
#include "../Helpers.h"
#include <ntddk.h>
#include <wdf.h>
#include <ntimage.h>
#include "logger.h"

////////////////////////////////////////////////////////////////////////////////////////////////////
#define PISS_IT_WRITE_IT(__code__) \
{ \
    PTR_T dwOldCR0 = __readcr0(); \
	__writecr0(dwOldCR0&~(1 << 16)); \
	__code__ \
    __writecr0(dwOldCR0); \
}

 ////////////////////////////////////////////////////////////////////////////////////////////////////
IMAGE_IMPORT_DESCRIPTOR* getImportDesc(PVOID h_Mod, const char* ps_objName)
{
	IMAGE_DOS_HEADER*         p_DOSHeader = (IMAGE_DOS_HEADER*)h_Mod;

	if (0x5A4D != p_DOSHeader->e_magic)
	{
		return NULL;
	}

	IMAGE_OPTIONAL_HEADER*    p_optHeader = (IMAGE_OPTIONAL_HEADER*)((BYTE*)h_Mod + p_DOSHeader->e_lfanew + 24);

#ifdef _WIN64
	if (p_optHeader->Magic != 0x20B)
#else
	if (p_optHeader->Magic != 0x10B)
#endif
	{
		return NULL;
	}

	IMAGE_IMPORT_DESCRIPTOR*  p_impDesc = (IMAGE_IMPORT_DESCRIPTOR*)((BYTE*)h_Mod + p_optHeader->DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress);

	if (p_optHeader->DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].Size == 0 ||
		p_optHeader->DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress == 0)
		return NULL;

	char* p_impAddr = 0;
	while (p_impDesc->FirstThunk)
	{
		p_impAddr = (char*)((BYTE*)h_Mod + p_impDesc->Name);

		if (p_impAddr)
		{
			if (_stricmp(ps_objName, p_impAddr))
			{
				p_impDesc++;
				continue;
			}
			else
			{
				return p_impDesc;
			}
		}

	}
	return NULL;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
IMAGE_THUNK_DATA* getOriginalFirstThunk(PVOID h_Mod, IMAGE_IMPORT_DESCRIPTOR* p_impDesc)
{
	return (IMAGE_THUNK_DATA*)((PTR_T)h_Mod + p_impDesc->OriginalFirstThunk);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
IMAGE_THUNK_DATA* getFirstThunk(PVOID h_Mod, IMAGE_IMPORT_DESCRIPTOR* p_impDesc)
{
	return (IMAGE_THUNK_DATA*)((PTR_T)h_Mod + p_impDesc->FirstThunk);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
PVOID getFunctionAddr(PVOID h_Mod, IMAGE_THUNK_DATA* p_orgFirstThunk, IMAGE_THUNK_DATA* p_firstThunk, char* ps_functionName)
{
	char* ps_stmp;

	while (p_orgFirstThunk->u1.Function)
	{
		ps_stmp = (char*)((PTR_T)h_Mod + (PTR_T)p_orgFirstThunk->u1.AddressOfData + 2);
		if (_stricmp(ps_functionName, ps_stmp) == 0)
		{
			return &p_firstThunk->u1.Function;
		}
		p_orgFirstThunk++;
		p_firstThunk++;
	}

	return NULL;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
PTR_T swapAddresses(PTR_T* dwp_orgAddr, PTR_T dw_newAddr)
{
	PTR_T orgVal;

	orgVal = *dwp_orgAddr;
	
	PISS_IT_WRITE_IT(*dwp_orgAddr = dw_newAddr;);
	
	return orgVal;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
PVOID hookIAT(PVOID h_Mod, const char* ps_nativeModule, char* ps_functionName, PVOID dw_NativeAddr)
{

	VLOG("      >  Hooking %s ...\n", ps_functionName);

	IMAGE_IMPORT_DESCRIPTOR* p_imgImpDesc = getImportDesc(h_Mod, ps_nativeModule);

	if (p_imgImpDesc == NULL)
	{
		return 0;
	}

	IMAGE_THUNK_DATA* p_orgFirstThunk = getOriginalFirstThunk(h_Mod, p_imgImpDesc);
	IMAGE_THUNK_DATA* p_firstThunk = getFirstThunk(h_Mod, p_imgImpDesc);
	PVOID            pdw_orgAddr = getFunctionAddr(h_Mod, p_orgFirstThunk, p_firstThunk, ps_functionName);

	if (pdw_orgAddr == NULL)
	{
		VLOG("  NOT FOUND \n");
		return 0;
	}

	VLOG("      FNAME: %s    OFFSET: %p  \n", ps_functionName, (PVOID)((PTR_T)pdw_orgAddr - (PTR_T)h_Mod));
	return (PVOID)swapAddresses((PTR_T*)pdw_orgAddr, (PTR_T)dw_NativeAddr);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
//HOOKS
///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_KeInitializeSpinLock(_Out_ PKSPIN_LOCK SpinLock)
{
	PTR_T ret = (PTR_T)_ReturnAddress();
	KeInitializeSpinLock(SpinLock);

	PVOID addrList[] = {&ret, &SpinLock,};
	ULONG sizesList[] = {sizeof(PTR_T), sizeof(KSPIN_LOCK)};
	addToLog(_F("KeInitializeSpinLock "), addrList, sizesList, 2);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_KeAcquireInStackQueuedSpinLock(PKSPIN_LOCK SpinLock, PKLOCK_QUEUE_HANDLE LockHandle)
{
	PTR_T ret = (PTR_T)_ReturnAddress();

	ULONG64 delta = GetTimeStamp();
	KeAcquireInStackQueuedSpinLock(SpinLock, LockHandle);
	delta = GetTimeStamp() - delta;

	PVOID addrList[] = { &ret, &SpinLock, &delta};
	ULONG sizesList[] = { sizeof(PTR_T), sizeof(KSPIN_LOCK), sizeof(delta)};
	addToLog(_F("KeAcquireInStackQueuedSpinLock "), addrList, sizesList, 3);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_KeAcquireInStackQueuedSpinLockAtDpcLevel(PKSPIN_LOCK SpinLock, PKLOCK_QUEUE_HANDLE LockHandle)
{
	PTR_T ret = (PTR_T)_ReturnAddress();

	ULONG64 delta = GetTimeStamp();
	KeAcquireInStackQueuedSpinLockAtDpcLevel(SpinLock, LockHandle);
	delta = GetTimeStamp() - delta;

	PVOID addrList[] = { &ret, &LockHandle->LockQueue.Lock, &delta};
	ULONG sizesList[] = { sizeof(PTR_T), sizeof(KSPIN_LOCK), sizeof(delta)};
	addToLog(_F("KeAcquireInStackQueuedSpinLockAtDpcLevel "), addrList, sizesList, 3);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_KeAcquireSpinLock(PKSPIN_LOCK SpinLock, PKIRQL OldIrql)
{
	PTR_T ret = (PTR_T)_ReturnAddress();
	
	ULONG64 delta = GetTimeStamp();
	KeAcquireSpinLock(SpinLock, OldIrql);
	delta = GetTimeStamp() - delta;

	PVOID addrList[] = { &ret, &SpinLock, &delta};
	ULONG sizesList[] = { sizeof(PTR_T), sizeof(KSPIN_LOCK), sizeof(delta)};
	addToLog(_F("KeAcquireSpinLock "), addrList, sizesList, 3);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_KeAcquireSpinLockAtDpcLevel(PKSPIN_LOCK SpinLock)
{
	PTR_T ret = (PTR_T)_ReturnAddress();

	ULONG64 delta = GetTimeStamp();
	KeAcquireSpinLockAtDpcLevel(SpinLock);
	delta = GetTimeStamp() - delta;

	PVOID addrList[] = { &ret, &SpinLock, &delta};
	ULONG sizesList[] = { sizeof(PTR_T), sizeof(KSPIN_LOCK), sizeof(delta)};
	addToLog(_F("KeAcquireSpinLockAtDpcLevel "), addrList, sizesList, 3);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_KeReleaseInStackQueuedSpinLock(PKLOCK_QUEUE_HANDLE LockHandle)
{
	PTR_T ret = (PTR_T)_ReturnAddress();
	
	KeReleaseInStackQueuedSpinLock(LockHandle);

	PVOID addrList[] = { &ret, &LockHandle->LockQueue.Lock};
	ULONG sizesList[] = { sizeof(PTR_T), sizeof(KSPIN_LOCK)};
	addToLog(_F("KeReleaseInStackQueuedSpinLock "), addrList, sizesList, 2);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_KeReleaseInStackQueuedSpinLockFromDpcLevel(PKLOCK_QUEUE_HANDLE LockHandle)
{
	PTR_T ret = (PTR_T)_ReturnAddress();

	KeReleaseInStackQueuedSpinLockFromDpcLevel(LockHandle);

	PVOID addrList[] = { &ret, &LockHandle->LockQueue.Lock};
	ULONG sizesList[] = { sizeof(PTR_T), sizeof(KSPIN_LOCK)};
	addToLog(_F("KeReleaseInStackQueuedSpinLockFromDpcLevel "), addrList, sizesList, 2);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_KeReleaseSpinLock(PKSPIN_LOCK SpinLock, KIRQL NewIrql)
{
	PTR_T ret = (PTR_T)_ReturnAddress();

	KeReleaseSpinLock(SpinLock, NewIrql);

	PVOID addrList[] = { &ret, &SpinLock};
	ULONG sizesList[] = { sizeof(PTR_T), sizeof(KSPIN_LOCK)};
	addToLog(_F("KeReleaseSpinLock "), addrList, sizesList, 2);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_KeReleaseSpinLockFromDpcLevel(PKSPIN_LOCK SpinLock)
{
	PTR_T ret = (PTR_T)_ReturnAddress();

	KeReleaseSpinLockFromDpcLevel(SpinLock);

	PVOID addrList[] = { &ret, &SpinLock};
	ULONG sizesList[] = { sizeof(PTR_T), sizeof(KSPIN_LOCK)};
	addToLog(_F("KeReleaseSpinLockFromDpcLevel "), addrList, sizesList, 2);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_ExInitializeFastMutex(PFAST_MUTEX FastMutex)
{
	PTR_T ret = (PTR_T)_ReturnAddress();

	ExInitializeFastMutex(FastMutex);

	PVOID addrList[] = { &ret, &FastMutex->Event};
	ULONG sizesList[] = { sizeof(PTR_T), sizeof(PKEVENT)};
	addToLog(_F("ExInitializeFastMutex "), addrList, sizesList, 2);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_ExAcquireFastMutex(PFAST_MUTEX FastMutex)
{
	PTR_T ret = (PTR_T)_ReturnAddress();

	ULONG64 delta = GetTimeStamp();
	ExAcquireFastMutex(FastMutex);
	delta = GetTimeStamp() - delta;

	PVOID addrList[] = { &ret, &FastMutex->Event, &delta};
	ULONG sizesList[] = {sizeof(PTR_T), sizeof(PKEVENT), sizeof(delta)};
	addToLog(_F("ExAcquireFastMutex "), addrList, sizesList, 3);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_ExAcquireFastMutexUnsafe(PFAST_MUTEX FastMutex)
{
	PTR_T ret = (PTR_T)_ReturnAddress();

	ULONG64 delta = GetTimeStamp();
	ExAcquireFastMutexUnsafe(FastMutex);
	delta = GetTimeStamp() - delta;

	PVOID addrList[] = { &ret, &FastMutex->Event, &delta};
	ULONG sizesList[] = { sizeof(PTR_T), sizeof(PKEVENT), sizeof(delta)};
	addToLog(_F("ExAcquireFastMutexUnsafe "), addrList, sizesList, 3);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_ExReleaseFastMutex(PFAST_MUTEX FastMutex)
{
	PTR_T ret = (PTR_T)_ReturnAddress();

	ExReleaseFastMutex(FastMutex);

	PVOID addrList[] = { &ret, &FastMutex->Event};
	ULONG sizesList[] = { sizeof(PTR_T), sizeof(PKEVENT)};
	addToLog(_F("ExReleaseFastMute "), addrList, sizesList, 2);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_ExReleaseFastMutexUnsafe(PFAST_MUTEX FastMutex)
{
	PTR_T ret = (PTR_T)_ReturnAddress();

	ExReleaseFastMutexUnsafe(FastMutex);

	PVOID addrList[] = { &ret, &FastMutex->Event};
	ULONG sizesList[] = { sizeof(PTR_T), sizeof(PKEVENT)};
	addToLog(_F("ExReleaseFastMutexUnsafe "), addrList, sizesList, 2);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
BOOLEAN __hooked_ExTryToAcquireFastMutex(PFAST_MUTEX FastMutex)
{
	UCHAR retv = ExTryToAcquireFastMutex(FastMutex);
	PTR_T ret = (PTR_T)_ReturnAddress();

	PVOID addrList[] = { &ret, &FastMutex->Event, &retv};
	ULONG sizesList[] = { sizeof(PTR_T), sizeof(PKEVENT), sizeof(retv)};
	addToLog(_F("ExTryToAcquireFastMutex "), addrList, sizesList, 3);

	return retv;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_KeInitializeMutex(PRKMUTEX Mutex, ULONG Level)
{
	PTR_T ret = (PTR_T)_ReturnAddress();

	KeInitializeMutex(Mutex, Level);

	PVOID addrList[] = { &ret, &Mutex->Header};
	ULONG sizesList[] = { sizeof(PTR_T), sizeof(PKEVENT)};
	addToLog(_F("KeInitializeMutex "), addrList, sizesList, 2);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
LONG __hooked_KeReleaseMutex(PRKMUTEX Mutex, BOOLEAN  Wait)
{
	PTR_T ret = (PTR_T)_ReturnAddress();

	LONG retv = KeReleaseMutex(Mutex, Wait);

	PVOID headerArrd = &Mutex->Header;

	PVOID addrList[] = { &ret, &headerArrd};
	ULONG sizesList[] = { sizeof(PTR_T), sizeof(PKEVENT)};
	addToLog(_F("KeReleaseMutex "), addrList, sizesList, 2);

	return retv;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_KeInitializeGuardedMutex(PKGUARDED_MUTEX Mutex)
{
	PTR_T ret = (PTR_T)_ReturnAddress();

	KeInitializeGuardedMutex(Mutex);

	PVOID addrList[] = { &ret, &((PKMUTEX)(Mutex))->Header};
	ULONG sizesList[] = { sizeof(PTR_T), sizeof(PKEVENT)};
	addToLog(_F("KeInitializeGuardedMutex "), addrList, sizesList, 2);

}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_KeAcquireGuardedMutex(PKGUARDED_MUTEX Mutex)
{
	PTR_T ret = (PTR_T)_ReturnAddress();

	ULONG64 delta = GetTimeStamp();
	KeAcquireGuardedMutex(Mutex);
	delta = GetTimeStamp() - delta;

	PVOID addrList[] = { &ret, &((PKMUTEX)(Mutex))->Header, &delta};
	ULONG sizesList[] = { sizeof(PTR_T), sizeof(PKEVENT), sizeof(delta)};
	addToLog(_F("KeAcquireGuardedMutex "), addrList, sizesList, 3);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_KeReleaseGuardedMutex(PKGUARDED_MUTEX Mutex)
{
	PTR_T ret = (PTR_T)_ReturnAddress();

	KeReleaseGuardedMutex(Mutex);

	PVOID addrList[] = { &ret, &((PKMUTEX)(Mutex))->Header};
	ULONG sizesList[] = { sizeof(PTR_T), sizeof(PKEVENT)};
	addToLog(_F("KeReleaseGuardedMutex "), addrList, sizesList, 2);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_KeInitializeSemaphore(PRKSEMAPHORE Semaphore, LONG Count, LONG Limit)
{
	PTR_T ret = (PTR_T)_ReturnAddress();

	KeInitializeSemaphore(Semaphore, Count, Limit);

	PVOID addrList[] = { &ret, &((PRKSEMAPHORE)(Semaphore))->Header};
	ULONG sizesList[] = { sizeof(PTR_T), sizeof(PKEVENT)};
	addToLog(_F("KeInitializeSemaphore "), addrList, sizesList, 2);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
LONG __hooked_KeReleaseSemaphore(PRKSEMAPHORE Semaphore, KPRIORITY Increment, LONG Adjustment, BOOLEAN Wait)
{
	PTR_T ret = (PTR_T)_ReturnAddress();

	LONG retv = KeReleaseSemaphore(Semaphore, Increment, Adjustment, Wait);

	PVOID addrList[] = { &ret, &((PRKSEMAPHORE)(Semaphore))->Header, &retv};
	ULONG sizesList[] = { sizeof(PTR_T), sizeof(PKEVENT), sizeof(retv)};
	addToLog(_F("KeReleaseSemaphore "), addrList, sizesList, 3);

	return retv;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_KeInitializeEvent(PRKEVENT Event, EVENT_TYPE Type, BOOLEAN State)
{
	PTR_T ret = (PTR_T)_ReturnAddress();

	KeInitializeEvent(Event, Type, State);

	PVOID addrList[] = { &ret, Event,};
	ULONG sizesList[] = { sizeof(PTR_T), sizeof(PKEVENT)};
	addToLog(_F("KeInitializeEvent "), addrList, sizesList, 2);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_KeClearEvent(PRKEVENT Event)
{
	PTR_T ret = (PTR_T)_ReturnAddress();

	KeClearEvent(Event);

	PVOID addrList[] = { &ret, &Event,};
	ULONG sizesList[] = {sizeof(PTR_T), sizeof(PKEVENT)};
	addToLog(_F("KeClearEvent "), addrList, sizesList, 2);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
LONG __hooked_KeResetEvent(PRKEVENT Event)
{
	PTR_T ret = (PTR_T)_ReturnAddress();

	LONG retv = KeResetEvent(Event);

	PVOID addrList[] = { &ret, &Event, &retv};
	ULONG sizesList[] = { sizeof(PTR_T), sizeof(PKEVENT), sizeof(retv)};
	addToLog(_F("KeResetEvent "), addrList, sizesList, 3);

	return retv;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
LONG __hooked_KeSetEvent(PRKEVENT  Event, KPRIORITY Increment, BOOLEAN   Wait)
{
	PTR_T ret = (PTR_T)_ReturnAddress();

	LONG retv = KeSetEvent(Event, Increment, Wait);

	PVOID addrList[] = { &ret, &Event, &retv};
	ULONG sizesList[] = { sizeof(PTR_T), sizeof(PKEVENT), sizeof(retv)};
	addToLog(_F("KeSetEvent "), addrList, sizesList, 3);

	return retv;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
NTSTATUS  __hooked_KeWaitForMultipleObjects(ULONG Count, PVOID Object[], WAIT_TYPE WaitType, KWAIT_REASON WaitReason, KPROCESSOR_MODE WaitMode, BOOLEAN Alertable, PLARGE_INTEGER  Timeout, PKWAIT_BLOCK    WaitBlockArray)
{
	PTR_T ret = (PTR_T)_ReturnAddress();

	ULONG64 delta = GetTimeStamp();
	NTSTATUS retv = KeWaitForMultipleObjects(Count, Object, WaitType, WaitReason, WaitMode, Alertable, Timeout, WaitBlockArray);
	delta = GetTimeStamp() - delta;

	PVOID* addrList  = kmalloc((4 + Count) * sizeof(PVOID));
	ULONG* sizesList = kmalloc((4 + Count) * sizeof(ULONG));
	
	addrList[0] = &ret;
	sizesList[0] = sizeof(ret);

	addrList[1] = &Count;
	sizesList[1] = sizeof(ULONG);

	int i;
	for (i = 0; i < (int)Count; i++)
	{
		addrList[i] = (PDISPATCHER_HEADER)(&Object[i]);
		sizesList[i] = sizeof(PVOID);
	};

	addrList[i] = &delta;
	sizesList[i++] = sizeof(delta);

	addrList[i] = &retv;
	sizesList[i++] = sizeof(retv);

	addToLog(_F("KeWaitForMultipleObjects "), addrList, sizesList, i);

	kfree(addrList);
	kfree(sizesList);

	return retv;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
NTSTATUS __hooked_KeWaitForSingleObject(PVOID Object, KWAIT_REASON WaitReason, KPROCESSOR_MODE WaitMode, BOOLEAN Alertable, PLARGE_INTEGER  Timeout)
{
	PTR_T ret = (PTR_T)_ReturnAddress();

	ULONG64 delta = GetTimeStamp();
	NTSTATUS retv = KeWaitForSingleObject(Object, WaitReason, WaitMode, Alertable, Timeout);
	delta = GetTimeStamp() - delta;

	PVOID addrList[] = { &ret, &Object, &delta, &retv};
	ULONG sizesList[] = { sizeof(PTR_T), sizeof(PDISPATCHER_HEADER), sizeof(delta), sizeof(retv)};
	addToLog(_F("KeWaitForSingleObject "), addrList, sizesList, 4);

	return retv;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
BOOLEAN __hooked_KeSynchronizeExecution(PKINTERRUPT Interrupt, PKSYNCHRONIZE_ROUTINE SynchronizeRoutine, PVOID SynchronizeContext)
{
	PTR_T ret = (PTR_T)_ReturnAddress();

	ULONG64 delta = GetTimeStamp();
	BOOLEAN retv = KeSynchronizeExecution(Interrupt, SynchronizeRoutine, SynchronizeContext);
	delta = GetTimeStamp() - delta;

	PVOID addrList[] = { &ret, (PVOID)(PTR_T)SynchronizeRoutine, &delta, &retv};
	ULONG sizesList[] = { sizeof(PTR_T), sizeof(PDISPATCHER_HEADER), sizeof(delta), sizeof(retv)};
	addToLog(_F("KeSynchronizeExecution "), addrList, sizesList, 4);

	return retv;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_KeStallExecutionProcessor(ULONG MicroSeconds)
{
	PTR_T ret = (PTR_T)_ReturnAddress();

	ULONG64 delta = GetTimeStamp();
	KeStallExecutionProcessor(MicroSeconds);
	delta = GetTimeStamp() - delta;

	PVOID addrList[] = { &ret, &delta};
	ULONG sizesList[] = { sizeof(PTR_T), sizeof(delta)};
	addToLog(_F("KeStallExecutionProcessor "), addrList, sizesList, 2);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
KIRQL __hooked_KeAcquireSpinLockRaiseToDpc(PKSPIN_LOCK SpinLock)
{
	PTR_T ret = (PTR_T)_ReturnAddress();

	ULONG64 delta = GetTimeStamp();
	KIRQL retv =  KeAcquireSpinLockRaiseToDpc(SpinLock);
	delta = GetTimeStamp() - delta;

	PVOID addrList[] = {&ret, &SpinLock, &delta, &retv};
	ULONG sizesList[] = { sizeof(PTR_T), sizeof(KSPIN_LOCK), sizeof(delta), sizeof(retv)};
	addToLog(_F("KeAcquireSpinLockRaiseToDpc "), addrList, sizesList, 4);

	return retv;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
//INIT
///////////////////////////////////////////////////////////////////////////////////////////////////
const char NTOSKRNL_M[] = "NTOSKRNL.EXE";
const char HAL_M[]      = "HAL.DLL";

INT LockyLook_Init(PVOID ImageBase)
{
	PTR_T ret = 1;

	ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "KeAcquireInStackQueuedSpinLock",              (PVOID)(PTR_T)__hooked_KeAcquireInStackQueuedSpinLock);
	ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "KeAcquireInStackQueuedSpinLockAtDpcLevel",    (PVOID)(PTR_T)__hooked_KeAcquireInStackQueuedSpinLockAtDpcLevel);
	ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "KeAcquireSpinLockRaiseToDpc",                 (PVOID)(PTR_T)__hooked_KeAcquireSpinLockRaiseToDpc);
	//ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "KeAcquireSpinLock",                           (PVOID)(PTR_T)__hooked_KeAcquireSpinLock);
	//ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "KeAcquireSpinLockAtDpcLevel",                 (PVOID)(PTR_T)__hooked_KeAcquireSpinLockAtDpcLevel);
	
	ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "KeReleaseInStackQueuedSpinLock",              (PVOID)(PTR_T)__hooked_KeReleaseInStackQueuedSpinLock);
	ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "KeReleaseInStackQueuedSpinLockFromDpcLevel",  (PVOID)(PTR_T)__hooked_KeReleaseInStackQueuedSpinLockFromDpcLevel);
	ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "KeReleaseSpinLock",                           (PVOID)(PTR_T)__hooked_KeReleaseSpinLock);
	ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "KeReleaseSpinLockFromDpcLevel",               (PVOID)(PTR_T)__hooked_KeReleaseSpinLockFromDpcLevel);

	
	//ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "ExInitializeFastMutex",                       (PVOID)(PTR_T)__hooked_ExInitializeFastMutex);
	ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "ExAcquireFastMutex",                          (PVOID)(PTR_T)__hooked_ExAcquireFastMutex);
	//ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "ExAcquireFastMutexUnsafe",                    (PVOID)(PTR_T)__hooked_ExAcquireFastMutexUnsafe);
	ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "ExReleaseFastMutex",                          (PVOID)(PTR_T)__hooked_ExReleaseFastMutex);
	//ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "ExReleaseFastMutexUnsafe",                    (PVOID)(PTR_T)__hooked_ExReleaseFastMutexUnsafe);
	//ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "ExTryToAcquireFastMutex",                     (PVOID)(PTR_T)__hooked_ExTryToAcquireFastMutex);

	ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "KeInitializeMutex",                           (PVOID)(PTR_T)__hooked_KeInitializeMutex);
	ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "KeReleaseMutex",                              (PVOID)(PTR_T)__hooked_KeReleaseMutex);

	ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "KeInitializeGuardedMutex",                    (PVOID)(PTR_T)__hooked_KeInitializeGuardedMutex);
	ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "KeAcquireGuardedMutex",                       (PVOID)(PTR_T)__hooked_KeAcquireGuardedMutex);
	ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "KeReleaseGuardedMutex",                       (PVOID)(PTR_T)__hooked_KeReleaseGuardedMutex);

	ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "KeInitializeSemaphore",                       (PVOID)(PTR_T)__hooked_KeInitializeSemaphore);
	ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "KeReleaseSemaphore",                          (PVOID)(PTR_T)__hooked_KeReleaseSemaphore);

	ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "KeInitializeEvent",                           (PVOID)(PTR_T)__hooked_KeInitializeEvent);
	ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "KeClearEvent",                                (PVOID)(PTR_T)__hooked_KeClearEvent);
	ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "KeResetEvent",                                (PVOID)(PTR_T)__hooked_KeResetEvent);
	ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "KeSetEvent",                                  (PVOID)(PTR_T)__hooked_KeSetEvent);
	
	ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "KeWaitForMultipleObjects",                    (PVOID)(PTR_T)__hooked_KeWaitForMultipleObjects);
	ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "KeWaitForSingleObject",                       (PVOID)(PTR_T)__hooked_KeWaitForSingleObject);

	ret &= (PTR_T)hookIAT(ImageBase, NTOSKRNL_M, "KeSynchronizeExecution",                      (PVOID)(PTR_T)__hooked_KeSynchronizeExecution);


	ret &= (PTR_T)hookIAT(ImageBase, HAL_M,      "KeStallExecutionProcessor",                   (PVOID)(PTR_T)__hooked_KeStallExecutionProcessor);


	return (INT)(ret-1);
}