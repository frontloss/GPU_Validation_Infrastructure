#pragma once
#include "../globals.h"
#include "../Driver.h"

INT LockyLook_Init(PVOID ImageBase);

