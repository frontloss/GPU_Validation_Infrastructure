/**
********************************************************************
*
* @file DisplayErrorDef.h
* @brief List of Display error codes to be used by 3 layers of Display driver
*
*
*
*
*********************************************************************
**/

#ifndef _DISPLAY_ERROR_H_
#define _DISPLAY_ERROR_H_

#define DD_ERROR_CODE_VER 1 // bump up rev when we modify the file

/**
* \brief @c DDSTATUS error code used across all display driver modules to return
* function status
*
* The error code has below major categories
* 1. generic failure
* 2. DSL (Display OS Layer) error
* 3. DPL (Display Protocol layer) error
* 4. DHL (Display HW-Abstraction layer) error
* 5. Success codes
*/
typedef enum _DDSTATUS
{
    /////////////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////////////
    //
    //      start of generic failure codes   0x8000 0000 - 0x8000 00FF
    //
    /////////////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////////////
    DDS_UNSUCCESSFUL = 0x80000000, // -2147483648
    DDS_NO_MEMORY,
    DDS_INVALID_PARAM,
    DDS_NULL_PARAM,
    DDS_TIMEOUT,
    DDS_I2C_DEVICE_DOES_NOT_EXIST,
    DDS_I2C_DATA_READ_ERROR,
    DDS_I2C_DATA_WRITE_ERROR,
    DDS_BUFFER_TOO_SMALL,
    DDS_BUFFER_OVERFLOW,
    DDS_MONITOR_NO_MORE_DESCRIPTOR_DATA,
    DDS_SET_TIMING_MONITOR_NOT_CONNECTED,
    DDS_ERROR_UNKNOWN,
    DDS_BUSY,
    DDS_NOT_SUPPORTED,
    DDS_DATA_OVERFLOW,
    DDS_DEVICE_NOT_READY,
    DDS_MONITOR_NOT_CONNECTED,
    DDS_INTERFACE_NOT_IMPLEMENTED,
    DDS_INVALID_DATA,
    DDS_INVALID_CONTEXT,
    DDS_DATA_ERROR,
    DDS_INVALID_LEVEL,

    // add new generic failure code above this line
    __DD_STATUS_RANGE_GENERIC_FAILURE_MAX = 0x80000100, // range limit, *not* to be used in coding
                                                        /////////////////////////////////////////////////////////////////////////

                                                        /////////////////////////////////////////////////////////////////////////
                                                        /////////////////////////////////////////////////////////////////////////
                                                        //
                                                        //      start of DSL status codes        0x8000 0101 - 0x80FF FFFF
                                                        //
                                                        /////////////////////////////////////////////////////////////////////////
                                                        /////////////////////////////////////////////////////////////////////////
                                                        DDS_MODE_NO_MODE_ADDED,
                                                        DDS_MODE_INVALID_FOR_GIVEN_TARGET,

                                                        // add new DSL success code above this line
                                                        __DD_STATUS_RANGE_DSL_MAX = 0x81000000, // range limit, *not* to be used in coding
                                                                                                /////////////////////////////////////////////////////////////////////////

                                                                                                /////////////////////////////////////////////////////////////////////////
                                                                                                /////////////////////////////////////////////////////////////////////////
                                                                                                //
                                                                                                //      start of protocol status codes   0x8100 0001 - 0xFFFF FFFF
                                                                                                //
                                                                                                /////////////////////////////////////////////////////////////////////////
                                                                                                /////////////////////////////////////////////////////////////////////////

                                                                                                DDS_DPL_VBT_PARSING_ERROR,
                                                                                                DDS_DPL_DETECTION_INCOMPLETE,
                                                                                                DDS_DPL_INVALID_PORT,
                                                                                                DDS_DPL_INVALID_PIPE,
                                                                                                DDS_DPL_INVALID_PROTOCOL,
                                                                                                DDS_DPL_INVALID_CONNECTOR,
                                                                                                DDS_DPL_FAILED_HAL_PROGRAMMING,
                                                                                                DDS_DPL_FAILED_EDID_READ,
                                                                                                DDS_DPL_EDID_PARSE_ERROR,
                                                                                                //***********************************************************************
                                                                                                // DP Protocol error codes
                                                                                                //
                                                                                                DDS_DPL_DP_AUX_FAILURE,
                                                                                                // link training related
                                                                                                DDS_DPL_DP_INVALID_LINK_RATE,
                                                                                                DDS_DPL_DP_INVALID_LANE_COUNT,
                                                                                                DDS_DPL_DP_LINK_TRAINING_FAILED,
                                                                                                DDS_DPL_DP_LT_CLOCK_RECOVERY_FAILED,
                                                                                                DDS_DPL_DP_LT_FAILED_TO_GET_NEXT_LINKRATE,
                                                                                                DDS_DPL_DP_LT_MAX_CLK_REC_ITER_REACHED,
                                                                                                DDS_DPL_DP_LT_CHAN_EQ_FAILED,
                                                                                                DDS_DPL_DP_LT_MAX_EQ_ITER_REACHED,
                                                                                                DDS_DPL_DP_GET_REQUESTED_DRIVE_SETTING_FAILED,
                                                                                                DDS_DPL_DP_ADJUST_DRIVE_SETTING_FAILED,
                                                                                                DDS_DPL_DP_INSUFFICIENT_LINK_BW,
                                                                                                DDS_DPL_DP_FAILED_LINK_CONFIG_SET,
                                                                                                DDS_DPL_DP_FAILED_SET_ASSR_CFG,
                                                                                                DDS_DPL_DP_FAILED_DPCD_READ,
                                                                                                DDS_DPL_DP_FAILED_DPCD_WRITE,

                                                                                                // add new protocol success code above this line
                                                                                                __DD_STATUS_RANGE_DPL_MAX = 0, // range limit, *not* to be used in coding
                                                                                                                               /////////////////////////////////////////////////////////////////////////

                                                                                                                               /////////////////////////////////////////////////////////////////////////
                                                                                                                               /////////////////////////////////////////////////////////////////////////
                                                                                                                               //
                                                                                                                               //      start of HAL status codes        0x0000 0001 - 0x7FFF FEFF
                                                                                                                               //
                                                                                                                               /////////////////////////////////////////////////////////////////////////
                                                                                                                               /////////////////////////////////////////////////////////////////////////
                                                                                                                               DDS_DHL_INVALID_PORT,
                                                                                                                               DDS_DHL_INVALID_PIPE,
                                                                                                                               DDS_DHL_INVALID_PLANE,

                                                                                                                               DDS_DHL_AUX_BUSY,
                                                                                                                               DDS_DHL_AUX_UNKNOWN,
                                                                                                                               DDS_DHL_AUX_NOTSUPPORTED,
                                                                                                                               DDS_DHL_AUX_OPEN,
                                                                                                                               DDS_DHL_AUX_DATA_READ_ERROR,
                                                                                                                               DDS_DHL_AUX_DATA_WRITE_ERROR,
                                                                                                                               DDS_DHL_AUX_INVALID_CHANNEL,
                                                                                                                               DDS_DHL_AUX_MORE_DATA,
                                                                                                                               DDS_DHL_AUX_DEFER,
                                                                                                                               DDS_DHL_AUX_TIMEOUT,

                                                                                                                               DDS_DHL_I2C_BUSY,
                                                                                                                               DDS_DHL_I2C_UNKNOWN,
                                                                                                                               DDS_DHL_I2C_TIMEOUT,
                                                                                                                               DDS_DHL_I2C_NOTSUPPORTED,
                                                                                                                               DDS_DHL_I2C_ERROR_OPEN,
                                                                                                                               DDS_DHL_I2C_ERROR_CLOSE,
                                                                                                                               DDS_DHL_I2C_ERROR_SEGMENT_POINTER_WRITE,
                                                                                                                               DDS_DHL_I2C_INVALID_PARAM,

                                                                                                                               DDS_DHL_TRANS_INVALID_TIMINGS,
                                                                                                                               DDS_DHL_TRANS_INVALID_PARAM,
                                                                                                                               DDS_DHL_TRANS_TIMEOUT,

                                                                                                                               DDS_PG_DISTRIB_ERROR,
                                                                                                                               DDS_PG_NOT_POWERED,
                                                                                                                               DDS_PG_INVALID_PARAM,

                                                                                                                               DDS_PLL_NOT_LOCKED,
                                                                                                                               DDS_PLL_INVALID_LINK_RATE,
                                                                                                                               DDS_PLL_INVALID_PLL,

                                                                                                                               DDS_DHL_PORT_INVALID_PATTERN,
                                                                                                                               DDS_DHL_PORT_INVALID_DRIVE_SETTING,
                                                                                                                               DDS_DHL_PORT_DISABLE_TIMEOUT,

                                                                                                                               DDS_DHL_RM_NUM_PLANE_EXCEEDS_LIMIT,
                                                                                                                               DDS_DHL_RM_NUM_SCALARS_EXCEEDS_LIMIT,
                                                                                                                               DDS_DHL_RM_INVALID_PIXEL_FORMAT,
                                                                                                                               DDS_DHL_RM_INVALID_PLANE_INDEX,
                                                                                                                               DDS_DHL_RM_ASYNC_FLIP_NOT_SUPPORTED,
                                                                                                                               DDS_DHL_RM_ASYNC_FLIP_HW_RESTRICTION_NOT_MET,
                                                                                                                               DDS_DHL_RM_ALPHA_BLEND_NOT_SUPPORTED,
                                                                                                                               DDS_DHL_RM_SURF_HEIGHT_HW_RESTRICTION_NOT_MET,
                                                                                                                               DDS_DHL_RM_SURF_WIDTH_HW_RESTRICTION_NOT_MET,
                                                                                                                               DDS_DHL_RM_SURF_SIZE_HW_RESTRICTION_NOT_MET,
                                                                                                                               DDS_DHL_RM_AUX_SURF_HW_RESTRICTION_NOT_MET,
                                                                                                                               DDS_DHL_RM_VFLIP_NOT_SUPPORTED,
                                                                                                                               DDS_DHL_RM_HFLIP_NOT_SUPPORTED,
                                                                                                                               DDS_DHL_RM_ROTATION_NOT_SUPPORTED,
                                                                                                                               DDS_DHL_RM_ROTATION_HW_RESTRICTION_NOT_MET,
                                                                                                                               DDS_DHL_RM_SCALE_NOT_SUPPORTED,
                                                                                                                               DDS_DHL_RM_SCALE_HW_RESTRICTION_NOT_MET,
                                                                                                                               DDS_DHL_RM_HIGH_Q_SCALE_NOT_SUPPORTED,
                                                                                                                               DDS_DHL_RM_BILINEAR_SCALE_NOT_SUPPORTED,
                                                                                                                               DDS_DHL_RM_HORZ_STRETCH_FACTOR_EXCEEDS_LIMIT,
                                                                                                                               DDS_DHL_RM_HORZ_SHRINK_FACTOR_EXCEEDS_LIMIT,
                                                                                                                               DDS_DHL_RM_VERT_STRETCH_FACTOR_EXCEEDS_LIMIT,
                                                                                                                               DDS_DHL_RM_VERT_SHRINK_FACTOR_EXCEEDS_LIMIT,

                                                                                                                               // add new HAL success code above this line
                                                                                                                               __DD_STATUS_RANGE_DHL_MAX = 0x7FFFFF00, // range limit, *not* to be used in coding
                                                                                                                                                                       /////////////////////////////////////////////////////////////////////////

                                                                                                                                                                       /////////////////////////////////////////////////////////////////////////
                                                                                                                                                                       /////////////////////////////////////////////////////////////////////////
                                                                                                                                                                       //
                                                                                                                                                                       //      start of generic success codes   0x7FFF FF01 - 0x7FFF FFFF
                                                                                                                                                                       //
                                                                                                                                                                       /////////////////////////////////////////////////////////////////////////
                                                                                                                                                                       /////////////////////////////////////////////////////////////////////////
                                                                                                                                                                       DDS_SUCCESS,//= 0x7FFFFF01,
                                                                                                                                                                       DDS_MORE_ENTRIES,
                                                                                                                                                                       DDS_NO_ACTION_REQUIRED,
                                                                                                                                                                       DDS_ENTRY_EXISTS_NO_UPDATE,
                                                                                                                                                                       DDS_ENTRY_EXISTS_REPLACED,
                                                                                                                                                                       DDS_ENTRY_NEW_ADDED,
                                                                                                                                                                       DDS_MODE_INRERLACE_MODE_REMOVED_BY_OEM,
                                                                                                                                                                       DDS_MODE_NO_PIXEL_FORMAT_SUPPORTED,
                                                                                                                                                                       DDS_CE_EXTN_BLOCK_NOT_FOUND,
                                                                                                                                                                       DDS_CE_EXTN_DTD_NOT_FOUND,
                                                                                                                                                                       DDS_CE_EXTN_S3D_MODES_NOT_PRESENT,

                                                                                                                                                                       // add new generic success code above this line
                                                                                                                                                                       __DD_STATUS_RANGE_GENERIC_SUCCESS_MAX = 0x7FFFFFFF, // range limit, *not* to be used in coding
                                                                                                                                                                                                                           /////////////////////////////////////////////////////////////////////////
} DDSTATUS;

/////////////////////////////////////////////////////////////////////////
//
// error code handling macros
//

/// returns true if @c Err is a success code
#define IS_DDSTATUS_SUCCESS(Err) (((DDSTATUS)(Err))>= DDS_SUCCESS)

/** returns true if @c Err is not a success code */
#define IS_DDSTATUS_ERROR(Err) (((DDSTATUS)(Err)) < DDS_SUCCESS)


/// break if @c status is a success code
#define BREAK_ON_SUCCESS(status) \
        if (IS_DDSTATUS_SUCCESS(status))  break

/// break if @c status is not a success code
#define BREAK_ON_ERROR(status) \
        if (IS_DDSTATUS_ERROR(status))  break

/// break if @c ptr is NULL
#define BREAK_ON_NULL(ptr) \
    if (NULL == ptr)  break

/// break if @c Cond is false
#define BREAK_IF_FALSE(Cond) \
     if (!(Cond)) break

/// break with Status if @c Cond is false
#define BREAK_W_STATUS_IF_FALSE(Cond,eStatus) \
     if (!(Cond)) { Status = eStatus; break; }
/////////////////////////////////////////////////////////////////////////

#endif // _DISPLAY_ERROR_H_
