#pragma once
#include "globals.h"
#include "Driver.h"

#define ADD_ASSIGN(_C_)\
__pragma(warning(push)) __pragma(warning(disable:4054))\
_C_ \
__pragma(warning(pop))

#define F_ASSIGN(_C_)\
__pragma(warning(push)) __pragma(warning(disable:4152)) __pragma(warning(disable:4047))\
_C_ \
__pragma(warning(pop))


VOID             GetBaseFileName(IN PUNICODE_STRING pIn, OUT PUNICODE_STRING pOut);
BOOLEAN          GetFileGUID(PUNICODE_STRING p_modPath, BYTE* pguid, ULONG* age);
BOOLEAN          GetImageGUID(PVOID ImageBase, ULONG ImageSize, BYTE* pguid, ULONG* age, BOOLEAN fill_gap);
void             stripToBaseName(char* istr);
PSYMBOLINFO      GetModSymbol(PPATCHED_MODINFO modInfo, const PCHAR symName);
char*            u2a(PCUNICODE_STRING u, char* a, int alen);
VOID             GenDumpName(PUNICODE_STRING uString);
ULONGLONG        GetTimeStamp();
LONG             cmpfunc(const void * a, const void * b);