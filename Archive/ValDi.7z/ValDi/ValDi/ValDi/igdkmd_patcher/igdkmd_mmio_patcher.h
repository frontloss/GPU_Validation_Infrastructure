#pragma once
#include "../globals.h"
#include <wdm.h>
#include <stdio.h>
#include <ntdef.h>


/////////////// STRUCTURE DEFNITION ////////////////////////

typedef struct _IGDKMD_MMIO_FUNC_INTERFACE {
    //COMMON Function Pointers for MMIO
    BOOL armed;
    NTSTATUS(*OSPCIWriteCfgReg)(PVOID devExt, ULONG ulBusNum, ULONG ulDeviceNum, ULONG ulFunctionNum, ULONG ulRegNum, PVOID pBuffer, ULONG ulSize);
    BOOLEAN(*MMIOWriteDataOffset)(PVOID devExt, ULONG ulOffset, PVOID data, ULONG ulSize);
    UCHAR(*MMIOWriteUcharOffset)(PVOID devExt, ULONG ulOffset, UCHAR ucData);
    USHORT(*MMIOWriteUshortOffset)(PVOID devExt, ULONG ulOffset, USHORT Data);
    ULONG(*MMIOWriteUlongOffset)(PVOID devExt, ULONG ulOffset, ULONG ulData);
    BOOLEAN(*MMIOWriteAndUlongOffset)(PVOID devExt, ULONG ulOffset, ULONG ulData);
    BOOLEAN(*MMIOWriteOrUlongOffset)(PVOID devExt, ULONG ulOffset, ULONG ulData);
    BOOLEAN(*MMIOWriteXorUlongOffset)(PVOID devExt, ULONG ulOffset, ULONG ulData);
    VOID(*MMIOWriteMaskedUcharValue)(PVOID devExt, ULONG ulOffset, UCHAR ucMask, UCHAR ucData);
    VOID(*MMIOWriteMaskedUshortValue)(PVOID devExt, ULONG ulOffset, USHORT usMask, USHORT usData);
    VOID(*MMIOWriteMaskedUlongValue)(PVOID devExt, ULONG ulOffset, ULONG ulMask, ULONG ulData);
    ULONG(*IOPortWriteUlongOffset)(PVOID devExt, ULONG ulOffset, ULONG ulData);
    ULONG(*MappedReadUlong)(PVOID pHwDev, PULONG pulMem);
    VOID(*MappedWriteUlong)(PVOID pHwDev, PULONG pulMem, ULONG ulData);
    BOOLEAN(*MMIOReadDataOffset)(PVOID pHwDev, ULONG ulOffset, PVOID pData, ULONG ulSize);
    UCHAR(*MMIOReadUcharOffset)(PVOID pHwDev, ULONG ulOffset);
    USHORT(*MMIOReadUshortOffset)(PVOID pHwDev, ULONG ulOffset);
    ULONG(*MMIOReadUlongOffset)(PVOID pHwDev, ULONG ulOffset);
}IGDKMD_MMIO_FUNC_INTERFACE, *PIGDKMD_MMIO_FUNC_INTERFACE;


typedef struct _MMIO_PATCH_CONTEXT {
    BOOL armed;
    BOOL hooked;
    PTR_T OSPCIWriteCfgReg_RVA;
    PTR_T MMIOWriteDataOffset_RVA;
    PTR_T MMIOWriteUcharOffset_RVA;
    PTR_T MMIOWriteUshortOffset_RVA;
    PTR_T MMIOWriteUlongOffset_RVA;
    PTR_T MMIOWriteAndUlongOffset_RVA;
    PTR_T MMIOWriteOrUlongOffset_RVA;
    PTR_T MMIOWriteXorUlongOffset_RVA;    
    PTR_T MMIOWriteMaskedUchar_RVA;
    PTR_T MMIOWriteMaskedUshort_RVA;
    PTR_T MMIOWriteMaskedUlong_RVA;
    PTR_T IOPortWriteUlongOffset_RVA;
    PTR_T MappedReadUlong_RVA;
    PTR_T MappedWriteUlong_RVA;
    PTR_T MMIOReadDataOffset_RVA;
    PTR_T MMIOReadUcharOffset_RVA;
    PTR_T MMIOReadUshortOffset_RVA;
    PTR_T MMIOReadUlongOffset_RVA;    
} MMIO_PATCH_CONTEXT, *PMMIO_PATCH_CONTEXT;


/////////////// STRUCTURE VARIABLES ////////////////////////
PIGDKMD_MMIO_FUNC_INTERFACE pMMIO_Interface;
PMMIO_PATCH_CONTEXT pMMIO_PatchContext;


/////////////// FUNCTION DEFNITION ////////////////////////
VOID        Setup_MMIOHooks();
VOID        Patch_MMIOInterface();
VOID        TearDown_MMIOHooks();