#include "globals.h"
#include "Helpers.h"
#include "logger.h"
#include "ddrw\ddrw_displayerrordef.h"
#include "kmem.h"
#include "registers.h"
#include "igdkmd_mmio_patcher.h"

extern PVOID    igdkmd_hwContext;
extern ULONG    igdkmd_patcher_status;
extern ULONG    HandleLiveState(ULONG offset, ULONG value);
extern ULONG    Simulate_HPD_Interrupt(ULONG value);

/*
** IGDKMD MMIO interface hooks
*/
ULONG __hooked_igdkmd_MappedReadUlong(PVOID pHwDev, PULONG pulMem);
VOID __hooked_igdkmd_MappedWriteUlong(PVOID pHwDev, PULONG pulMem, ULONG ulData);

BOOLEAN __hooked_igdkmd_MMIOReadDataOffset(PVOID pHwDev, ULONG ulOffset, PVOID pData, ULONG ulSize);
UCHAR __hooked_igdkmd_MMIOReadUcharOffset(PVOID pHwDev, ULONG ulOffset);
USHORT __hooked_igdkmd_MMIOReadUshortOffset(PVOID pHwDev, ULONG ulOffset);
ULONG __hooked_igdkmd_MMIOReadUlongOffset(PVOID pHwDev, ULONG ulOffset);

NTSTATUS __hooked_igdkmd_OSPCIWriteCfgReg(PVOID devExt, ULONG ulBusNum, ULONG ulDeviceNum, ULONG ulFunctionNum, ULONG ulRegNum, PVOID pBuffer, ULONG ulSize);
BOOLEAN __hooked_igdkmd_MMIOWriteDataOffset(PVOID devExt, ULONG ulOffset, PVOID data, ULONG ulSize);
UCHAR __hooked_igdkmd_MMIOWriteUcharOffset(PVOID devExt, ULONG ulOffset, UCHAR ucData);
USHORT __hooked_igdkmd_MMIOWriteUshortOffset(PVOID devExt, ULONG ulOffset, USHORT Data);
ULONG __hooked_igdkmd_MMIOWriteUlongOffset(PVOID devExt, ULONG ulOffset, ULONG ulData);
BOOLEAN __hooked_igdkmd_MMIOWriteAndUlongOffset(PVOID devExt, ULONG ulOffset, ULONG ulData);
BOOLEAN __hooked_igdkmd_MMIOWriteOrUlongOffset(PVOID devExt, ULONG ulOffset, ULONG ulData);
BOOLEAN __hooked_igdkmd_MMIOWriteXorUlongOffset(PVOID devExt, ULONG ulOffset, ULONG ulData);
VOID __hooked_igdkmd_MMIOWriteMaskedUcharValue(PVOID devExt, ULONG ulOffset, UCHAR ucMask, UCHAR ucData);
VOID __hooked_igdkmd_MMIOWriteMaskedUshortValue(PVOID devExt, ULONG ulOffset, USHORT usMask, USHORT usData);
VOID __hooked_igdkmd_MMIOWriteMaskedUlongValue(PVOID devExt, ULONG ulOffset, ULONG ulMask, ULONG ulData);
ULONG __hooked_igdkmd_IOPortWriteUlongOffset(PVOID devExt, ULONG ulOffset, ULONG ulData);


/*
** IGDKMD MMIO interface hooks with timestamp
*/
ULONG __hooked_T_igdkmd_MappedReadUlong(PVOID pHwDev, PULONG pulMem);
VOID __hooked_T_igdkmd_MappedWriteUlong(PVOID pHwDev, PULONG pulMem, ULONG ulData);

BOOLEAN __hooked_T_igdkmd_MMIOReadDataOffset(PVOID pHwDev, ULONG ulOffset, PVOID pData, ULONG ulSize);
UCHAR __hooked_T_igdkmd_MMIOReadUcharOffset(PVOID pHwDev, ULONG ulOffset);
USHORT __hooked_T_igdkmd_MMIOReadUshortOffset(PVOID pHwDev, ULONG ulOffset);
ULONG __hooked_T_igdkmd_MMIOReadUlongOffset(PVOID pHwDev, ULONG ulOffset);

BOOLEAN __hooked_T_igdkmd_MMIOWriteDataOffset(PVOID devExt, ULONG ulOffset, PVOID data, ULONG ulSize);
UCHAR __hooked_T_igdkmd_MMIOWriteUcharOffset(PVOID devExt, ULONG ulOffset, UCHAR ucData);
USHORT __hooked_T_igdkmd_MMIOWriteUshortOffset(PVOID devExt, ULONG ulOffset, USHORT Data);
ULONG __hooked_T_igdkmd_MMIOWriteUlongOffset(PVOID devExt, ULONG ulOffset, ULONG ulData);
BOOLEAN __hooked_T_igdkmd_MMIOWriteAndUlongOffset(PVOID devExt, ULONG ulOffset, ULONG ulData);
BOOLEAN __hooked_T_igdkmd_MMIOWriteOrUlongOffset(PVOID devExt, ULONG ulOffset, ULONG ulData);
BOOLEAN __hooked_T_igdkmd_MMIOWriteXorUlongOffset(PVOID devExt, ULONG ulOffset, ULONG ulData);
VOID __hooked_T_igdkmd_MMIOWriteMaskedUcharValue(PVOID devExt, ULONG ulOffset, UCHAR ucMask, UCHAR ucData);
VOID __hooked_T_igdkmd_MMIOWriteMaskedUshortValue(PVOID devExt, ULONG ulOffset, USHORT usMask, USHORT usData);
VOID __hooked_T_igdkmd_MMIOWriteMaskedUlongValue(PVOID devExt, ULONG ulOffset, ULONG ulMask, ULONG ulData);
ULONG __hooked_T_igdkmd_IOPortWriteUlongOffset(PVOID devExt, ULONG ulOffset, ULONG ulData);



BOOL Check_Patcher_Status() {
    if (igdkmd_patcher_status == 0 || igdkmd_patcher_modInfoPtr == NULL)
    {
        ELOG("MMIO_PATCHER: Cannot patch MMIO hooks, Patcher status is invalid \n");
        return FALSE;
    }

    if (pMMIO_Interface == NULL || pMMIO_PatchContext == NULL) {
        ELOG("MMIO_PATCHER: MMIO Interface not patched \n");
        return FALSE;
    }
    return TRUE;
}


BOOL LoadSymbols() {
    BOOL symbols_found = FALSE;

    if (Check_Patcher_Status() == FALSE) {
        return FALSE;
    }

    PSYMBOLINFO PSI_pMiniVtbl = GetModSymbol(igdkmd_patcher_modInfoPtr, "pMiniVtbl@HW_DEV_EXT");
    PSYMBOLINFO PSI_pfnPCIWriteCgfReg = GetModSymbol(igdkmd_patcher_modInfoPtr, "pfnPCIWriteCfgReg@MINI_SERVICES");
    PSYMBOLINFO PSI_pfnMMIOWriteDataOffset = GetModSymbol(igdkmd_patcher_modInfoPtr, "pfnMMIOWriteDataOffset@MINI_SERVICES");
    PSYMBOLINFO PSI_pfnMMIOWriteUcharOffset = GetModSymbol(igdkmd_patcher_modInfoPtr, "pfnMMIOWriteUcharOffset@MINI_SERVICES");
    PSYMBOLINFO PSI_pfnMMIOWriteUshortOffset = GetModSymbol(igdkmd_patcher_modInfoPtr, "pfnMMIOWriteUshortOffset@MINI_SERVICES");
    PSYMBOLINFO PSI_pfnMMIOWriteUlongOffset = GetModSymbol(igdkmd_patcher_modInfoPtr, "pfnMMIOWriteUlongOffset@MINI_SERVICES");
    PSYMBOLINFO PSI_pfnMMIOWriteAndUlongOffset = GetModSymbol(igdkmd_patcher_modInfoPtr, "pfnMMIOWriteAndUlongOffset@MINI_SERVICES");
    PSYMBOLINFO PSI_pfnMMIOWriteOrUlongOffset = GetModSymbol(igdkmd_patcher_modInfoPtr, "pfnMMIOWriteOrUlongOffset@MINI_SERVICES");
    PSYMBOLINFO PSI_pfnMMIOWriteXorUlongOffset = GetModSymbol(igdkmd_patcher_modInfoPtr, "pfnMMIOWriteXorUlongOffset@MINI_SERVICES");
    PSYMBOLINFO PSI_pfnMMIOWriteMaskedUchar = GetModSymbol(igdkmd_patcher_modInfoPtr, "pfnMMIOWriteMaskedUchar@MINI_SERVICES");
    PSYMBOLINFO PSI_pfnMMIOWriteMaskedUshort = GetModSymbol(igdkmd_patcher_modInfoPtr, "pfnMMIOWriteMaskedUshort@MINI_SERVICES");
    PSYMBOLINFO PSI_pfnMMIOWriteMaskedUlong = GetModSymbol(igdkmd_patcher_modInfoPtr, "pfnMMIOWriteMaskedUlong@MINI_SERVICES");
    PSYMBOLINFO PSI_pfnIOPortWriteUlongOffset = GetModSymbol(igdkmd_patcher_modInfoPtr, "pfnIOPortWriteUlongOffset@MINI_SERVICES");
    PSYMBOLINFO PSI_pfnMappedReadUlong = GetModSymbol(igdkmd_patcher_modInfoPtr, "pfnMappedReadUlong@MINI_SERVICES");
    PSYMBOLINFO PSI_pfnMappedWriteUlong = GetModSymbol(igdkmd_patcher_modInfoPtr, "pfnMappedWriteUlong@MINI_SERVICES");
    PSYMBOLINFO PSI_pfnMMIOReadDataOffset = GetModSymbol(igdkmd_patcher_modInfoPtr, "pfnMMIOReadDataOffset@MINI_SERVICES");
    PSYMBOLINFO PSI_pfnMMIOReadUcharOffset = GetModSymbol(igdkmd_patcher_modInfoPtr, "pfnMMIOReadUcharOffset@MINI_SERVICES");
    PSYMBOLINFO PSI_pfnMMIOReadUshortOffset = GetModSymbol(igdkmd_patcher_modInfoPtr, "pfnMMIOReadUshortOffset@MINI_SERVICES");
    PSYMBOLINFO PSI_pfnMMIOReadUlongOffset = GetModSymbol(igdkmd_patcher_modInfoPtr, "pfnMMIOReadUlongOffset@MINI_SERVICES");

    do
    {
        BREAK_ON_NULL(PSI_pMiniVtbl);
        BREAK_ON_NULL(PSI_pfnPCIWriteCgfReg);
        BREAK_ON_NULL(PSI_pfnMMIOWriteDataOffset);
        BREAK_ON_NULL(PSI_pfnMMIOWriteUcharOffset);
        BREAK_ON_NULL(PSI_pfnMMIOWriteUshortOffset);
        BREAK_ON_NULL(PSI_pfnMMIOWriteUlongOffset);
        BREAK_ON_NULL(PSI_pfnMMIOWriteAndUlongOffset);
        BREAK_ON_NULL(PSI_pfnMMIOWriteOrUlongOffset);
        BREAK_ON_NULL(PSI_pfnMMIOWriteXorUlongOffset);
        BREAK_ON_NULL(PSI_pfnMMIOWriteMaskedUchar);
        BREAK_ON_NULL(PSI_pfnMMIOWriteMaskedUshort);
        BREAK_ON_NULL(PSI_pfnMMIOWriteMaskedUlong);
        BREAK_ON_NULL(PSI_pfnIOPortWriteUlongOffset);
        BREAK_ON_NULL(PSI_pfnMappedReadUlong);
        BREAK_ON_NULL(PSI_pfnMappedWriteUlong);
        BREAK_ON_NULL(PSI_pfnMMIOReadDataOffset);
        BREAK_ON_NULL(PSI_pfnMMIOReadUcharOffset);
        BREAK_ON_NULL(PSI_pfnMMIOReadUshortOffset);
        BREAK_ON_NULL(PSI_pfnMMIOReadUlongOffset);

        symbols_found = TRUE;
    } while (FALSE);

    if (symbols_found == FALSE) {
        return FALSE;
    }

    pMMIO_PatchContext->armed = FALSE;
    pMMIO_Interface->armed = FALSE;

    PVOID base = *(PVOID*)((PTR_T)igdkmd_hwContext + PSI_pMiniVtbl->rva);

    //Get RVA for MMIO symbols
    pMMIO_PatchContext->OSPCIWriteCfgReg_RVA = ((PTR_T)base + PSI_pfnPCIWriteCgfReg->rva);
    pMMIO_PatchContext->MMIOWriteDataOffset_RVA = ((PTR_T)base + PSI_pfnMMIOWriteDataOffset->rva);
    pMMIO_PatchContext->MMIOWriteUcharOffset_RVA = ((PTR_T)base + PSI_pfnMMIOWriteUcharOffset->rva);
    pMMIO_PatchContext->MMIOWriteUshortOffset_RVA = ((PTR_T)base + PSI_pfnMMIOWriteUshortOffset->rva);
    pMMIO_PatchContext->MMIOWriteUlongOffset_RVA = ((PTR_T)base + PSI_pfnMMIOWriteUlongOffset->rva);
    pMMIO_PatchContext->MMIOWriteAndUlongOffset_RVA = ((PTR_T)base + PSI_pfnMMIOWriteAndUlongOffset->rva);
    pMMIO_PatchContext->MMIOWriteOrUlongOffset_RVA = ((PTR_T)base + PSI_pfnMMIOWriteOrUlongOffset->rva);
    pMMIO_PatchContext->MMIOWriteXorUlongOffset_RVA = ((PTR_T)base + PSI_pfnMMIOWriteXorUlongOffset->rva);
    pMMIO_PatchContext->MMIOWriteMaskedUchar_RVA = ((PTR_T)base + PSI_pfnMMIOWriteMaskedUchar->rva);
    pMMIO_PatchContext->MMIOWriteMaskedUshort_RVA = ((PTR_T)base + PSI_pfnMMIOWriteMaskedUshort->rva);
    pMMIO_PatchContext->MMIOWriteMaskedUlong_RVA = ((PTR_T)base + PSI_pfnMMIOWriteMaskedUlong->rva);
    pMMIO_PatchContext->IOPortWriteUlongOffset_RVA = ((PTR_T)base + PSI_pfnIOPortWriteUlongOffset->rva);
    pMMIO_PatchContext->MappedReadUlong_RVA = ((PTR_T)base + PSI_pfnMappedReadUlong->rva);
    pMMIO_PatchContext->MappedWriteUlong_RVA = ((PTR_T)base + PSI_pfnMappedWriteUlong->rva);
    pMMIO_PatchContext->MMIOReadDataOffset_RVA = ((PTR_T)base + PSI_pfnMMIOReadDataOffset->rva);
    pMMIO_PatchContext->MMIOReadUcharOffset_RVA = ((PTR_T)base + PSI_pfnMMIOReadUcharOffset->rva);
    pMMIO_PatchContext->MMIOReadUshortOffset_RVA = ((PTR_T)base + PSI_pfnMMIOReadUshortOffset->rva);
    pMMIO_PatchContext->MMIOReadUlongOffset_RVA = ((PTR_T)base + PSI_pfnMMIOReadUlongOffset->rva);

    //Get Function address based on RVA 
    F_ASSIGN(pMMIO_Interface->OSPCIWriteCfgReg = *(PVOID*)pMMIO_PatchContext->OSPCIWriteCfgReg_RVA);
    F_ASSIGN(pMMIO_Interface->MMIOWriteDataOffset = *(PVOID*)pMMIO_PatchContext->MMIOWriteDataOffset_RVA);
    F_ASSIGN(pMMIO_Interface->MMIOWriteUcharOffset = *(PVOID*)pMMIO_PatchContext->MMIOWriteUcharOffset_RVA);
    F_ASSIGN(pMMIO_Interface->MMIOWriteUshortOffset = *(PVOID*)pMMIO_PatchContext->MMIOWriteUshortOffset_RVA);
    F_ASSIGN(pMMIO_Interface->MMIOWriteUlongOffset = *(PVOID*)pMMIO_PatchContext->MMIOWriteUlongOffset_RVA);
    F_ASSIGN(pMMIO_Interface->MMIOWriteAndUlongOffset = *(PVOID*)pMMIO_PatchContext->MMIOWriteAndUlongOffset_RVA);
    F_ASSIGN(pMMIO_Interface->MMIOWriteOrUlongOffset = *(PVOID*)pMMIO_PatchContext->MMIOWriteOrUlongOffset_RVA);
    F_ASSIGN(pMMIO_Interface->MMIOWriteXorUlongOffset = *(PVOID*)pMMIO_PatchContext->MMIOWriteXorUlongOffset_RVA);
    F_ASSIGN(pMMIO_Interface->MMIOWriteMaskedUcharValue = *(PVOID*)pMMIO_PatchContext->MMIOWriteMaskedUchar_RVA);
    F_ASSIGN(pMMIO_Interface->MMIOWriteMaskedUshortValue = *(PVOID*)pMMIO_PatchContext->MMIOWriteMaskedUshort_RVA);
    F_ASSIGN(pMMIO_Interface->MMIOWriteMaskedUlongValue = *(PVOID*)pMMIO_PatchContext->MMIOWriteMaskedUlong_RVA);
    F_ASSIGN(pMMIO_Interface->IOPortWriteUlongOffset = *(PVOID*)pMMIO_PatchContext->IOPortWriteUlongOffset_RVA);    
    F_ASSIGN(pMMIO_Interface->MappedReadUlong = *(PVOID*)pMMIO_PatchContext->MappedReadUlong_RVA);
    F_ASSIGN(pMMIO_Interface->MappedWriteUlong = *(PVOID*)pMMIO_PatchContext->MappedWriteUlong_RVA);
    F_ASSIGN(pMMIO_Interface->MMIOReadDataOffset = *(PVOID*)pMMIO_PatchContext->MMIOReadDataOffset_RVA);
    F_ASSIGN(pMMIO_Interface->MMIOReadUcharOffset = *(PVOID*)pMMIO_PatchContext->MMIOReadUcharOffset_RVA);
    F_ASSIGN(pMMIO_Interface->MMIOReadUshortOffset = *(PVOID*)pMMIO_PatchContext->MMIOReadUshortOffset_RVA);
    F_ASSIGN(pMMIO_Interface->MMIOReadUlongOffset = *(PVOID*)pMMIO_PatchContext->MMIOReadUlongOffset_RVA);

    pMMIO_Interface->armed = TRUE;
    pMMIO_PatchContext->armed = TRUE;
    return TRUE;
}


///////////////////////////////////////////////////////////////////////////////
//
// Patch_MMIOInterface: Method to patch MMIO interfaces
//
///////////////////////////////////////////////////////////////////////////////
VOID Patch_MMIOInterface() {
    pMMIO_Interface = (PIGDKMD_MMIO_FUNC_INTERFACE)kmalloc(sizeof(IGDKMD_MMIO_FUNC_INTERFACE));
    pMMIO_PatchContext = (PMMIO_PATCH_CONTEXT)kmalloc(sizeof(MMIO_PATCH_CONTEXT));
    pMMIO_PatchContext->hooked = FALSE;
    Setup_MMIOHooks();
    return;
}


///////////////////////////////////////////////////////////////////////////////
//
// TearDown_MMIOHooks: Restore MMIO Interface function pointer back to original pointers
//
///////////////////////////////////////////////////////////////////////////////
VOID TearDown_MMIOHooks()
{
    if (Check_Patcher_Status() == FALSE) {
        ELOG("MMIO_PATCHER: MMIO Interface not patched \n");
        return;
    }

    if (pMMIO_Interface->armed == FALSE || pMMIO_PatchContext->armed == FALSE) {
        ELOG("MMIO_PATCHER: MMIO Interface patching not complete \n");
        return;
    }

    if (pMMIO_PatchContext->hooked == TRUE) {
        F_ASSIGN(*(PVOID*)pMMIO_PatchContext->OSPCIWriteCfgReg_RVA = pMMIO_Interface->OSPCIWriteCfgReg);
        F_ASSIGN(*(PVOID*)pMMIO_PatchContext->MMIOWriteDataOffset_RVA = pMMIO_Interface->MMIOWriteDataOffset);
        F_ASSIGN(*(PVOID*)pMMIO_PatchContext->MMIOWriteUcharOffset_RVA = pMMIO_Interface->MMIOWriteUcharOffset);
        F_ASSIGN(*(PVOID*)pMMIO_PatchContext->MMIOWriteUshortOffset_RVA = pMMIO_Interface->MMIOWriteUshortOffset);
        F_ASSIGN(*(PVOID*)pMMIO_PatchContext->MMIOWriteUlongOffset_RVA = pMMIO_Interface->MMIOWriteUlongOffset);
        F_ASSIGN(*(PVOID*)pMMIO_PatchContext->MMIOWriteAndUlongOffset_RVA = pMMIO_Interface->MMIOWriteAndUlongOffset);
        F_ASSIGN(*(PVOID*)pMMIO_PatchContext->MMIOWriteOrUlongOffset_RVA = pMMIO_Interface->MMIOWriteOrUlongOffset);
        F_ASSIGN(*(PVOID*)pMMIO_PatchContext->MMIOWriteXorUlongOffset_RVA = pMMIO_Interface->MMIOWriteXorUlongOffset);
        F_ASSIGN(*(PVOID*)pMMIO_PatchContext->MMIOWriteMaskedUchar_RVA = pMMIO_Interface->MMIOWriteMaskedUcharValue);
        F_ASSIGN(*(PVOID*)pMMIO_PatchContext->MMIOWriteMaskedUshort_RVA = pMMIO_Interface->MMIOWriteMaskedUshortValue);
        F_ASSIGN(*(PVOID*)pMMIO_PatchContext->MMIOWriteMaskedUlong_RVA = pMMIO_Interface->MMIOWriteMaskedUlongValue);
        F_ASSIGN(*(PVOID*)pMMIO_PatchContext->MappedReadUlong_RVA = pMMIO_Interface->MappedReadUlong);
        F_ASSIGN(*(PVOID*)pMMIO_PatchContext->MappedWriteUlong_RVA = pMMIO_Interface->MappedWriteUlong);
        F_ASSIGN(*(PVOID*)pMMIO_PatchContext->MMIOReadDataOffset_RVA = pMMIO_Interface->MMIOReadDataOffset);
        F_ASSIGN(*(PVOID*)pMMIO_PatchContext->MMIOReadUcharOffset_RVA = pMMIO_Interface->MMIOReadUcharOffset);
        F_ASSIGN(*(PVOID*)pMMIO_PatchContext->MMIOReadUshortOffset_RVA = pMMIO_Interface->MMIOReadUshortOffset);
        F_ASSIGN(*(PVOID*)pMMIO_PatchContext->MMIOReadUlongOffset_RVA = pMMIO_Interface->MMIOReadUlongOffset);

        pMMIO_PatchContext->hooked = FALSE;
        pMMIO_PatchContext->armed = FALSE;
        pMMIO_Interface->armed = FALSE;
    }
}


///////////////////////////////////////////////////////////////////////////////
//
// Setup_MMIOHooks: Enable MMIO Hooks based on igdkmd patcher status 
//
///////////////////////////////////////////////////////////////////////////////
VOID Setup_MMIOHooks()
{
    if (Check_Patcher_Status() == FALSE) {
        ELOG("MMIO_PATCHER: MMIO Interface not patched");
        return;
    }

    if (__option_trace_MMIO == 0 && __option_mmio_timings == 0) {
        TearDown_MMIOHooks();
        return;
    }

    if (LoadSymbols(&pMMIO_PatchContext) == FALSE) {
        ELOG("MMIO_PATCHER: MMIO Interface symbols loader failed");
        return;
    }

    if (__option_trace_MMIO) {
        if (pMMIO_PatchContext->hooked == TRUE &&
            (*(PVOID*)(pMMIO_PatchContext->MMIOWriteDataOffset_RVA) == __hooked_igdkmd_MMIOWriteDataOffset))
        {
            ELOG("MMIO_PATCHER: MMIO interface already patched");
            return;
        }

        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->OSPCIWriteCfgReg_RVA) = __hooked_igdkmd_OSPCIWriteCfgReg);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOWriteDataOffset_RVA) = __hooked_igdkmd_MMIOWriteDataOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOWriteUcharOffset_RVA) = __hooked_igdkmd_MMIOWriteUcharOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOWriteUcharOffset_RVA) = __hooked_igdkmd_MMIOWriteUcharOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOWriteUshortOffset_RVA) = __hooked_igdkmd_MMIOWriteUshortOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOWriteUshortOffset_RVA) = __hooked_igdkmd_MMIOWriteUshortOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOWriteUlongOffset_RVA) = __hooked_igdkmd_MMIOWriteUlongOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOWriteUlongOffset_RVA) = __hooked_igdkmd_MMIOWriteUlongOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOWriteAndUlongOffset_RVA) = __hooked_igdkmd_MMIOWriteAndUlongOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOWriteOrUlongOffset_RVA) = __hooked_igdkmd_MMIOWriteOrUlongOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOWriteXorUlongOffset_RVA) = __hooked_igdkmd_MMIOWriteXorUlongOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOWriteMaskedUchar_RVA) = __hooked_igdkmd_MMIOWriteMaskedUcharValue);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOWriteMaskedUshort_RVA) = __hooked_igdkmd_MMIOWriteMaskedUshortValue);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOWriteMaskedUlong_RVA) = __hooked_igdkmd_MMIOWriteMaskedUlongValue);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->IOPortWriteUlongOffset_RVA) = __hooked_igdkmd_IOPortWriteUlongOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MappedReadUlong_RVA) = __hooked_igdkmd_MappedReadUlong);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MappedWriteUlong_RVA) = __hooked_igdkmd_MappedWriteUlong);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOReadDataOffset_RVA) = __hooked_igdkmd_MMIOReadDataOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOReadUcharOffset_RVA) = __hooked_igdkmd_MMIOReadUcharOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOReadUshortOffset_RVA) = __hooked_igdkmd_MMIOReadUshortOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOReadUlongOffset_RVA) = __hooked_igdkmd_MMIOReadUlongOffset);
        pMMIO_PatchContext->hooked = TRUE;
    }
    else if (__option_mmio_timings)
    {
        if (pMMIO_PatchContext->hooked == TRUE &&
            (*(PVOID*)(pMMIO_PatchContext->MMIOWriteDataOffset_RVA) == __hooked_T_igdkmd_MMIOWriteDataOffset))
        {
            ELOG("MMIO_PATCHER: MMIO timing interface already patched");
            return;
        }

        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->OSPCIWriteCfgReg_RVA) = __hooked_igdkmd_OSPCIWriteCfgReg);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOWriteDataOffset_RVA) = __hooked_T_igdkmd_MMIOWriteDataOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOWriteUcharOffset_RVA) = __hooked_T_igdkmd_MMIOWriteUcharOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOWriteUcharOffset_RVA) = __hooked_T_igdkmd_MMIOWriteUcharOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOWriteUshortOffset_RVA) = __hooked_T_igdkmd_MMIOWriteUshortOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOWriteUshortOffset_RVA) = __hooked_T_igdkmd_MMIOWriteUshortOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOWriteUlongOffset_RVA) = __hooked_T_igdkmd_MMIOWriteUlongOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOWriteUlongOffset_RVA) = __hooked_T_igdkmd_MMIOWriteUlongOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOWriteAndUlongOffset_RVA) = __hooked_T_igdkmd_MMIOWriteAndUlongOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOWriteOrUlongOffset_RVA) = __hooked_T_igdkmd_MMIOWriteOrUlongOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOWriteXorUlongOffset_RVA) = __hooked_T_igdkmd_MMIOWriteXorUlongOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOWriteMaskedUchar_RVA) = __hooked_T_igdkmd_MMIOWriteMaskedUcharValue);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOWriteMaskedUshort_RVA) = __hooked_T_igdkmd_MMIOWriteMaskedUshortValue);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOWriteMaskedUlong_RVA) = __hooked_T_igdkmd_MMIOWriteMaskedUlongValue);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->IOPortWriteUlongOffset_RVA) = __hooked_T_igdkmd_IOPortWriteUlongOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MappedReadUlong_RVA) = __hooked_T_igdkmd_MappedReadUlong);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MappedWriteUlong_RVA) = __hooked_T_igdkmd_MappedWriteUlong);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOReadDataOffset_RVA) = __hooked_T_igdkmd_MMIOReadDataOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOReadUcharOffset_RVA) = __hooked_T_igdkmd_MMIOReadUcharOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOReadUshortOffset_RVA) = __hooked_T_igdkmd_MMIOReadUshortOffset);
        F_ASSIGN(*(PVOID*)(pMMIO_PatchContext->MMIOReadUlongOffset_RVA) = __hooked_T_igdkmd_MMIOReadUlongOffset);
        pMMIO_PatchContext->hooked = TRUE;
    }

    return;
}


///////////////////////////////////////////////////////////////////////////////////////////////////
NTSTATUS __hooked_igdkmd_OSPCIWriteCfgReg(PVOID devExt, ULONG ulBusNum, ULONG ulDeviceNum, ULONG ulFunctionNum, ULONG ulRegNum, PVOID pBuffer, ULONG ulSize)
{
    //PVOID addrList[] = { &ulBusNum,      &ulDeviceNum,    &ulFunctionNum, &ulRegNum,     pBuffer,         &ulSize };
    //ULONG sizesList[] = { sizeof(ULONG),  sizeof(ULONG),   sizeof(ULONG),  sizeof(ULONG), (USHORT)ulSize,  sizeof(ULONG) };

    //addToLog(_F("WOSPCI "), addrList, sizesList, 6);

    return pMMIO_Interface->OSPCIWriteCfgReg(devExt, ulBusNum, ulDeviceNum, ulFunctionNum, ulRegNum, pBuffer, ulSize);
}


///////////////////////////////////////////////////////////////////////////////////////////////////
BOOLEAN __hooked_igdkmd_MMIOWriteDataOffset(PVOID devExt, ULONG ulOffset, PVOID data, ULONG ulSize)
{
    //PVOID addrList[] = { &ulOffset,      data,    &ulSize };
    //ULONG sizesList[] = { sizeof(ULONG),  ulSize,  sizeof(ULONG) };

    //addToLog(_F("WD "), addrList, sizesList, 3 | SPLIT_4BB);

    return pMMIO_Interface->MMIOWriteDataOffset(devExt, ulOffset, data, ulSize);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
UCHAR __hooked_igdkmd_MMIOWriteUcharOffset(PVOID devExt, ULONG ulOffset, UCHAR ucData)
{
    //PVOID addrList[] = { &ulOffset,      &ucData };
    //ULONG sizesList[] = { sizeof(ULONG),  sizeof(UCHAR) };

    //addToLog(_F("W "), addrList, sizesList, 2);

    return pMMIO_Interface->MMIOWriteUcharOffset(devExt, ulOffset, ucData);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
USHORT __hooked_igdkmd_MMIOWriteUshortOffset(PVOID devExt, ULONG ulOffset, USHORT Data)
{
    //PVOID addrList[] = { &ulOffset,      &Data };
    //ULONG sizesList[] = { sizeof(ULONG),  sizeof(USHORT) };

    //addToLog(_F("W "), addrList, sizesList, 2);

    return pMMIO_Interface->MMIOWriteUshortOffset(devExt, ulOffset, Data);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
ULONG __hooked_igdkmd_MMIOWriteUlongOffset(PVOID devExt, ULONG ulOffset, ULONG ulData)
{
    //PVOID addrList[] = { &ulOffset,      &ulData };
    //ULONG sizesList[] = { sizeof(ULONG),  sizeof(ULONG) };

    //addToLog(_F("W "), addrList, sizesList, 2);

    return pMMIO_Interface->MMIOWriteUlongOffset(devExt, ulOffset, ulData);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
BOOLEAN __hooked_igdkmd_MMIOWriteAndUlongOffset(PVOID devExt, ULONG ulOffset, ULONG ulData)
{
    //PVOID addrList[] = { &ulOffset,      &ulData };
    //ULONG sizesList[] = { sizeof(ULONG),  sizeof(ULONG) };

    //addToLog(_F("WAnd "), addrList, sizesList, 2);

    return pMMIO_Interface->MMIOWriteAndUlongOffset(devExt, ulOffset, ulData);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
BOOLEAN __hooked_igdkmd_MMIOWriteOrUlongOffset(PVOID devExt, ULONG ulOffset, ULONG ulData)
{
    //PVOID addrList[] = { &ulOffset,      &ulData };
    //ULONG sizesList[] = { sizeof(ULONG),  sizeof(ULONG) };

    //addToLog(_F("WOr "), addrList, sizesList, 2);

    return pMMIO_Interface->MMIOWriteOrUlongOffset(devExt, ulOffset, ulData);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
BOOLEAN __hooked_igdkmd_MMIOWriteXorUlongOffset(PVOID devExt, ULONG ulOffset, ULONG ulData)
{
    //PVOID addrList[] = { &ulOffset,       &ulData };
    //ULONG sizesList[] = { sizeof(ULONG),  sizeof(ULONG) };

    //addToLog(_F("WXor "), addrList, sizesList, 2);

    return pMMIO_Interface->MMIOWriteXorUlongOffset(devExt, ulOffset, ulData);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_igdkmd_MMIOWriteMaskedUcharValue(PVOID devExt, ULONG ulOffset, UCHAR ucMask, UCHAR ucData)
{
    //PVOID addrList[] = { &ulOffset,       &ucMask,       &ucData };
    //ULONG sizesList[] = { sizeof(ULONG),  sizeof(UCHAR), sizeof(UCHAR) };

    //addToLog(_F("W* "), addrList, sizesList, 3);

    pMMIO_Interface->MMIOWriteMaskedUcharValue(devExt, ulOffset, ucMask, ucData);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_igdkmd_MMIOWriteMaskedUshortValue(PVOID devExt, ULONG ulOffset, USHORT usMask, USHORT usData)
{
    //PVOID addrList[] = { &ulOffset,      &usMask,        &usData };
    //ULONG sizesList[] = { sizeof(ULONG),  sizeof(USHORT), sizeof(USHORT) };

    //addToLog(_F("W* "), addrList, sizesList, 3);

    pMMIO_Interface->MMIOWriteMaskedUshortValue(devExt, ulOffset, usMask, usData);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_igdkmd_MMIOWriteMaskedUlongValue(PVOID devExt, ULONG ulOffset, ULONG ulMask, ULONG ulData)
{
    //PVOID addrList[] = { &ulOffset,       &ulMask,        &ulData };
    //ULONG sizesList[] = { sizeof(ULONG),  sizeof(ULONG),  sizeof(ULONG) };

    //addToLog(_F("W* "), addrList, sizesList, 3);

    pMMIO_Interface->MMIOWriteMaskedUlongValue(devExt, ulOffset, ulMask, ulData);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
ULONG __hooked_igdkmd_IOPortWriteUlongOffset(PVOID devExt, ULONG ulOffset, ULONG ulData)
{
    //PVOID addrList[] = { &ulOffset,       &ulData };
    //ULONG sizesList[] = { sizeof(ULONG),  sizeof(ULONG) };

    //addToLog(_F("WIO "), addrList, sizesList, 2);

    return pMMIO_Interface->IOPortWriteUlongOffset(devExt, ulOffset, ulData);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
ULONG __hooked_igdkmd_MappedReadUlong(PVOID pHwDev, PULONG pulMem)
{
    ULONG ret = pMMIO_Interface->MappedReadUlong(pHwDev, pulMem);

    //PVOID addrList[] = { &pulMem, &ret };
    //ULONG sizesList[] = { sizeof(PULONG),  sizeof(ULONG) };
    //addToLog(_F("R "), addrList, sizesList, 2);
    return ret;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_igdkmd_MappedWriteUlong(PVOID pHwDev, PULONG pulMem, ULONG ulData)
{
    //PVOID addrList[] = { &pulMem, &ulData };
    //ULONG sizesList[] = { sizeof(PULONG),  sizeof(ULONG) };
    //addToLog(_F("W "), addrList, sizesList, 2);

    pMMIO_Interface->MappedWriteUlong(pHwDev, pulMem, ulData);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
BOOLEAN __hooked_igdkmd_MMIOReadDataOffset(PVOID pHwDev, ULONG ulOffset, PVOID pData, ULONG ulSize)
{
    BOOLEAN ret = pMMIO_Interface->MMIOReadDataOffset(pHwDev, ulOffset, pData, ulSize);

    //PVOID addrList[] = { &ulOffset, pData, &ulSize };
    //ULONG sizesList[] = { sizeof(ULONG),  ulSize, sizeof(ULONG) };

    //addToLog(_F("RD "), addrList, sizesList, 3 | SPLIT_4BB);    
    return ret;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
UCHAR __hooked_igdkmd_MMIOReadUcharOffset(PVOID pHwDev, ULONG ulOffset)
{
    UCHAR ret = pMMIO_Interface->MMIOReadUcharOffset(pHwDev, ulOffset);

    //PVOID addrList[] = { &ulOffset, &ret };
    //ULONG sizesList[] = { sizeof(ULONG),  sizeof(UCHAR) };
    //	addToLog(_F("R "), addrList, sizesList, 2);
    return ret;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
USHORT __hooked_igdkmd_MMIOReadUshortOffset(PVOID pHwDev, ULONG ulOffset)
{
    USHORT ret = pMMIO_Interface->MMIOReadUshortOffset(pHwDev, ulOffset);

    //PVOID addrList[] = { &ulOffset, &ret };
    //ULONG sizesList[] = { sizeof(ULONG),  sizeof(USHORT) };
    //addToLog(_F("R "), addrList, sizesList, 2);

    return ret;
}


///////////////////////////////////////////////////////////////////////////////////////////////////
ULONG __hooked_igdkmd_MMIOReadUlongOffset(PVOID pHwDev, ULONG ulOffset)
{
    ULONG mmio_value = pMMIO_Interface->MMIOReadUlongOffset(pHwDev, ulOffset);

    if (ulOffset == DISPLAY_INT_CTL) {
        mmio_value = Simulate_HPD_Interrupt(mmio_value);
    }
    else if (ulOffset == SHOTPLUG_CTL || ulOffset == SDE_INTERRUPT || ulOffset == PCHIIR 
                || ulOffset == DE_PORT_HPD_STATUS || ulOffset == DE_PORT_INTERRUPT)
    {
        mmio_value = HandleLiveState(ulOffset, mmio_value);
    }

    return mmio_value;
}



///////////////////////////////////////////////////////////////////////////////////////////////////
//MMIO Timings
///////////////////////////////////////////////////////////////////////////////////////////////////
#define RAISE_IRQL \
KIRQL oldIrql = 0;\
BOOLEAN irqlChanged = FALSE;\
if(KeGetCurrentIrql() < DISPATCH_LEVEL)\
{\
   oldIrql = KeRaiseIrqlToDpcLevel();\
    irqlChanged = TRUE;\
}

#define RESTORE_IRQL \
if(irqlChanged)\
    KeLowerIrql(oldIrql);



///////////////////////////////////////////////////////////////////////////////////////////////////
BOOLEAN __hooked_T_igdkmd_MMIOWriteDataOffset(PVOID devExt, ULONG ulOffset, PVOID data, ULONG ulSize)
{
    RAISE_IRQL;
    ULONGLONG timestampA = GetTimeStamp();
    BOOLEAN retV = pMMIO_Interface->MMIOWriteDataOffset(devExt, ulOffset, data, ulSize);
    ULONG timestampB = (ULONG)(GetTimeStamp() - timestampA);
    RESTORE_IRQL;

    PVOID addrList[] = { &timestampB, &ulOffset,      data,    &ulSize };
    ULONG sizesList[] = { sizeof(ULONG) | DEC_FORMAT, sizeof(ULONG),  ulSize,  sizeof(ULONG) };
    addToLog(_F("^WD "), addrList, sizesList, 4 | SPLIT_4BB);

    return retV;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
UCHAR __hooked_T_igdkmd_MMIOWriteUcharOffset(PVOID devExt, ULONG ulOffset, UCHAR ucData)
{
    RAISE_IRQL;
    ULONGLONG timestampA = GetTimeStamp();
    UCHAR retV = pMMIO_Interface->MMIOWriteUcharOffset(devExt, ulOffset, ucData);
    ULONG timestampB = (ULONG)(GetTimeStamp() - timestampA);
    RESTORE_IRQL;

    PVOID addrList[] = { &timestampB, &ulOffset, &ucData };
    ULONG sizesList[] = { sizeof(ULONG) | DEC_FORMAT, sizeof(ULONG),  sizeof(UCHAR) };

    addToLog(_F("^W "), addrList, sizesList, 3);

    return retV;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
USHORT __hooked_T_igdkmd_MMIOWriteUshortOffset(PVOID devExt, ULONG ulOffset, USHORT Data)
{
    RAISE_IRQL;
    ULONGLONG timestampA = GetTimeStamp();
    USHORT retV = pMMIO_Interface->MMIOWriteUshortOffset(devExt, ulOffset, Data);
    ULONG timestampB = (ULONG)(GetTimeStamp() - timestampA);
    RESTORE_IRQL;


    PVOID addrList[] = { &timestampB, &ulOffset,      &Data };
    ULONG sizesList[] = { sizeof(ULONG) | DEC_FORMAT, sizeof(ULONG),  sizeof(USHORT) };
    addToLog(_F("^W "), addrList, sizesList, 3);

    return retV;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
ULONG __hooked_T_igdkmd_MMIOWriteUlongOffset(PVOID devExt, ULONG ulOffset, ULONG ulData)
{
    RAISE_IRQL;
    ULONGLONG timestampA = GetTimeStamp();
    ULONG retV = pMMIO_Interface->MMIOWriteUlongOffset(devExt, ulOffset, ulData);
    ULONG timestampB = (ULONG)(GetTimeStamp() - timestampA);
    RESTORE_IRQL;

    PVOID addrList[] = { &timestampB, &ulOffset, &ulData };
    ULONG sizesList[] = { sizeof(ULONG) | DEC_FORMAT, sizeof(ULONG),  sizeof(ULONG) };

    addToLog(_F("^W "), addrList, sizesList, 3);

    return retV;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
BOOLEAN __hooked_T_igdkmd_MMIOWriteAndUlongOffset(PVOID devExt, ULONG ulOffset, ULONG ulData)
{
    RAISE_IRQL;
    ULONGLONG timestampA = GetTimeStamp();
    BOOLEAN retV = pMMIO_Interface->MMIOWriteAndUlongOffset(devExt, ulOffset, ulData);
    ULONG timestampB = (ULONG)(GetTimeStamp() - timestampA);
    RESTORE_IRQL;

    PVOID addrList[] = { &timestampB,  &ulOffset,      &ulData };
    ULONG sizesList[] = { sizeof(ULONG) | DEC_FORMAT, sizeof(ULONG),  sizeof(ULONG) };

    addToLog(_F("^WAnd "), addrList, sizesList, 3);

    return retV;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
BOOLEAN __hooked_T_igdkmd_MMIOWriteOrUlongOffset(PVOID devExt, ULONG ulOffset, ULONG ulData)
{
    RAISE_IRQL;
    ULONGLONG timestampA = GetTimeStamp();
    BOOLEAN retV = pMMIO_Interface->MMIOWriteOrUlongOffset(devExt, ulOffset, ulData);
    ULONG timestampB = (ULONG)(GetTimeStamp() - timestampA);
    RESTORE_IRQL;

    PVOID addrList[] = { &timestampB, &ulOffset, &ulData };
    ULONG sizesList[] = { sizeof(ULONG) | DEC_FORMAT, sizeof(ULONG),  sizeof(ULONG) };

    addToLog(_F("^WOr "), addrList, sizesList, 3);

    return retV;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
BOOLEAN __hooked_T_igdkmd_MMIOWriteXorUlongOffset(PVOID devExt, ULONG ulOffset, ULONG ulData)
{
    RAISE_IRQL;
    ULONGLONG timestampA = GetTimeStamp();
    BOOLEAN retV = pMMIO_Interface->MMIOWriteXorUlongOffset(devExt, ulOffset, ulData);
    ULONG timestampB = (ULONG)(GetTimeStamp() - timestampA);
    RESTORE_IRQL;


    PVOID addrList[] = { &timestampB, &ulOffset, &ulData };
    ULONG sizesList[] = { sizeof(ULONG) | DEC_FORMAT, sizeof(ULONG),  sizeof(ULONG) };

    addToLog(_F("^WXor "), addrList, sizesList, 3);

    return retV;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_T_igdkmd_MMIOWriteMaskedUcharValue(PVOID devExt, ULONG ulOffset, UCHAR ucMask, UCHAR ucData)
{
    RAISE_IRQL;
    ULONGLONG timestampA = GetTimeStamp();
    pMMIO_Interface->MMIOWriteMaskedUcharValue(devExt, ulOffset, ucMask, ucData);
    ULONG timestampB = (ULONG)(GetTimeStamp() - timestampA);
    RESTORE_IRQL;

    PVOID addrList[] = { &timestampB, &ulOffset, &ucMask, &ucData };
    ULONG sizesList[] = { sizeof(ULONG) | DEC_FORMAT, sizeof(ULONG),  sizeof(UCHAR), sizeof(UCHAR) };

    addToLog(_F("^W* "), addrList, sizesList, 4);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_T_igdkmd_MMIOWriteMaskedUshortValue(PVOID devExt, ULONG ulOffset, USHORT usMask, USHORT usData)
{
    RAISE_IRQL;
    ULONGLONG timestampA = GetTimeStamp();
    pMMIO_Interface->MMIOWriteMaskedUshortValue(devExt, ulOffset, usMask, usData);
    ULONG timestampB = (ULONG)(GetTimeStamp() - timestampA);
    RESTORE_IRQL;

    PVOID addrList[] = { &timestampB,  &ulOffset,      &usMask,        &usData };
    ULONG sizesList[] = { sizeof(ULONG) | DEC_FORMAT, sizeof(ULONG),  sizeof(USHORT), sizeof(USHORT) };

    addToLog(_F("^W* "), addrList, sizesList, 4);

}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_T_igdkmd_MMIOWriteMaskedUlongValue(PVOID devExt, ULONG ulOffset, ULONG ulMask, ULONG ulData)
{
    RAISE_IRQL;
    ULONGLONG timestampA = GetTimeStamp();
    pMMIO_Interface->MMIOWriteMaskedUlongValue(devExt, ulOffset, ulMask, ulData);
    ULONG timestampB = (ULONG)(GetTimeStamp() - timestampA);
    RESTORE_IRQL;

    PVOID addrList[] = { &timestampB, &ulOffset,       &ulMask,        &ulData };
    ULONG sizesList[] = { sizeof(ULONG) | DEC_FORMAT, sizeof(ULONG),  sizeof(ULONG),  sizeof(ULONG) };

    addToLog(_F("^W* "), addrList, sizesList, 4);

}

///////////////////////////////////////////////////////////////////////////////////////////////////
ULONG __hooked_T_igdkmd_IOPortWriteUlongOffset(PVOID devExt, ULONG ulOffset, ULONG ulData)
{
    RAISE_IRQL;
    ULONGLONG timestampA = GetTimeStamp();
    ULONG retV = pMMIO_Interface->IOPortWriteUlongOffset(devExt, ulOffset, ulData);
    ULONG timestampB = (ULONG)(GetTimeStamp() - timestampA);
    RESTORE_IRQL;


    PVOID addrList[] = { &timestampB, &ulOffset,       &ulData };
    ULONG sizesList[] = { sizeof(ULONG) | DEC_FORMAT, sizeof(ULONG),  sizeof(ULONG) };

    addToLog(_F("^WIO "), addrList, sizesList, 3);

    return retV;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
ULONG __hooked_T_igdkmd_MappedReadUlong(PVOID pHwDev, PULONG pulMem)
{
    RAISE_IRQL;
    ULONGLONG timestampA = GetTimeStamp();
    ULONG retV = pMMIO_Interface->MappedReadUlong(pHwDev, pulMem);
    ULONGLONG timestampB = GetTimeStamp() - timestampA;
    RESTORE_IRQL;

    PVOID addrList[] = { &timestampB, &pulMem, &retV };
    ULONG sizesList[] = { sizeof(ULONG) | DEC_FORMAT, sizeof(PULONG),  sizeof(ULONG) };
    addToLog(_F("^R "), addrList, sizesList, 3);

    return retV;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __hooked_T_igdkmd_MappedWriteUlong(PVOID pHwDev, PULONG pulMem, ULONG ulData)
{
    RAISE_IRQL;
    ULONGLONG timestampA = GetTimeStamp();
    pMMIO_Interface->MappedWriteUlong(pHwDev, pulMem, ulData);
    ULONG timestampB = (ULONG)(GetTimeStamp() - timestampA);
    RESTORE_IRQL;

    PVOID addrList[] = { &timestampB, &pulMem, &ulData };
    ULONG sizesList[] = { sizeof(ULONG) | DEC_FORMAT, sizeof(PULONG),  sizeof(ULONG) };
    addToLog(_F("^W "), addrList, sizesList, 3);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
BOOLEAN __hooked_T_igdkmd_MMIOReadDataOffset(PVOID pHwDev, ULONG ulOffset, PVOID pData, ULONG ulSize)
{
    RAISE_IRQL;
    ULONGLONG timestampA = GetTimeStamp();
    BOOLEAN ret = pMMIO_Interface->MMIOReadDataOffset(pHwDev, ulOffset, pData, ulSize);
    ULONG timestampB = (ULONG)(GetTimeStamp() - timestampA);
    RESTORE_IRQL;

    PVOID addrList[] = { &timestampB,  &ulOffset, pData, &ulSize };
    ULONG sizesList[] = { sizeof(ULONG) | DEC_FORMAT, sizeof(ULONG),  ulSize, sizeof(ULONG) };

    addToLog(_F("^RD "), addrList, sizesList, 4 | SPLIT_4BB);

    return ret;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
UCHAR __hooked_T_igdkmd_MMIOReadUcharOffset(PVOID pHwDev, ULONG ulOffset)
{
    RAISE_IRQL;
    ULONGLONG timestampA = GetTimeStamp();
    UCHAR retV = pMMIO_Interface->MMIOReadUcharOffset(pHwDev, ulOffset);
    ULONG timestampB = (ULONG)(GetTimeStamp() - timestampA);
    RESTORE_IRQL;

    PVOID addrList[] = { &timestampB, &ulOffset, &retV };
    ULONG sizesList[] = { sizeof(ULONG) | DEC_FORMAT, sizeof(ULONG),  sizeof(UCHAR) };
    addToLog(_F("^R "), addrList, sizesList, 3);

    return retV;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
USHORT __hooked_T_igdkmd_MMIOReadUshortOffset(PVOID pHwDev, ULONG ulOffset)
{
    RAISE_IRQL;
    ULONGLONG timestampA = GetTimeStamp();
    USHORT retV = pMMIO_Interface->MMIOReadUshortOffset(pHwDev, ulOffset);
    ULONG timestampB = (ULONG)(GetTimeStamp() - timestampA);
    RESTORE_IRQL;

    PVOID addrList[] = { &timestampB, &ulOffset, &retV };
    ULONG sizesList[] = { sizeof(ULONG) | DEC_FORMAT, sizeof(ULONG),  sizeof(USHORT) };
    addToLog(_F("^R "), addrList, sizesList, 3);

    return retV;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
ULONG __hooked_T_igdkmd_MMIOReadUlongOffset(PVOID pHwDev, ULONG ulOffset)
{
    RAISE_IRQL;
    ULONGLONG timestampA = GetTimeStamp();
    ULONG retV = pMMIO_Interface->MMIOReadUlongOffset(pHwDev, ulOffset);
    ULONG timestampB = (ULONG)(GetTimeStamp() - timestampA);
    RESTORE_IRQL;

    PVOID addrList[] = { &timestampB,  &ulOffset, &retV };
    ULONG sizesList[] = { sizeof(ULONG) | DEC_FORMAT, sizeof(ULONG),  sizeof(ULONG) };
    addToLog(_F("^R "), addrList, sizesList, 3);

    return retV;
}
