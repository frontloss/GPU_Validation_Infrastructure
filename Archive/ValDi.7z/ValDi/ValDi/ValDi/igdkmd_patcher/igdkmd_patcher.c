#include "../globals.h"
#include "../Hooks.h"
#include "../Helpers.h"
#include "../kmem.h"
#include "../Patcher.h"
#include "../DFT.h"
#include "igdkmd_intc.h"
#include <stdlib.h>
#include <stdio.h>
#include "igdkmd_patcher.h"
#include "ddrw\ddrw_displayerrordef.h"
#include "../GfxValStub/GfxValStub_bridge.h"
#include "../logger.h"
#include "../registers.h"


extern VOID  enablePipeCRC(ULONG pipeId);
extern VOID  enablePortCRC(ULONG portId);

ULONG                       igdkmd_patcher_status = 0;
PPATCHED_MODINFO            igdkmd_patcher_modInfoPtr = NULL;
PTR_T                       igdkmd_imageBase = 0ULL;
PTR_T                       igdkmd_patchOfThePatches = 0ULL;
VALDI_PATCH_STORE patchStore = { 0 };
IGDKMD_PATCHER_REQUESTS     igdkmd_requests = { 0 };
ULONGLONG                   intTiming[MAX_PIPES] = { 0 };



///////////////////////////////////////////////////////////////////////////////////////////////////
//SYMBOL LOCS
///////////////////////////////////////////////////////////////////////////////////////////////////
PSYMBOLINFO PSI_s_pGMCHPointer;
PSYMBOLINFO PSI_GMCH_CONFIG_GMCHBASE;
PSYMBOLINFO PSI_PIPE_CONFIG_GMCH_CONFIG;
PSYMBOLINFO PSI_PIPE_PORT_CONFIG_PIPE_CONFIG;
PSYMBOLINFO PSI_PORT_TYPES_PIPE_PORT;
PSYMBOLINFO PSI_PIPE_CONFIG;


///////////////////////////////////////////////////////////////////////////////////////////////////
//PIPE STATUS
///////////////////////////////////////////////////////////////////////////////////////////////////
static PIPE_MAPS            PipeStatus = { 0 };

PPIPE_MAPS                  __getPipeStatusPtr() { return &PipeStatus; }

///////////////////////////////////////////////////////////////////////////////////////////////////
//BSoD trigger flags
///////////////////////////////////////////////////////////////////////////////////////////////////
static ULONG                BSoD_Triggers[MAX_PIPES] = { 0 };

VOID                        __setBSoDTriggers(ULONG pipeId, ULONG v) { if (pipeId < MAX_PIPES) BSoD_Triggers[pipeId] = v; }


///////////////////////////////////////////////////////////////////////////////////////////////////
__pragma(warning(push))
__pragma(warning(disable:4221))
__pragma(warning(disable:4204))

VOID __report_Underrun(const char* msg, USHORT strbytes, ULONG pipeId)
{
    PVOID addrList[] = { &pipeId };
    ULONG sizesList[] = { sizeof(ULONG) };
    addToLog(msg, strbytes, addrList, sizesList, 1);
    InterlockedIncrement64((volatile LONGLONG*)&hStats.underrunds[pipeId]);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __report_FlipDone(ULONG pipeId, ULONG planeId)
{

    PVOID addrList[] = { &pipeId, &planeId };
    ULONG sizesList[] = { sizeof(ULONG), sizeof(ULONG) };

    addToLog(_F("FLIP_DONE "), addrList, sizesList, 2);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __report_FlipQueueEmpty(ULONG pipeId, ULONG planeId)
{

    PVOID addrList[] = { &pipeId, &planeId };
    ULONG sizesList[] = { sizeof(ULONG), sizeof(ULONG) };

    addToLog(_F("FLIP_QEMPTY "), addrList, sizesList, 2);
}


///////////////////////////////////////////////////////////////////////////////////////////////////
ULONG getScanLine(ULONG pipeId)
{
    ULONG RES_address;
    ULONG data1;

    switch (pipeId)
    {
    case 0: RES_address = PIPE_SCANLINE_A; break;
    case 1: RES_address = PIPE_SCANLINE_B; break;
    case 2: RES_address = PIPE_SCANLINE_C; break;
    default:
        return 0;
    }

    igdkmd_readMMIOData(RES_address, &data1, sizeof(data1));

    return data1;
}


///////////////////////////////////////////////////////////////////////////////////////////////////
static ULONG pipeFlag[MAX_PIPES] = { 0 };
VOID __crc_done_isr(ULONG pipeId)
{
    ULONG presentFlag = InterlockedExchange((volatile LONG*)&pipeFlag[pipeId], 1);
    if (presentFlag)
        return;
    __report_SoftSync(pipeId);
    InterlockedExchange((volatile LONG*)&pipeFlag[pipeId], 0);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
INT __AUXAccess(PVOID pArgs)
{
    PTR_T baseAddress;

    PSYMBOLINFO PSI_AUXAccess = GetModSymbol(igdkmd_patcher_modInfoPtr, "AUXAccess@GMCHBASE");
    if (!PSI_AUXAccess)
    {
        ELOG("No symbol info for [AUXAccess@GMCHBASE].\n");
        return -1;
    }

    INT(*_igdkmd_AUXAccess)(PVOID this, PVOID pArgs);

    baseAddress = *(PTR_T*)((PTR_T)igdkmd_imageBase + PSI_s_pGMCHPointer->rva);
    F_ASSIGN(_igdkmd_AUXAccess = *(PTR_T*)((PTR_T)baseAddress + PSI_AUXAccess->rva);)

        return _igdkmd_AUXAccess((PVOID)baseAddress, pArgs);
}


///////////////////////////////////////////////////////////////////////////////////////////////////
VOID igdkmd_getPipeToPortConfig()
{
    ULONG i;

    if (!(PSI_s_pGMCHPointer&&
        PSI_GMCH_CONFIG_GMCHBASE&&
        PSI_PIPE_CONFIG_GMCH_CONFIG&&
        PSI_PIPE_PORT_CONFIG_PIPE_CONFIG&&
        PSI_PORT_TYPES_PIPE_PORT&&
        PSI_PIPE_CONFIG))
    {
        ELOG("[igdkmd_getPipeToPortConfig] symbol info not complete.\n");
        return;
    }

    PTR_T baseAddress;
    PTR_T magicAddress[MAX_PIPES];
    baseAddress = *(PTR_T*)((PTR_T)igdkmd_imageBase + PSI_s_pGMCHPointer->rva);
    baseAddress += PSI_GMCH_CONFIG_GMCHBASE->rva;
    ULONG numOfPipes = PSI_PIPE_CONFIG_GMCH_CONFIG->size / PSI_PIPE_CONFIG->size;

    if (numOfPipes > MAX_PIPES)
    {
        ELOG("[igdkmd_getPipeToPortConfig] Invalid pipes count.\n");
        return;
    }

    for (i = 0; i < numOfPipes; i++)
    {
        magicAddress[i] = baseAddress + PSI_PIPE_CONFIG->size*i + PSI_PIPE_CONFIG_GMCH_CONFIG->rva;
        magicAddress[i] += PSI_PIPE_PORT_CONFIG_PIPE_CONFIG->rva;
        magicAddress[i] += PSI_PORT_TYPES_PIPE_PORT->rva;
        PipeStatus.pipeToPortConfig[i] = *(ULONG*)magicAddress[i];
        VLOG("Pipe[%u]: %u\n", i, PipeStatus.pipeToPortConfig[i]);
        if (PipeStatus.pipeToPortConfig[i] >= INTDPA_PORT) 
        {
            enablePipeCRC(i);            
        }
        enablePortCRC(PipeStatus.pipeToPortConfig[i] - INTDPA_PORT);
    }

    PVOID addrList[] = { &PipeStatus.pipeToPortConfig[0],  &PipeStatus.pipeToPortConfig[1],  &PipeStatus.pipeToPortConfig[2] };
    ULONG sizesList[] = { sizeof(ULONG), sizeof(ULONG), sizeof(ULONG) };
    addToLog(_F("PIPE2PORT "), addrList, sizesList, 3);
}


///////////////////////////////////////////////////////////////////////////////
//
// FindPatchPoint: Method to to find the RVA of a function within a function
//
///////////////////////////////////////////////////////////////////////////////
PVOID  FindPatchPoint(PIGDKMD_FUNCTION_PATCH_REQUEST pRequest)
{
    //WA for now - need to have a dedicated dissassm module...
    BYTE searchSeq[5];
    searchSeq[0] = 0xE8;
    PTR_T p;

    for (p = pRequest->start_address; p < pRequest->start_address + pRequest->target_size - 5; p++)
    {
        PTR_T offset = pRequest->target_address - (p + 5);
        RtlCopyMemory(&searchSeq[1], &offset, sizeof(ULONG));
        if (RtlCompareMemory(searchSeq, (PVOID)p, 5) == 5)
            return (PVOID)p;
    }

    return NULL;
}


///////////////////////////////////////////////////////////////////////////////////////////////////
VOID igdkmd_patcher_ReleaseModInfo(PPATCHED_MODINFO modInfoPtr)
{
    if (modInfoPtr->symInfo)
        kfree(modInfoPtr->symInfo);

    kfree(modInfoPtr);
}


INT igdkmd_patch_mainline() {
    BOOL commit_patching = FALSE;

    do {
        PSYMBOLINFO PSI_SB_INTERRUPT_ARGS = GetModSymbol(igdkmd_patcher_modInfoPtr, "_IGFX_SET_SOURCE_VISIBILITY_ARG");
        if (PSI_SB_INTERRUPT_ARGS->size == 2)
        {
            PSYMBOLINFO PSI_GfxSetSourceVisibility = GetModSymbol(igdkmd_patcher_modInfoPtr, "GfxSetSourceVisibility");
            if (!PSI_GfxSetSourceVisibility)
            {
                ELOG("No symbol info for [GfxSetSourceVisibility].\n");
                return -1;
            }

            F_ASSIGN(igdkmd_GfxSetSourceVisibility_16 = (PVOID)((PTR_T)igdkmd_patcher_modInfoPtr->imageBase + PSI_GfxSetSourceVisibility->rva);)
        }
        else
        {
            ELOG("Unknown PIGFX_SET_SOURCE_VISIBILITY_ARG size.\n");
        }


        PSYMBOLINFO PSI_PIPE_INDEX = GetModSymbol(igdkmd_patcher_modInfoPtr, "ulPipeIndex@SB_MODE_ARGS");
        if (!PSI_PIPE_INDEX)
        {
            ELOG("No symbol info for [ulPipeIndex@SB_MODE_ARGS].\n");
            return -1;
        }
        pipeId__SB_MODE_ARGS = (USHORT)PSI_PIPE_INDEX->rva;


        PSYMBOLINFO PSI_IGFX_DISPLAY_PWR_SET_ARGS = GetModSymbol(igdkmd_patcher_modInfoPtr, "_IGFX_DISPLAY_PWR_SET_ARGS");
        if (!PSI_IGFX_DISPLAY_PWR_SET_ARGS)
        {
            ELOG("No symbol info for [_IGFX_DISPLAY_PWR_SET_ARGS].\n");
            return -1;
        }
        DisplayPwrSetArgs_Size = (USHORT)PSI_IGFX_DISPLAY_PWR_SET_ARGS->size;


        PSYMBOLINFO PSI_SB_ADAPTERPOWERSTATE_ARGS = GetModSymbol(igdkmd_patcher_modInfoPtr, "_SB_ADAPTERPOWERSTATE_ARGS");
        if (!PSI_SB_ADAPTERPOWERSTATE_ARGS)
        {
            ELOG("No symbol info for [_SB_ADAPTERPOWERSTATE_ARGS].\n");
            return -1;
        }
        igdkmd_NotifyPowerState_Args_size = (USHORT)PSI_SB_ADAPTERPOWERSTATE_ARGS->size;

        PSYMBOLINFO PSI_SB_BLANKVIDEO_ARGS = GetModSymbol(igdkmd_patcher_modInfoPtr, "_SB_BLANKVIDEO_ARGS");
        if (!PSI_SB_BLANKVIDEO_ARGS)
        {
            ELOG("No symbol info for [_SB_BLANKVIDEO_ARGS].\n");
            return -1;
        }
        igdkmd_BlankVideo_Args_size = (USHORT)PSI_SB_BLANKVIDEO_ARGS->size;


        PSI_s_pGMCHPointer = GetModSymbol(igdkmd_patcher_modInfoPtr, "s_pGMCHPointer");
        PSI_GMCH_CONFIG_GMCHBASE = GetModSymbol(igdkmd_patcher_modInfoPtr, "GMCH_CONFIG@GMCHBASE");
        PSI_PIPE_CONFIG_GMCH_CONFIG = GetModSymbol(igdkmd_patcher_modInfoPtr, "PIPE_CONFIG@GMCH_CONFIG");
        PSI_PIPE_PORT_CONFIG_PIPE_CONFIG = GetModSymbol(igdkmd_patcher_modInfoPtr, "PIPE_PORT_CONFIG@PIPE_CONFIG");
        PSI_PORT_TYPES_PIPE_PORT = GetModSymbol(igdkmd_patcher_modInfoPtr, "PORT_TYPES@PIPE_PORT");
        PSI_PIPE_CONFIG = GetModSymbol(igdkmd_patcher_modInfoPtr, "_PIPE_CONFIG");

        GfxValStubBridgeInit((PTR_T)igdkmd_patcher_modInfoPtr->imageBase);
        commit_patching = TRUE;
    } while (FALSE);

    if (commit_patching == FALSE) {
        ELOG("Required symbol info not found\n");
        return -1;
    }

    return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
INT igdkmd_patcher(PPATCHED_MODINFO modInfo)
{
    INT status = -1;
    BOOL commit_patching = FALSE;

    igdkmd_hwContext = NULL;

    if (igdkmd_patcher_modInfoPtr)
    {
        ELOG("Releasing patch mode info  \n");
        igdkmd_patcher_ReleaseModInfo(igdkmd_patcher_modInfoPtr);
    }

    igdkmd_imageBase = (PTR_T)modInfo->imageBase;

    igdkmd_patcher_modInfoPtr = kcalloc(sizeof(PATCHED_MODINFO), 1);
    RtlCopyMemory(igdkmd_patcher_modInfoPtr, modInfo, sizeof(PATCHED_MODINFO));

    //Common
    PSYMBOLINFO pDriverEntry = GetModSymbol(igdkmd_patcher_modInfoPtr, "DriverEntry");
    PSYMBOLINFO pDxgkInitialize = GetModSymbol(igdkmd_patcher_modInfoPtr, "DxgkInitialize");
    PSYMBOLINFO PSI_KmReadMMIO_Data = GetModSymbol(igdkmd_patcher_modInfoPtr, "KmReadMMIO_Data");
    PSYMBOLINFO PSI_KmWriteMMIO_Data = GetModSymbol(igdkmd_patcher_modInfoPtr, "KmWriteMMIO_Data");

    //DDRW
    PSYMBOLINFO PSI_pGetHALInterface = GetModSymbol(igdkmd_patcher_modInfoPtr, "GetHALInterface");
        
    
    do {
        BREAK_ON_NULL(pDriverEntry);
        BREAK_ON_NULL(pDxgkInitialize);
        BREAK_ON_NULL(PSI_KmReadMMIO_Data);
        BREAK_ON_NULL(PSI_KmWriteMMIO_Data);
        commit_patching = TRUE;
    } while (FALSE);

    
    if (commit_patching == FALSE) {
        ELOG("Required symbol info not found\n");
        return -1;
    }
    
    PATCHPOINT p1;
    IGDKMD_FUNCTION_PATCH_REQUEST stRequest = { 0 };
    stRequest.start_address = (PTR_T)igdkmd_patcher_modInfoPtr->imageBase + (PTR_T)pDriverEntry->rva;
    stRequest.target_address = (PTR_T)igdkmd_patcher_modInfoPtr->imageBase + (PTR_T)pDxgkInitialize->rva;
    stRequest.target_size = pDriverEntry->size;

    PVOID pFuncPatchPoint = FindPatchPoint(&stRequest);    
    if (pFuncPatchPoint)
    {
        p1.orgData = 0;
        ADD_ASSIGN(p1.vaPatchPoint = pFuncPatchPoint;)
            p1.patchPointSize = 5;
        p1.vaTrampolineSection = 0x0;
        ADD_ASSIGN(p1.vaDestination = (PVOID)__hooked_DxgkInitialize;)
            ADD_ASSIGN(p1.vaPostCall = (PVOID)((PTR_T)igdkmd_patcher_modInfoPtr->imageBase + pDxgkInitialize->rva);)
            F_ASSIGN(native_DxgkInitialize = p1.vaPostCall;)
            CommitPatchPoint(&p1);
    }
    else
    {
        ELOG("[DriverEntry] patch point not found - already patched?\n");
        //return -1;
        status = -1;
    }

    F_ASSIGN(igdkmd_KmReadMMIO_Data = (PVOID)((PTR_T)igdkmd_patcher_modInfoPtr->imageBase + PSI_KmReadMMIO_Data->rva);)
        F_ASSIGN(igdkmd_KmWriteMMIO_Data = (PVOID)((PTR_T)igdkmd_patcher_modInfoPtr->imageBase + PSI_KmWriteMMIO_Data->rva);)

    if (PSI_pGetHALInterface  && PSI_pGetHALInterface->size) {
        //DDRW function patching
        F_ASSIGN(igdkmd_GetHALInterface = (PVOID)((PTR_T)igdkmd_patcher_modInfoPtr->imageBase + PSI_pGetHALInterface->rva);)            
    }
    else {
        //Mainline driver function patching
        int ret_status = igdkmd_patch_mainline();
        if (ret_status != 0) {
           return ret_status;
       }
    }

	LoadDFTConfig();
    InterlockedOr((volatile LONG*)&ValDiState, VALDISTATE_ARMED_FLAG);
    return status;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
INT igdkmd_patcher_cleanup()
{
    if (igdkmd_patcher_modInfoPtr)
        igdkmd_patcher_ReleaseModInfo(igdkmd_patcher_modInfoPtr);

    igdkmd_patcher_modInfoPtr = NULL;

    return 0;
}


///////////////////////////////////////////////////////////////////////////////
//
// igdkmd_readMMIOData: Patched function to read MMIO HW register
//
///////////////////////////////////////////////////////////////////////////////
INT igdkmd_readMMIOData(ULONG addr, PVOID data, ULONG size)
{
    if (!igdkmd_KmReadMMIO_Data)
    {
        ELOG("NULL address for [KmReadMMIO_Data].\n");
        return -1;
    }

    if (igdkmd_KmReadMMIO_Data(igdkmd_hwContext, addr, data, size))
        return 0;

    return -1;
}


///////////////////////////////////////////////////////////////////////////////
//
// igdkmd_writeMMIOData: Patched function to write MMIO HW register
//
///////////////////////////////////////////////////////////////////////////////
INT igdkmd_writeMMIOData(ULONG addr, PVOID data, ULONG size)
{
    if (!igdkmd_KmWriteMMIO_Data)
    {
        ELOG("NULL address for [KmWriteMMIO_Data].\n");
        return -1;
    }

    if (igdkmd_KmWriteMMIO_Data(igdkmd_hwContext, addr, data, size))
        return 0;

    return -1;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
INT __setPipeVisibility(ULONG pipeID, UCHAR enableFlag)
{
    UCHAR ub[2];
    ub[0] = (UCHAR)pipeID;
    ub[1] = enableFlag;

    if (!igdkmd_GfxSetSourceVisibility_16)
        return -1;

    if (!igdkmd_hwContext)
        return -1;

    if (!NT_SUCCESS(igdkmd_GfxSetSourceVisibility_16(igdkmd_hwContext, (PVOID)ub)))
        return -1;

    return 0;
}

__pragma(warning(pop))