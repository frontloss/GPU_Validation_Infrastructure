#pragma once
#include "../globals.h"
#include "../Driver.h"
#include "config.h"

#define _F(X) X,sizeof(X)-1
#define SPLIT_4BB  0x10000000
#define DEC_FORMAT 0x10000000

typedef struct _IGDKMD_PATCHER_REQUESTS
{
    INT               request_pauseTracing         :1;
    INT               request_resumeTracing        :1;
    INT               request_restartTracing       :1;
    INT               request_finalizeTracing      :1;
    INT               request_finalizeTracingAck   :1;
    INT               request_hotplugDPC           : 1;

    ULONG             request_updateBSODTriggerFlags[MAX_DPORTS];

    //PKEVENT           CRCShadowCopyReady_UserEvent;

}IGDKMD_PATCHER_REQUESTS, *PIGDKMD_PATCHER_REQUESTS;


typedef struct _VALDI_LOG_CHUNK
{
    ULONG64       ticketNumber;
    PVOID         pBuffAddress;
    ULONG64       timeStamp;
} VALDI_LOG_CHUNK, *PVALDI_LOG_CHUNK;


#define MAX_PATCH_POINTS        10

/*
    Currently Yangra project requires atleast 3 patch point and mainline requires only one patch point.
    But considering the design principle delta between mainline and yangra, expecting yangra to have 
    more patch point. Hence an arbitrary number of 10 is chosen as MAX_PATCH_POINTS
*/
typedef struct _VALDI_PATCH_STORE {
    PTR_T  igdkmd_patch_point_list[MAX_PATCH_POINTS];
    // Number of patch points available
    INT patch_count;
    // Next available patch point index
    INT next_idx;
} VALDI_PATCH_STORE;


extern PVALDI_LOG_CHUNK head;

extern  IGDKMD_PATCHER_REQUESTS            igdkmd_requests;
extern  PTR_T                              igdkmd_imageBase;
extern  UNICODE_STRING                     uniDumpFilePath;
extern  UNICODE_STRING                     alt_uniDumpFilePath;
///////////////////////////////////////////////////////////////////////////////////////////////////

VOID             igdkmd_getPipeToPortConfig();
VOID             __setBSoDTriggers(ULONG pipeID, ULONG v);
INT              igdkmd_readMMIOData(ULONG addr, PVOID data, ULONG size);
INT              igdkmd_writeMMIOData(ULONG addr, PVOID data, ULONG size);
PPIPE_MAPS       __getPipeStatusPtr();
INT              __setPipeVisibility(ULONG pipeID, UCHAR enableFlag);
INT              __AUXAccess(PVOID pArgs);


typedef struct _IGDKMD_FUNCTION_PATCH_REQUEST {
    PTR_T start_address;
    PTR_T target_address;
    ULONG target_size;
}IGDKMD_FUNCTION_PATCH_REQUEST, *PIGDKMD_FUNCTION_PATCH_REQUEST;
