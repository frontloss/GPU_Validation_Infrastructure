#pragma once




///////////////////////////////////////////////////////////////////////////////////////////////////

typedef enum _BASE_EVENTS {
    UNDEFINED_BASE_EVENT = 0,
    DE_EVENT_BASE_INDEX,
    PORT_EVENT_BASE_INDEX,
    REN_GEY_EVENT_BASE_INDEX,
    RENDER_EVENT_BASE_INDEX,
    VIDEO_EVENT_BASE_INDEX,
    VE_EVENT_BASE_INDEX,
    BLITTER_EVENT_BASE_INDEX,
    PINNING_EVENT_BASE_INDEX,
    PC_EVENT_BASE_INDEX,
    GUC_EVENT_BASE_INDEX,
    MISC_EVENT_BASE_INDEX,
    DE_PIPE_FLIP_EVENT_INDEX,
    DE_PLANE_GTT_FAULT_EVENT_INDEX,
    MAX_BASE_EVENTS
} BASE_EVENTS;


// subevents of a base should start at base index times multiple of this constant.
#define SUBEVENT_START_CONST 0x40      // 64 specific events in each EVENTbase (2 ^6)


typedef enum _EVENTS {

    UNDEFINED_EVENT = 0,

    //DE_Events
    VSYNC_PIPEA_EVENT = DE_EVENT_BASE_INDEX * SUBEVENT_START_CONST,
    VSYNC_PIPEB_EVENT,
    VSYNC_PIPEC_EVENT,
    VBLANK_PIPEA_EVENT,
    VBLANK_PIPEB_EVENT,
    VBLANK_PIPEC_EVENT,
    CRCDONE_PIPEA_EVENT,
    CRCDONE_PIPEB_EVENT,
    CRCDONE_PIPEC_EVENT,
    CRCERROR_PIPEA_EVENT,
    CRCERROR_PIPEB_EVENT,
    CRCERROR_PIPEC_EVENT,
    SPRITE_PLANEAFLIPDONE_EVENT,
    SPRITE_PLANEBFLIPDONE_EVENT,
    SPRITE_PLANECFLIPDONE_EVENT,
    SVM_WAITDESCRIPTORCOMPLETED_EVENT,
    SVM_VTDFAULT_EVENT,
    SVM_PRQ_EVENT,
    MIPIA_EVENT,
    MIPIC_EVENT,
    LPE_PIPEA_EVENT,
    LPE_PIPEB_EVENT,
    LPE_PIPEC_EVENT,
    LPEAUDIO_PIPEA_EVENT,
    LPEAUDIO_PIPEB_EVENT,
    LPEAUDIO_PIPEC_EVENT,
    PSR_GTC_EVENT,
    WD_EVENT,
    WD_END_OF_FRAME_EVENT,
    DEMISC_WD_COMBINED_EVENT,
    UNDERRUN_PIPEA_EVENT,
    UNDERRUN_PIPEB_EVENT,
    UNDERRUN_PIPEC_EVENT,
    //ADD new DE EVENTbefore MAX_DE_EVENT
    MAX_DE_EVENT,

    //PORT_EVENTS
    SDVOB_HOTPLUG_EVENT = PORT_EVENT_BASE_INDEX * SUBEVENT_START_CONST,
    SDVOC_HOTPLUG_EVENT,
    SDVOD_HOTPLUG_EVENT,
    CRT_HOTPLUG_EVENT,
    RESERVED_HOTPLUG_EVENT,
    INTDP_HDMIA_HOTPLUG_EVENT,
    INTDP_HDMIB_HOTPLUG_EVENT,
    INTDP_HDMIC_HOTPLUG_EVENT,
    INTDP_HDMID_HOTPLUG_EVENT,
    INTDP_HDMIA_SPI_EVENT,
    INTDP_HDMIB_SPI_EVENT,
    INTDP_HDMIC_SPI_EVENT,
    INTDP_HDMID_SPI_EVENT,
    AUDIO_HDCP_PIPE_A_EVENT,
    AUDIO_HDCP_PIPE_B_EVENT,
    AUDIO_HDCP_PIPE_C_EVENT,
    INTDP_HDMIE_HOTPLUG_EVENT,
    INTDP_HDMIE_SPI_EVENT,
    INTDP_HDMIF_HOTPLUG_EVENT,
    INTDP_HDMIF_SPI_EVENT,
    //ADD new PORT EVENTbefore MAX_PORT_EVENT
    MAX_PORT_EVENT,

    //render geyserville events
    REN_GEY_EVAL_FREQ_CHANGE = REN_GEY_EVENT_BASE_INDEX * SUBEVENT_START_CONST,
    REN_GEY_SW_COMMAND_COMPLETE,
    REN_GEY_AVGBUSY_THRESHOLD,
    REN_GEY_CONTINUOUS_BUSY_THRESHOLD,
    REN_GEY_UP_EVAL_INTERVAL,
    REN_GEY_DOWN_EVAL_INTERVAL,
    REN_GEY_CONTROLLER_DISABLE,
    //ADD new REN_GEY EVENTbefore MAX_REN_GEY_EVENT
    MAX_REN_GEY_EVENT,

    //render events
    RENDER_DEBUG_EVENT = RENDER_EVENT_BASE_INDEX * SUBEVENT_START_CONST,
    RENDER_PIPE_CONTROL_NOTIFY_EVENT,
    RENDER_USER_EVENT,
    RENDER_MMIO_SYNC_FLUSH_EVENT,
    RENDER_WATCHDOG_COUNTER_EXCEED,
    RENDER_AS_CONTEXT_SWITCH,
    RENDER_PAGE_FAULT,
    RENDER_PARITY_ERROR,
    RENDER_PERF_BUFFER_HALF_FULL,
    RENDER_TDL_RETRY_INTERRUPT, //Restart Interrupt for BKL
                                //ADD new RENDER EVENTbefore MAX_RENDER_EVENT
                                MAX_RENDER_EVENT,

                                //video events
                                VIDEO_USER_EVENT = VIDEO_EVENT_BASE_INDEX * SUBEVENT_START_CONST,
                                VIDEO_DEC_PIPELINE_COUNTER_EXCEED,
                                VIDEO_MI_FLUSH_DW_NOTIFY,
                                VIDEO_MMIO_SYNC_FLUSH_EVENT,
                                VIDEO_AS_CONTEXT_SWITCH,
                                VIDEO_PAGE_FAULT,
                                VIDEO_PAVP_UNSOLICITED_ATTACK,
                                VIDEO_USER_INTERRUPT2,
                                VIDEO_DEC_PIPELINE_COUNTER_EXCEED2,
                                VIDEO_MI_FLUSH_DW_NOTIFY2,
                                VIDEO_AS_CONTEXT_SWITCH2,
                                VIDEO_PAGE_FAULT2,
                                VIDEO_PAVP_UNSOLICITED_ATTACK2,
                                //ADD new video EVENTbefore MAX_VIDEO_EVENT
                                MAX_VIDEO_EVENT,

                                //video enhancement events
                                VE_USER_EVENT = VE_EVENT_BASE_INDEX * SUBEVENT_START_CONST,
                                VE_MI_FLUSH_DW_NOTIFY,
                                VE_MMIO_SYNC_FLUSH_EVENT,
                                VE_CMD_PARSER_MASTER_ERROR,
                                VE_AS_CONTEXT_SWITCH,
                                VE_WATCHDOG_COUNTER_EXCEED,

                                //ADD new video enhancement EVENTbefore MAX_VE_EVENT
                                MAX_VE_EVENT,

                                //blitter events
                                BLITTER_AS_CONTEXT_SWITCH = BLITTER_EVENT_BASE_INDEX * SUBEVENT_START_CONST,
                                BLITTER_MI_FLUSH_DW_NOTIFY,
                                BLITTER_MMIO_SYNC_FLUSH_EVENT,
                                BLITTER_USER_EVENT,
                                BLITTER_PAGE_FAULT,
                                //ADD new blitter EVENTbefore MAX_BLITTER_EVENT
                                MAX_BLITTER_EVENT,

                                //Pinning events
                                PINNING_AS_CONTEXT_SWITCH = PINNING_EVENT_BASE_INDEX * SUBEVENT_START_CONST,
                                PINNING_USER_EVENT,
                                //ADD new pinning EVENTbefore MAX_PINNING_EVENT
                                MAX_PINNING_EVENT,

                                //PC_Events
                                PC_LBPC_PIPEAEVENT = PC_EVENT_BASE_INDEX * SUBEVENT_START_CONST,
                                PC_LBPC_PIPEBEVENT,
                                PC_DPST_HISTOGRAM_EVENT,
                                PC_DPST_HISTOGRAM_PIPEAEVENT,
                                PC_DPST_HISTOGRAM_PIPEBEVENT,
                                PC_DPST_HISTOGRAM_PIPECEVENT,
                                PC_DPST_PHASEIN_EVENT,
                                PC_PCU_DRIVER_MB_EVENT,
                                PC_REN_FREQ_DOWN_RC6TIMEOUT,
                                PC_RP_UP_THRESHOLD,
                                PC_RP_DOWN_THRESHOLD,
                                PC_RP_UP_EI,
                                //ADD new PC EVENTbefore MAX_PC_EVENT
                                MAX_PC_EVENT,

                                // GuC Events
                                GUC_TO_HOST_EVENT = GUC_EVENT_BASE_INDEX * SUBEVENT_START_CONST,
                                // Add new GuC events before MAX_GUC_EVENT
                                MAX_GUC_EVENT,

                                //Miscellaneous events
                                ASLE_EVENT = MISC_EVENT_BASE_INDEX  * SUBEVENT_START_CONST,
                                GSE_SYSTEM_LEVEL,
                                ISP_INTERRUPT,
                                MSVDX_DEVICE_EVENT,
                                MSVDX_POWER_EVENT,
                                VED_BLOCK_EVENT,
                                VED_POWER_EVENT,
                                VBLANK_TPV,
                                INVALID_GTT_PAGE_TABLE_ENTRY_EVENT,
                                INVALID_PAGE_TABLE_ENTRY_DATA_EVENT,
                                //ADD new misc EVENTbefore MAX_MISC_EVENT
                                MAX_MISC_EVENT,

                                //Add new EVENTbase first then add EVENTto the base at 
                                //multiple of SUBEVENT_START_CONST 

                                //XX_EVENTXX_BASE_EVENTINDEX * SUBEVENT_START_CONST,
                                //MAX_XX_EVENT,
                                //else
                                //Add EVENTwithin appropriate existing EVENTbase range 

                                PIPEA_PLANE1FLIPDONE_EVENT = DE_PIPE_FLIP_EVENT_INDEX * SUBEVENT_START_CONST,
                                PIPEA_PLANE2FLIPDONE_EVENT,
                                PIPEA_PLANE3FLIPDONE_EVENT,

                                PIPEB_PLANE1FLIPDONE_EVENT,
                                PIPEB_PLANE2FLIPDONE_EVENT,
                                PIPEB_PLANE3FLIPDONE_EVENT,

                                PIPEC_PLANE1FLIPDONE_EVENT,
                                PIPEC_PLANE2FLIPDONE_EVENT,
                                PIPEC_PLANE3FLIPDONE_EVENT,

                                PIPEA_PLANE1FLIPQUEUEEMPTY_EVENT,
                                PIPEA_PLANE2FLIPQUEUEEMPTY_EVENT,
                                PIPEA_PLANE3FLIPQUEUEEMPTY_EVENT,

                                PIPEB_PLANE1FLIPQUEUEEMPTY_EVENT,
                                PIPEB_PLANE2FLIPQUEUEEMPTY_EVENT,
                                PIPEB_PLANE3FLIPQUEUEEMPTY_EVENT,

                                PIPEC_PLANE1FLIPQUEUEEMPTY_EVENT,
                                PIPEC_PLANE2FLIPQUEUEEMPTY_EVENT,
                                PIPEC_PLANE3FLIPQUEUEEMPTY_EVENT,

                                PIPEA_PLANE4FLIPDONE_EVENT,
                                PIPEB_PLANE4FLIPDONE_EVENT,
                                PIPEC_PLANE4FLIPDONE_EVENT,

                                MAX_PIPE_FLIP_EVENTS,

                                //Plane GTT Fault Interrupts
                                PIPEA_PLANE1GTTFAULTSTATUS_EVENT = DE_PLANE_GTT_FAULT_EVENT_INDEX * SUBEVENT_START_CONST,
                                PIPEA_PLANE2GTTFAULTSTATUS_EVENT,
                                PIPEA_PLANE3GTTFAULTSTATUS_EVENT,
                                PIPEA_PLANE4GTTFAULTSTATUS_EVENT,
                                PIPEA_CURSORGTTFAULTSTATUS_EVENT,

                                PIPEB_PLANE1GTTFAULTSTATUS_EVENT,
                                PIPEB_PLANE2GTTFAULTSTATUS_EVENT,
                                PIPEB_PLANE3GTTFAULTSTATUS_EVENT,
                                PIPEB_PLANE4GTTFAULTSTATUS_EVENT,
                                PIPEB_CURSORGTTFAULTSTATUS_EVENT,

                                PIPEC_PLANE1GTTFAULTSTATUS_EVENT,
                                PIPEC_PLANE2GTTFAULTSTATUS_EVENT,
                                PIPEC_PLANE3GTTFAULTSTATUS_EVENT,
                                PIPEC_PLANE4GTTFAULTSTATUS_EVENT,
                                PIPEC_CURSORGTTFAULTSTATUS_EVENT,

                                INTDP_HDMIB_SCDC_EVENT,
                                INTDP_HDMIC_SCDC_EVENT,
                                INTDP_HDMID_SCDC_EVENT,
                                INTDP_HDMIE_SCDC_EVENT,
                                INTDP_HDMIF_SCDC_EVENT,

                                MAX_PLANE_GTT_FAULT_EVENTS,


                                MAX_EVENTS
} EVENTS;


///////////////////////////////////////////////////////////////////////////////////////////////////
//  Display port type enumeration
typedef enum {
    NULL_PORT_TYPE = -1,
    ANALOG_PORT = 0,
    DVOA_PORT,
    DVOB_PORT,
    DVOC_PORT,
    DVOD_PORT,
    LVDS_PORT,
    INTDPE_PORT,
    INTHDMIB_PORT,
    INTHDMIC_PORT,
    INTHDMID_PORT,
    INT_DVI_PORT, //NA
    INTDPA_PORT, //Embedded DP For ILK
    INTDPB_PORT,
    INTDPC_PORT,
    INTDPD_PORT,
    TPV_PORT,  //This is for all the TPV Ports..
    INTMIPIA_PORT,
    INTMIPIC_PORT,
    WIGIG_PORT,
    DVOF_PORT,
    INTHDMIF_PORT,
    INTDPF_PORT,
    MAX_PORTS
} PORT_TYPES, *PPORT_TYPES;

#pragma warning( disable: 4214 )
#pragma warning( disable: 4201 )
// Data Structure for Interrupt operations
typedef enum _INTERRUPT_OPERATION
{ 
    ENABLE_INTERRUPT      = 1,
    DISABLE_INTERRUPT     = 2,
    MASK_INTERRUPT        = 3,
    UNMASK_INTERRUPT      = 4,
    GET_DISABLED_INTERRUPTS = 5 // Flag To Detect Disabled Interrupts also.
} INTERRUPT_OPERATION;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//NOTE: Any change in the interrrupt args structure below has to be reflected in the enum definitions above.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Interrupt Args structure
typedef struct _SB_INTERRUPT_ARGS_48
{
    INTERRUPT_OPERATION eOperation; // Data structure for interrupt operations
    ULONG ulPrivateData; // Private Interrupt Data. This will not be used in ILK and GT since enabling/disabling of all interrupts has become much simpler.. 

    ULONG PlatformUsesGen11InterruptArchitecture : 1; // Let Event handler code know that all non-display engines are handled by new Selector methods
    ULONG SelectorInterruptsOccurred             : 1; // New for Gen11+  ::  This bit means one of the hierarchical interrupts (has to use selector register) has occurred and needs to be handled by GEN11+ handler
    ULONG LegacyInterruptsOccurred               : 1; // New for Gen11+  ::  This bit means use the IntArgs below for handling the interrupts
    
    IN BOOLEAN HierarchicalInterruptService      : 1; // This bit means request for Hirearchial Interrupt services

    IN ULONG ulEngineClass;                           // Can re-use ulValue in union
    IN ULONG ulEngineIntrpt;                          // Can re-use ulValue1 in union

    union
    {
        ULONG ulValue;
        struct
        {
            //1. Hot Plug Interrupts Definitions - Starts Here

            ULONG    bIntegratedCRTInterrupt    : 1;    // Bit 0
            ULONG    ulReservedBit              : 1;    // Bit 1
            ULONG    bInterruptReserved1        : 1;    // Bit 2
            ULONG    bInterruptReserved2        : 1;    // Bit 3 //From Gen6 onwards,no need to register for this event as sDVO on Port C is disabled..
            ULONG    bIntDP_HDMIAInterrupt      : 1;    // Bit 4  //New Introduction from ILK onwards
            ULONG    bIntDP_HDMIBInterrupt      : 1;    // Bit 5
            ULONG    bIntDP_HDMICInterrupt      : 1;    // Bit 6
            ULONG    bIntDP_HDMIDInterrupt      : 1;    // Bit 7
            ULONG    bIntDP_HDMIA_SPInterrupt   : 1;    // Bit 8 //New Introduction from ILK onwards
            ULONG    bIntDP_HDMIB_SPInterrupt   : 1;    // Bit 9
            ULONG    bIntDP_HDMIC_SPInterrupt   : 1;    // Bit 10
            ULONG    bIntDP_HDMID_SPInterrupt   : 1;    // Bit 11            

            //1. Hot Plug Interrupts Definitions - Ends Here

            //2. Render Geyserville Interrupts Definitions - Starts Here

            //Render Geyserville Interrupts common till ILK Platform
            ULONG    bRen_Gey_SoftwareCommandCompleteInterrupt    : 1; // bit 12 // Render GeyserVille Interrupt             
            ULONG    bRen_Gey_EvaluatedFrequencyChangeInterrupt   : 1; // bit 13 // Render GeyserVille Interrupt            

            //New Render Geyserville Interrupts exists only in ILK
            ULONG    bRen_Gey_AvgBusyThreshold                    : 1; // bit 14 // Render GeyserVille Interrupt
            ULONG    bRen_Gey_ContinuousBusyThreshold             : 1; // bit 15 // Render GeyserVille Interrupt            

            //Render Geyserville Common between ILK and GT
            ULONG    bRen_Gey_UpEvaluationIntervalInterrupt       : 1; // bit 16 // Render GeyserVille Interrupt 
            ULONG    bRen_Gey_DownEvaluationIntervalInterrupt     : 1; // bit 17 // Render GeyserVille Interrupt

            //Render Geyserville Introduced from GT
            ULONG    bRen_Gey_Controller_Disable_StateInterrupt   : 1; // bit 18 // Render GeyserVille Interrupt

            //2. Render Geyserville Interrupts Definitions - Ends Here


            //3. Basic Render Interrupt Definitions - Starts Here

            ULONG    bDebugInterrupt                           : 1; // Bit 19 Gen4 Onwards
            ULONG    bPipeControlNotifyInterrupt               : 1; // Bit 20 Gen4 Onwards
            ULONG    bRenderUserInterrupt                      : 1; // Bit 21 Render Cmd UI      
            ULONG    bRenderMMIOSyncFlushStatus                : 1; // Bit 22
            ULONG    bRenderWatchDogCounterExcd                : 1; // Bit 23 //ILK Onwards           
            ULONG    bRenderASContextSwitch                    : 1; // Bit 24 //ILK Onwards           
            ULONG    bRenderPageFault                          : 1; // Bit 25 //ILK Onwards           

            //3. Basic Render Interrupt Definitions - Ends Here          

            //4. Media/Video Interrupt Definitions - Starts Here
            ULONG    bVideoUserInterrupt                       : 1; // Bit 26 Gen4 Onwards
            ULONG    bVideoDecPipelineCntrExceed               : 1; // Bit 27 Gen4 Onwards..Same as Video Command Streamer WatchDog Counter Exceeded in GT            
            //Following are valid from GT
            ULONG    bVideoMIFlush_DWNotify                    : 1; // Bit 28
            ULONG    bVideoMMIOSyncFlushStatus                 : 1; // Bit 29                 
            ULONG    bVideoASContextSwitch                     : 1; // Bit 30
            ULONG    bVideoPageFault                           : 1; // Bit 31

            //4. Media/Video Interrupt Definitions - Ends Here

        };
    };

    union
    {
        ULONG ulValue1;
        struct
        {
            //5. Remaining Power Conservation Interrupt Starts here            
            ULONG    bLBPC_PipeAInterrupt        : 1;    // Bit 0 - crestline and after. Doesnt exist from ILK Onwards            
            ULONG    bLBPC_PipeBInterrupt        : 1;    // Bit 1 - crestline and after. Doesnt exist from ILK Onwards            
            ULONG    bDPST_HistInterrupt         : 1;    // Bit 2 - crestline and after            
            ULONG    bDPST_PhaseInInterrupt      : 1;    // Bit 3 - crestline and after           

            //Valid from GT Onwards
            ULONG    bPCUDriverMBEvent                         : 1; // Bit 4
            ULONG    bPCRenderFreqDownwardDuringRC6Timeout     : 1; // Bit 5
            ULONG    bPC_RPUpThresholdIntr                     : 1; // Bit 6
            ULONG    bPC_RPDownThresholdIntr                   : 1; // Bit 7

            //5. Remaining Power Conservation Interrupt Ends here

            //6. Blitter Interrupts from GT Onwards Starts here

            ULONG    bBlitterASContextSwitch          : 1; // Bit 8            
            ULONG    bBlitterMIFlush_DWNotify         : 1; // Bit 9
            ULONG    bBlitterMMIOSyncFlushStatus      : 1; // Bit 10
            ULONG    bBlitterMI_User_Interrupt        : 1; // Bit 11
            ULONG    bBlitterPageFault                : 1; // Bit 12
            //6. Blitter Interrupts from GT Onwards Ends here    


            //7. Misc Interrupts Category Starts here
            ULONG    bVSync_PipeAInterrupt            : 1;    // Bit 13 //Not Required
            ULONG    bVSync_PipeBInterrupt            : 1;    // Bit 14 //Not Required
            ULONG    bVBlank_PipeAInterrupt           : 1;    // Bit 15
            ULONG    bVBlank_PipeBInterrupt           : 1;    // Bit 16            
            ULONG    bGSESystemLevel                  : 1;    // Bit 17  Valid from ILK Replacement for ASLE Interrupt           
            ULONG    bVblankTPV                       : 1;    // BIT 18 //Used for TPV Vblank Interrupt
            ULONG    bASLEInterrupt                   : 1;    // Bit 19  Need to remove Once MP Cleans up the ASLE INterrupt Stuff
            ULONG    bAllFirstLevelInterrupts         : 1;    // BIT 20 //Used for Enabling/Disabling of Interrupts..

            //7. Misc Interrupts Category Ends here

            //8. New added Interrupts
            ULONG    bSpritePlaneAFlipDoneInterrupt   : 1;    // BIT 21 //Used for Enabling/Disabling of Sprite Plane A Flip Done Interrupt..
            ULONG    bSpritePlaneBFlipDoneInterrupt   : 1;    // BIT 22 //Used for Enabling/Disabling of Sprite Plane B Flip Done Interrupt..

            ULONG    bVSync_PipeCInterrupt            : 1;    // BIT 23
            ULONG    bVBlank_PipeCInterrupt           : 1;    // BIT 24
            ULONG    bSpritePlaneCFlipDoneInterrupt   : 1;    // BIT 25

            ULONG    bAudioHDCPRequestInterruptA      : 1;    // BIT 26 //Audio HDCP request for transcoder A
            ULONG    bAudioHDCPRequestInterruptB      : 1;    // BIT 27 //Audio HDCP request for transcoder B
            ULONG    bAudioHDCPRequestInterruptC      : 1;    // BIT 28 //Audio HDCP request for transcoder C
            ULONG    bAudioHDCPRequestInterrupt       : 1;    // BIT 29 //Audio HDCP request for pre ilk platforms            

            ULONG   bPerfMonBufferHalfFullInterrupt   : 1;    // BIT 30

            ULONG   ulReserved_Bit31                 : 1;    // Bit 31

        };
    };

    union
    {
        ULONG ulValue2;
        struct
        {
            // This sections contains error/debug status bits
            ULONG bFIFOUnderrun_PipeAInterrupt                          : 1; // bit 0 
            ULONG bCRC_Error_PipeAInterrupt                             : 1; // bit 1
            ULONG bCRC_Done_PipeAInterrupt                              : 1; // bit 2

            ULONG bFIFOUnderrun_PipeBInterrupt                          : 1; // bit 3
            ULONG bCRC_Error_PipeBInterrupt                             : 1; // bit 4
            ULONG bCRC_Done_PipeBInterrupt                              : 1; // bit 5

            ULONG bFIFOUnderrun_PipeCInterrupt                          : 1; // bit 6
            ULONG bCRC_Error_PipeCInterrupt                             : 1; // bit 7
            ULONG bCRC_Done_PipeCInterrupt                              : 1; // bit 8

            // VE (Video Enhancement) Interrupt Definitions - Starts Here - Valid from Gen7_5 (HSW+) onward
            ULONG bVEUserInterrupt                                      : 1; // bit 9
            ULONG bVEMMIOSyncFlushStatus                                : 1; // bit 10
            ULONG bVECmdParserMasterError                               : 1; // bit 11
            ULONG bVEMIFlush_DWNotify                                   : 1; // bit 12
            // VE (Video Enhancement) Interrupt Definitions - Ends Here

            // other interrupt bits that don't fit into the previous dwords
            ULONG bRenderParityError                                    : 1; // Bit 13 Gen7 Onwards

            ULONG bVideoPavpUnsolicitedAttack                           : 1; // Bit 14 Gen7 Onwards

            //Below are valid from BDW
            ULONG bVideoUserInterrupt2                                  : 1; // Bit 15 
            ULONG bVideoDecPipelineCntrExceed2                          : 1; // Bit 16 
            ULONG bVideoMIFlush_DWNotify2                               : 1; // Bit 17
            ULONG bVideoMMIOSyncFlushStatus2                            : 1; // Bit 18                 
            ULONG bVideoASContextSwitch2                                : 1; // Bit 19
            ULONG bVideoPageFault2                                      : 1; // Bit 20
            ULONG bVideoPavpUnsolicitedAttack2                          : 1; // Bit 21

            ULONG bGuCSHIMError                                         : 1;    // bit 22
            ULONG bGuCDMAINTError                                       : 1;    // bit 23                
            ULONG bGuCDMADone                                           : 1;    // bit 24                
            ULONG bGuCDoorBellRang                                      : 1;    // bit 25
            ULONG bGuCIOMMUSentMsgtoGuc                                 : 1;    // bit 26
            ULONG bGuCSemaphoreSignaled                                 : 1;    // bit 27
            ULONG bGuCDisplayEventRecieved                              : 1;    // bit 28
            ULONG bGuCExecutionError                                    : 1;    // bit 29
            ULONG bGuCInterruptToHost                                   : 1;    // bit 30

            ULONG bCSTRInvalidTileDetection                             : 1;    // bits 31
        };
    };

    union
    {
        ULONG ulValue3;
        struct
        {
            // This sections contains VEC/WiDi interrupts
            ULONG bVECSContextSwitchInterrupt                           : 1; // bit 0
            ULONG bVECSWaitOnSemaphore                                  : 1; // bit 1
            ULONG bWDBoxInterrupt                                       : 1; // bit 2
            ULONG bDPST_HistInterruptPipeB                              : 1;// bit 3
            ULONG bDPST_PhaseInInterruptPipeB                           : 1; // bit 4
            ULONG bDPST_HistInterruptPipeC                              : 1;// bit 5
            ULONG bDPST_PhaseInInterruptPipeC                           : 1; // bit 6 

            ULONG bPipeA_Plane1FlipDoneInterrupt                        : 1; //bit 7
            ULONG bPipeA_Plane2FlipDoneInterrupt                        : 1; //bit 8
            ULONG bPipeA_Plane3FlipDoneInterrupt                        : 1; //bit 9

            ULONG bPipeB_Plane1FlipDoneInterrupt                        : 1; //bit 10
            ULONG bPipeB_Plane2FlipDoneInterrupt                        : 1; //bit 11
            ULONG bPipeB_Plane3FlipDoneInterrupt                        : 1; //bit 12

            ULONG bPipeC_Plane1FlipDoneInterrupt                        : 1; //bit 13
            ULONG bPipeC_Plane2FlipDoneInterrupt                        : 1; //bit 14
            ULONG bPipeC_Plane3FlipDoneInterrupt                        : 1; //bit 15

            ULONG bPipeA_Plane1FlipQueueEmptyInterrupt                  : 1; //bit 16
            ULONG bPipeA_Plane2FlipQueueEmptyInterrupt                  : 1; //bit 17
            ULONG bPipeA_Plane3FlipQueueEmptyInterrupt                  : 1; //bit 18

            ULONG bPipeB_Plane1FlipQueueEmptyInterrupt                  : 1; //bit 19
            ULONG bPipeB_Plane2FlipQueueEmptyInterrupt                  : 1; //bit 20
            ULONG bPipeB_Plane3FlipQueueEmptyInterrupt                  : 1; //bit 21

            ULONG bPipeC_Plane1FlipQueueEmptyInterrupt                  : 1; //bit 22
            ULONG bPipeC_Plane2FlipQueueEmptyInterrupt                  : 1; //bit 23
            ULONG bPipeC_Plane3FlipQueueEmptyInterrupt                  : 1; //bit 24

            ULONG bDEMiscSVMWaitDescriptorCompleted                     : 1; // bit 25
            ULONG bDEMiscSVMVTDFault                                    : 1; // bit 26
            ULONG bDEMiscSVMPRQEvent                                    : 1; // bit 27


            ULONG bPipeA_Plane4FlipDoneInterrupt                        : 1; // bit 28
            ULONG bPipeB_Plane4FlipDoneInterrupt                        : 1; // bit 29
            ULONG bPSR2GTCLockLoss                                      : 1; // bit 30
            ULONG bVECSWatchDogCounterExcd								: 1; // bit 31
        };
    };
    union
    {
        ULONG ulValue4;
        struct
        {
            ULONG bMIPIAInterrupt                                       : 1; // bit 0
            ULONG bMIPICInterrupt                                       : 1; // bit 1
            ULONG bLPEPipeAInterrupt                                    : 1; // bit 2
            ULONG bLPEPipeBInterrupt                                    : 1; // bit 3

            ULONG bISPInterrupt                                         : 1; // bit 4
            ULONG bVEDBlockInterrupt                                    : 1; // bit 5
            ULONG bVEDPowerInterrupt                                    : 1; // bit 6
            ULONG bPipeA_Plane4FlipQueueEmptyInterrupt                  : 1; // bit 7

            ULONG bPipeB_Plane4FlipQueueEmptyInterrupt                  : 1; // bit 8
            ULONG bLPEPipeCInterrupt                                    : 1; // bit 9
            ULONG bGTPMCoreToUncoreTrapInterrupt                        : 1; //bit 10
            ULONG bWDBoxEndofFrameInterrupt                             : 1; //bit 11 corresponds to WDBOX_END_OF_FRAME_INTERRUPT = 0X800, in INTERRUPT_UNION_VALUE_4
            
            ULONG bIntDP_HDMIEInterrupt                                 : 1; // Bit 12// skl ddi - e hot plug interrupt
            ULONG bIntDP_HDMIE_SPInterrupt                              : 1; // Bit 13
            ULONG bRenderTDLRetryInterrupt                              : 1; // bit 14
            ULONG bPinningContextSwitch                                 : 1; // Bit 15
            ULONG bPinningUserInterrupt                                 : 1; // Bit 16
            ULONG bDEMisc_WDCombinedInterrupt                           : 1; // bit 17 corresponds to DEMISC_WD_COMBINED_INTERRUPT  = 0x20000, in INTERRUPT_UNION_VALUE_4

            ULONG bPipeA_Underrun                                       : 1; // bit 18
            ULONG bPipeB_Underrun                                       : 1; // bit 19
            ULONG bPipeC_Underrun                                       : 1; // bit 20
            ULONG bPipeC_Plane4FlipDoneInterrupt                        : 1; // bit 21
            ULONG bInvalidGTTPageTableEntry                             : 1; // bit 22
            ULONG bInvalidPageTableEntryData                            : 1; // bit 23
            ULONG bVSync_PipeDInterrupt                                 : 1; // BIT 24
            ULONG bVBlank_PipeDInterrupt                                : 1; // BIT 25
            ULONG bIntDP_HDMIFInterrupt                                 : 1; // Bit 26// ddi - f hot plug interrupt 
            ULONG ulReserved_Bits31_27                                  : 5; // bits 31:27
        };
    };
    union
    {
        ULONG ulValue5;
        struct
        {
            ULONG PipeA_Plane1GTTFaultStatus                            : 1; //bit 0
            ULONG PipeA_Plane2GTTFaultStatus                            : 1; //bit 1
            ULONG PipeA_Plane3GTTFaultStatus                            : 1; //bit 2
            ULONG PipeA_Plane4GTTFaultStatus                            : 1; //bit 3
            ULONG PipeA_CursorGTTFaultStatus                            : 1; //bit 4

            ULONG PipeB_Plane1GTTFaultStatus                            : 1; //bit 5
            ULONG PipeB_Plane2GTTFaultStatus                            : 1; //bit 6
            ULONG PipeB_Plane3GTTFaultStatus                            : 1; //bit 7
            ULONG PipeB_Plane4GTTFaultStatus                            : 1; //bit 8
            ULONG PipeB_CursorGTTFaultStatus                            : 1; //bit 9

            ULONG PipeC_Plane1GTTFaultStatus                            : 1; //bit 10
            ULONG PipeC_Plane2GTTFaultStatus                            : 1; //bit 11
            ULONG PipeC_Plane3GTTFaultStatus                            : 1; //bit 12
            ULONG PipeC_Plane4GTTFaultStatus                            : 1; //bit 13
            ULONG PipeC_CursorGTTFaultStatus                            : 1; //bit 14

            ULONG IntDP_HDMIB_SCDCInterrupt							: 1; //bit 15
            ULONG IntDP_HDMIC_SCDCInterrupt							: 1; //bit 16
            ULONG IntDP_HDMID_SCDCInterrupt							: 1; //bit 17
            ULONG IntDP_HDMIE_SCDCInterrupt							: 1; //bit 18
            ULONG IntDP_HDMIF_SCDCInterrupt							: 1; //bit 19

            ULONG ulReserved_Bits31_20                                  : 12; // bits 31:20
        };
    };

}SB_INTERRUPT_ARGS_48, *PSB_INTERRUPT_ARGS_48;


typedef struct _SB_INTERRUPT_ARGS_28
{
    INTERRUPT_OPERATION eOperation; // Data structure for interrupt operations
    ULONG ulPrivateData; // Private Interrupt Data. This will not be used in ILK and GT since enabling/disabling of all interrupts has become much simpler.. 
    union
    {
        ULONG ulValue;
        struct
        {
            //1. Hot Plug Interrupts Definitions - Starts Here

            ULONG    bIntegratedCRTInterrupt : 1;    // Bit 0
            ULONG    ulReservedBit : 1;    // BIT 1
            ULONG    bInterruptReserved1 : 1;    // Bit 2
            ULONG    bInterruptReserved2 : 1;    // Bit 3 //From Gen6 onwards,no need to register for this event as sDVO on Port C is disabled..
            ULONG    bIntDP_HDMIAInterrupt : 1;    // Bit 4  //New Introduction from ILK onwards
            ULONG    bIntDP_HDMIBInterrupt : 1;    // Bit 5
            ULONG    bIntDP_HDMICInterrupt : 1;    // Bit 6
            ULONG    bIntDP_HDMIDInterrupt : 1;    // Bit 7
            ULONG    bIntDP_HDMIA_SPInterrupt : 1;    // Bit 8 //New Introduction from ILK onwards
            ULONG    bIntDP_HDMIB_SPInterrupt : 1;    // Bit 9
            ULONG    bIntDP_HDMIC_SPInterrupt : 1;    // Bit 10
            ULONG    bIntDP_HDMID_SPInterrupt : 1;    // Bit 11            

                                                      //1. Hot Plug Interrupts Definitions - Ends Here

                                                      //2. Render Geyserville Interrupts Definitions - Starts Here

                                                      //Render Geyserville Interrupts common till ILK Platform
            ULONG    bRen_Gey_SoftwareCommandCompleteInterrupt : 1; // bit 12 // Render GeyserVille Interrupt             
            ULONG    bRen_Gey_EvaluatedFrequencyChangeInterrupt : 1; // bit 13 // Render GeyserVille Interrupt            

                                                                     //New Render Geyserville Interrupts exists only in ILK
            ULONG    bRen_Gey_AvgBusyThreshold : 1; // bit 14 // Render GeyserVille Interrupt
            ULONG    bRen_Gey_ContinuousBusyThreshold : 1; // bit 15 // Render GeyserVille Interrupt            

                                                           //Render Geyserville Common between ILK and GT
            ULONG    bRen_Gey_UpEvaluationIntervalInterrupt : 1; // bit 16 // Render GeyserVille Interrupt 
            ULONG    bRen_Gey_DownEvaluationIntervalInterrupt : 1; // bit 17 // Render GeyserVille Interrupt

                                                                   //Render Geyserville Introduced from GT
            ULONG    bRen_Gey_Controller_Disable_StateInterrupt : 1; // bit 18 // Render GeyserVille Interrupt

                                                                     //2. Render Geyserville Interrupts Definitions - Ends Here


                                                                     //3. Basic Render Interrupt Definitions - Starts Here

            ULONG    bDebugInterrupt : 1; // Bit 19 Gen4 Onwards
            ULONG    bPipeControlNotifyInterrupt : 1; // Bit 20 Gen4 Onwards
            ULONG    bRenderUserInterrupt : 1; // Bit 21 Render Cmd UI      
            ULONG    bRenderMMIOSyncFlushStatus : 1; // Bit 22
            ULONG    bRenderWatchDogCounterExcd : 1; // Bit 23 //ILK Onwards           
            ULONG    bRenderASContextSwitch : 1; // Bit 24 //ILK Onwards           
            ULONG    bRenderPageFault : 1; // Bit 25 //ILK Onwards           

                                           //3. Basic Render Interrupt Definitions - Ends Here          

                                           //4. Media/Video Interrupt Definitions - Starts Here
            ULONG    bVideoUserInterrupt : 1; // Bit 26 Gen4 Onwards
            ULONG    bVideoDecPipelineCntrExceed : 1; // Bit 27 Gen4 Onwards..Same as Video Command Streamer WatchDog Counter Exceeded in GT            
                                                      //Following are valid from GT
            ULONG    bVideoMIFlush_DWNotify : 1; // Bit 28
            ULONG    bVideoMMIOSyncFlushStatus : 1; // Bit 29                 
            ULONG    bVideoASContextSwitch : 1; // Bit 30
            ULONG    bVideoPageFault : 1; // Bit 31

                                          //4. Media/Video Interrupt Definitions - Ends Here

        };
    };

    union
    {
        ULONG ulValue1;
        struct
        {
            //5. Remaining Power Conservation Interrupt Starts here            
            ULONG    bLBPC_PipeAInterrupt : 1;    // Bit 0 - crestline and after. Doesnt exist from ILK Onwards            
            ULONG    bLBPC_PipeBInterrupt : 1;    // Bit 1 - crestline and after. Doesnt exist from ILK Onwards            
            ULONG    bDPST_HistInterrupt : 1;    // Bit 2 - crestline and after            
            ULONG    bDPST_PhaseInInterrupt : 1;    // Bit 3 - crestline and after           

                                                    //Valid from GT Onwards
            ULONG    bPCUDriverMBEvent : 1; // Bit 4
            ULONG    bPCRenderFreqDownwardDuringRC6Timeout : 1; // Bit 5
            ULONG    bPC_RPUpThresholdIntr : 1; // Bit 6
            ULONG    bPC_RPDownThresholdIntr : 1; // Bit 7

                                                  //5. Remaining Power Conservation Interrupt Ends here

                                                  //6. Blitter Interrupts from GT Onwards Starts here

            ULONG    bBlitterASContextSwitch : 1; // Bit 8            
            ULONG    bBlitterMIFlush_DWNotify : 1; // Bit 9
            ULONG    bBlitterMMIOSyncFlushStatus : 1; // Bit 10
            ULONG    bBlitterMI_User_Interrupt : 1; // Bit 11
            ULONG    bBlitterPageFault : 1; // Bit 12
                                            //6. Blitter Interrupts from GT Onwards Ends here    


                                            //7. Misc Interrupts Category Starts here
            ULONG    bVSync_PipeAInterrupt : 1;    // Bit 13 //Not Required
            ULONG    bVSync_PipeBInterrupt : 1;    // Bit 14 //Not Required
            ULONG    bVBlank_PipeAInterrupt : 1;    // Bit 15
            ULONG    bVBlank_PipeBInterrupt : 1;    // Bit 16            
            ULONG    bGSESystemLevel : 1;    // Bit 17  Valid from ILK Replacement for ASLE Interrupt           
            ULONG    bVblankTPV : 1;    // BIT 18 //Used for TPV Vblank Interrupt
            ULONG    bASLEInterrupt : 1;    // Bit 19  Need to remove Once MP Cleans up the ASLE INterrupt Stuff
            ULONG    bAllFirstLevelInterrupts : 1;    // BIT 20 //Used for Enabling/Disabling of Interrupts..

                                                      //7. Misc Interrupts Category Ends here

                                                      //8. New added Interrupts
            ULONG    bSpritePlaneAFlipDoneInterrupt : 1;    // BIT 21 //Used for Enabling/Disabling of Sprite Plane A Flip Done Interrupt..
            ULONG    bSpritePlaneBFlipDoneInterrupt : 1;    // BIT 22 //Used for Enabling/Disabling of Sprite Plane B Flip Done Interrupt..

            ULONG    bVSync_PipeCInterrupt : 1;    // BIT 23
            ULONG    bVBlank_PipeCInterrupt : 1;    // BIT 24
            ULONG    bSpritePlaneCFlipDoneInterrupt : 1;    // BIT 25

            ULONG    bAudioHDCPRequestInterruptA : 1;    // BIT 26 //Audio HDCP request for transcoder A
            ULONG    bAudioHDCPRequestInterruptB : 1;    // BIT 27 //Audio HDCP request for transcoder B
            ULONG    bAudioHDCPRequestInterruptC : 1;    // BIT 28 //Audio HDCP request for transcoder C
            ULONG    bAudioHDCPRequestInterrupt : 1;    // BIT 29 //Audio HDCP request for pre ilk platforms            

            ULONG   bPerfMonBufferHalfFullInterrupt : 1;    // BIT 30

            ULONG   ulReserved_Bit31 : 1;    // Bit 31

        };
    };

    union
    {
        ULONG ulValue2;
        struct
        {
            // This sections contains error/debug status bits
            ULONG bFIFOUnderrun_PipeAInterrupt : 1; // bit 0 
            ULONG bCRC_Error_PipeAInterrupt : 1; // bit 1
            ULONG bCRC_Done_PipeAInterrupt : 1; // bit 2

            ULONG bFIFOUnderrun_PipeBInterrupt : 1; // bit 3
            ULONG bCRC_Error_PipeBInterrupt : 1; // bit 4
            ULONG bCRC_Done_PipeBInterrupt : 1; // bit 5

            ULONG bFIFOUnderrun_PipeCInterrupt : 1; // bit 6
            ULONG bCRC_Error_PipeCInterrupt : 1; // bit 7
            ULONG bCRC_Done_PipeCInterrupt : 1; // bit 8

                                                // VE (Video Enhancement) Interrupt Definitions - Starts Here - Valid from Gen7_5 (HSW+) onward
            ULONG bVEUserInterrupt : 1; // bit 9
            ULONG bVEMMIOSyncFlushStatus : 1; // bit 10
            ULONG bVECmdParserMasterError : 1; // bit 11
            ULONG bVEMIFlush_DWNotify : 1; // bit 12
                                           // VE (Video Enhancement) Interrupt Definitions - Ends Here

                                           // other interrupt bits that don't fit into the previous dwords
            ULONG bRenderParityError : 1; // Bit 13 Gen7 Onwards

            ULONG bVideoPavpUnsolicitedAttack : 1; // Bit 14 Gen7 Onwards

                                                   //Below are valid from BDW
            ULONG bVideoUserInterrupt2 : 1; // Bit 15 
            ULONG bVideoDecPipelineCntrExceed2 : 1; // Bit 16 
            ULONG bVideoMIFlush_DWNotify2 : 1; // Bit 17
            ULONG bVideoMMIOSyncFlushStatus2 : 1; // Bit 18                 
            ULONG bVideoASContextSwitch2 : 1; // Bit 19
            ULONG bVideoPageFault2 : 1; // Bit 20
            ULONG bVideoPavpUnsolicitedAttack2 : 1; // Bit 21

            ULONG bGuCSHIMError : 1;    // bit 22
            ULONG bGuCDMAINTError : 1;    // bit 23                
            ULONG bGuCDMADone : 1;    // bit 24                
            ULONG bGuCDoorBellRang : 1;    // bit 25
            ULONG bGuCIOMMUSentMsgtoGuc : 1;    // bit 26
            ULONG bGuCSemaphoreSignaled : 1;    // bit 27
            ULONG bGuCDisplayEventRecieved : 1;    // bit 28
            ULONG bGuCExecutionError : 1;    // bit 29
            ULONG bGuCInterruptToHost : 1;    // bit 30

            ULONG bCSTRInvalidTileDetection : 1;    // bits 31
        };
    };

    union
    {
        ULONG ulValue3;
        struct
        {
            // This sections contains VEC/WiDi interrupts
            ULONG bVECSContextSwitchInterrupt : 1; // bit 0
            ULONG bVECSWaitOnSemaphore : 1; // bit 1
            ULONG bWDBoxInterrupt : 1; // bit 2
            ULONG bDPST_HistInterruptPipeB : 1;// bit 3
            ULONG bDPST_PhaseInInterruptPipeB : 1; // bit 4
            ULONG bDPST_HistInterruptPipeC : 1;// bit 5
            ULONG bDPST_PhaseInInterruptPipeC : 1; // bit 6 

            ULONG bPipeA_Plane1FlipDoneInterrupt : 1; //bit 7
            ULONG bPipeA_Plane2FlipDoneInterrupt : 1; //bit 8
            ULONG bPipeA_Plane3FlipDoneInterrupt : 1; //bit 9

            ULONG bPipeB_Plane1FlipDoneInterrupt : 1; //bit 10
            ULONG bPipeB_Plane2FlipDoneInterrupt : 1; //bit 11
            ULONG bPipeB_Plane3FlipDoneInterrupt : 1; //bit 12

            ULONG bPipeC_Plane1FlipDoneInterrupt : 1; //bit 13
            ULONG bPipeC_Plane2FlipDoneInterrupt : 1; //bit 14
            ULONG bPipeC_Plane3FlipDoneInterrupt : 1; //bit 15

            ULONG bPipeA_Plane1FlipQueueEmptyInterrupt : 1; //bit 16
            ULONG bPipeA_Plane2FlipQueueEmptyInterrupt : 1; //bit 17
            ULONG bPipeA_Plane3FlipQueueEmptyInterrupt : 1; //bit 18

            ULONG bPipeB_Plane1FlipQueueEmptyInterrupt : 1; //bit 19
            ULONG bPipeB_Plane2FlipQueueEmptyInterrupt : 1; //bit 20
            ULONG bPipeB_Plane3FlipQueueEmptyInterrupt : 1; //bit 21

            ULONG bPipeC_Plane1FlipQueueEmptyInterrupt : 1; //bit 22
            ULONG bPipeC_Plane2FlipQueueEmptyInterrupt : 1; //bit 23
            ULONG bPipeC_Plane3FlipQueueEmptyInterrupt : 1; //bit 24

            ULONG bDEMiscSVMWaitDescriptorCompleted : 1; // bit 25
            ULONG bDEMiscSVMVTDFault : 1; // bit 26
            ULONG bDEMiscSVMPRQEvent : 1; // bit 27


            ULONG bPipeA_Plane4FlipDoneInterrupt : 1; // bit 28
            ULONG bPipeB_Plane4FlipDoneInterrupt : 1; // bit 29
            ULONG bPSR2GTCLockLoss : 1; // bit 30
            ULONG bVECSWatchDogCounterExcd : 1; // bit 31
        };
    };
    union
    {
        ULONG ulValue4;
        struct
        {
            ULONG bMIPIAInterrupt : 1; // bit 0
            ULONG bMIPICInterrupt : 1; // bit 1
            ULONG bLPEPipeAInterrupt : 1; // bit 2
            ULONG bLPEPipeBInterrupt : 1; // bit 3

            ULONG bISPInterrupt : 1; // bit 4
            ULONG bVEDBlockInterrupt : 1; // bit 5
            ULONG bVEDPowerInterrupt : 1; // bit 6
            ULONG bPipeA_Plane4FlipQueueEmptyInterrupt : 1; // bit 7

            ULONG bPipeB_Plane4FlipQueueEmptyInterrupt : 1; // bit 8
            ULONG bLPEPipeCInterrupt : 1; // bit 9
            ULONG bGTPMCoreToUncoreTrapInterrupt : 1; //bit 10
            ULONG bWDBoxEndofFrameInterrupt : 1; //bit 11 corresponds to WDBOX_END_OF_FRAME_INTERRUPT = 0X800, in INTERRUPT_UNION_VALUE_4

            ULONG bIntDP_HDMIEInterrupt : 1; // Bit 12// skl ddi - e hot plug interrupt
            ULONG bIntDP_HDMIE_SPInterrupt : 1; // Bit 13
            ULONG bRenderTDLRetryInterrupt : 1; // bit 14
            ULONG bPinningContextSwitch : 1; // Bit 15
            ULONG bPinningUserInterrupt : 1; // Bit 16
            ULONG bDEMisc_WDCombinedInterrupt : 1; // bit 17 corresponds to DEMISC_WD_COMBINED_INTERRUPT  = 0x20000, in INTERRUPT_UNION_VALUE_4
            ULONG bPipeA_Underrun : 1;
            ULONG bPipeB_Underrun : 1;
            ULONG bPipeC_Underrun : 1;
            ULONG ulReserved_Bits31_21 : 11;// bits 31:18
        };
    };

}SB_INTERRUPT_ARGS_28, *PSB_INTERRUPT_ARGS_28;

typedef struct _SB_INTERRUPT_ARGS_52
{
    INTERRUPT_OPERATION eOperation; // Data structure for interrupt operations
    ULONG ulPrivateData; // Private Interrupt Data. This will not be used in ILK and GT since enabling/disabling of all interrupts has become much simpler.. 

    ULONG PlatformUsesGen11InterruptArchitecture : 1; // Let Event handler code know that all non-display engines are handled by new Selector methods
    ULONG SelectorInterruptsOccurred : 1; // New for Gen11+  ::  This bit means one of the hierarchical interrupts (has to use selector register) has occurred and needs to be handled by GEN11+ handler
    ULONG LegacyInterruptsOccurred : 1; // New for Gen11+  ::  This bit means use the IntArgs below for handling the interrupts

    IN BOOLEAN HierarchicalInterruptService : 1; // This bit means request for Hirearchial Interrupt services

    IN ULONG ulEngineClass;                           // Can re-use ulValue in union
    IN ULONG ulEngineIntrpt;                          // Can re-use ulValue1 in union

    union
    {
        ULONG ulValue;
        struct
        {
            //1. Hot Plug Interrupts Definitions - Starts Here

            ULONG    bIntegratedCRTInterrupt : 1;    // Bit 0
            ULONG    ulReservedBit : 1;    // Bit 1
            ULONG    bInterruptReserved1 : 1;    // Bit 2
            ULONG    bInterruptReserved2 : 1;    // Bit 3 //From Gen6 onwards,no need to register for this event as sDVO on Port C is disabled..
            ULONG    bIntDP_HDMIAInterrupt : 1;    // Bit 4  //New Introduction from ILK onwards
            ULONG    bIntDP_HDMIBInterrupt : 1;    // Bit 5
            ULONG    bIntDP_HDMICInterrupt : 1;    // Bit 6
            ULONG    bIntDP_HDMIDInterrupt : 1;    // Bit 7
            ULONG    bIntDP_HDMIA_SPInterrupt : 1;    // Bit 8 //New Introduction from ILK onwards
            ULONG    bIntDP_HDMIB_SPInterrupt : 1;    // Bit 9
            ULONG    bIntDP_HDMIC_SPInterrupt : 1;    // Bit 10
            ULONG    bIntDP_HDMID_SPInterrupt : 1;    // Bit 11            

                                                      //1. Hot Plug Interrupts Definitions - Ends Here

                                                      //2. Render Geyserville Interrupts Definitions - Starts Here

                                                      //Render Geyserville Interrupts common till ILK Platform
            ULONG    bRen_Gey_SoftwareCommandCompleteInterrupt : 1; // bit 12 // Render GeyserVille Interrupt             
            ULONG    bRen_Gey_EvaluatedFrequencyChangeInterrupt : 1; // bit 13 // Render GeyserVille Interrupt            

                                                                     //New Render Geyserville Interrupts exists only in ILK
            ULONG    bRen_Gey_AvgBusyThreshold : 1; // bit 14 // Render GeyserVille Interrupt
            ULONG    bRen_Gey_ContinuousBusyThreshold : 1; // bit 15 // Render GeyserVille Interrupt            

                                                           //Render Geyserville Common between ILK and GT
            ULONG    bRen_Gey_UpEvaluationIntervalInterrupt : 1; // bit 16 // Render GeyserVille Interrupt 
            ULONG    bRen_Gey_DownEvaluationIntervalInterrupt : 1; // bit 17 // Render GeyserVille Interrupt

                                                                   //Render Geyserville Introduced from GT
            ULONG    bRen_Gey_Controller_Disable_StateInterrupt : 1; // bit 18 // Render GeyserVille Interrupt

                                                                     //2. Render Geyserville Interrupts Definitions - Ends Here


                                                                     //3. Basic Render Interrupt Definitions - Starts Here

            ULONG    bDebugInterrupt : 1; // Bit 19 Gen4 Onwards
            ULONG    bPipeControlNotifyInterrupt : 1; // Bit 20 Gen4 Onwards
            ULONG    bRenderUserInterrupt : 1; // Bit 21 Render Cmd UI      
            ULONG    bRenderMMIOSyncFlushStatus : 1; // Bit 22
            ULONG    bRenderWatchDogCounterExcd : 1; // Bit 23 //ILK Onwards           
            ULONG    bRenderASContextSwitch : 1; // Bit 24 //ILK Onwards           
            ULONG    bRenderPageFault : 1; // Bit 25 //ILK Onwards           

                                           //3. Basic Render Interrupt Definitions - Ends Here          

                                           //4. Media/Video Interrupt Definitions - Starts Here
            ULONG    bVideoUserInterrupt : 1; // Bit 26 Gen4 Onwards
            ULONG    bVideoDecPipelineCntrExceed : 1; // Bit 27 Gen4 Onwards..Same as Video Command Streamer WatchDog Counter Exceeded in GT            
                                                      //Following are valid from GT
            ULONG    bVideoMIFlush_DWNotify : 1; // Bit 28
            ULONG    bVideoMMIOSyncFlushStatus : 1; // Bit 29                 
            ULONG    bVideoASContextSwitch : 1; // Bit 30
            ULONG    bVideoPageFault : 1; // Bit 31

                                          //4. Media/Video Interrupt Definitions - Ends Here

        };
    };

    union
    {
        ULONG ulValue1;
        struct
        {
            //5. Remaining Power Conservation Interrupt Starts here            
            ULONG    bLBPC_PipeAInterrupt : 1;    // Bit 0 - crestline and after. Doesnt exist from ILK Onwards            
            ULONG    bLBPC_PipeBInterrupt : 1;    // Bit 1 - crestline and after. Doesnt exist from ILK Onwards            
            ULONG    bDPST_HistInterrupt : 1;    // Bit 2 - crestline and after            
            ULONG    bDPST_PhaseInInterrupt : 1;    // Bit 3 - crestline and after           

                                                    //Valid from GT Onwards
            ULONG    bPCUDriverMBEvent : 1; // Bit 4
            ULONG    bPCRenderFreqDownwardDuringRC6Timeout : 1; // Bit 5
            ULONG    bPC_RPUpThresholdIntr : 1; // Bit 6
            ULONG    bPC_RPDownThresholdIntr : 1; // Bit 7

                                                  //5. Remaining Power Conservation Interrupt Ends here

                                                  //6. Blitter Interrupts from GT Onwards Starts here

            ULONG    bBlitterASContextSwitch : 1; // Bit 8            
            ULONG    bBlitterMIFlush_DWNotify : 1; // Bit 9
            ULONG    bBlitterMMIOSyncFlushStatus : 1; // Bit 10
            ULONG    bBlitterMI_User_Interrupt : 1; // Bit 11
            ULONG    bBlitterPageFault : 1; // Bit 12
                                            //6. Blitter Interrupts from GT Onwards Ends here    


                                            //7. Misc Interrupts Category Starts here
            ULONG    bVSync_PipeAInterrupt : 1;    // Bit 13 //Not Required
            ULONG    bVSync_PipeBInterrupt : 1;    // Bit 14 //Not Required
            ULONG    bVBlank_PipeAInterrupt : 1;    // Bit 15
            ULONG    bVBlank_PipeBInterrupt : 1;    // Bit 16            
            ULONG    bGSESystemLevel : 1;    // Bit 17  Valid from ILK Replacement for ASLE Interrupt           
            ULONG    bVblankTPV : 1;    // BIT 18 //Used for TPV Vblank Interrupt
            ULONG    bASLEInterrupt : 1;    // Bit 19  Need to remove Once MP Cleans up the ASLE INterrupt Stuff
            ULONG    bAllFirstLevelInterrupts : 1;    // BIT 20 //Used for Enabling/Disabling of Interrupts..

                                                      //7. Misc Interrupts Category Ends here

                                                      //8. New added Interrupts
            ULONG    bSpritePlaneAFlipDoneInterrupt : 1;    // BIT 21 //Used for Enabling/Disabling of Sprite Plane A Flip Done Interrupt..
            ULONG    bSpritePlaneBFlipDoneInterrupt : 1;    // BIT 22 //Used for Enabling/Disabling of Sprite Plane B Flip Done Interrupt..

            ULONG    bVSync_PipeCInterrupt : 1;    // BIT 23
            ULONG    bVBlank_PipeCInterrupt : 1;    // BIT 24
            ULONG    bSpritePlaneCFlipDoneInterrupt : 1;    // BIT 25

            ULONG    bAudioHDCPRequestInterruptA : 1;    // BIT 26 //Audio HDCP request for transcoder A
            ULONG    bAudioHDCPRequestInterruptB : 1;    // BIT 27 //Audio HDCP request for transcoder B
            ULONG    bAudioHDCPRequestInterruptC : 1;    // BIT 28 //Audio HDCP request for transcoder C
            ULONG    bAudioHDCPRequestInterrupt : 1;    // BIT 29 //Audio HDCP request for pre ilk platforms            

            ULONG   bPerfMonBufferHalfFullInterrupt : 1;    // BIT 30

            ULONG   ulReserved_Bit31 : 1;    // Bit 31

        };
    };

    union
    {
        ULONG ulValue2;
        struct
        {
            // This sections contains error/debug status bits
            ULONG bFIFOUnderrun_PipeAInterrupt : 1; // bit 0 
            ULONG bCRC_Error_PipeAInterrupt : 1; // bit 1
            ULONG bCRC_Done_PipeAInterrupt : 1; // bit 2

            ULONG bFIFOUnderrun_PipeBInterrupt : 1; // bit 3
            ULONG bCRC_Error_PipeBInterrupt : 1; // bit 4
            ULONG bCRC_Done_PipeBInterrupt : 1; // bit 5

            ULONG bFIFOUnderrun_PipeCInterrupt : 1; // bit 6
            ULONG bCRC_Error_PipeCInterrupt : 1; // bit 7
            ULONG bCRC_Done_PipeCInterrupt : 1; // bit 8

                                                // VE (Video Enhancement) Interrupt Definitions - Starts Here - Valid from Gen7_5 (HSW+) onward
            ULONG bVEUserInterrupt : 1; // bit 9
            ULONG bVEMMIOSyncFlushStatus : 1; // bit 10
            ULONG bVECmdParserMasterError : 1; // bit 11
            ULONG bVEMIFlush_DWNotify : 1; // bit 12
                                           // VE (Video Enhancement) Interrupt Definitions - Ends Here

                                           // other interrupt bits that don't fit into the previous dwords
            ULONG bRenderParityError : 1; // Bit 13 Gen7 Onwards

            ULONG bVideoPavpUnsolicitedAttack : 1; // Bit 14 Gen7 Onwards

                                                   //Below are valid from BDW
            ULONG bVideoUserInterrupt2 : 1; // Bit 15 
            ULONG bVideoDecPipelineCntrExceed2 : 1; // Bit 16 
            ULONG bVideoMIFlush_DWNotify2 : 1; // Bit 17
            ULONG bVideoMMIOSyncFlushStatus2 : 1; // Bit 18                 
            ULONG bVideoASContextSwitch2 : 1; // Bit 19
            ULONG bVideoPageFault2 : 1; // Bit 20
            ULONG bVideoPavpUnsolicitedAttack2 : 1; // Bit 21

            ULONG bGuCSHIMError : 1;    // bit 22
            ULONG bGuCDMAINTError : 1;    // bit 23                
            ULONG bGuCDMADone : 1;    // bit 24                
            ULONG bGuCDoorBellRang : 1;    // bit 25
            ULONG bGuCIOMMUSentMsgtoGuc : 1;    // bit 26
            ULONG bGuCSemaphoreSignaled : 1;    // bit 27
            ULONG bGuCDisplayEventRecieved : 1;    // bit 28
            ULONG bGuCExecutionError : 1;    // bit 29
            ULONG bGuCInterruptToHost : 1;    // bit 30

            ULONG bCSTRInvalidTileDetection : 1;    // bits 31
        };
    };

    union
    {
        ULONG ulValue3;
        struct
        {
            // This sections contains VEC/WiDi interrupts
            ULONG bVECSContextSwitchInterrupt : 1; // bit 0
            ULONG bVECSWaitOnSemaphore : 1; // bit 1
            ULONG bWDBoxInterrupt : 1; // bit 2
            ULONG bDPST_HistInterruptPipeB : 1;// bit 3
            ULONG bDPST_PhaseInInterruptPipeB : 1; // bit 4
            ULONG bDPST_HistInterruptPipeC : 1;// bit 5
            ULONG bDPST_PhaseInInterruptPipeC : 1; // bit 6 

            ULONG bPipeA_Plane1FlipDoneInterrupt : 1; //bit 7
            ULONG bPipeA_Plane2FlipDoneInterrupt : 1; //bit 8
            ULONG bPipeA_Plane3FlipDoneInterrupt : 1; //bit 9

            ULONG bPipeB_Plane1FlipDoneInterrupt : 1; //bit 10
            ULONG bPipeB_Plane2FlipDoneInterrupt : 1; //bit 11
            ULONG bPipeB_Plane3FlipDoneInterrupt : 1; //bit 12

            ULONG bPipeC_Plane1FlipDoneInterrupt : 1; //bit 13
            ULONG bPipeC_Plane2FlipDoneInterrupt : 1; //bit 14
            ULONG bPipeC_Plane3FlipDoneInterrupt : 1; //bit 15

            ULONG bPipeA_Plane1FlipQueueEmptyInterrupt : 1; //bit 16
            ULONG bPipeA_Plane2FlipQueueEmptyInterrupt : 1; //bit 17
            ULONG bPipeA_Plane3FlipQueueEmptyInterrupt : 1; //bit 18

            ULONG bPipeB_Plane1FlipQueueEmptyInterrupt : 1; //bit 19
            ULONG bPipeB_Plane2FlipQueueEmptyInterrupt : 1; //bit 20
            ULONG bPipeB_Plane3FlipQueueEmptyInterrupt : 1; //bit 21

            ULONG bPipeC_Plane1FlipQueueEmptyInterrupt : 1; //bit 22
            ULONG bPipeC_Plane2FlipQueueEmptyInterrupt : 1; //bit 23
            ULONG bPipeC_Plane3FlipQueueEmptyInterrupt : 1; //bit 24

            ULONG bDEMiscSVMWaitDescriptorCompleted : 1; // bit 25
            ULONG bDEMiscSVMVTDFault : 1; // bit 26
            ULONG bDEMiscSVMPRQEvent : 1; // bit 27


            ULONG bPipeA_Plane4FlipDoneInterrupt : 1; // bit 28
            ULONG bPipeB_Plane4FlipDoneInterrupt : 1; // bit 29
            ULONG bPSR2GTCLockLoss : 1; // bit 30
            ULONG bVECSWatchDogCounterExcd : 1; // bit 31
        };
    };
    union
    {
        ULONG ulValue4;
        struct
        {
            ULONG bMIPIAInterrupt : 1; // bit 0
            ULONG bMIPICInterrupt : 1; // bit 1
            ULONG bLPEPipeAInterrupt : 1; // bit 2
            ULONG bLPEPipeBInterrupt : 1; // bit 3

            ULONG bISPInterrupt : 1; // bit 4
            ULONG bVEDBlockInterrupt : 1; // bit 5
            ULONG bVEDPowerInterrupt : 1; // bit 6
            ULONG bPipeA_Plane4FlipQueueEmptyInterrupt : 1; // bit 7

            ULONG bPipeB_Plane4FlipQueueEmptyInterrupt : 1; // bit 8
            ULONG bLPEPipeCInterrupt : 1; // bit 9
            ULONG bGTPMCoreToUncoreTrapInterrupt : 1; //bit 10
            ULONG bWDBoxEndofFrameInterrupt : 1; //bit 11 corresponds to WDBOX_END_OF_FRAME_INTERRUPT = 0X800, in INTERRUPT_UNION_VALUE_4

            ULONG bIntDP_HDMIEInterrupt : 1; // Bit 12// skl ddi - e hot plug interrupt
            ULONG bIntDP_HDMIE_SPInterrupt : 1; // Bit 13
            ULONG bRenderTDLRetryInterrupt : 1; // bit 14
            ULONG bPinningContextSwitch : 1; // Bit 15
            ULONG bPinningUserInterrupt : 1; // Bit 16
            ULONG bDEMisc_WDCombinedInterrupt : 1; // bit 17 corresponds to DEMISC_WD_COMBINED_INTERRUPT  = 0x20000, in INTERRUPT_UNION_VALUE_4

            ULONG bPipeA_Underrun : 1; // bit 18
            ULONG bPipeB_Underrun : 1; // bit 19
            ULONG bPipeC_Underrun : 1; // bit 20
            ULONG bPipeC_Plane4FlipDoneInterrupt : 1; // bit 21
            ULONG bInvalidGTTPageTableEntry : 1; // bit 22
            ULONG bInvalidPageTableEntryData : 1; // bit 23
            ULONG bVSync_PipeDInterrupt : 1; // BIT 24
            ULONG bVBlank_PipeDInterrupt : 1; // BIT 25
            ULONG bIntDP_HDMIFInterrupt : 1; // Bit 26// ddi - f hot plug interrupt 
            ULONG bIntDP_HDMIF_SPInterrupt : 1; // Bit 27
            ULONG bWDBox2Interrupt : 1; // bit 28
            ULONG bWDBox2EndofFrameInterrupt : 1; // bit 29
            ULONG bDEMisc_WD2CombinedInterrupt : 1; // bit 30
            ULONG ulReserved_Bits31_ulValue4 : 1; // bit 31
        };
    };
    union
    {
        ULONG ulValue5;
        struct
        {
            ULONG PipeA_Plane1GTTFaultStatus : 1; //bit 0
            ULONG PipeA_Plane2GTTFaultStatus : 1; //bit 1
            ULONG PipeA_Plane3GTTFaultStatus : 1; //bit 2
            ULONG PipeA_Plane4GTTFaultStatus : 1; //bit 3
            ULONG PipeA_CursorGTTFaultStatus : 1; //bit 4

            ULONG PipeB_Plane1GTTFaultStatus : 1; //bit 5
            ULONG PipeB_Plane2GTTFaultStatus : 1; //bit 6
            ULONG PipeB_Plane3GTTFaultStatus : 1; //bit 7
            ULONG PipeB_Plane4GTTFaultStatus : 1; //bit 8
            ULONG PipeB_CursorGTTFaultStatus : 1; //bit 9

            ULONG PipeC_Plane1GTTFaultStatus : 1; //bit 10
            ULONG PipeC_Plane2GTTFaultStatus : 1; //bit 11
            ULONG PipeC_Plane3GTTFaultStatus : 1; //bit 12
            ULONG PipeC_Plane4GTTFaultStatus : 1; //bit 13
            ULONG PipeC_CursorGTTFaultStatus : 1; //bit 14

            ULONG IntDP_HDMIB_SCDCInterrupt : 1; //bit 15
            ULONG IntDP_HDMIC_SCDCInterrupt : 1; //bit 16
            ULONG IntDP_HDMID_SCDCInterrupt : 1; //bit 17
            ULONG IntDP_HDMIE_SCDCInterrupt : 1; //bit 18
            ULONG IntDP_HDMIF_SCDCInterrupt : 1; //bit 19

            ULONG bPipeA_Plane5FlipDoneInterrupt : 1; // bit 20
            ULONG bPipeA_Plane6FlipDoneInterrupt : 1; // bit 21
            ULONG bPipeA_Plane7FlipDoneInterrupt : 1; // bit 22
            ULONG bPipeB_Plane5FlipDoneInterrupt : 1; // bit 23
            ULONG bPipeB_Plane6FlipDoneInterrupt : 1; // bit 24
            ULONG bPipeB_Plane7FlipDoneInterrupt : 1; // bit 25
            ULONG bPipeC_Plane5FlipDoneInterrupt : 1; // bit 26
            ULONG bPipeC_Plane6FlipDoneInterrupt : 1; // bit 27
            ULONG bPipeC_Plane7FlipDoneInterrupt : 1; // bit 28
            ULONG bPipeD_Plane5FlipDoneInterrupt : 1; // bit 29
            ULONG bPipeD_Plane6FlipDoneInterrupt : 1; // bit 30
            ULONG bPipeD_Plane7FlipDoneInterrupt : 1; // bit 31
        };
    };
    union
    {
        ULONG ulValue6;
        struct
        {
            ULONG PipeA_Plane5GTTFaultStatus : 1; //bit 0
            ULONG PipeA_Plane6GTTFaultStatus : 1; //bit 1
            ULONG PipeA_Plane7GTTFaultStatus : 1; //bit 2
            ULONG PipeB_Plane5GTTFaultStatus : 1; //bit 3
            ULONG PipeB_Plane6GTTFaultStatus : 1; //bit 4
            ULONG PipeB_Plane7GTTFaultStatus : 1; //bit 5
            ULONG PipeC_Plane5GTTFaultStatus : 1; //bit 6
            ULONG PipeC_Plane6GTTFaultStatus : 1; //bit 7
            ULONG PipeC_Plane7GTTFaultStatus : 1; //bit 8
            ULONG PipeD_Plane5GTTFaultStatus : 1; //bit 9
            ULONG PipeD_Plane6GTTFaultStatus : 1; //bit 10
            ULONG PipeD_Plane7GTTFaultStatus : 1; //bit 11
            ULONG bPipeD_Plane1FlipDoneInterrupt : 1; //bit 12
            ULONG bPipeD_Plane2FlipDoneInterrupt : 1; //bit 13
            ULONG bPipeD_Plane3FlipDoneInterrupt : 1; //bit 14
            ULONG bPipeD_Plane4FlipDoneInterrupt : 1; //bit 15
            ULONG PipeD_Plane1GTTFaultStatus : 1; //bit 16
            ULONG PipeD_Plane2GTTFaultStatus : 1; //bit 17
            ULONG PipeD_Plane3GTTFaultStatus : 1; //bit 18
            ULONG PipeD_Plane4GTTFaultStatus : 1; //bit 19
            ULONG PipeD_CursorGTTFaultStatus : 1; //bit 20
            ULONG PipeD_DPST_HistInterrupt : 1;// bit 21
            ULONG bCRC_Error_PipeDInterrupt : 1; // bit 22
            ULONG bCRC_Done_PipeDInterrupt : 1; // bit 23
            ULONG bPipeD_Underrun : 1; // bit 24
            ULONG bAudioHDCPRequestInterruptD : 1; // bit 25
            ULONG IntDP_HDMIA_SCDCInterrupt : 1; // bit 26
            ULONG PIPEA_VRRDoubleBufferUpdate : 1; // bit 27
            ULONG PIPEB_VRRDoubleBufferUpdate : 1; // bit 28
            ULONG PIPEC_VRRDoubleBufferUpdate : 1; // bit 29
            ULONG PIPED_VRRDoubleBufferUpdate : 1; // bit 30
            ULONG ulReserved_Bits31_ulValue6 : 1; // bits 31
        };
    };
}SB_INTERRUPT_ARGS_52, *PSB_INTERRUPT_ARGS_52;



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//NOTE: Any change in the interrrupt args structure below has to be reflected in the enum definitions above.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Interrupt Args structure
typedef struct _SB_INTERRUPT_ARGS_56
{
    INTERRUPT_OPERATION eOperation; // Data structure for interrupt operations
    ULONG ulPrivateData; // Private Interrupt Data. This will not be used in ILK and GT since enabling/disabling of all interrupts has become much simpler.. 

    ULONG PlatformUsesGen11InterruptArchitecture : 1; // Let Event handler code know that all non-display engines are handled by new Selector methods
    ULONG SelectorInterruptsOccurred : 1; // New for Gen11+  ::  This bit means one of the hierarchical interrupts (has to use selector register) has occurred and needs to be handled by GEN11+ handler
    ULONG LegacyInterruptsOccurred : 1; // New for Gen11+  ::  This bit means use the IntArgs below for handling the interrupts

    IN BOOLEAN HierarchicalInterruptService : 1; // This bit means request for Hirearchial Interrupt services

    IN ULONG ulEngineClass;                           // Can re-use ulValue in union
    IN ULONG ulEngineIntrpt;                          // Can re-use ulValue1 in union

    union
    {
        ULONG ulValue;
        struct
        {
            //1. Hot Plug Interrupts Definitions - Starts Here

            ULONG    bIntegratedCRTInterrupt : 1;    // Bit 0
            ULONG    ulReservedBit : 1;    // Bit 1
            ULONG    bInterruptReserved1 : 1;    // Bit 2
            ULONG    bInterruptReserved2 : 1;    // Bit 3 //From Gen6 onwards,no need to register for this event as sDVO on Port C is disabled..
            ULONG    bIntDP_HDMIAInterrupt : 1;    // Bit 4  //New Introduction from ILK onwards
            ULONG    bIntDP_HDMIBInterrupt : 1;    // Bit 5
            ULONG    bIntDP_HDMICInterrupt : 1;    // Bit 6
            ULONG    bIntDP_HDMIDInterrupt : 1;    // Bit 7
            ULONG    bIntDP_HDMIA_SPInterrupt : 1;    // Bit 8 //New Introduction from ILK onwards
            ULONG    bIntDP_HDMIB_SPInterrupt : 1;    // Bit 9
            ULONG    bIntDP_HDMIC_SPInterrupt : 1;    // Bit 10
            ULONG    bIntDP_HDMID_SPInterrupt : 1;    // Bit 11            

                                                      //1. Hot Plug Interrupts Definitions - Ends Here

                                                      //2. Render Geyserville Interrupts Definitions - Starts Here

                                                      //Render Geyserville Interrupts common till ILK Platform
            ULONG    bRen_Gey_SoftwareCommandCompleteInterrupt : 1; // bit 12 // Render GeyserVille Interrupt             
            ULONG    bRen_Gey_EvaluatedFrequencyChangeInterrupt : 1; // bit 13 // Render GeyserVille Interrupt            

                                                                     //New Render Geyserville Interrupts exists only in ILK
            ULONG    bRen_Gey_AvgBusyThreshold : 1; // bit 14 // Render GeyserVille Interrupt
            ULONG    bRen_Gey_ContinuousBusyThreshold : 1; // bit 15 // Render GeyserVille Interrupt            

                                                           //Render Geyserville Common between ILK and GT
            ULONG    bRen_Gey_UpEvaluationIntervalInterrupt : 1; // bit 16 // Render GeyserVille Interrupt 
            ULONG    bRen_Gey_DownEvaluationIntervalInterrupt : 1; // bit 17 // Render GeyserVille Interrupt

                                                                   //Render Geyserville Introduced from GT
            ULONG    bRen_Gey_Controller_Disable_StateInterrupt : 1; // bit 18 // Render GeyserVille Interrupt

                                                                     //2. Render Geyserville Interrupts Definitions - Ends Here


                                                                     //3. Basic Render Interrupt Definitions - Starts Here

            ULONG    bDebugInterrupt : 1; // Bit 19 Gen4 Onwards
            ULONG    bPipeControlNotifyInterrupt : 1; // Bit 20 Gen4 Onwards
            ULONG    bRenderUserInterrupt : 1; // Bit 21 Render Cmd UI      
            ULONG    bRenderMMIOSyncFlushStatus : 1; // Bit 22
            ULONG    bRenderWatchDogCounterExcd : 1; // Bit 23 //ILK Onwards           
            ULONG    bRenderASContextSwitch : 1; // Bit 24 //ILK Onwards           
            ULONG    bRenderPageFault : 1; // Bit 25 //ILK Onwards           

                                           //3. Basic Render Interrupt Definitions - Ends Here          

                                           //4. Media/Video Interrupt Definitions - Starts Here
            ULONG    bVideoUserInterrupt : 1; // Bit 26 Gen4 Onwards
            ULONG    bVideoDecPipelineCntrExceed : 1; // Bit 27 Gen4 Onwards..Same as Video Command Streamer WatchDog Counter Exceeded in GT            
                                                      //Following are valid from GT
            ULONG    bVideoMIFlush_DWNotify : 1; // Bit 28
            ULONG    bVideoMMIOSyncFlushStatus : 1; // Bit 29                 
            ULONG    bVideoASContextSwitch : 1; // Bit 30
            ULONG    bVideoPageFault : 1; // Bit 31

                                          //4. Media/Video Interrupt Definitions - Ends Here

        };
    };

    union
    {
        ULONG ulValue1;
        struct
        {
            //5. Remaining Power Conservation Interrupt Starts here            
            ULONG    bLBPC_PipeAInterrupt : 1;    // Bit 0 - crestline and after. Doesnt exist from ILK Onwards            
            ULONG    bLBPC_PipeBInterrupt : 1;    // Bit 1 - crestline and after. Doesnt exist from ILK Onwards            
            ULONG    bDPST_HistInterrupt : 1;    // Bit 2 - crestline and after            
            ULONG    bDPST_PhaseInInterrupt : 1;    // Bit 3 - crestline and after           

                                                    //Valid from GT Onwards
            ULONG    bPCUDriverMBEvent : 1; // Bit 4
            ULONG    bPCRenderFreqDownwardDuringRC6Timeout : 1; // Bit 5
            ULONG    bPC_RPUpThresholdIntr : 1; // Bit 6
            ULONG    bPC_RPDownThresholdIntr : 1; // Bit 7

                                                  //5. Remaining Power Conservation Interrupt Ends here

                                                  //6. Blitter Interrupts from GT Onwards Starts here

            ULONG    bBlitterASContextSwitch : 1; // Bit 8            
            ULONG    bBlitterMIFlush_DWNotify : 1; // Bit 9
            ULONG    bBlitterMMIOSyncFlushStatus : 1; // Bit 10
            ULONG    bBlitterMI_User_Interrupt : 1; // Bit 11
            ULONG    bBlitterPageFault : 1; // Bit 12
                                            //6. Blitter Interrupts from GT Onwards Ends here    


                                            //7. Misc Interrupts Category Starts here
            ULONG    bVSync_PipeAInterrupt : 1;    // Bit 13 //Not Required
            ULONG    bVSync_PipeBInterrupt : 1;    // Bit 14 //Not Required
            ULONG    bVBlank_PipeAInterrupt : 1;    // Bit 15
            ULONG    bVBlank_PipeBInterrupt : 1;    // Bit 16            
            ULONG    bGSESystemLevel : 1;    // Bit 17  Valid from ILK Replacement for ASLE Interrupt           
            ULONG    bVblankTPV : 1;    // BIT 18 //Used for TPV Vblank Interrupt
            ULONG    bASLEInterrupt : 1;    // Bit 19  Need to remove Once MP Cleans up the ASLE INterrupt Stuff
            ULONG    bAllFirstLevelInterrupts : 1;    // BIT 20 //Used for Enabling/Disabling of Interrupts..

                                                      //7. Misc Interrupts Category Ends here

                                                      //8. New added Interrupts
            ULONG    bSpritePlaneAFlipDoneInterrupt : 1;    // BIT 21 //Used for Enabling/Disabling of Sprite Plane A Flip Done Interrupt..
            ULONG    bSpritePlaneBFlipDoneInterrupt : 1;    // BIT 22 //Used for Enabling/Disabling of Sprite Plane B Flip Done Interrupt..

            ULONG    bVSync_PipeCInterrupt : 1;    // BIT 23
            ULONG    bVBlank_PipeCInterrupt : 1;    // BIT 24
            ULONG    bSpritePlaneCFlipDoneInterrupt : 1;    // BIT 25

            ULONG    bAudioHDCPRequestInterruptA : 1;    // BIT 26 //Audio HDCP request for transcoder A
            ULONG    bAudioHDCPRequestInterruptB : 1;    // BIT 27 //Audio HDCP request for transcoder B
            ULONG    bAudioHDCPRequestInterruptC : 1;    // BIT 28 //Audio HDCP request for transcoder C
            ULONG    bAudioHDCPRequestInterrupt : 1;    // BIT 29 //Audio HDCP request for pre ilk platforms            

            ULONG   bPerfMonBufferHalfFullInterrupt : 1;    // BIT 30

            ULONG   ulReserved_Bit31 : 1;    // Bit 31

        };
    };

    union
    {
        ULONG ulValue2;
        struct
        {
            // This sections contains error/debug status bits
            ULONG bFIFOUnderrun_PipeAInterrupt : 1; // bit 0 
            ULONG bCRC_Error_PipeAInterrupt : 1; // bit 1
            ULONG bCRC_Done_PipeAInterrupt : 1; // bit 2

            ULONG bFIFOUnderrun_PipeBInterrupt : 1; // bit 3
            ULONG bCRC_Error_PipeBInterrupt : 1; // bit 4
            ULONG bCRC_Done_PipeBInterrupt : 1; // bit 5

            ULONG bFIFOUnderrun_PipeCInterrupt : 1; // bit 6
            ULONG bCRC_Error_PipeCInterrupt : 1; // bit 7
            ULONG bCRC_Done_PipeCInterrupt : 1; // bit 8

                                                // VE (Video Enhancement) Interrupt Definitions - Starts Here - Valid from Gen7_5 (HSW+) onward
            ULONG bVEUserInterrupt : 1; // bit 9
            ULONG bVEMMIOSyncFlushStatus : 1; // bit 10
            ULONG bVECmdParserMasterError : 1; // bit 11
            ULONG bVEMIFlush_DWNotify : 1; // bit 12
                                           // VE (Video Enhancement) Interrupt Definitions - Ends Here

                                           // other interrupt bits that don't fit into the previous dwords
            ULONG bRenderParityError : 1; // Bit 13 Gen7 Onwards

            ULONG bVideoPavpUnsolicitedAttack : 1; // Bit 14 Gen7 Onwards

                                                   //Below are valid from BDW
            ULONG bVideoUserInterrupt2 : 1; // Bit 15 
            ULONG bVideoDecPipelineCntrExceed2 : 1; // Bit 16 
            ULONG bVideoMIFlush_DWNotify2 : 1; // Bit 17
            ULONG bVideoMMIOSyncFlushStatus2 : 1; // Bit 18                 
            ULONG bVideoASContextSwitch2 : 1; // Bit 19
            ULONG bVideoPageFault2 : 1; // Bit 20
            ULONG bVideoPavpUnsolicitedAttack2 : 1; // Bit 21

            ULONG bGuCSHIMError : 1;    // bit 22
            ULONG bGuCDMAINTError : 1;    // bit 23                
            ULONG bGuCDMADone : 1;    // bit 24                
            ULONG bGuCDoorBellRang : 1;    // bit 25
            ULONG bGuCIOMMUSentMsgtoGuc : 1;    // bit 26
            ULONG bGuCSemaphoreSignaled : 1;    // bit 27
            ULONG bGuCDisplayEventRecieved : 1;    // bit 28
            ULONG bGuCExecutionError : 1;    // bit 29
            ULONG bGuCInterruptToHost : 1;    // bit 30

            ULONG bCSTRInvalidTileDetection : 1;    // bits 31
        };
    };

    union
    {
        ULONG ulValue3;
        struct
        {
            // This sections contains VEC/WiDi interrupts
            ULONG bVECSContextSwitchInterrupt : 1; // bit 0
            ULONG bVECSWaitOnSemaphore : 1; // bit 1
            ULONG bWDBoxInterrupt : 1; // bit 2
            ULONG bDPST_HistInterruptPipeB : 1;// bit 3
            ULONG bDPST_PhaseInInterruptPipeB : 1; // bit 4
            ULONG bDPST_HistInterruptPipeC : 1;// bit 5
            ULONG bDPST_PhaseInInterruptPipeC : 1; // bit 6 

            ULONG bPipeA_Plane1FlipDoneInterrupt : 1; //bit 7
            ULONG bPipeA_Plane2FlipDoneInterrupt : 1; //bit 8
            ULONG bPipeA_Plane3FlipDoneInterrupt : 1; //bit 9

            ULONG bPipeB_Plane1FlipDoneInterrupt : 1; //bit 10
            ULONG bPipeB_Plane2FlipDoneInterrupt : 1; //bit 11
            ULONG bPipeB_Plane3FlipDoneInterrupt : 1; //bit 12

            ULONG bPipeC_Plane1FlipDoneInterrupt : 1; //bit 13
            ULONG bPipeC_Plane2FlipDoneInterrupt : 1; //bit 14
            ULONG bPipeC_Plane3FlipDoneInterrupt : 1; //bit 15

            ULONG bPipeA_Plane1FlipQueueEmptyInterrupt : 1; //bit 16
            ULONG bPipeA_Plane2FlipQueueEmptyInterrupt : 1; //bit 17
            ULONG bPipeA_Plane3FlipQueueEmptyInterrupt : 1; //bit 18

            ULONG bPipeB_Plane1FlipQueueEmptyInterrupt : 1; //bit 19
            ULONG bPipeB_Plane2FlipQueueEmptyInterrupt : 1; //bit 20
            ULONG bPipeB_Plane3FlipQueueEmptyInterrupt : 1; //bit 21

            ULONG bPipeC_Plane1FlipQueueEmptyInterrupt : 1; //bit 22
            ULONG bPipeC_Plane2FlipQueueEmptyInterrupt : 1; //bit 23
            ULONG bPipeC_Plane3FlipQueueEmptyInterrupt : 1; //bit 24

            ULONG bDEMiscSVMWaitDescriptorCompleted : 1; // bit 25
            ULONG bDEMiscSVMVTDFault : 1; // bit 26
            ULONG bDEMiscSVMPRQEvent : 1; // bit 27


            ULONG bPipeA_Plane4FlipDoneInterrupt : 1; // bit 28
            ULONG bPipeB_Plane4FlipDoneInterrupt : 1; // bit 29
            ULONG bPSR2GTCLockLoss : 1; // bit 30
            ULONG bVECSWatchDogCounterExcd : 1; // bit 31
        };
    };
    union
    {
        ULONG ulValue4;
        struct
        {
            ULONG bMIPIAInterrupt : 1; // bit 0
            ULONG bMIPICInterrupt : 1; // bit 1
            ULONG bLPEPipeAInterrupt : 1; // bit 2
            ULONG bLPEPipeBInterrupt : 1; // bit 3

            ULONG bISPInterrupt : 1; // bit 4
            ULONG bVEDBlockInterrupt : 1; // bit 5
            ULONG bVEDPowerInterrupt : 1; // bit 6
            ULONG bPipeA_Plane4FlipQueueEmptyInterrupt : 1; // bit 7

            ULONG bPipeB_Plane4FlipQueueEmptyInterrupt : 1; // bit 8
            ULONG bLPEPipeCInterrupt : 1; // bit 9
            ULONG bGTPMCoreToUncoreTrapInterrupt : 1; //bit 10
            ULONG bWDBoxEndofFrameInterrupt : 1; //bit 11 corresponds to WDBOX_END_OF_FRAME_INTERRUPT = 0X800, in INTERRUPT_UNION_VALUE_4

            ULONG bIntDP_HDMIEInterrupt : 1; // Bit 12// skl ddi - e hot plug interrupt
            ULONG bIntDP_HDMIE_SPInterrupt : 1; // Bit 13
            ULONG bRenderTDLRetryInterrupt : 1; // bit 14
            ULONG bPinningContextSwitch : 1; // Bit 15
            ULONG bPinningUserInterrupt : 1; // Bit 16
            ULONG bDEMisc_WDCombinedInterrupt : 1; // bit 17 corresponds to DEMISC_WD_COMBINED_INTERRUPT  = 0x20000, in INTERRUPT_UNION_VALUE_4

            ULONG bPipeA_Underrun : 1; // bit 18
            ULONG bPipeB_Underrun : 1; // bit 19
            ULONG bPipeC_Underrun : 1; // bit 20
            ULONG bPipeC_Plane4FlipDoneInterrupt : 1; // bit 21
            ULONG bInvalidGTTPageTableEntry : 1; // bit 22
            ULONG bInvalidPageTableEntryData : 1; // bit 23
            ULONG bVSync_PipeDInterrupt : 1; // BIT 24
            ULONG bVBlank_PipeDInterrupt : 1; // BIT 25
            ULONG bIntDP_HDMIFInterrupt : 1; // Bit 26// ddi - f hot plug interrupt 
            ULONG bIntDP_HDMIF_SPInterrupt : 1; // Bit 27
            ULONG bWDBox2Interrupt : 1; // bit 28
            ULONG bWDBox2EndofFrameInterrupt : 1; // bit 29
            ULONG bDEMisc_WD2CombinedInterrupt : 1; // bit 30
            ULONG ulReserved_Bits31_ulValue4 : 1; // bit 31
        };
    };
    union
    {
        ULONG ulValue5;
        struct
        {
            ULONG PipeA_Plane1GTTFaultStatus : 1; //bit 0
            ULONG PipeA_Plane2GTTFaultStatus : 1; //bit 1
            ULONG PipeA_Plane3GTTFaultStatus : 1; //bit 2
            ULONG PipeA_Plane4GTTFaultStatus : 1; //bit 3
            ULONG PipeA_CursorGTTFaultStatus : 1; //bit 4

            ULONG PipeB_Plane1GTTFaultStatus : 1; //bit 5
            ULONG PipeB_Plane2GTTFaultStatus : 1; //bit 6
            ULONG PipeB_Plane3GTTFaultStatus : 1; //bit 7
            ULONG PipeB_Plane4GTTFaultStatus : 1; //bit 8
            ULONG PipeB_CursorGTTFaultStatus : 1; //bit 9

            ULONG PipeC_Plane1GTTFaultStatus : 1; //bit 10
            ULONG PipeC_Plane2GTTFaultStatus : 1; //bit 11
            ULONG PipeC_Plane3GTTFaultStatus : 1; //bit 12
            ULONG PipeC_Plane4GTTFaultStatus : 1; //bit 13
            ULONG PipeC_CursorGTTFaultStatus : 1; //bit 14

            ULONG IntDP_HDMIB_SCDCInterrupt : 1; //bit 15
            ULONG IntDP_HDMIC_SCDCInterrupt : 1; //bit 16
            ULONG IntDP_HDMID_SCDCInterrupt : 1; //bit 17
            ULONG IntDP_HDMIE_SCDCInterrupt : 1; //bit 18
            ULONG IntDP_HDMIF_SCDCInterrupt : 1; //bit 19

            ULONG bPipeA_Plane5FlipDoneInterrupt : 1; // bit 20
            ULONG bPipeA_Plane6FlipDoneInterrupt : 1; // bit 21
            ULONG bPipeA_Plane7FlipDoneInterrupt : 1; // bit 22
            ULONG bPipeB_Plane5FlipDoneInterrupt : 1; // bit 23
            ULONG bPipeB_Plane6FlipDoneInterrupt : 1; // bit 24
            ULONG bPipeB_Plane7FlipDoneInterrupt : 1; // bit 25
            ULONG bPipeC_Plane5FlipDoneInterrupt : 1; // bit 26
            ULONG bPipeC_Plane6FlipDoneInterrupt : 1; // bit 27
            ULONG bPipeC_Plane7FlipDoneInterrupt : 1; // bit 28
            ULONG bPipeD_Plane5FlipDoneInterrupt : 1; // bit 29
            ULONG bPipeD_Plane6FlipDoneInterrupt : 1; // bit 30
            ULONG bPipeD_Plane7FlipDoneInterrupt : 1; // bit 31
        };
    };
    union
    {
        ULONG ulValue6;
        struct
        {
            ULONG PipeA_Plane5GTTFaultStatus : 1; //bit 0
            ULONG PipeA_Plane6GTTFaultStatus : 1; //bit 1
            ULONG PipeA_Plane7GTTFaultStatus : 1; //bit 2
            ULONG PipeB_Plane5GTTFaultStatus : 1; //bit 3
            ULONG PipeB_Plane6GTTFaultStatus : 1; //bit 4
            ULONG PipeB_Plane7GTTFaultStatus : 1; //bit 5
            ULONG PipeC_Plane5GTTFaultStatus : 1; //bit 6
            ULONG PipeC_Plane6GTTFaultStatus : 1; //bit 7
            ULONG PipeC_Plane7GTTFaultStatus : 1; //bit 8
            ULONG PipeD_Plane5GTTFaultStatus : 1; //bit 9
            ULONG PipeD_Plane6GTTFaultStatus : 1; //bit 10
            ULONG PipeD_Plane7GTTFaultStatus : 1; //bit 11
            ULONG bPipeD_Plane1FlipDoneInterrupt : 1; //bit 12
            ULONG bPipeD_Plane2FlipDoneInterrupt : 1; //bit 13
            ULONG bPipeD_Plane3FlipDoneInterrupt : 1; //bit 14
            ULONG bPipeD_Plane4FlipDoneInterrupt : 1; //bit 15
            ULONG PipeD_Plane1GTTFaultStatus : 1; //bit 16
            ULONG PipeD_Plane2GTTFaultStatus : 1; //bit 17
            ULONG PipeD_Plane3GTTFaultStatus : 1; //bit 18
            ULONG PipeD_Plane4GTTFaultStatus : 1; //bit 19
            ULONG PipeD_CursorGTTFaultStatus : 1; //bit 20
            ULONG PipeD_DPST_HistInterrupt : 1;// bit 21
            ULONG bCRC_Error_PipeDInterrupt : 1; // bit 22
            ULONG bCRC_Done_PipeDInterrupt : 1; // bit 23
            ULONG bPipeD_Underrun : 1; // bit 24
            ULONG bAudioHDCPRequestInterruptD : 1; // bit 25
            ULONG IntDP_HDMIA_SCDCInterrupt : 1; // bit 26
            ULONG PIPEA_VRRDoubleBufferUpdate : 1; // bit 27
            ULONG PIPEB_VRRDoubleBufferUpdate : 1; // bit 28
            ULONG PIPEC_VRRDoubleBufferUpdate : 1; // bit 29
            ULONG PIPED_VRRDoubleBufferUpdate : 1; // bit 30
            ULONG ulReserved_Bits31_ulValue6 : 1; // bits 31
        };
    };
    union
    {
        ULONG ulValue7;
        struct
        {
            ULONG bPipeA_ScanLineEvent : 1; //bit 0
            ULONG bPipeB_ScanLineEvent : 1; //bit 1
            ULONG bPipeC_ScanLineEvent : 1; //bit 2
            ULONG bPipeD_ScanLineEvent : 1; //bit 3
        };
    };

}SB_INTERRUPT_ARGS_56, *PSB_INTERRUPT_ARGS_56;


typedef struct _SB_BLANKVIDEO_ARGS
{
     ULONG ulPipeIndex;
     ULONG ulVideoOn;
}SB_BLANKVIDEO_ARGS, *PSB_BLANKVIDEO_ARGS;



#pragma warning( default: 4214 )
#pragma warning( default: 4201 )