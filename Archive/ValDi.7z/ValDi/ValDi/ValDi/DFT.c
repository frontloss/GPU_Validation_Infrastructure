#include "Driver.h"
#include "DFT.h"
#include "kmem.h"
#include "logger.h"
#include "config.h"
#include "registers.h"
#include "ddrw\ddrw_displayerrordef.h"


// Constants
#define MAX_SIMULATED_PORTS 5

// EDID constants
#define MAX_EDID_BLOCKS  255 //According to E-EDID Standard doc.
#define EDID_BLOCK_SIZE  (128)

//------------------------------------------------------------------------------
//
// MailBox (4): Used to get VBT from system BIOS
//
//------------------------------------------------------------------------------
#define MAILBOX4_OFFSET      0x400     // Offset[0x400] : VBT table starts here and ends until VBT size.
#define VBT_MAILBOX_SIZE     6 * 1024  // 6KB space is pre-reserved for VBT End Offset = 0x1BFF


DECLARE_GLOBAL_CONST_UNICODE_STRING(DFTPath, L"\\Registry\\Machine\\SOFTWARE\\Intel\\Display");
DECLARE_GLOBAL_CONST_UNICODE_STRING(REGISTER_SIMULATION_KEY, L"registry_simulation");
DECLARE_GLOBAL_CONST_UNICODE_STRING(DPCD_SIMULATION_KEY, L"dpcd_simulation");

//Static variables
static DFT_Context dft_context = { 0 };


// Struct used in GfxGetRegistryInfo & cbGfxGetRegistryInfo
// This allows partial registry reads based on provided buffer size.
typedef struct _REGISTRY_BUFFER
{
    ULONG ulMaxValueLength;
    PVOID pvValueData;
}REGISTRY_BUFFER, *PREGISTRY_BUFFER;

int LoadDPCD(DD_PORT_TYPE port);
SIMULATION_STATUS LoadVBT();


//----------------------------------------------------------------------------
//  Function    :   cbGfxGetRegistryInfo
//  Type        :   GfxGetRegistryInfo callback routine
//  Description :   Gets registry ValueData for ValueName
//  Arguments   :   
//                  IN ValueName,
//                  IN ValueType,
//                  IN ValueData,
//                  IN ValueLength,
//                  IN Context,
//                  IN EntryContext
//  Returns     :   NTSTATUS
//  Callers     :   OS in response to RtlQueryRegistryValues in GfxGetRegistryInfo().
//  Notes       :   We do not support REG_*SZ types today.
//-----------------------------------------------------------------------------
NTSTATUS
cbGfxGetRegistryInfo(
    IN PWSTR ValueName,
    IN ULONG ValueType,
    IN PVOID ValueData,
    IN ULONG ValueLength,
    IN PVOID Context,
    IN PVOID EntryContext)
{
    PREGISTRY_BUFFER pReadBuffer = (PREGISTRY_BUFFER)EntryContext;

    switch (ValueType) {
        // Suported types
    case REG_BINARY:
    case REG_DWORD:
    case REG_QWORD:
    case REG_SZ:
    case REG_EXPAND_SZ:
        break;

    default:
        return STATUS_INVALID_PARAMETER;
    }

    if (Context) {
        Context = Context;
        ValueName = ValueName;
    }
    if (!ValueLength)
    {
        return STATUS_OBJECT_NAME_NOT_FOUND;
    }


    if (ValueData == NULL)
    {
        return STATUS_INVALID_PARAMETER;
    }

    //.Use the smaller length out of two: user-supplied (i.e. pReadBuffer->ulMaxValueLength) or OS-supplied (i.e. ValueLength).
    if ((pReadBuffer->ulMaxValueLength < ValueLength) && (pReadBuffer->ulMaxValueLength != 0))
    {
        if (0 != memcpy_s(pReadBuffer->pvValueData, pReadBuffer->ulMaxValueLength, ValueData, pReadBuffer->ulMaxValueLength))
        {
            return STATUS_INVALID_PARAMETER;
        }
    }
    else
    {
        if (0 != memcpy_s(pReadBuffer->pvValueData, ValueLength, ValueData, ValueLength))
        {
            return STATUS_INVALID_PARAMETER;
        }
    }

    return STATUS_SUCCESS;
}



///////////////////////////////////////////////////////////////////////////////
//
// LoadVBT: Method to load DPCD data from registry based on port
//
///////////////////////////////////////////////////////////////////////////////
SIMULATION_STATUS LoadVBT()
{
    WCHAR                       dftRegPathBuffer[MAX_PATH] = { 0 };
    UNICODE_STRING              dftRegpath = { 0, MAX_PATH * 2,  dftRegPathBuffer };
    NTSTATUS status;
    RTL_QUERY_REGISTRY_TABLE paramTable[2];
    REGISTRY_BUFFER            stReadBuffer = { 0 };
    SIMULATION_STATUS ret_status = SIMULATION_IGNORED;

    do {
        if (DFTPath.Buffer == NULL)
        {
            ELOG("ValDi init error: LoadConfiguration internal allocation failed.\n");
            break;
        }

        if (dft_context.dft_config.enabled == 0 || dft_context.dft_config.vbt == 0) {
            ELOG("ValDi : VBT simulation not enabled.\n");
            break;
        }

        RtlCopyUnicodeString(&dftRegpath, &DFTPath);

        stReadBuffer.ulMaxValueLength = VBT_MAILBOX_SIZE;
        stReadBuffer.pvValueData = kmalloc(stReadBuffer.ulMaxValueLength);

        RtlZeroMemory(paramTable, sizeof(paramTable));
        paramTable[0].Flags = RTL_QUERY_REGISTRY_REQUIRED;
        paramTable[0].Name = L"SIMULATED_VBT";
        paramTable[0].EntryContext = (PVOID)&stReadBuffer;
        paramTable[0].DefaultType = REG_BINARY;
        paramTable[0].DefaultLength = 0;
        paramTable[0].DefaultData = NULL;
        paramTable[0].QueryRoutine = cbGfxGetRegistryInfo;
        status = RtlQueryRegistryValues(RTL_REGISTRY_ABSOLUTE, dftRegpath.Buffer, paramTable, NULL, NULL);

        if (NT_SUCCESS(status))
        {
            InterlockedExchangePointer(&(PVOID)dft_context.pSimulatedVbtData, stReadBuffer.pvValueData);
        }
        else
        {
            dft_context.pSimulatedVbtData = NULL;
            kfree(stReadBuffer.pvValueData);
        }
    } while (FALSE);

    return ret_status;
}



VOID Initialize_DFT() {
    InitializeListHead(&dft_context.resume_list_head);
    KeInitializeSpinLock(&dft_context.resume_event_lock);

    PLOG("Initialize DFT \n");
    for (int i = 0; i < MAX_PORTS; i++) {
        dft_context.Port_PlugState[i] = PORT_HOTPLUG_NO_ACTION;
        dft_context.pDPCDContainer[MAX_PORTS] = NULL;
    }
	dft_context.onBootProcessed = FALSE;
}


///////////////////////////////////////////////////////////////////////////////
//
// LoadDFTConfig: Load DFT master config from registry
// Callee: HotPlugUnPlug, Logger and LoadVSM
//
///////////////////////////////////////////////////////////////////////////////
void LoadDFTConfig()
{
    WCHAR                       dftRegPathBuffer[MAX_PATH] = { 0 };
    UNICODE_STRING              dftRegPath = { 0, MAX_PATH * 2,  dftRegPathBuffer };
    NTSTATUS status;
    RTL_QUERY_REGISTRY_TABLE paramTable[2];
    ULONG defaultUData;
    PIPE_MAPS *pPipePortMap = __getPipeStatusPtr();

    PLOG("Reading DFT configuration:\n");

    if (DFTPath.Buffer == NULL)
    {
        ELOG("ValDi init error: LoadConfiguration internal allocation failed.\n");
        return;
    }

    RtlCopyUnicodeString(&dftRegPath, &DFTPath);

    // Read DFT config key
    defaultUData = 0;
    RtlZeroMemory(paramTable, sizeof(paramTable));
    paramTable[0].Flags = RTL_QUERY_REGISTRY_DIRECT;
    paramTable[0].Name = L"DFT";
    paramTable[0].EntryContext = &defaultUData;
    paramTable[0].DefaultData = &defaultUData;
    paramTable[0].DefaultType = REG_DWORD;
    paramTable[0].DefaultLength = sizeof(defaultUData);
    status = RtlQueryRegistryValues(RTL_REGISTRY_ABSOLUTE, dftRegPath.Buffer, paramTable, NULL, NULL);
    dft_context.dft_config.ulValue = defaultUData;

	// For EDP panel version below 1.2 we need to
	// disable reset bit and for other reset bit needs to be enabled
	defaultUData = __option_scrumbler_reset;
	RtlZeroMemory(paramTable, sizeof(paramTable));
	paramTable[0].Flags = RTL_QUERY_REGISTRY_DIRECT;
	paramTable[0].Name = L"ScramblerReset";
	paramTable[0].EntryContext = &defaultUData;
	paramTable[0].DefaultData = &defaultUData;
	paramTable[0].DefaultType = REG_DWORD;
	paramTable[0].DefaultLength = sizeof(defaultUData);
	status = RtlQueryRegistryValues(RTL_REGISTRY_ABSOLUTE, dftRegPath.Buffer, paramTable, NULL, NULL);
	__option_scrumbler_reset = defaultUData;


    // Read Simulated PORT config key
    defaultUData = 0;
    RtlZeroMemory(paramTable, sizeof(paramTable));
    paramTable[0].Flags = RTL_QUERY_REGISTRY_DIRECT;
    paramTable[0].Name = L"expected_port_state";
    paramTable[0].EntryContext = &defaultUData;
    paramTable[0].DefaultData = &defaultUData;
    paramTable[0].DefaultType = REG_DWORD;
    paramTable[0].DefaultLength = sizeof(defaultUData);
    status = RtlQueryRegistryValues(RTL_REGISTRY_ABSOLUTE, dftRegPath.Buffer, paramTable, NULL, NULL);
    dft_context.stExpectedPortState.ulValue = defaultUData;

    // Read PORT2PIPECONFIG PORT config key
    defaultUData = 0;
    RtlZeroMemory(paramTable, sizeof(paramTable));
    paramTable[0].Flags = RTL_QUERY_REGISTRY_DIRECT;
    paramTable[0].Name = L"PORT2PIPECONFIG";
    paramTable[0].EntryContext = &defaultUData;
    paramTable[0].DefaultData = &defaultUData;
    paramTable[0].DefaultType = REG_DWORD;
    paramTable[0].DefaultLength = sizeof(defaultUData);
    status = RtlQueryRegistryValues(RTL_REGISTRY_ABSOLUTE, dftRegPath.Buffer, paramTable, NULL, NULL);
    dft_context.port2pipe_map.ulValue = defaultUData;

    PLOG("ValDi [LoadDFTConfig]: DFT = 0x%X and Expected ports = 0x%X Port2Pipe config = 0x%X\n",
        dft_context.dft_config.ulValue,
        dft_context.stExpectedPortState.ulValue,
        dft_context.port2pipe_map.ulValue);

    pPipePortMap->pipeToPortConfig[PIPE_A_ID] = PORT_A_ID + 11;
    pPipePortMap->pipeToPortConfig[PIPE_B_ID] = PORT_B_ID + 11;
    pPipePortMap->pipeToPortConfig[PIPE_C_ID] = PORT_C_ID + 11;

    if (pPipePortMap != NULL) {
        PORT2PIPECONFIG *port2pipe = &dft_context.port2pipe_map;
        if (dft_context.port2pipe_map.ulValue) {
            if (port2pipe->PIPE_IDX_1 || port2pipe->PORT_IDX_1)
            {
                ELOG("ValDi: Debug: Port index  = %d \n", port2pipe->PORT_IDX_1);
                pPipePortMap->pipeToPortConfig[port2pipe->PIPE_IDX_1] = (ULONG)(port2pipe->PORT_IDX_1);
            }

            if (port2pipe->PIPE_IDX_2 || port2pipe->PORT_IDX_2)
                pPipePortMap->pipeToPortConfig[port2pipe->PIPE_IDX_2] = (ULONG)port2pipe->PORT_IDX_2;

            if (port2pipe->PIPE_IDX_3 || port2pipe->PORT_IDX_3)
                pPipePortMap->pipeToPortConfig[port2pipe->PIPE_IDX_3] = (ULONG)port2pipe->PORT_IDX_3;

            //For future use
            /*
            if (port2pipe->PIPE_IDX_4 || port2pipe->PORT_IDX_4)
            pPipePortMap->pipeToPortConfig[port2pipe->PIPE_IDX_4] = port2pipe->PORT_IDX_4;
            */
        }
    }

    if (dft_context.dft_config.enabled && dft_context.dft_config.device_simulation) {
        for (int port = 0; port < MAX_SIMULATED_PORTS; port++) {
            if (dft_context.stExpectedPortState.ulValue & (1 << port)) {
                LoadDPCD(port);
// To handle eDP simulation on boot scenario
#if 1
				if (dft_context.onBootProcessed == FALSE) {
					dft_context.Port_PlugState[port] = PORT_HOTPLUG_REQUEST;					
				}
#endif
            }
        }
    }
	dft_context.onBootProcessed = TRUE;
    LoadVBT();
}


///////////////////////////////////////////////////////////////////////////////
//
// Read_SimulatedEDID: Fetch EDID data from registry and fill pIntArgs;
// if port is configured for simulation
// 
// TODO: Block wise EDID read
//
///////////////////////////////////////////////////////////////////////////////
SIMULATION_STATUS Read_SimulatedEDID(DD_PORT_TYPE port,
    PDD_READ_DDC_ARGUMENTS pIntArgs)
{
    WCHAR                   dftRegPathBuffer[MAX_PATH] = { 0 };
    UNICODE_STRING          dftRegPath = { 0, MAX_PATH * 2,  dftRegPathBuffer };
    NTSTATUS status;
    RTL_QUERY_REGISTRY_TABLE paramTable[2];
    REGISTRY_BUFFER         stReadBuffer = { 0 };
    SIMULATION_STATUS       ret_status = SIMULATION_IGNORED;
    WCHAR port_name[] = L"\\DDI_A\\0\\EDID";


    if (DFTPath.Buffer == NULL)
    {
        ELOG("ValDi [Read_SimulatedEDID]: LoadConfiguration internal allocation failed.\n");
        return ret_status;
    }

    if (dft_context.dft_config.enabled == 0 || dft_context.dft_config.device_simulation == 0) {
        ELOG("ValDi [Read_SimulatedEDID]: Device simulation not enabled.\n");
        return ret_status;
    }

    PLOG("ValDi [Read_SimulatedEDID]: Port = %X  dft_context.dft_config.faked_ports = x%X stExpectedPortState = 0x%X\n", port,
        dft_context.dft_config.faked_ports, dft_context.stExpectedPortState.ulValue);

    if ((dft_context.dft_config.faked_ports & (1 << port))) {
        if ((dft_context.stExpectedPortState.ulValue & (1 << port))) {
            //Configure registry path based on port parameter
            if (port >= DD_PORT_TYPE_UNKNOWN && port <= DD_PORT_TYPE_MAX)
            {
                port_name[5] = (WCHAR)('A' + port);
            }

            RtlCopyUnicodeString(&dftRegPath, &DFTPath);

            stReadBuffer.ulMaxValueLength = sizeof(BYTE) * ((pIntArgs->BlockNumber + 1)  * EDID_BLOCK_SIZE);
            stReadBuffer.pvValueData = kmalloc(stReadBuffer.ulMaxValueLength);

            RtlAppendUnicodeToString(&dftRegPath, port_name);
            RtlZeroMemory(paramTable, sizeof(paramTable));
            paramTable[0].Flags = /* RTL_QUERY_REGISTRY_DIRECT | */ RTL_QUERY_REGISTRY_REQUIRED;
            paramTable[0].Name = L"block_0";
            paramTable[0].EntryContext = (PVOID)&stReadBuffer;
            paramTable[0].DefaultType = REG_BINARY;
            paramTable[0].DefaultLength = 0;
            paramTable[0].DefaultData = NULL;
            paramTable[0].QueryRoutine = cbGfxGetRegistryInfo;
            status = RtlQueryRegistryValues(RTL_REGISTRY_ABSOLUTE, dftRegPath.Buffer, paramTable, NULL, NULL);

            if (NT_SUCCESS(status))
            {
                if (pIntArgs->BufferSize <= stReadBuffer.ulMaxValueLength) {
                    PLOG("copy edid data for block %X on port %X \n", pIntArgs->BlockNumber, port);
                    memcpy_s(pIntArgs->pBuffer, pIntArgs->BufferSize, (UCHAR *)stReadBuffer.pvValueData + (pIntArgs->BlockNumber * EDID_BLOCK_SIZE), pIntArgs->BufferSize);
                    ret_status = SIMULATION_HANDLED;
                }

                PLOG("EDID block %X read %X != %X \n", pIntArgs->BlockNumber, stReadBuffer.ulMaxValueLength, pIntArgs->BufferSize);
            }
            kfree(stReadBuffer.pvValueData);
        }
        else {
            //Disconnect state
            ret_status = SIMULATION_HANDLED;
        }
    }
    return ret_status;
}


///////////////////////////////////////////////////////////////////////////////
//
// decode_value: Method to convert BIG endian ULONG to LITTLE endian
//
///////////////////////////////////////////////////////////////////////////////
ULONG32 decode_value(ULONG value) {
    ULONG32 b0, b1, b2, b3;

    b0 = (value & 0x000000ff) << 24u;
    b1 = (value & 0x0000ff00) << 8u;
    b2 = (value & 0x00ff0000) >> 8u;
    b3 = (value & 0xff000000) >> 24u;
    return (b0 | b1 | b2 | b3);
}


///////////////////////////////////////////////////////////////////////////////
//
// LoadDPCD: Method to load DPCD data from registry based on port
//
///////////////////////////////////////////////////////////////////////////////
SIMULATION_STATUS LoadDPCD(DD_PORT_TYPE port)
{
    WCHAR                       dftRegPathBuffer[MAX_PATH] = { 0 };
    UNICODE_STRING              dftRegpath = { 0, MAX_PATH * 2,  dftRegPathBuffer };
    NTSTATUS status;
    RTL_QUERY_REGISTRY_TABLE paramTable[2];
    REGISTRY_BUFFER            stReadBuffer = { 0 };
    WCHAR port_name[] = L"\\DDI_A\\0";
    PREGISTER_CONTAINER pContainer = dft_context.pDPCDContainer[port];
    PVOID freePtr = NULL;
    PREGISTER_DICT pRegister = NULL;
    SIMULATION_STATUS ret_status = SIMULATION_IGNORED;

    do {
        if (DFTPath.Buffer == NULL)
        {
            ELOG("ValDi init error: LoadConfiguration internal allocation failed.\n");
            return ret_status;
        }

        if (dft_context.dft_config.enabled == 0 || dft_context.dft_config.device_simulation == 0) {
            ELOG("ValDi : Device simulation not enabled.\n");
            return ret_status;
        }

        //Configure registry path based on port parameter
        if (port >= DD_PORT_TYPE_UNKNOWN && port <= DD_PORT_TYPE_MAX)
        {
            port_name[5] = (WCHAR)('A' + port);
        }

        RtlCopyUnicodeString(&dftRegpath, &DFTPath);
        if (pContainer == NULL)
        {
            pContainer = kmalloc(sizeof(PREGISTER_CONTAINER));
            BREAK_ON_NULL(pContainer);
            pContainer->pDict = NULL;
        }
        freePtr = pContainer->pDict;
        stReadBuffer.ulMaxValueLength = REGISTER_DICT_PACK_SIZE(MAX_PAIR);
        stReadBuffer.pvValueData = kmalloc(stReadBuffer.ulMaxValueLength);
        pContainer->encoded_data = stReadBuffer.ulMaxValueLength;

        RtlAppendUnicodeToString(&dftRegpath, port_name);
        RtlZeroMemory(paramTable, sizeof(paramTable));
        paramTable[0].Flags = /* RTL_QUERY_REGISTRY_DIRECT | */ RTL_QUERY_REGISTRY_REQUIRED;
        paramTable[0].Name = L"dpcd_simulation";
        paramTable[0].EntryContext = (PVOID)&stReadBuffer;
        paramTable[0].DefaultType = REG_BINARY;
        paramTable[0].DefaultLength = 0;
        paramTable[0].DefaultData = NULL;
        paramTable[0].QueryRoutine = cbGfxGetRegistryInfo;
        status = RtlQueryRegistryValues(RTL_REGISTRY_ABSOLUTE, dftRegpath.Buffer, paramTable, NULL, NULL);

        if (NT_SUCCESS(status))
        {
            InterlockedExchangePointer(&(PVOID)pContainer->pDict, stReadBuffer.pvValueData);
            if (freePtr) {
                kfree(freePtr);
            }

            pRegister = pContainer->pDict;
            pContainer->encoded_data = 0;

            pRegister->key = decode_value(pRegister->key);
            pRegister->value = decode_value(pRegister->value);

            while (pRegister->key != 0xDEADBEEF && pContainer->encoded_data < MAX_PAIR)
            {
                pRegister++;
                pRegister->key = decode_value(pRegister->key);
                pRegister->value = decode_value(pRegister->value);
                pContainer->encoded_data++;
            }
            ret_status = SIMULATION_HANDLED;
            dft_context.pDPCDContainer[port] = pContainer;
        }
        else
        {
            kfree(stReadBuffer.pvValueData);
        }

    } while (FALSE);

    return ret_status;
}


////////////////////////////////////////////////////////////////////
//
// Find_DictItem: Method to search item in given array
// Find the dictionary item in the given dictionary based on search_item parameter.
//
// Note: Ensure that registry packing should have happened in sorted 
// order otherwise below algorithm will fail to find all the items
//
////////////////////////////////////////////////////////////////////
PREGISTER_DICT Find_DictItem(PREGISTER_CONTAINER pContainer, ULONG search_item)
{
    PREGISTER_DICT pRegister = NULL;
    PREGISTER_DICT pivot = NULL;

    do {
        BREAK_ON_NULL(pContainer);
        BREAK_ON_NULL(pContainer->pDict);

        pRegister = pContainer->pDict;

        // Binary search
        int mid = 0;
        int low = 0;
        int high = pContainer->encoded_data - 1;

        while (low <= high)
        {
            mid = (low + high) / 2;

            pivot = pRegister + mid;

            // Check if x is present at mid
            if (pivot->key == search_item)
                break;

            // If x greater, ignore left half  
            if (pivot->key < search_item)
                low = mid + 1;
            else
                // If x is smaller, ignore right half 
                high = mid - 1;
        }

        // if we reach here, then element was not present
        if (pivot != NULL && pivot->key != search_item) {
            pivot = NULL;
        }

    } while (FALSE);

    return pivot;
}


#define SHOT_PULSE_AND_LONG_PULSE   2

////////////////////////////////////////////////////////////////////
//
// Simulate_HPD_Interrupt: Check whether HPD Interrupt simulation required
// HotPlugUnPlug IOCTL should have configured REQUEST state for one of the port
//
////////////////////////////////////////////////////////////////////
ULONG Simulate_HPD_Interrupt(ULONG value)
{
    BDW_MSTR_INTR_TABLE BdwMSTR_ReadTable = { 0 };

    if (!(dft_context.dft_config.device_simulation
        && dft_context.dft_config.faked_ports
        && dft_context.dft_config.enabled)) {
        return value;
    }

    BdwMSTR_ReadTable.Value = value;
    for (int port_idx = PORT_B_ID; port_idx < MAX_DPORTS; port_idx++) {
        if (dft_context.Port_PlugState[port_idx] == PORT_HOTPLUG_REQUEST) {
            BdwMSTR_ReadTable.DEPortInterruptsPending = 1;            
            break;
        }
    }

    return BdwMSTR_ReadTable.Value;
}

////////////////////////////////////////////////////////////////////
//
// HandleLiveState: Simulate HPD and fake livestate for configured ports
// MMIO Hook function to handle simulated live state
//
////////////////////////////////////////////////////////////////////
ULONG HandleLiveState(ULONG offset, ULONG value)
{
    DE_PORT_INTR_TABLE_CNL DEPortReadTable = { 0 };
    SPT_HOTPLUG_CTL_REG_ST DpHpCtrlValue = { 0 };
    SPT_PCH_INT_TABLE PchLiveState = { 0 };
    SPT_PCH_INT_TABLE PCHIIR_ReadTable = { 0 }; // Used for reading the current IIR register

    if (!(dft_context.dft_config.device_simulation
        && dft_context.dft_config.faked_ports
        && dft_context.dft_config.enabled)) {
        return value;
    }

    if (offset == PCHIIR) {
        PCHIIR_ReadTable.Value = value;
        for (ULONG port_idx = PORT_A_ID; port_idx < MAX_DPORTS; port_idx++) {
            if (dft_context.Port_PlugState[port_idx] == PORT_HOTPLUG_REQUEST) {
                if (PORT_A_ID == port_idx)
                    PCHIIR_ReadTable.DdiAHotplug = 1;
                else if (PORT_B_ID == port_idx)
                    PCHIIR_ReadTable.DdiBHotplug = 1;
                else if (PORT_C_ID == port_idx)
                    PCHIIR_ReadTable.DdiCHotplug = 1;
                else if (PORT_D_ID == port_idx)
                    PCHIIR_ReadTable.DdiDHotplug = 1;
                dft_context.Port_PlugState[port_idx] = PORT_HOTPLUG_SIMULATE;
            }
        }
        return PCHIIR_ReadTable.Value;
    }
    
	else if (offset == DE_PORT_HPD_STATUS) {
		//HPD occurred ?
		DEPortReadTable.Value = value;
		for (ULONG i = PORT_A_ID; i < MAX_DPORTS; i++) {
			if (dft_context.Port_PlugState[i] == PORT_HOTPLUG_REQUEST) {
				if (i == PORT_A_ID)
					DEPortReadTable.DdiAHotplug = 1;
				else if (i == PORT_B_ID)
					DEPortReadTable.DdiBHotplug = 1;
				else if (i == PORT_C_ID)
					DEPortReadTable.DdiCHotplug = 1;

				dft_context.Port_PlugState[i] = PORT_HOTPLUG_SIMULATE;
			}
		}
		value = DEPortReadTable.Value;
	}
    else if (offset == SHOTPLUG_CTL) {
        //Hotplug detect status        
        DpHpCtrlValue.Value = value;
        for (ULONG i = PORT_A_ID; i < MAX_DPORTS; i++) {
            if (dft_context.Port_PlugState[i] == PORT_HOTPLUG_SIMULATE) {
                if (PORT_A_ID == i)
                    DpHpCtrlValue.DdiA_HPDStatus = SHOT_PULSE_AND_LONG_PULSE;
                else if (PORT_B_ID == i)
                    DpHpCtrlValue.DdiB_HPDStatus = SHOT_PULSE_AND_LONG_PULSE;
                else if (PORT_C_ID == i)
                    DpHpCtrlValue.DdiC_HPDStatus = SHOT_PULSE_AND_LONG_PULSE;
                else if (PORT_D_ID == i)
                    DpHpCtrlValue.DdiD_HPDStatus = SHOT_PULSE_AND_LONG_PULSE;
            }
        }
        value = DpHpCtrlValue.Value;
    }
	else if (offset == DE_PORT_INTERRUPT) {
		DEPortReadTable.Value = value;
		for (ULONG idx = PORT_A_ID; idx < MAX_DPORTS; idx++) {
			if (dft_context.Port_PlugState[idx] == PORT_HOTPLUG_SIMULATE) {
				if (PORT_A_ID == idx)
					DEPortReadTable.DdiAHotplug = 1;
				else if (PORT_B_ID == idx)
					DEPortReadTable.DdiBHotplug = 1;
				else if (PORT_C_ID == idx)
					DEPortReadTable.DdiCHotplug = 1;
			}
		}
		return DEPortReadTable.Value;
	}
    else if (offset == SDE_INTERRUPT) {
		//Live state check
        PchLiveState.Value = value;
        for (ULONG i = PORT_A_ID; i < MAX_DPORTS; i++) {
            if (dft_context.Port_PlugState[i] >= PORT_HOTPLUG_REQUEST) {
                if (i == PORT_A_ID)
                    PchLiveState.DdiAHotplug = 1;
                else if (i == PORT_B_ID)
                    PchLiveState.DdiBHotplug = 1;
                else if (i == PORT_C_ID)
                    PchLiveState.DdiCHotplug = 1;
                else if (i == PORT_D_ID)
                    PchLiveState.DdiDHotplug = 1;
            }
        }
        value = PchLiveState.Value;
    }
    
    return value;
}


////////////////////////////////////////////////////////////////////
//
// ToggleInterruptLine: Simulate HotPlug/UnPlug interrupt
// Wait for Interrupt to process by resetting Port state machine to started
//
////////////////////////////////////////////////////////////////////
void ToggleInterruptLine(ULONG port)
{
    LARGE_INTEGER       short_sleepFor = { 0 };
    int timeout_limit = 10;
    int counter = 0;

    ELOG("ValDi : Wait for fake interrupt processing for port %X.\n", port);
    if (dft_context.dft_config.faked_ports & (1 << port)) {
        if (dft_context.Port_PlugState[port] == PORT_HOTPLUG_SIMULATE) {
            dft_context.Port_PlugState[port] = PORT_HOTPLUG_SIMULATE; //Need to disconnect and reconnect
        }

		//Handle Plug Unplug during low power/ on resume events
		if (dft_context.stExpectedPortState.ulValue && (1 << port)) {
			dft_context.Port_PlugState[port] = PORT_HOTPLUG_REQUEST;
		}
		else {
			dft_context.Port_PlugState[port] = PORT_HOTPLUG_NO_ACTION;
		}


        //Wait for 1 milli seconds
        short_sleepFor.QuadPart = -10000;
        while (dft_context.Port_PlugState[port] != PORT_HOTPLUG_SIMULATE)
        {
            KeDelayExecutionThread(KernelMode, TRUE, &short_sleepFor);

            counter++;
            if (counter >= timeout_limit) {
                ELOG("ValDi : Stop waiting due to timeout \n");
                break;
            }
        }

    }
    ELOG("ValDi : Done waiting for fake interrupt processing for port %X.\n", port);

    return;
}


////////////////////////////////////////////////////////////////////
//
// HandleAuxAccess: Simulate DPCD based on configured port
//
////////////////////////////////////////////////////////////////////
int HandleAuxAccess(DD_AUX_OPERATIONS opCode, DD_PORT_TYPE port, ULONG DPCDAddress, UCHAR BufferSize, UCHAR *pBuffer)
{
    int status = BufferSize;
    int index = 0;

    ELOG("ValDi: Reading DPCD data for port = %X \n", port);
    if ((dft_context.dft_config.faked_ports & (1 << port))) {
        if ((dft_context.stExpectedPortState.ulValue & (1 << port))) {
            if (opCode == DD_AUX_WRITE) {
                return 0;
            }
            ELOG("ValDi: Reading DPCD data for port = %X \n", port);
            while (status) {

                //PREGISTER_DICT pRegister = find_register(pDPCDRegisterContainer, DPCDAddress);
                PREGISTER_DICT pRegister = Find_DictItem(dft_context.pDPCDContainer[port], DPCDAddress);
                if (pRegister != NULL)
                {
                    *(pBuffer + index) = (UCHAR)pRegister->value;
                    DPCDAddress = DPCDAddress + 1;
                }
                index++;
                status--;
            }
        }
    }
    else {
        ELOG("ValDi: Reading DPCD data for port = %X - simulation status did not match\n", port);
        ELOG("ValDi: Faked ports = %X and expected port status = %X \n", dft_context.dft_config.faked_ports, dft_context.stExpectedPortState.ulValue);
    }
    return status;
}


////////////////////////////////////////////////////////////////////
//
// Handle_PlugUnPlug: Handle Plug UnPlug request from IOCTL service
//
////////////////////////////////////////////////////////////////////
VOID Handle_PlugUnPlug(ULONG port, ULONG onResume)
{
    PRESUME_EVENTS  plug_event = NULL;
    KLOCK_QUEUE_HANDLE resume_event_ListLockHandle;

    LoadDFTConfig();

    if (port > MAX_PORTS)
        return;

    if (onResume) {
        KeAcquireInStackQueuedSpinLock(&dft_context.resume_event_lock, &resume_event_ListLockHandle);

        plug_event = kmalloc(sizeof(RESUME_EVENTS));
        plug_event->port_simulation_request.portId = port;
        plug_event->port_simulation_request.onResume = onResume;
        InsertTailList(&dft_context.resume_list_head, &plug_event->list_entry);
        KeReleaseInStackQueuedSpinLock(&resume_event_ListLockHandle);
    }
    else {
        //Wait for Interrupt to process
        ToggleInterruptLine(port);

        //Queue HotPlug DPC
        Call_HotPlugUnPlug_DPC(port);
    }
}


////////////////////////////////////////////////////////////////////
//
// TearDown_DFTConfig: Method to do clean up DFT related variables
// Free up used memory 
//
////////////////////////////////////////////////////////////////////
void TearDown_DFTConfig()
{
    for (int i = 0; i < MAX_PORTS; i++)
    {
        PREGISTER_CONTAINER pContainer = dft_context.pDPCDContainer[i];
        if (pContainer != NULL) {
            if (pContainer->pDict != NULL) {
                kfree(pContainer->pDict);
            }
        }
    }
}


/**
* \brief  Write VBT data from opregion to registry
* \param  pVbtData pointer to driver VBT data region
* \return VOID
*/
VOID CacheVBT(DDU8 *pVbtData)
{
    ULONG vbt_size = VBT_MAILBOX_SIZE;

    do {
        BREAK_ON_NULL(pVbtData);

        RtlWriteRegistryValue(RTL_REGISTRY_ABSOLUTE,
            DFTPath.Buffer,
            L"VBT_SIZE",
            REG_DWORD,
            &vbt_size,
            sizeof(ULONG));

        RtlWriteRegistryValue(RTL_REGISTRY_ABSOLUTE,
            DFTPath.Buffer,
            L"VBT",
            REG_BINARY,
            pVbtData,
            vbt_size);

    } while (FALSE);
}


/**
* \brief Copy simulated VBT data from registry to Driver variable
* \param  pVbtData pointer to driver VBT data region
* \return SIMULATION_IGNORED or SIMULATION_HANDLED
*/
SIMULATION_STATUS SimulateVBT(DDU8 *pVbtData)
{
    do {
        BREAK_ON_NULL(dft_context.pSimulatedVbtData);

        if (dft_context.dft_config.vbt && dft_context.dft_config.enabled)
        {
            memcpy_s(pVbtData, VBT_MAILBOX_SIZE, dft_context.pSimulatedVbtData, VBT_MAILBOX_SIZE);
            return SIMULATION_HANDLED;
        }
    } while (FALSE);
    return SIMULATION_IGNORED;
}


/**
* \brief Handle events during resume from S3/S4
*/
VOID HandleResumeEvent()
{
    ULONG port = 0;
    KLOCK_QUEUE_HANDLE resume_event_ListLockHandle;

    KeAcquireInStackQueuedSpinLock(&dft_context.resume_event_lock, &resume_event_ListLockHandle);

    PLOG("ValDi [HandleResumeEvent] : Processing Resume event.\n");
    while (!IsListEmpty(&dft_context.resume_list_head))
    {
        PLIST_ENTRY node = RemoveHeadList(&dft_context.resume_list_head);
        RESUME_EVENTS *pEvent = CONTAINING_RECORD(node, RESUME_EVENTS, list_entry);
        port = pEvent->port_simulation_request.portId;

		//Handle Plug Unplug during low power/ on resume events based on ExpectedPort state flag
        if (dft_context.dft_config.faked_ports & (1 << port)) {
			if (dft_context.stExpectedPortState.ulValue & (1 << port)) {
				dft_context.Port_PlugState[port] = PORT_HOTPLUG_REQUEST;
			}	
			else {
				dft_context.Port_PlugState[port] = PORT_HOTPLUG_NO_ACTION;
			}
            ELOG("ValDi [HandleResumeEvent] intialize port 0x%X to state = 0x%X.\n", port, dft_context.Port_PlugState[port]);
        }
        kfree(pEvent);
    }
    KeReleaseInStackQueuedSpinLock(&resume_event_ListLockHandle);
    PLOG("ValDi : Done processing Resume event.\n");
}