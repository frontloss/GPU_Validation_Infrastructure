#pragma once
#include <ntdef.h>
#include "logger.h"


// CRC interfaces
VOID    Setup_CRC();
VOID    TearDown_CRC();

VOID    syncPipePort();
VOID    __schedule_pipeportCRCFetch(ULONG pipeId);
VOID    __report_portCRC(ULONG pipeId);

VOID    enablePipeCRC(ULONG pipeId);
VOID    enablePortCRC(ULONG portId);

