#pragma once

///////////////////////////////////////////////////////////////////////////////////////////////////
#define DDI_CRC_CTL_A 0x64050
#define DDI_CRC_CTL_B 0x64150
#define DDI_CRC_CTL_C 0x64250
#define DDI_CRC_CTL_D 0x64350

#define DDI_SRC_RESET_A 0x640E0
#define DDI_SRC_RESET_B 0x641E0
#define DDI_SRC_RESET_C 0x642E0
#define DDI_SRC_RESET_D 0x643E0

#define DDI_CRC_RES_A 0x64064
#define DDI_CRC_RES_B 0x64164
#define DDI_CRC_RES_C 0x64264
#define DDI_CRC_RES_D 0x64364

#define DDI_CRC_ENABLE 0x83000000
#define DDI_CRC_READY  0x01000000




#define DE_PIPE_INTERRUPT_ISR_A 0x44400
#define DE_PIPE_INTERRUPT_ISR_B 0x44410
#define DE_PIPE_INTERRUPT_ISR_C 0x44420
#define DE_PIPE_INTERRUPT_ISR_D 0x44430

#define DE_PIPE_INTERRUPT_IMR_A 0x44404
#define DE_PIPE_INTERRUPT_IMR_B 0x44414
#define DE_PIPE_INTERRUPT_IMR_C 0x44424
#define DE_PIPE_INTERRUPT_IMR_D 0x44434


#define DE_PIPE_INTERRUPT_IIR_A 0x44408
#define DE_PIPE_INTERRUPT_IIR_B 0x44418
#define DE_PIPE_INTERRUPT_IIR_C 0x44428
#define DE_PIPE_INTERRUPT_IIR_D 0x44438


/* 
    The IER enabled Display Engine Pipe Interrupt IIR(sticky) bits are ORed 
    together to generate the DE_Pipe Interrupts Pending bit in the Master Interrupt Control register.
    There is one full set of Display Engine Pipe interrupts per display pipes A / B / C.
    The STEREO3D_EVENT_MASK selects between left eye and right eye reporting of vertical blank, 
    vertical sync, and scanline events in stereo 3D modes.
*/
#define DE_PIPE_INTERRUPT_IER_A 0x4440C
#define DE_PIPE_INTERRUPT_IER_B 0x4441C
#define DE_PIPE_INTERRUPT_IER_C 0x4442C
#define DE_PIPE_INTERRUPT_IER_D 0x4443C



#define DE_PIPE_UNDERRUN_BIT    0x80000000
#define DE_PIPE_CRCDONE_BIT     0x10000000
#define DE_PIPE_FLIPDONE_BITS   0x00000078


#define DE_PIPE_VBLANK_MASK     0x1

#define GT0_INTERRUPT 0x44308
#define GT0_CS_CONTEXT_SWITCH 0x80


#define PIPE_SCANLINE_A         0x70000
#define PIPE_SCANLINE_B         0x71000
#define PIPE_SCANLINE_C         0x72000

#define DBUF_STATUS             0x4500C


#define PIPE_CRC_CTL_INT        0xC0000000
#define PIPE_CRC_CTL_READY      0x1000000

#define PIPE_CD_CRC_CTL_A       0x60050
#define PIPE_CD_CRC_CTL_B       0x61050
#define PIPE_CD_CRC_CTL_C       0x62050
#define PIPE_CD_CRC_CTL_D       0x63050

#define PIPE_CD_CRC_RES_A       0x60064
#define PIPE_CD_CRC_RES_B       0x61064
#define PIPE_CD_CRC_RES_C       0x62064
#define PIPE_CD_CRC_RES_D       0x63064


///////////////////////////////////////////////////////////////////////////////////////////////////
//WATERMARK CORRUPTIONS
#define CUR_WM_A     0x70140
#define PLANE_WM_1_A 0x70240
#define PLANE_WM_2_A 0x70340
#define PLANE_WM_3_A 0x70440
#define PLANE_WM_4_A 0x70540

#define CUR_WM_B     0x71140
#define PLANE_WM_1_B 0x71240
#define PLANE_WM_2_B 0x71340
#define PLANE_WM_3_B 0x71440
#define PLANE_WM_4_B 0x71540

#define WM_LINETIME_A 0x45270
#define WM_LINETIME_B 0x45274

#define DISPLAY_INT_CTL     0x44200
#define DE_PORT_INTERRUPT   0x44440
#define DE_PORT_HPD_STATUS  0x44448

//South Display Engine Interrupts
#define SDE_INTERRUPT       0xC4000
#define PCHIIR              0xC4008
//South hotplug control
#define SHOTPLUG_CTL        0xC4030
