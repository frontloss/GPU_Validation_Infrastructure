#pragma once
#include "ddrw_hooks.h"
#include <stdlib.h>

extern PVOID                                  igdkmd_hwContext;

#pragma warning( disable: 4201 )

#define MAX_PAIR 256
#define HEADER_SIZE sizeof(ULONG)
#define FOOTER_SIZE sizeof(ULONG)
#define DPCD_DICT_PACK_SIZE(MAX_PAIR) HEADER_SIZE + sizeof(DPCD_DICT) * MAX_PAIR + FOOTER_SIZE
#define REGISTER_DICT_PACK_SIZE(MAX_PAIR) sizeof(REGISTER_DICT) * MAX_PAIR + FOOTER_SIZE * 2


typedef struct _register_dict {
    ULONG32 key;
    ULONG32 value;
}REGISTER_DICT, *PREGISTER_DICT;


typedef struct _register_container {
    PREGISTER_DICT pDict;
    unsigned int encoded_data;
}REGISTER_CONTAINER, *PREGISTER_CONTAINER;


typedef struct _DFT_CONFIG
{
	union
	{
		ULONG ulValue;
		struct {
			INT device_simulation : 1;
			INT mpo : 1;
			INT hw_register_stub : 1;
			INT vbt : 1;
            INT crc : 1;
			INT reserved1 : 15;
			INT faked_ports : 8;
			INT reserved2 : 3;
			INT enabled : 1;
		};
	};
}DFT_CONFIG;


// Enum to represent HOTPLUG states
enum {
    PORT_HOTPLUG_NO_ACTION = 0,
    PORT_HOTPLUG_REQUEST = 1,    
    PORT_HOTPLUG_SIMULATE = 2,
};


// Enum to represent SIMULATION erorr state
typedef enum {
    SIMULATION_IGNORED = 0,
    SIMULATION_HANDLED = 1,
    SIMULATION_ERRORED = 2,
}SIMULATION_STATUS;


typedef struct _SIMULATED_PORT_STATUS
{
    union
    {
        ULONG ulValue;
        struct {
            INT PORT_A : 1;
            INT PORT_B : 1;
            INT PORT_C : 1;
            INT PORT_D : 1;
            INT PORT_E : 1;
            INT PORT_F : 1;
            INT PORT_G : 1;
            INT PORT_H : 1;
            INT reserved1 : 23;            
        };
    };
}SIMULATED_PORT_STATUS;


typedef struct _PORT2PIPECONFIG
{
    union
    {
        ULONG ulValue;
        struct {
            UINT PORT_IDX_1 : 4;
            UINT PIPE_IDX_1 : 4;
            UINT PORT_IDX_2 : 4;
            UINT PIPE_IDX_2 : 4;
            UINT PORT_IDX_3 : 4;
            UINT PIPE_IDX_3 : 4;
            UINT PORT_IDX_4 : 4;
            UINT PIPE_IDX_4 : 4;

        };
    };
}PORT2PIPECONFIG;

typedef struct _resume_events 
{
    LIST_ENTRY list_entry;
    VALDI_PLUG_UNPLUG_PORT_IN port_simulation_request;    
}RESUME_EVENTS, *PRESUME_EVENTS;


typedef struct _DFT_Context
{
    //common
    DFT_CONFIG dft_config;

    //Device Simulationed
    SIMULATED_PORT_STATUS stExpectedPortState;
    PORT2PIPECONFIG port2pipe_map;
    ULONG Port_PlugState[MAX_PORTS];
    PREGISTER_CONTAINER pDPCDContainer[MAX_PORTS];


    // Variable to store simulated VBT
    DDU8 *pSimulatedVbtData;

    // Action on resume
    RESUME_EVENTS resume_events;
    LIST_ENTRY resume_list_head;
    KSPIN_LOCK resume_event_lock;
	BOOL onBootProcessed;

}DFT_Context, *PDFT_Context;




typedef union _SPT_HOTPLUG_CTL_REG_ST
{
    DDU32 Value;
    struct
    {
        int DdiB_HPDStatus : DD_BITFIELD_RANGE(0, 1); // X1b: short Pulse, 1Xb: long pulse
        int UNIQUENAME(Reserved) : DD_BITFIELD_RANGE(2, 3); // MBZ
        int DdiBHpdInputEnable : DD_BITFIELD_BIT(4); // DDI_B_HPD_INPUT_ENABLE
        int UNIQUENAME(Reserved) : DD_BITFIELD_RANGE(5, 7); // MBZ

        int DdiC_HPDStatus : DD_BITFIELD_RANGE(8, 9); // X1b: short Pulse, 1Xb: long pulse
        int UNIQUENAME(Reserved) : DD_BITFIELD_RANGE(10, 11); // MBZ
        int DdiCHpdInputEnable : DD_BITFIELD_BIT(12); // DDI_C_HPD_INPUT_ENABLE
        int UNIQUENAME(Reserved) : DD_BITFIELD_RANGE(13, 15); // MBZ

        int DdiD_HPDStatus : DD_BITFIELD_RANGE(16, 17); // X1b: short Pulse, 1Xb: long pulse
        int UNIQUENAME(Reserved) : DD_BITFIELD_RANGE(18, 19); // MBZ
        int DdiDHpdInputEnable : DD_BITFIELD_BIT(20); // DDI_D_HPD_INPUT_ENABLE
        int UNIQUENAME(Reserved) : DD_BITFIELD_RANGE(21, 23); // MBZ

        int DdiA_HPDStatus : DD_BITFIELD_RANGE(24, 25); // X1b: short Pulse, 1Xb: long pulse
        int UNIQUENAME(Reserved) : DD_BITFIELD_RANGE(26, 27); // MBZ
        int DdiAHpdInputEnable : DD_BITFIELD_BIT(28); // DDI_A_HPD_INPUT_ENABLE
        int UNIQUENAME(Reserved) : DD_BITFIELD_RANGE(29, 31); // MBZ
    };
} SPT_HOTPLUG_CTL_REG_ST;


typedef union _SPT_PCH_INT_TABLE
{
    DDU32 Value;
    struct
    {
        int UNIQUENAME(Reserved) : DD_BITFIELD_RANGE(0, 16); // MBZ
        int Gmbus : DD_BITFIELD_BIT(17); //
        int UNIQUENAME(Reserved) : DD_BITFIELD_RANGE(18, 20); // MBZ
        int DdiBHotplug : DD_BITFIELD_BIT(21); //
        int DdiCHotplug : DD_BITFIELD_BIT(22); //
        int DdiDHotplug : DD_BITFIELD_BIT(23); //
        int DdiAHotplug : DD_BITFIELD_BIT(24); //
        int DdiEHotplug : DD_BITFIELD_BIT(25); //
        int DdiFHotplug : DD_BITFIELD_BIT(26); //
        int UNIQUENAME(Reserved) : DD_BITFIELD_RANGE(27, 31); // MBZ
    };
} SPT_PCH_INT_TABLE;

/*****************************************************************************\
This table indicates which events are mapped to each bit of the Display Engine Port Interrupt registers.
The IER enabled Display Engine Port Interrupt IIR (sticky) bits are ORed together to generate the DE_Port Interrupts Pending bit in the Master Interrupt Control register.

0x44440 = ISR
0x44444 = IMR
0x44448 = IIR
0x4444C = IER
\*****************************************************************************/
typedef union _DE_PORT_INTR_TABLE_CNL
{
    struct
    {

        /*****************************************************************************\
        The ISR is an active high pulse on the AUX DDI A done event. This event will not occur for SRD AUX done.
        \*****************************************************************************/
        int Aux_Channel_A : DD_BITFIELD_BIT(0); // 

                                                  /*****************************************************************************\
                                                  The ISR is an active high pulse when any of the unmasked events in GMBUS4 Interrupt Mask register occur.
                                                  This field is only used on projects that have GMBUS integrated into the north display. Projects that have GMBUS in the south display
                                                  have the GMBUS interrupt in the south display interrupts.
                                                  \*****************************************************************************/
        int Gmbus : DD_BITFIELD_BIT(1); // 
        int Reserved1 : DD_BITFIELD_BIT(2); // 

                                                         /*****************************************************************************\
                                                         The ISR gives the live state of the DDI A HPD pin when the HPD input is enabled.
                                                         The IIR is set if a short or long pulse is detected when HPD input is enabled.
                                                         \*****************************************************************************/
        int DdiAHotplug : DD_BITFIELD_BIT(3); // 

                                                /*****************************************************************************\
                                                The ISR gives the live state of the DDI B HPD pin when the HPD input is enabled.
                                                The IIR is set if a short or long pulse is detected when HPD input is enabled.
                                                \*****************************************************************************/
        int DdiBHotplug : DD_BITFIELD_BIT(4); // 

                                                /*****************************************************************************\
                                                The ISR gives the live state of the DDI C HPD pin when the HPD input is enabled.
                                                The IIR is set if a short or long pulse is detected when HPD input is enabled.
                                                \*****************************************************************************/
        int DdiCHotplug : DD_BITFIELD_BIT(5); // 
        int Reserved2 : DD_BITFIELD_RANGE(6, 7); // 

                                                              /*****************************************************************************\
                                                              The IIR is set when a HDMI 2.0 SCDC read request event is detected and is cleared by writing a '1' to this bit.
                                                              The ISR is active high level signal that will indicate if the read request (RR) is still active.
                                                              \*****************************************************************************/
        int ScdcReadRequestInterruptPortB : DD_BITFIELD_BIT(8); // 

                                                                  /*****************************************************************************\
                                                                  The IIR is set when a HDMI 2.0 SCDC read request event is detected and is cleared by writing a '1' to this bit.
                                                                  The ISR is active high level signal that will indicate if the read request (RR) is still active.
                                                                  \*****************************************************************************/
        int ScdcReadRequestInterruptPortC : DD_BITFIELD_BIT(9); // 
        int Reserved3 : DD_BITFIELD_RANGE(10, 22); // 

                                                                /*****************************************************************************\
                                                                The ISR is an active high level indicating a TE interrupt is set in MIPIA_STATUS.
                                                                \*****************************************************************************/
        int MipiATe : DD_BITFIELD_BIT(23); // 

                                             /*****************************************************************************\
                                             The ISR is an active high level indicating a TE interrupt is set in MIPIC_STATUS.
                                             \*****************************************************************************/
        int MipiCTe : DD_BITFIELD_BIT(24); // 

                                             /*****************************************************************************\
                                             The ISR is an active high pulse on the AUX DDI B done event. This event will not occur for SRD AUX done.
                                             \*****************************************************************************/
        int AuxChannelB : DD_BITFIELD_BIT(25); // 

                                                 /*****************************************************************************\
                                                 The ISR is an active high pulse on the AUX DDI C done event. This event will not occur for SRD AUX done.
                                                 \*****************************************************************************/
        int AuxChannelC : DD_BITFIELD_BIT(26); // 

                                                 /*****************************************************************************\
                                                 The ISR is an active high pulse on the AUX DDI D done event. This event will not occur for SRD AUX done.
                                                 \*****************************************************************************/
        int AuxChannelD : DD_BITFIELD_BIT(27); // 

                                                 /*****************************************************************************\
                                                 The ISR is an active high pulse on the AUX DDI F done event. This event will not occur for SRD AUX done.
                                                 \*****************************************************************************/
        int AuxChannelF : DD_BITFIELD_BIT(28); // 
        int Reserved4 : DD_BITFIELD_BIT(29); // 

                                                          /*****************************************************************************\
                                                          The ISR is an active high level indicating an interrupt is set in MIPIA_INTR_STAT_REG or MIPIA_INTR_STAT_REG_1.
                                                          This field is only used on BXT.
                                                          \*****************************************************************************/
        int MipiA : DD_BITFIELD_BIT(30); // 

                                           /*****************************************************************************\
                                           The ISR is an active high level indicating an interrupt is set in MIPIC_INTR_STAT_REG or MIPIC_INTR_STAT_REG_1.
                                           \*****************************************************************************/
        int MipiC : DD_BITFIELD_BIT(31); // 
    };
    DDU32 Value;

} DE_PORT_INTR_TABLE_CNL;

typedef union _BDW_MSTR_INTR_TABLE
{
    DDU32 Value;
    struct
    {
        int RenderInterruptsPending : 1;     // bit 0
        int BlitterInterruptsPending : 1;     // bit 1
        int VCS1InterruptsPending : 1;     // bit 2
        int VCS2InterruptsPending : 1;     // bit 3
        int GTPMInterruptsPending : 1;     // bit 4
        int GuCInterruptsPending : 1;     // bit 5
        int VEBoxInterruptsPending : 1;     // bit 6
        int WDBoxInterruptsPending : 1;     // bit 7

        int  UNIQUENAME(Reserved) :8;     // bit 8-15

        int  DEPipeAInterruptsPending : 1;     // bit 16
        int  DEPipeBInterruptsPending : 1;     // bit 17
        int  DEPipeCInterruptsPending : 1;     // bit 18

        int  UNIQUENAME(Reserved) :1;     // bit 19

        int  DEPortInterruptsPending : 1;     // bit 20

        int  UNIQUENAME(Reserved) :1;     // bit 21

        int  DEMiscInterruptsPending : 1;     // bit 22
        int  DEPCHInterruptsPending : 1;     // bit 23

        int  DEAudioCodecInterruptsPending : 1;     // bit 24

        int  UNIQUENAME(Reserved) :5;     // bit 25-29

        int  PCUInterruptsPending : 1;     // bit 30
        int  MstrInterruptEnable : 1;     // bit 31
    };
}BDW_MSTR_INTR_TABLE;


//DFT configuration functions
VOID Initialize_DFT();
VOID LoadDFTConfig();
VOID TearDown_DFTConfig();

// Function for device simulation
VOID Handle_PlugUnPlug(ULONG port, ULONG onResume);
VOID HandleResumeEvent();
INT32 Read_SimulatedEDID(DD_PORT_TYPE, PDD_READ_DDC_ARGUMENTS pIntArgs);
ULONG HandleLiveState(ULONG offset, ULONG value);
VOID ToggleInterruptLine(ULONG port);
INT32 HandleAuxAccess(DD_AUX_OPERATIONS Operation, DD_PORT_TYPE port, ULONG DPCDAddress, UCHAR BufferSize, UCHAR *pBuffer);
PREGISTER_DICT Find_DictItem(PREGISTER_CONTAINER pContainer, ULONG search_item);

// Functions for VBT simulation
VOID CacheVBT(DDU8 *pVbtData);
SIMULATION_STATUS SimulateVBT(DDU8 *pVbtData);

