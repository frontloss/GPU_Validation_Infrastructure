/**
* @file globlas.h
* @addtogroup CDll_ValDi
* @brief Contains global declarations and structures which provides system specific
*		 Input Output Control(IOCTL) interfaces between display driver and any application
*
* @author Krzysztof Olinski
*/

/***********************************************************************************************
* INTEL CONFIDENTIAL. Copyright (c) 2016 Intel Corporation All Rights Reserved.
*  <br>The source code contained or described herein and all documents related to the source code
*  ("Material") are owned by Intel Corporation or its suppliers or licensors. Title to the
*  Material remains with Intel Corporation or its suppliers and licensors. The Material contains
*  trade secrets and proprietary and confidential information of Intel or its suppliers and licensors.
*  The Material is protected by worldwide copyright and trade secret laws and treaty provisions.
*  No part of the Material may be used, copied, reproduced, modified, published, uploaded, posted,
*  transmitted, distributed, or disclosed in any way without Intel�s prior express written permission.
*  <br>No license under any patent, copyright, trade secret or other intellectual property right is
*  granted to or conferred upon you by disclosure or delivery of the Materials, either expressly,
*  by implication, inducement, estoppel or otherwise. Any license under such intellectual property
*  rights must be express and approved by Intel in writing.
*/


/* Avoid multi inclusion of header file*/
#pragma once

#ifndef US_INCLUDE
	#include <ntddk.h>
	#include <wdftypes.h>
	#include <minwindef.h>
#else
	#include <Windows.h>
	#include <Subauth.h>
#endif

#ifdef _WIN64
	#define PTR_T ULONG64
	#define  FAKE_ADDRESS 0xFFFFFFFFFFFFFFFFULL
#else
	#define PTR_T ULONG32
	#define  FAKE_ADDRESS 0xFFFFFFFF
#endif

#define MAX_PIPES		4
#define PIPE_A_ID		0
#define PIPE_B_ID		1
#define PIPE_C_ID		2
#define PIPE_D_ID		3

#define MAX_DPORTS		4
#define PORT_A_ID		0
#define PORT_B_ID		1
#define PORT_C_ID		2
#define PORT_D_ID		3
#define PORT_E_ID		4

#define MAX_CPUs		32

#define VALDI_MAX_TXT_MARKER_LENGTH 		63
#define SECTION_HEADER_SIZE					3
#define BSOD_ON_PIPE_UNDERRUN				0x004
#define VALDISTATE_UNINITIALIZED			0x000
#define VALDISTATE_RUNNING					0x001
#define VALDISTATE_DEMISED					0x002
#define VALDISTATE_TRACING_FLAG				0x008
#define VALDISTATE_ARMED_FLAG				0x010
#define VALDISTATE_BUFFER_OVERFLOW			0x020
#define MAX_MMIOWRITE_RECORDS				4096
#define MESSAGE_SLOTS						32
#define MESSAGE_SIZE						128
#define ENTRYID_PATCHPOINT					0x01
#define VAADDRESS_DXGKINITIALIZE			0x01
#define PREVALDI_MAGIC_STR					"PVALDI0"

/*
Input Output Controls
function codes 0-2047 are reserved for Microsoft Corporation, and 2048-4095 are reserved for customers
*/
#define FILE_DEVICE_VALDI									0xCF83
#define IOCTL_VALDI__IGDKMD_GET_ADAPTER_INFO				CTL_CODE(FILE_DEVICE_VALDI, 2052, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)
#define IOCTL_VALDI__IGDKMD_READ_MMIO						CTL_CODE(FILE_DEVICE_VALDI, 2053, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)
#define IOCTL_VALDI__IGDKMD_WRITE_MMIO						CTL_CODE(FILE_DEVICE_VALDI, 2054, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)
#define IOCTL_VALDI__IGDKMD_RESUME_MMIOWRITE_TRACING		CTL_CODE(FILE_DEVICE_VALDI, 2055, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)
#define IOCTL_VALDI__IGDKMD_SUSPEND_MMIOWRITE_TRACING		CTL_CODE(FILE_DEVICE_VALDI, 2056, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)
#define IOCTL_VALDI__IGDKMD_FINALIZE_MMIOWRITE_TRACING		CTL_CODE(FILE_DEVICE_VALDI, 2057, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)
#define IOCTL_VALDI__IGDKMD_RESTART_MMIOWRITE_TRACING		CTL_CODE(FILE_DEVICE_VALDI, 2058, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)
#define IOCTL_VALDI__IGDKMD_SET_BSOD_TRIGGERS				CTL_CODE(FILE_DEVICE_VALDI, 2059, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)
#define IOCTL_VALDI__IGDKMD_GET_PIPE_TO_PORT_MAPPINGS		CTL_CODE(FILE_DEVICE_VALDI, 2060, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)
#define IOCTL_VALDI__GET_STATE								CTL_CODE(FILE_DEVICE_VALDI, 2061, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)
#define IOCTL_VALDI__SET_PIPE_VISIBILITY					CTL_CODE(FILE_DEVICE_VALDI, 2062, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)
#define IOCTL_VALDI__GET_HOOK_STATS							CTL_CODE(FILE_DEVICE_VALDI, 2063, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)
#define IOCTL_VALDI__INSERT_TXT_MARKER						CTL_CODE(FILE_DEVICE_VALDI, 2064, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)
#define IOCTL_VALDI__GET_MSGS								CTL_CODE(FILE_DEVICE_VALDI, 2065, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)
#define IOCTL_VALDI__GFXVALSTUB								CTL_CODE(FILE_DEVICE_VALDI, 2066, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)
#define IOCTL_AUX_ACCESS									CTL_CODE(FILE_DEVICE_VALDI, 2067, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)
#define IOCTL_PLUG_UNPLUG_PORT								CTL_CODE(FILE_DEVICE_VALDI, 2068, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)

typedef struct _PATCHPOINT
{
    CHAR        entryID;
    CHAR        moduleName[MAX_PATH];
    GUID        moduleSignature;
    ULONG       moduleAge;

    PVOID       vaPatchPoint;
    PVOID       vaTrampolineSection;
    PVOID       vaPostCall;
    ULONG       patchPointSize;
    ULONGLONG   orgData;
    
    PVOID       vaDestination;
}PATCHPOINT, *PPATCHPOINT;

typedef struct _PIPE_MAPS
{
    ULONG pipeToPortConfig[MAX_PIPES];
}PIPE_MAPS, *PPIPE_MAPS;

/**
* VDS STRUCTS
*/
typedef struct _SYMBOLINFO
{
    CHAR        shortName[64];
    ULONG       size;
    ULONGLONG   rva;
}SYMBOLINFO, *PSYMBOLINFO;

typedef struct _VALDI_ADAPTERINFO_IN
{
    UINT infoType;
    UINT expectedDataSize;
}VALDI_ADAPTERINFO_IN, *PVALDI_ADAPTERINFO_IN;

typedef struct _VALDI_MMIODATA
{
    ULONG    address;
    ULONG    size;
}VALDI_MMIODATA, *PVALDI_MMIODATA;

typedef struct _VALDI_BSOD_TRIGGERS_IN
{
    ULONG pipeID;
    ULONG BSoDTriggersFlag;
}VALDI_BSOD_TRIGGERS_IN, *PVALDI_BSOD_TRIGGERS_IN;

typedef struct _VALDI_SET_PIPE_VISIBILITY_IN
{
    ULONG pipeId;
    ULONG enableFlag;
}VALDI_SET_PIPE_VISIBILITY_IN, *PVALDI_SET_PIPE_VISIBILITY_IN;

typedef struct _VALDI_HOOK_STATS
{
    ULONGLONG softSyncs[MAX_PIPES];
    ULONGLONG underrunds[MAX_PIPES];
} VALDI_HOOK_STATS, *PVALDI_HOOK_STATS;

typedef struct _VALDI_TXT_MARKER_IN
{
    CHAR txtBuff[VALDI_MAX_TXT_MARKER_LENGTH + 1];
}VALDI_TXT_MARKER_IN, *PVALDI_TXT_MARKER_IN;

typedef struct _VALDI_PLUG_UNPLUG_PORT_IN
{
    ULONG portId;
    ULONG onResume;
}VALDI_PLUG_UNPLUG_PORT_IN, *PVALDI_PLUG_UNPLUG_PORT_IN;