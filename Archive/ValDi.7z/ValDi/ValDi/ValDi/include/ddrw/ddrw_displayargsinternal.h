#pragma once
#include "igdkmd_patcher\igdkmd_intc.h"
#include "ddrw_displaydefs.h"

typedef enum _DD_PROTOCOL_TYPE
{
    PROTOCOL_UNKNOWN = 0,
    PROTOCOL_HDMI,
    PROTOCOL_DISPLAYPORT_SST,
    PROTOCOL_DISPLAYPORT_EMBEDDED,
    PROTOCOL_DISPLAYPORT_MST,
    PROTOCOL_MIPI,
    PROTOCOL_WDE, // wigig
    PROTOCOL_VIRTUAL,

    PROTOCOL_MAX = PROTOCOL_VIRTUAL
} DD_PROTOCOL_TYPE;


typedef enum _DD_AUX_OPERATIONS
{
    DD_AUX_OPERATION_UNKNOWN = 0,
    DD_AUX_READ,
    DD_AUX_WRITE,
    DD_AUX_I2C_READ,
    DD_AUX_I2C_WRITE,
}DD_AUX_OPERATIONS;


typedef enum _DD_PORT_TYPE
{
	DD_PORT_TYPE_UNKNOWN = -1,
	DD_PORT_TYPE_DIGITAL_PORT_A,
	DD_PORT_TYPE_DIGITAL_PORT_B,
	DD_PORT_TYPE_DIGITAL_PORT_C,
	DD_PORT_TYPE_DIGITAL_PORT_D,
	DD_PORT_TYPE_DIGITAL_PORT_E,
	DD_PORT_TYPE_DIGITAL_PORT_F,
	DD_PORT_TYPE_DSI_PORT_0,
	DD_PORT_TYPE_DSI_PORT_1,
	DD_PORT_TYPE_WIGIG_PORT,
	DD_PORT_TYPE_VIRTUAL_PORT,
	DD_PORT_TYPE_MAX
} DD_PORT_TYPE;

typedef struct _DD_AUX_ARGUMENTS
{
    DD_IN DD_PORT_TYPE DisplayPort;

    DD_IN DD_AUX_OPERATIONS Operation;

    DD_IN DDU32 DPCDAddress;
    DD_IN_OUT DDU8 *pBuffer;    // Note: Format of data is little-endian only (usual Intel format)
    DD_IN DDU8 BufferSize; // This is treated as DD_IN_OUT -> DD_OUT to send back the size in case of NACK
    DD_IN BOOLEAN AksvBufferSelect; // TO select AKSV buffer

                                    // > 1 for burst operation, here
                                    // ulDPCDAddress will indicate the starting address. Max
                                    // possible size is 16 for native AUX

                                    // I2C on AUX specific arguments... (Note: Not complete yet)
    DD_IN BOOLEAN MiddleOfTransaction;   // caller can set this if it's middle of a transaction (ie., first transaction or re-start)
    DD_IN BOOLEAN IssueWriteStatusRequest;
    DD_IN DDU8 I2CAddress; // 7-bit format I2C address

    DD_IN DDU8 AuxChannelType;

    DD_IN BOOLEAN StartTransaction;

    // temp usage
    DD_TRI_STATE IsCurrentChannelBusy;
} DD_AUX_ARGUMENTS, *PDD_AUX_ARGUMENTS;



//Video output technology (VOT) type
typedef enum _DD_VIDEO_OUTPUT_TECHNOLOGY
{
    DD_VOT_UNKNOWN = 0,
    DD_VOT_VGA,
    DD_VOT_DVI,
    DD_VOT_HDMI,
    DD_VOT_DISPLAYPORT_EXTERNAL,
    DD_VOT_DISPLAYPORT_EMBEDDED,
    DD_VOT_MIPI,
    DD_VOT_VIRTUAL,
    DD_VOT_WIGIG,
    DD_VOT_MIRACAST,

    DD_VOT_MAX = DD_VOT_MIRACAST
} DD_VIDEO_OUTPUT_TECHNOLOGY;


// Target descriptor to be passed to protocol
typedef struct _DD_TARGET_DESCRIPTOR
{
    DD_PORT_TYPE Port;
    DD_VIDEO_OUTPUT_TECHNOLOGY SinkType;
    DDU8 SinkIndex; // non zero for DP MST or other multi-display scenarios on same port
} DD_TARGET_DESCRIPTOR;

/// Get EDID block buffer for \c Target
typedef struct _DD_RETRIEVE_EDID_BLOCK_ARGS
{
    DD_TARGET_DESCRIPTOR Target;
    DDU8 BlockNum;
    DDU8 *pEDID;
} DD_RETRIEVE_EDID_BLOCK_ARGS;