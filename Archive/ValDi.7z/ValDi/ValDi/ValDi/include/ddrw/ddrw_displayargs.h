#pragma once
#include "ddrw\ddrw_displayargsinternal.h"

#pragma warning( disable: 4214 )
#pragma warning( disable: 4201 )




// Args for read DDC operation
typedef struct _DD_READ_DDC_ARGUMENTS
{
    DD_PORT_TYPE  Port;    // Of type PORT_TYPES
    DD_PROTOCOL_TYPE Protocol;

    DDU8  DdcPinPairIndex;       // GMBUS pin pair Index from VBT to read HDMI/DVI EDID/panel params. From CNL, values are platform independant

    DDU32 SlaveAddress;   // Slave address (Final address to be used. e.g. for DDC on sDVO device this will be 0xA0 & not 0x70)
    DDU16 BlockNumber;    // EDID block (0, 1, ...)
    DDU8 *pBuffer;        // Note: Always a byte pointer to data
    DDU32 BufferSize;     // Data size in bytes

                          // AUX Channel type
    DDU8 AuxChannelType;
} DD_READ_DDC_ARGUMENTS, *PDD_READ_DDC_ARGUMENTS;


//----------------------------------------------------------------------------
//
// Power Manager data structures -- START
//
//----------------------------------------------------------------------------

typedef enum _DD_DEV_POWER_STATE
{
    DD_POWERSTATE_UNDEFINED = 0,
    DD_POWERSTATE_D0 = 1,
    DD_POWERSTATE_D1,
    DD_POWERSTATE_D2,
    DD_POWERSTATE_D3,
} DD_DEV_POWER_STATE;

typedef enum _DD_SYS_POWER_ACTION
{
    DD_POWERACTION_UNDEFINED = 0,
    DD_POWERACTION_NONE,
    DD_POWERACTION_SLEEP,
    DD_POWERACTION_HIBERNATE,
    DD_POWERACTION_SHUTDOWN,
    DD_POWERACTION_SHUTDOWNRESET,
    DD_POWERACTION_SHUTDOWNOFF,
} DD_SYS_POWER_ACTION;

typedef struct _DD_SET_ADAPTER_PWR_ARGS
{
    DD_DEV_POWER_STATE     DisplayDevPowerState;
    DD_SYS_POWER_ACTION    DisplaySysPowerAction;
} DD_SET_ADAPTER_PWR_ARGS;





// Interrupt Args structure
typedef struct _DD_INTERRUPT_ARGS
{
    INTERRUPT_OPERATION Operation; // Data structure for interrupt operations
    DDU32 PrivateData; // Private Interrupt Data. This will not be used in ILK and GT since enabling/disabling of all interrupts has become much simpler..

    DDU32 PlatformUsesGen11InterruptArchitecture : 1; // Let Event handler code know that all non-display engines are handled by new Selector methods
    DDU32 SelectorInterruptsOccurred : 1; // New for Gen11+  ::  This bit means one of the hierarchical interrupts (has to use selector register) has occurred and needs to be handled by GEN11+ handler
    DDU32 LegacyInterruptsOccurred : 1; // New for Gen11+  ::  This bit means use the IntArgs below for handling the interrupts

    DD_IN BOOLEAN HierarchicalInterruptService : 1; // This bit means request for Hirearchial Interrupt services

    DD_IN DDU32 EngineClass;                           // Can re-use ulValue in union
    DD_IN DDU32 EngineIntrpt;                          // Can re-use ulValue1 in union

    union
    {
        DDU32 Value;
        struct
        {
            //1. Hot Plug Interrupts Definitions - Starts Here

            DDU32    IntegratedCRTInterrupt : 1;    // Bit 0
            DDU32    ReservedBit : 1;    // Bit 1
            DDU32    InterruptReserved1 : 1;    // Bit 2
            DDU32    InterruptReserved2 : 1;    // Bit 3 //From Gen6 onwards,no need to register for this event as sDVO on Port C is disabled..
            DDU32    IntDP_HDMIAInterrupt : 1;    // Bit 4  //New Introduction from ILK onwards
            DDU32    IntDP_HDMIBInterrupt : 1;    // Bit 5
            DDU32    IntDP_HDMICInterrupt : 1;    // Bit 6
            DDU32    IntDP_HDMIDInterrupt : 1;    // Bit 7
            DDU32    IntDP_HDMIA_SPInterrupt : 1;    // Bit 8 //New Introduction from ILK onwards
            DDU32    IntDP_HDMIB_SPInterrupt : 1;    // Bit 9
            DDU32    IntDP_HDMIC_SPInterrupt : 1;    // Bit 10
            DDU32    IntDP_HDMID_SPInterrupt : 1;    // Bit 11

                                                     //1. Hot Plug Interrupts Definitions - Ends Here

                                                     //2. Render Geyserville Interrupts Definitions - Starts Here

                                                     //Render Geyserville Interrupts common till ILK Platform
            DDU32    Ren_Gey_SoftwareCommandCompleteInterrupt : 1; // bit 12 // Render GeyserVille Interrupt
            DDU32    Ren_Gey_EvaluatedFrequencyChangeInterrupt : 1; // bit 13 // Render GeyserVille Interrupt

                                                                    //New Render Geyserville Interrupts exists only in ILK
            DDU32    Ren_Gey_AvgBusyThreshold : 1; // bit 14 // Render GeyserVille Interrupt
            DDU32    Ren_Gey_ContinuousBusyThreshold : 1; // bit 15 // Render GeyserVille Interrupt

                                                          //Render Geyserville Common between ILK and GT
            DDU32    Ren_Gey_UpEvaluationIntervalInterrupt : 1; // bit 16 // Render GeyserVille Interrupt
            DDU32    Ren_Gey_DownEvaluationIntervalInterrupt : 1; // bit 17 // Render GeyserVille Interrupt

                                                                  //Render Geyserville Introduced from GT
            DDU32    Ren_Gey_Controller_Disable_StateInterrupt : 1; // bit 18 // Render GeyserVille Interrupt

                                                                    //2. Render Geyserville Interrupts Definitions - Ends Here

                                                                    //3. Basic Render Interrupt Definitions - Starts Here

            DDU32    DebugInterrupt : 1; // Bit 19 Gen4 Onwards
            DDU32    PipeControlNotifyInterrupt : 1; // Bit 20 Gen4 Onwards
            DDU32    RenderUserInterrupt : 1; // Bit 21 Render Cmd UI
            DDU32    RenderMMIOSyncFlushStatus : 1; // Bit 22
            DDU32    RenderWatchDogCounterExcd : 1; // Bit 23 //ILK Onwards
            DDU32    RenderASContextSwitch : 1; // Bit 24 //ILK Onwards
            DDU32    RenderPageFault : 1; // Bit 25 //ILK Onwards

                                          //3. Basic Render Interrupt Definitions - Ends Here

                                          //4. Media/Video Interrupt Definitions - Starts Here
            DDU32    VideoUserInterrupt : 1; // Bit 26 Gen4 Onwards
            DDU32    VideoDecPipelineCntrExceed : 1; // Bit 27 Gen4 Onwards..Same as Video Command Streamer WatchDog Counter Exceeded in GT
                                                     //Following are valid from GT
            DDU32    VideoMIFlush_DWNotify : 1; // Bit 28
            DDU32    VideoMMIOSyncFlushStatus : 1; // Bit 29
            DDU32    VideoASContextSwitch : 1; // Bit 30
            DDU32    VideoPageFault : 1; // Bit 31

                                         //4. Media/Video Interrupt Definitions - Ends Here
        };
    };

    union
    {
        DDU32 Value1;
        struct
        {
            //5. Remaining Power Conservation Interrupt Starts here
            DDU32    LBPC_PipeAInterrupt : 1;    // Bit 0 - crestline and after. Doesnt exist from ILK Onwards
            DDU32    LBPC_PipeBInterrupt : 1;    // Bit 1 - crestline and after. Doesnt exist from ILK Onwards
            DDU32    DPST_HistInterrupt : 1;    // Bit 2 - crestline and after
            DDU32    DPST_PhaseInInterrupt : 1;    // Bit 3 - crestline and after

                                                   //Valid from GT Onwards
            DDU32    PCUDriverMBEvent : 1; // Bit 4
            DDU32    PCRenderFreqDownwardDuringRC6Timeout : 1; // Bit 5
            DDU32    PC_RPUpThresholdIntr : 1; // Bit 6
            DDU32    PC_RPDownThresholdIntr : 1; // Bit 7

                                                 //5. Remaining Power Conservation Interrupt Ends here

                                                 //6. Blitter Interrupts from GT Onwards Starts here

            DDU32    BlitterASContextSwitch : 1; // Bit 8
            DDU32    BlitterMIFlush_DWNotify : 1; // Bit 9
            DDU32    BlitterMMIOSyncFlushStatus : 1; // Bit 10
            DDU32    BlitterMI_User_Interrupt : 1; // Bit 11
            DDU32    BlitterPageFault : 1; // Bit 12
                                           //6. Blitter Interrupts from GT Onwards Ends here

                                           //7. Misc Interrupts Category Starts here
            DDU32    VSync_PipeAInterrupt : 1;    // Bit 13 //Not Required
            DDU32    VSync_PipeBInterrupt : 1;    // Bit 14 //Not Required
            DDU32    VBlank_PipeAInterrupt : 1;    // Bit 15
            DDU32    VBlank_PipeBInterrupt : 1;    // Bit 16
            DDU32    GSESystemLevel : 1;    // Bit 17  Valid from ILK Replacement for ASLE Interrupt
            DDU32    VblankTPV : 1;    // BIT 18 //Used for TPV Vblank Interrupt
            DDU32    ASLEInterrupt : 1;    // Bit 19  Need to remove Once MP Cleans up the ASLE INterrupt Stuff
            DDU32    AllFirstLevelInterrupts : 1;    // BIT 20 //Used for Enabling/Disabling of Interrupts..

                                                     //7. Misc Interrupts Category Ends here

                                                     //8. New added Interrupts
            DDU32    SpritePlaneAFlipDoneInterrupt : 1;    // BIT 21 //Used for Enabling/Disabling of Sprite Plane A Flip Done Interrupt..
            DDU32    SpritePlaneBFlipDoneInterrupt : 1;    // BIT 22 //Used for Enabling/Disabling of Sprite Plane B Flip Done Interrupt..

            DDU32    VSync_PipeCInterrupt : 1;    // BIT 23
            DDU32    VBlank_PipeCInterrupt : 1;    // BIT 24
            DDU32    SpritePlaneCFlipDoneInterrupt : 1;    // BIT 25

            DDU32    AudioHDCPRequestInterruptA : 1;    // BIT 26 //Audio HDCP request for transcoder A
            DDU32    AudioHDCPRequestInterruptB : 1;    // BIT 27 //Audio HDCP request for transcoder B
            DDU32    AudioHDCPRequestInterruptC : 1;    // BIT 28 //Audio HDCP request for transcoder C
            DDU32    AudioHDCPRequestInterrupt : 1;    // BIT 29 //Audio HDCP request for pre ilk platforms

            DDU32   PerfMonBufferHalfFullInterrupt : 1;    // BIT 30

            DDU32   Reserved_Bit31 : 1;    // Bit 31
        };
    };

    union
    {
        DDU32 Value2;
        struct
        {
            // This sections contains error/debug status bits
            DDU32 FIFOUnderrun_PipeAInterrupt : 1; // bit 0
            DDU32 CRC_Error_PipeAInterrupt : 1; // bit 1
            DDU32 CRC_Done_PipeAInterrupt : 1; // bit 2

            DDU32 FIFOUnderrun_PipeBInterrupt : 1; // bit 3
            DDU32 CRC_Error_PipeBInterrupt : 1; // bit 4
            DDU32 CRC_Done_PipeBInterrupt : 1; // bit 5

            DDU32 FIFOUnderrun_PipeCInterrupt : 1; // bit 6
            DDU32 CRC_Error_PipeCInterrupt : 1; // bit 7
            DDU32 CRC_Done_PipeCInterrupt : 1; // bit 8

                                               // VE (Video Enhancement) Interrupt Definitions - Starts Here - Valid from Gen7_5 (HSW+) onward
            DDU32 VEUserInterrupt : 1; // bit 9
            DDU32 VEMMIOSyncFlushStatus : 1; // bit 10
            DDU32 VECmdParserMasterError : 1; // bit 11
            DDU32 VEMIFlush_DWNotify : 1; // bit 12
                                          // VE (Video Enhancement) Interrupt Definitions - Ends Here

                                          // other interrupt bits that don't fit into the previous dwords
            DDU32 RenderParityError : 1; // Bit 13 Gen7 Onwards

            DDU32 VideoPavpUnsolicitedAttack : 1; // Bit 14 Gen7 Onwards

                                                  //Below are valid from BDW
            DDU32 VideoUserInterrupt2 : 1; // Bit 15
            DDU32 VideoDecPipelineCntrExceed2 : 1; // Bit 16
            DDU32 VideoMIFlush_DWNotify2 : 1; // Bit 17
            DDU32 VideoMMIOSyncFlushStatus2 : 1; // Bit 18
            DDU32 VideoASContextSwitch2 : 1; // Bit 19
            DDU32 VideoPageFault2 : 1; // Bit 20
            DDU32 VideoPavpUnsolicitedAttack2 : 1; // Bit 21

            DDU32 GuCSHIMError : 1;    // bit 22
            DDU32 GuCDMAINTError : 1;    // bit 23
            DDU32 GuCDMADone : 1;    // bit 24
            DDU32 GuCDoorBellRang : 1;    // bit 25
            DDU32 GuCIOMMUSentMsgtoGuc : 1;    // bit 26
            DDU32 GuCSemaphoreSignaled : 1;    // bit 27
            DDU32 GuCDisplayEventRecieved : 1;    // bit 28
            DDU32 GuCExecutionError : 1;    // bit 29
            DDU32 GuCInterruptToHost : 1;    // bit 30

            DDU32 CSTRInvalidTileDetection : 1;    // bits 31
        };
    };

    union
    {
        DDU32 Value3;
        struct
        {
            // This sections contains VEC/WiDi interrupts
            DDU32 VECSContextSwitchInterrupt : 1; // bit 0
            DDU32 VECSWaitOnSemaphore : 1; // bit 1
            DDU32 WDBoxInterrupt : 1; // bit 2
            DDU32 DPST_HistInterruptPipeB : 1;// bit 3
            DDU32 DPST_PhaseInInterruptPipeB : 1; // bit 4
            DDU32 DPST_HistInterruptPipeC : 1;// bit 5
            DDU32 DPST_PhaseInInterruptPipeC : 1; // bit 6

            DDU32 PipeA_Plane1FlipDoneInterrupt : 1; //bit 7
            DDU32 PipeA_Plane2FlipDoneInterrupt : 1; //bit 8
            DDU32 PipeA_Plane3FlipDoneInterrupt : 1; //bit 9

            DDU32 PipeB_Plane1FlipDoneInterrupt : 1; //bit 10
            DDU32 PipeB_Plane2FlipDoneInterrupt : 1; //bit 11
            DDU32 PipeB_Plane3FlipDoneInterrupt : 1; //bit 12

            DDU32 PipeC_Plane1FlipDoneInterrupt : 1; //bit 13
            DDU32 PipeC_Plane2FlipDoneInterrupt : 1; //bit 14
            DDU32 PipeC_Plane3FlipDoneInterrupt : 1; //bit 15

            DDU32 PipeA_Plane1FlipQueueEmptyInterrupt : 1; //bit 16
            DDU32 PipeA_Plane2FlipQueueEmptyInterrupt : 1; //bit 17
            DDU32 PipeA_Plane3FlipQueueEmptyInterrupt : 1; //bit 18

            DDU32 PipeB_Plane1FlipQueueEmptyInterrupt : 1; //bit 19
            DDU32 PipeB_Plane2FlipQueueEmptyInterrupt : 1; //bit 20
            DDU32 PipeB_Plane3FlipQueueEmptyInterrupt : 1; //bit 21

            DDU32 PipeC_Plane1FlipQueueEmptyInterrupt : 1; //bit 22
            DDU32 PipeC_Plane2FlipQueueEmptyInterrupt : 1; //bit 23
            DDU32 PipeC_Plane3FlipQueueEmptyInterrupt : 1; //bit 24

            DDU32 DEMiscSVMWaitDescriptorCompleted : 1; // bit 25
            DDU32 DEMiscSVMVTDFault : 1; // bit 26
            DDU32 DEMiscSVMPRQEvent : 1; // bit 27

            DDU32 PipeA_Plane4FlipDoneInterrupt : 1; // bit 28
            DDU32 PipeB_Plane4FlipDoneInterrupt : 1; // bit 29
            DDU32 PSR2GTCLockLoss : 1; // bit 30
            DDU32 VECSWatchDogCounterExcd : 1; // bit 31
        };
    };
    union
    {
        DDU32 Value4;
        struct
        {
            DDU32 MIPIAInterrupt : 1; // bit 0
            DDU32 MIPICInterrupt : 1; // bit 1
            DDU32 LPEPipeAInterrupt : 1; // bit 2
            DDU32 LPEPipeBInterrupt : 1; // bit 3

            DDU32 ISPInterrupt : 1; // bit 4
            DDU32 VEDBlockInterrupt : 1; // bit 5
            DDU32 VEDPowerInterrupt : 1; // bit 6
            DDU32 PipeA_Plane4FlipQueueEmptyInterrupt : 1; // bit 7

            DDU32 PipeB_Plane4FlipQueueEmptyInterrupt : 1; // bit 8
            DDU32 LPEPipeCInterrupt : 1; // bit 9
            DDU32 GTPMCoreToUncoreTrapInterrupt : 1; //bit 10
            DDU32 WDBoxEndofFrameInterrupt : 1; //bit 11 corresponds to WDBOX_END_OF_FRAME_INTERRUPT = 0X800, in INTERRUPT_UNION_VALUE_4

            DDU32 IntDP_HDMIEInterrupt : 1; // Bit 12// skl ddi - e hot plug interrupt
            DDU32 IntDP_HDMIE_SPInterrupt : 1; // Bit 13
            DDU32 RenderTDLRetryInterrupt : 1; // bit 14
            DDU32 PinningContextSwitch : 1; // Bit 15
            DDU32 PinningUserInterrupt : 1; // Bit 16
            DDU32 DEMisc_WDCombinedInterrupt : 1; // bit 17 corresponds to DEMISC_WD_COMBINED_INTERRUPT  = 0x20000, in INTERRUPT_UNION_VALUE_4

            DDU32 PipeA_Underrun : 1; // bit 18
            DDU32 PipeB_Underrun : 1; // bit 19
            DDU32 PipeC_Underrun : 1; // bit 20
            DDU32 PipeC_Plane4FlipDoneInterrupt : 1; // bit 21
            DDU32 InvalidGTTPageTableEntry : 1; // bit 22
            DDU32 InvalidPageTableEntryData : 1; // bit 23
            DDU32 VSync_PipeDInterrupt : 1; // BIT 24
            DDU32 VBlank_PipeDInterrupt : 1; // BIT 25
            DDU32 IntDP_HDMIFInterrupt : 1; // Bit 26// ddi - f hot plug interrupt
            DDU32 IntDP_HDMIF_SPInterrupt : 1; // Bit 27
            DDU32 WDBox2Interrupt : 1; // bit 28
            DDU32 WDBox2EndofFrameInterrupt : 1; // bit 29
            DDU32 DEMisc_WD2CombinedInterrupt : 1; // bit 30
            DDU32 Reserved_Bits31_ulValue4 : 1; // bit 31
        };
    };
    union
    {
        DDU32 Value5;
        struct
        {
            DDU32 PipeA_Plane1GTTFaultStatus : 1; //bit 0
            DDU32 PipeA_Plane2GTTFaultStatus : 1; //bit 1
            DDU32 PipeA_Plane3GTTFaultStatus : 1; //bit 2
            DDU32 PipeA_Plane4GTTFaultStatus : 1; //bit 3
            DDU32 PipeA_CursorGTTFaultStatus : 1; //bit 4

            DDU32 PipeB_Plane1GTTFaultStatus : 1; //bit 5
            DDU32 PipeB_Plane2GTTFaultStatus : 1; //bit 6
            DDU32 PipeB_Plane3GTTFaultStatus : 1; //bit 7
            DDU32 PipeB_Plane4GTTFaultStatus : 1; //bit 8
            DDU32 PipeB_CursorGTTFaultStatus : 1; //bit 9

            DDU32 PipeC_Plane1GTTFaultStatus : 1; //bit 10
            DDU32 PipeC_Plane2GTTFaultStatus : 1; //bit 11
            DDU32 PipeC_Plane3GTTFaultStatus : 1; //bit 12
            DDU32 PipeC_Plane4GTTFaultStatus : 1; //bit 13
            DDU32 PipeC_CursorGTTFaultStatus : 1; //bit 14

            DDU32 IntDP_HDMIB_SCDCInterrupt : 1; //bit 15
            DDU32 IntDP_HDMIC_SCDCInterrupt : 1; //bit 16
            DDU32 IntDP_HDMID_SCDCInterrupt : 1; //bit 17
            DDU32 IntDP_HDMIE_SCDCInterrupt : 1; //bit 18
            DDU32 IntDP_HDMIF_SCDCInterrupt : 1; //bit 19

            DDU32 PipeA_Plane5FlipDoneInterrupt : 1; // bit 20
            DDU32 PipeA_Plane6FlipDoneInterrupt : 1; // bit 21
            DDU32 PipeA_Plane7FlipDoneInterrupt : 1; // bit 22
            DDU32 PipeB_Plane5FlipDoneInterrupt : 1; // bit 23
            DDU32 PipeB_Plane6FlipDoneInterrupt : 1; // bit 24
            DDU32 PipeB_Plane7FlipDoneInterrupt : 1; // bit 25
            DDU32 PipeC_Plane5FlipDoneInterrupt : 1; // bit 26
            DDU32 PipeC_Plane6FlipDoneInterrupt : 1; // bit 27
            DDU32 PipeC_Plane7FlipDoneInterrupt : 1; // bit 28
            DDU32 PipeD_Plane5FlipDoneInterrupt : 1; // bit 29
            DDU32 PipeD_Plane6FlipDoneInterrupt : 1; // bit 30
            DDU32 PipeD_Plane7FlipDoneInterrupt : 1; // bit 31
        };
    };
    union
    {
        DDU32 Value6;
        struct
        {
            DDU32 PipeA_Plane5GTTFaultStatus : 1; //bit 0
            DDU32 PipeA_Plane6GTTFaultStatus : 1; //bit 1
            DDU32 PipeA_Plane7GTTFaultStatus : 1; //bit 2
            DDU32 PipeB_Plane5GTTFaultStatus : 1; //bit 3
            DDU32 PipeB_Plane6GTTFaultStatus : 1; //bit 4
            DDU32 PipeB_Plane7GTTFaultStatus : 1; //bit 5
            DDU32 PipeC_Plane5GTTFaultStatus : 1; //bit 6
            DDU32 PipeC_Plane6GTTFaultStatus : 1; //bit 7
            DDU32 PipeC_Plane7GTTFaultStatus : 1; //bit 8
            DDU32 PipeD_Plane5GTTFaultStatus : 1; //bit 9
            DDU32 PipeD_Plane6GTTFaultStatus : 1; //bit 10
            DDU32 PipeD_Plane7GTTFaultStatus : 1; //bit 11
            DDU32 PipeD_Plane1FlipDoneInterrupt : 1; //bit 12
            DDU32 PipeD_Plane2FlipDoneInterrupt : 1; //bit 13
            DDU32 PipeD_Plane3FlipDoneInterrupt : 1; //bit 14
            DDU32 PipeD_Plane4FlipDoneInterrupt : 1; //bit 15
            DDU32 PipeD_Plane1GTTFaultStatus : 1; //bit 16
            DDU32 PipeD_Plane2GTTFaultStatus : 1; //bit 17
            DDU32 PipeD_Plane3GTTFaultStatus : 1; //bit 18
            DDU32 PipeD_Plane4GTTFaultStatus : 1; //bit 19
            DDU32 PipeD_CursorGTTFaultStatus : 1; //bit 20
            DDU32 PipeD_DPST_HistInterrupt : 1;// bit 21
            DDU32 CRC_Error_PipeDInterrupt : 1; // bit 22
            DDU32 CRC_Done_PipeDInterrupt : 1; // bit 23
            DDU32 PipeD_Underrun : 1; // bit 24
            DDU32 AudioHDCPRequestInterruptD : 1; // bit 25
            DDU32 IntDP_HDMIA_SCDCInterrupt : 1; // bit 26
            DDU32 PIPEA_VRRDoubleBufferUpdate : 1; // bit 27
            DDU32 PIPEB_VRRDoubleBufferUpdate : 1; // bit 28
            DDU32 PIPEC_VRRDoubleBufferUpdate : 1; // bit 29
            DDU32 PIPED_VRRDoubleBufferUpdate : 1; // bit 30
            DDU32 Reserved_Bits31_ulValue6 : 1; // bits 31
        };
    }; // TODO: map new events 5 6
} DD_INTERRUPT_ARGS, *PDD_INTERRUPT_ARGS;

