#include "globals.h"
#include "Driver.h"
#include "Hooks.h"
#include "kmem.h"
#include "Helpers.h"
#include <stdlib.h>
#include <stdio.h>
#include "igdkmd_patcher\igdkmd_patcher.h"
#include "igdkmd_patcher\igdkmd_intc.h"
#include "DFT.h"
#include "logger.h"
#include "crc.h"
#include "registers.h"


extern ULONG igdkmd_patcher_status;
extern VOID  Patch_MMIOInterface();

ULONG enableWaterMarkCorruptions = 0;
KDPC  DpcGetCRC[MAX_PIPES];
KTIMER TimerSwapBuffers;

///////////////////////////////////////////////////////////////////////////////////////////////////
extern NTSTATUS __hooked_DxgkDdiStartDevice_DDRW(_In_ const PVOID MiniportDeviceContext, _In_ PDXGK_START_INFO DxgkStartInfo, _In_ PDXGKRNL_INTERFACE DxgkInterface, _Out_ PULONG NumberOfVideoPresentSources, _Out_ PULONG NumberOfChildren);


VOID MessageCollectorDpcRoutine(
    _In_     struct _KDPC *Dpc,
    _In_opt_ PVOID        DeferredContext,
    _In_opt_ PVOID        SystemArgument1,
    _In_opt_ PVOID        SystemArgument2
);

BOOLEAN(*igdkmd_KmWriteMMIO_Data)(PVOID, ULONG, PVOID, ULONG) = NULL;
BOOLEAN(*igdkmd_KmReadMMIO_Data)(PVOID, ULONG, PVOID, ULONG) = NULL;

//DDI framework functions
PDXGKDDI_QUERYADAPTERINFO              igdkmd_DxgkDdiQueryAdapterInfo = NULL;
PDXGKDDI_ADD_DEVICE                    igdkmd_DxgkDdiAddDevice = NULL;
PDXGKDDI_COMMITVIDPN                   igdkmd_DxgkDdiCommitVidPn = NULL;
PDXGKDDI_UPDATEACTIVEVIDPNPRESENTPATH  igdkmd_DxgkDdiUpdateActiveVidPnPresentPath = NULL;
PDXGKDDI_INTERRUPT_ROUTINE             igdkmd_DxgkDdiInterruptRoutine = NULL;
PDXGKDDI_START_DEVICE                  igdkmd_DxgkDdiStartDevice = NULL;
PVOID                                  igdkmd_hwContext = NULL;
PDXGKDDI_CONTROLINTERRUPT              igdkmd_DxgkDdiControlInterrupt = NULL;
PDXGKDDI_SET_POWER_STATE               igdkmd_DxgkDdiSetPowerState = NULL;
PDXGKDDI_QUERY_CHILD_STATUS            igdkmd_DxgkDdiQueryChildStatus = NULL;


NTSTATUS(*igdkmd_EventNotifyInterrupt_56)(PVOID pHwDev, SB_INTERRUPT_ARGS_56 IntArgs) = NULL;
NTSTATUS(*igdkmd_EventNotifyInterrupt_52)(PVOID pHwDev, SB_INTERRUPT_ARGS_52 IntArgs) = NULL;
NTSTATUS(*igdkmd_EventNotifyInterrupt_48)(PVOID pHwDev, SB_INTERRUPT_ARGS_48 IntArgs) = NULL;
NTSTATUS(*igdkmd_EventNotifyInterrupt_28)(PVOID pHwDev, SB_INTERRUPT_ARGS_28 IntArgs) = NULL;

NTSTATUS(*igdkmd_InterruptServices_56)(PVOID pHwDev, SB_INTERRUPT_ARGS_56 IntArgs) = NULL;
NTSTATUS(*igdkmd_InterruptServices_52)(PVOID pHwDev, SB_INTERRUPT_ARGS_52 IntArgs) = NULL;
NTSTATUS(*igdkmd_InterruptServices_48)(PVOID pHwDev, SB_INTERRUPT_ARGS_48 IntArgs) = NULL;
NTSTATUS(*igdkmd_InterruptServices_28)(PVOID pHwDev, SB_INTERRUPT_ARGS_28 IntArgs) = NULL;
NTSTATUS(*igdkmd_EventService)(PVOID pHwDev, INT eOperation, INT eEvent) = NULL;
NTSTATUS(*igdkmd_UpdateHandlers)(PVOID pHwDev, INT eEvent, void(__cdecl *pIsr)(PVOID), void(__cdecl *pDpc)(PVOID)) = NULL;
NTSTATUS(*igdkmd_GfxSetSourceVisibility_16)(PVOID pHwDev, PVOID args) = NULL;
NTSTATUS(*igdkmd_InterruptServices)(PVOID pHwDev, PSB_INTERRUPT_ARGS IntArgs) = NULL;
ULONG(*igdkmd_NotifyPowerState)(PVOID pThis, PVOID pArgs) = NULL;

VOID(*report_SoftSync)(ULONG pipeId) = __dummy_report_SoftSync;

USHORT pipeId__SB_MODE_ARGS = 0;
ULONG(*igdkmd_SetMode)(PVOID pThis, PVOID pSetModeArgs) = NULL;
ULONG(*igdkmd_NotifyModeSetComplete)(PVOID pThis, PVOID pSetModeArgs) = NULL;

ULONG(*igdkmd_BlankVideo)(PVOID pThis, PVOID pArgs) = NULL;

USHORT DisplayPwrSetArgs_Size = 0;
ULONG(*igdkmd_SetDisplayPowerState)(PVOID pThis, PVOID pDisplaySetPwrArgs) = NULL;

NTSTATUS __hooked_EventNotifyInterrupt_56(PVOID pHwDev, SB_INTERRUPT_ARGS_56 IntArgs);
NTSTATUS __hooked_EventNotifyInterrupt_52(PVOID pHwDev, SB_INTERRUPT_ARGS_52 IntArgs);
NTSTATUS __hooked_EventNotifyInterrupt_48(PVOID pHwDev, SB_INTERRUPT_ARGS_48 IntArgs);
NTSTATUS __hooked_EventNotifyInterrupt_28(PVOID pHwDev, SB_INTERRUPT_ARGS_28 IntArgs);

PVOID(*igdkmd_GetHALInterface)() = NULL;

__pragma(warning(push))
__pragma(warning(disable:4221))
__pragma(warning(disable:4204))


BOOL isDDRWPath() {
    if (igdkmd_GetHALInterface)
    {
        return TRUE;
    }
    return FALSE;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
//DDI API HOOKS
///////////////////////////////////////////////////////////////////////////////////////////////////
NTSTATUS __hooked_DxgkDdiAddDevice(_In_  const PDEVICE_OBJECT PhysicalDeviceObject, _Out_ PVOID *MiniportDeviceContext)
{
    NTSTATUS retV = igdkmd_DxgkDdiAddDevice(PhysicalDeviceObject, MiniportDeviceContext);
    igdkmd_hwContext = *MiniportDeviceContext;
    return retV;
}


///////////////////////////////////////////////////////////////////////////////////////////////////
NTSTATUS  __hooked_DxgkDdiUpdateActiveVidPnPresentPath(_In_ const HANDLE hAdapter, _In_ const DXGKARG_UPDATEACTIVEVIDPNPRESENTPATH *pUpdateActiveVidPnPresentPathArg)
{
    addToLog(_F(">> UPDATE VIDPN "), 0, 0, 0);
    NTSTATUS retV = igdkmd_DxgkDdiUpdateActiveVidPnPresentPath(hAdapter, pUpdateActiveVidPnPresentPathArg);
    addToLog(_F("<< UPDATE VIDPN "), 0, 0, 0);
    return retV;
}


///////////////////////////////////////////////////////////////////////////////////////////////////
NTSTATUS __hooked_DxgkDdiStartDevice(_In_ const PVOID MiniportDeviceContext, _In_ PDXGK_START_INFO DxgkStartInfo, _In_ PDXGKRNL_INTERFACE DxgkInterface, _Out_ PULONG NumberOfVideoPresentSources, _Out_ PULONG NumberOfChildren)
{

    PSYMBOLINFO PSI_pIntVtbl = GetModSymbol(igdkmd_patcher_modInfoPtr, "pIntVtbl@HW_DEV_EXT");
    PSYMBOLINFO PSI_pfnEventNotifyIsr = GetModSymbol(igdkmd_patcher_modInfoPtr, "pfnEvNotIsr@INT_SRV");
    PSYMBOLINFO PSI_pfnEventService = GetModSymbol(igdkmd_patcher_modInfoPtr, "pfnEventService@INT_SRV");

    PSYMBOLINFO PSI_pfnInterruptServices = GetModSymbol(igdkmd_patcher_modInfoPtr, "pfnInterruptServices@SW_BIOS");
    PSYMBOLINFO PSI_SwBios = GetModSymbol(igdkmd_patcher_modInfoPtr, "SwBios@HW_DEV_EXT");

    PTR_T _pfnInterruptServices = (PTR_T)MiniportDeviceContext + (PTR_T)PSI_SwBios->rva;
    _pfnInterruptServices = *(PTR_T*)_pfnInterruptServices + (PTR_T)PSI_pfnInterruptServices->rva;

    PSYMBOLINFO PSI_pfnUpdateHandlers = GetModSymbol(igdkmd_patcher_modInfoPtr, "pfnUpdateHandlers@INT_SRV");

    NTSTATUS status = igdkmd_DxgkDdiStartDevice(MiniportDeviceContext, DxgkStartInfo, DxgkInterface, NumberOfVideoPresentSources, NumberOfChildren);


    PTR_T _pIntVtbl = (PTR_T)MiniportDeviceContext + (PTR_T)PSI_pIntVtbl->rva;
    PTR_T _pfnEventNotifyIsr = *(PTR_T*)_pIntVtbl + (PTR_T)PSI_pfnEventNotifyIsr->rva;
    PTR_T _EventService = *(PTR_T*)_pIntVtbl + (PTR_T)PSI_pfnEventService->rva;


    F_ASSIGN(igdkmd_EventService = *(PVOID*)_EventService;);
    PTR_T _UpdateHandlers = *(PTR_T*)_pIntVtbl + (PTR_T)PSI_pfnUpdateHandlers->rva;
    F_ASSIGN(igdkmd_UpdateHandlers = *(PVOID*)_UpdateHandlers;); \


        PSYMBOLINFO PSI_SB_INTERRUPT_ARGS = GetModSymbol(igdkmd_patcher_modInfoPtr, "_SB_INTERRUPT_ARGS");

    if (PSI_SB_INTERRUPT_ARGS->size == 56) {
        if (*(PVOID*)_pfnEventNotifyIsr != __hooked_EventNotifyInterrupt_56)
        {
            F_ASSIGN(igdkmd_EventNotifyInterrupt_56 = *(PVOID*)_pfnEventNotifyIsr;)
                F_ASSIGN(*(PVOID*)_pfnEventNotifyIsr = __hooked_EventNotifyInterrupt_56;)
                F_ASSIGN(igdkmd_InterruptServices_56 = *(PVOID*)_pfnInterruptServices);
        }

    }
    else if (PSI_SB_INTERRUPT_ARGS->size == 52)
    {
        if (*(PVOID*)_pfnEventNotifyIsr != __hooked_EventNotifyInterrupt_52)
        {
            F_ASSIGN(igdkmd_EventNotifyInterrupt_52 = *(PVOID*)_pfnEventNotifyIsr;)
                F_ASSIGN(*(PVOID*)_pfnEventNotifyIsr = __hooked_EventNotifyInterrupt_52;)
                F_ASSIGN(igdkmd_InterruptServices_52 = *(PVOID*)_pfnInterruptServices);
        }
    }
    else if (PSI_SB_INTERRUPT_ARGS->size == 48)
    {
        if (*(PVOID*)_pfnEventNotifyIsr != __hooked_EventNotifyInterrupt_48)
        {
            F_ASSIGN(igdkmd_EventNotifyInterrupt_48 = *(PVOID*)_pfnEventNotifyIsr;)
                F_ASSIGN(*(PVOID*)_pfnEventNotifyIsr = __hooked_EventNotifyInterrupt_48;)
                F_ASSIGN(igdkmd_InterruptServices_48 = *(PVOID*)_pfnInterruptServices);
        }
    }
    else if (PSI_SB_INTERRUPT_ARGS->size == 28)
    {
        if (*(PVOID*)_pfnEventNotifyIsr != __hooked_EventNotifyInterrupt_28)
        {
            F_ASSIGN(igdkmd_EventNotifyInterrupt_28 = *(PVOID*)_pfnEventNotifyIsr;)
                F_ASSIGN(*(PVOID*)_pfnEventNotifyIsr = __hooked_EventNotifyInterrupt_28;)
                F_ASSIGN(igdkmd_InterruptServices_28 = *(PVOID*)_pfnInterruptServices);
        }
    }
    else
    {
        ELOG("Unknown SB_INTERRUPT_ARGS size!");
    }

    PSYMBOLINFO PSI_SetMode = GetModSymbol(igdkmd_patcher_modInfoPtr, "pfnSetMode@SW_BIOS");
    if (!PSI_SetMode)
    {
        ELOG("No symbol info for [pfnSetMode].\n");
    }
    else
    {
        PTR_T _pfnSetMode = *(PTR_T*)((PTR_T)MiniportDeviceContext + (PTR_T)PSI_SwBios->rva) + (PTR_T)PSI_SetMode->rva;
        F_ASSIGN(igdkmd_SetMode = *(PVOID*)_pfnSetMode);
        F_ASSIGN(*(PVOID*)_pfnSetMode = __hooked_igdkmd_SetMode;);
    }

    PSYMBOLINFO PSI_NotifyModeSetComplete = GetModSymbol(igdkmd_patcher_modInfoPtr, "pfnNotifyModeSetComplete@SW_BIOS");
    if (!PSI_NotifyModeSetComplete)
    {
        ELOG("No symbol info for [pfnNotifyModeSetComplete].\n");
    }
    else
    {
        PTR_T _pfnNotifyModeSetComplete = *(PTR_T*)((PTR_T)MiniportDeviceContext + (PTR_T)PSI_SwBios->rva) + (PTR_T)PSI_NotifyModeSetComplete->rva;
        F_ASSIGN(igdkmd_NotifyModeSetComplete = *(PVOID*)_pfnNotifyModeSetComplete);
        F_ASSIGN(*(PVOID*)_pfnNotifyModeSetComplete = __hooked_igdkmd_NotifyModeSetComplete;);
    }


    PSYMBOLINFO PSI_SetDisplayPowerState = GetModSymbol(igdkmd_patcher_modInfoPtr, "pfnSetDisplayPowerState@SW_BIOS");
    if (!PSI_SetDisplayPowerState)
    {
        ELOG("No symbol info for [pfnSetDisplayPowerState].\n");
    }
    else
    {
        PTR_T _pfnSetDisplayPowerState = *(PTR_T*)((PTR_T)MiniportDeviceContext + (PTR_T)PSI_SwBios->rva) + (PTR_T)PSI_SetDisplayPowerState->rva;
        F_ASSIGN(igdkmd_SetDisplayPowerState = *(PVOID*)_pfnSetDisplayPowerState);
        F_ASSIGN(*(PVOID*)_pfnSetDisplayPowerState = __hooked_igdkmd_SetDisplayPowerState;);
    }

    PSYMBOLINFO PSI_s_pGMCHPointer = GetModSymbol(igdkmd_patcher_modInfoPtr, "s_pGMCHPointer");
    PSYMBOLINFO PSI_NotifyPowerState = GetModSymbol(igdkmd_patcher_modInfoPtr, "NotifyPowerState@GMCHBASE");
    if (!(PSI_s_pGMCHPointer&&PSI_NotifyPowerState))
    {
        ELOG("No symbol info for [s_pGMCHPointer/NotifyPowerState].\n");
    }
    else
    {
        PTR_T _NotifyPowerState = *(PTR_T*)((PTR_T)igdkmd_imageBase + PSI_s_pGMCHPointer->rva);
        _NotifyPowerState += PSI_NotifyPowerState->rva;
        F_ASSIGN(igdkmd_NotifyPowerState = *(PVOID*)_NotifyPowerState);
        F_ASSIGN(*(PVOID*)_NotifyPowerState = __hooked_igdkmd_NotifyPowerState;);
    }


#if 0
    PSYMBOLINFO PSI_BlankVideo = GetModSymbol(igdkmd_patcher_modInfoPtr, "pfnBlankVideo@SW_BIOS");
    if (!PSI_BlankVideo)
    {
        ELOG("No symbol info for [PSI_BlankVideo].\n");
    }
    else
    {
        PTR_T _pfnBlankVideo = *(PTR_T*)((PTR_T)MiniportDeviceContext + (PTR_T)PSI_SwBios->rva) + (PTR_T)PSI_BlankVideo->rva;
        F_ASSIGN(igdkmd_BlankVideo = *(PVOID*)_pfnBlankVideo);
        F_ASSIGN(*(PVOID*)_pfnBlankVideo = __hooked_igdkmd_BlankVideo;);
    }
#endif

    igdkmd_patcher_status = 1;

    Patch_MMIOInterface();
    
    ValDiState = VALDISTATE_RUNNING;

    return status;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
BOOLEAN __hooked_DxgkDdiInterruptRoutine(IN PVOID MiniportDeviceContext, IN ULONG MessageNumber)
{
    //@NOTICE: Place to implement custom INT handler.
    return igdkmd_DxgkDdiInterruptRoutine(MiniportDeviceContext, MessageNumber);
}



static BOOL _resumeAction = FALSE;

///////////////////////////////////////////////////////////////////////////////////////////////////
NTSTATUS __hooked_DxgkDdi_SetPowerState(
    IN_CONST_PVOID          MiniportDeviceContext,
    IN_ULONG                DeviceUid,
    IN_DEVICE_POWER_STATE   DevicePowerState,
    IN_POWER_ACTION         ActionType
)
{
    PLOG("ValDi [__hooked_DxgkDdi_SetPowerState]: 0x%X. ActionType: 0x%X\n", DevicePowerState, ActionType);
    if (DevicePowerState == PowerDeviceD3 && (ActionType == PowerActionSleep || ActionType == PowerActionHibernate))
    { 
        ELOG("ValDi [__hooked_DxgkDdi_SetPowerState]: Set ResumeAction = TRUE \n");
        _resumeAction = TRUE;
    }
   
    return igdkmd_DxgkDdiSetPowerState(MiniportDeviceContext, DeviceUid, DevicePowerState, ActionType);    
}


NTSTATUS
__hooked_DxgkDdi_Query_Child_Status(
    IN_CONST_PVOID              MiniportDeviceContext,
    INOUT_PDXGK_CHILD_STATUS    ChildStatus,
    IN_BOOLEAN                  NonDestructiveOnly
)
{
    ELOG("ValDi [__hooked_DxgkDdi_Query_Child_Status]: Action = %X\n", _resumeAction);
    if (_resumeAction)
    {        
        ELOG("ValDi [__hooked_DxgkDdi_Query_Child_Status]: Set ResumeAction = FALSE \n");
        _resumeAction = FALSE;
        HandleResumeEvent();
        
    }
    return igdkmd_DxgkDdiQueryChildStatus(MiniportDeviceContext, ChildStatus, NonDestructiveOnly);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
NTSTATUS(*native_DxgkInitialize)(PDRIVER_OBJECT, PUNICODE_STRING, PDRIVER_INITIALIZATION_DATA) = NULL;
NTSTATUS __hooked_DxgkInitialize(_In_ PDRIVER_OBJECT DriverObject, _In_ PUNICODE_STRING RegistryPath, _In_ PDRIVER_INITIALIZATION_DATA DriverInitializationData)
{
    DriverObject->DriverExtension;

    if (DriverInitializationData->DxgkDdiStartDevice != __hooked_DxgkDdiStartDevice_DDRW ||
        DriverInitializationData->DxgkDdiStartDevice != __hooked_DxgkDdiStartDevice)
    {
        igdkmd_DxgkDdiQueryAdapterInfo = DriverInitializationData->DxgkDdiQueryAdapterInfo;
        igdkmd_DxgkDdiAddDevice = DriverInitializationData->DxgkDdiAddDevice;
        igdkmd_DxgkDdiStartDevice = DriverInitializationData->DxgkDdiStartDevice;
        igdkmd_DxgkDdiInterruptRoutine = DriverInitializationData->DxgkDdiInterruptRoutine;
        igdkmd_DxgkDdiCommitVidPn = DriverInitializationData->DxgkDdiCommitVidPn;
        igdkmd_DxgkDdiUpdateActiveVidPnPresentPath = DriverInitializationData->DxgkDdiUpdateActiveVidPnPresentPath;
        igdkmd_DxgkDdiControlInterrupt = DriverInitializationData->DxgkDdiControlInterrupt;
        igdkmd_DxgkDdiSetPowerState = DriverInitializationData->DxgkDdiSetPowerState;
        igdkmd_DxgkDdiQueryChildStatus = DriverInitializationData->DxgkDdiQueryChildStatus;

        DriverInitializationData->DxgkDdiAddDevice = __hooked_DxgkDdiAddDevice;
        if (isDDRWPath())
        {
            DriverInitializationData->DxgkDdiStartDevice = __hooked_DxgkDdiStartDevice_DDRW;
            DriverInitializationData->DxgkDdiSetPowerState = __hooked_DxgkDdi_SetPowerState;
            DriverInitializationData->DxgkDdiQueryChildStatus = __hooked_DxgkDdi_Query_Child_Status;
        }
        else {
            DriverInitializationData->DxgkDdiStartDevice = __hooked_DxgkDdiStartDevice;
        }
    }

    /*
     ULONG max, min, curr;
     ExQueryTimerResolution(&max, &min, &curr);
     ExSetTimerResolution(max, TRUE);
     */
    NTSTATUS status = native_DxgkInitialize(DriverObject, RegistryPath, DriverInitializationData);
    return status;
}


///////////////////////////////////////////////////////////////////////////////////////////////////
NTSTATUS(*igdkmd_DxgkInitializeDisplayOnlyDriver)(PDRIVER_OBJECT, PUNICODE_STRING, PKMDDOD_INITIALIZATION_DATA) = NULL;


//----------------------------------------------------------------------------
//  Function    :   __hooked_DxgkInitializeDisplayOnlyDriver
//  Type        :   Hooked function 
//  Description :   Patch igdkmd64.sys before original DxgkInitializeDisplayOnlyDriver()
//  Callers     :   igdkmd64.sys in response to DriveryEntry within igfxkmd64.sys.
//  Notes       :   DriverEntry[igdkmd.sys]->__hooked_DxgkInitializeDisplayOnlyDriver[ValDi.sys]->igdkmd_DxgkInitializeDisplayOnlyDriver[igdkmd.sys]
//-----------------------------------------------------------------------------
NTSTATUS __hooked_DxgkInitializeDisplayOnlyDriver(
	_In_ PDRIVER_OBJECT DriverObject, 
	_In_ PUNICODE_STRING RegistryPath, 
	_In_ PKMDDOD_INITIALIZATION_DATA DriverInitializationData)
{
	if (DriverInitializationData->DxgkDdiStartDevice != __hooked_DxgkDdiStartDevice_DDRW ||
		DriverInitializationData->DxgkDdiStartDevice != __hooked_DxgkDdiStartDevice)
	{
		//Cache HwContext in __hooked_DxgkDdiAddDevice()
		DriverInitializationData->DxgkDdiAddDevice = __hooked_DxgkDdiAddDevice;
		if (isDDRWPath())
		{
			DriverInitializationData->DxgkDdiStartDevice = __hooked_DxgkDdiStartDevice_DDRW;
		}
		else {
			DriverInitializationData->DxgkDdiStartDevice = __hooked_DxgkDdiStartDevice;
		}
	}
	
	// call original function in igdkmd64.sys
	NTSTATUS status = igdkmd_DxgkInitializeDisplayOnlyDriver(DriverObject, RegistryPath, DriverInitializationData);
	return status;
}


///////////////////////////////////////////////////////////////////////////////////////////////////
//IGD API HOOKS
///////////////////////////////////////////////////////////////////////////////////////////////////


//Patched function to trap interrupt handling for mainline driver. 58 is the size of the SB_INTERRUPTS_ARGS structure
// in driver
NTSTATUS __hooked_EventNotifyInterrupt_56(PVOID pHwDev, SB_INTERRUPT_ARGS_56 IntArgs)
{
    if (ValDiState&VALDISTATE_TRACING_FLAG)
    {

        if (__option_trace_flip)
        {
            if (IntArgs.bPipeA_Plane1FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_A_ID, 1);
                IntArgs.bPipeA_Plane1FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeA_Plane2FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_A_ID, 2);
                IntArgs.bPipeA_Plane2FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeA_Plane3FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_A_ID, 3);
                IntArgs.bPipeA_Plane3FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeA_Plane4FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_A_ID, 4);
                IntArgs.bPipeA_Plane4FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane1FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_B_ID, 1);
                IntArgs.bPipeB_Plane1FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane2FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_B_ID, 2);
                IntArgs.bPipeB_Plane2FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane3FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_B_ID, 3);
                IntArgs.bPipeB_Plane3FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane4FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_B_ID, 4);
                IntArgs.bPipeB_Plane4FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeC_Plane1FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_C_ID, 1);
                IntArgs.bPipeC_Plane1FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeC_Plane2FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_C_ID, 2);
                IntArgs.bPipeC_Plane2FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeC_Plane3FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_C_ID, 3);
                IntArgs.bPipeC_Plane3FlipDoneInterrupt &= __option_mask_ints;
            }


            /*
            if (IntArgs.bPipeA_Plane1FlipQueueEmptyInterrupt)
            {
            __report_FlipQueueEmpt(PIPE_A_ID, 1);
            IntArgs.bPipeA_Plane1FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeA_Plane2FlipQueueEmptyInterrupt)
            {
            __report_FlipQueueEmpt(PIPE_A_ID, 2);
            IntArgs.bPipeA_Plane2FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeA_Plane3FlipQueueEmptyInterrupt)
            {
            __report_FlipQueueEmpt(PIPE_A_ID, 3);
            IntArgs.bPipeA_Plane3FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeA_Plane4FlipQueueEmptyInterrupt)
            {
            __report_FlipQueueEmpt(PIPE_A_ID, 4);
            IntArgs.bPipeA_Plane4FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane1FlipQueueEmptyInterrupt)
            {
            __report_FlipQueueEmpt(PIPE_B_ID, 1);
            IntArgs.bPipeB_Plane1FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane2FlipQueueEmptyInterrupt)
            {
            __report_FlipQueueEmpt(PIPE_B_ID, 2);
            IntArgs.bPipeB_Plane2FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane3FlipQueueEmptyInterrupt)
            {
            __report_FlipQueueEmpt(PIPE_B_ID, 3);
            IntArgs.bPipeB_Plane3FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane4FlipQueueEmptyInterrupt)
            {
            __report_FlipQueueEmpt(PIPE_B_ID, 4);
            IntArgs.bPipeB_Plane4FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeC_Plane1FlipQueueEmptyInterrupt)
            {
            __report_FlipQueueEmpt(PIPE_C_ID, 1);
            IntArgs.bPipeC_Plane1FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeC_Plane2FlipQueueEmptyInterrupt)
            {
            __report_FlipQueueEmpt(PIPE_C_ID, 2);
            IntArgs.bPipeC_Plane2FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeC_Plane3FlipQueueEmptyInterrupt)
            {
            __report_FlipQueueEmpt(PIPE_C_ID, 3);
            IntArgs.bPipeC_Plane3FlipQueueEmptyInterrupt &= __option_mask_ints;
            }
            */
        }


        if (__option_trace_with_pipe_CRC_done)
        {
            if (IntArgs.bCRC_Done_PipeAInterrupt)
            {
                __report_SoftSync(PIPE_A_ID);
                IntArgs.bCRC_Done_PipeAInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bCRC_Done_PipeBInterrupt)
            {
                __report_SoftSync(PIPE_B_ID);
                IntArgs.bCRC_Done_PipeBInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bCRC_Done_PipeCInterrupt)
            {
                __report_SoftSync(PIPE_C_ID);
                IntArgs.bCRC_Done_PipeCInterrupt &= __option_mask_ints;
            }
        }
        else
        {
            if (IntArgs.bVBlank_PipeAInterrupt | IntArgs.bVSync_PipeAInterrupt)
                __schedule_pipeportCRCFetch(PIPE_A_ID);
            if (IntArgs.bVBlank_PipeBInterrupt | IntArgs.bVSync_PipeBInterrupt)
                __schedule_pipeportCRCFetch(PIPE_B_ID);
            if (IntArgs.bVBlank_PipeCInterrupt | IntArgs.bVSync_PipeCInterrupt)
                __schedule_pipeportCRCFetch(PIPE_C_ID);

            /*
            if (IntArgs.bVBlank_PipeAInterrupt)
            __report_portCRC(PIPE_A_ID);
            if (IntArgs.bVBlank_PipeBInterrupt)
            __report_portCRC(PIPE_B_ID);
            if (IntArgs.bVBlank_PipeCInterrupt)
            __report_portCRC(PIPE_C_ID);
            */
        }
    }

    if (IntArgs.bFIFOUnderrun_PipeAInterrupt)
    {
        __report_Underrun(_F("!FIFO_UND "), PIPE_A_ID);
        IntArgs.bFIFOUnderrun_PipeAInterrupt &= __option_mask_ints;

    }

    if (IntArgs.bFIFOUnderrun_PipeBInterrupt)
    {
        __report_Underrun(_F("!FIFO_UND "), PIPE_B_ID);
        IntArgs.bFIFOUnderrun_PipeBInterrupt &= __option_mask_ints;

    }

    if (IntArgs.bFIFOUnderrun_PipeCInterrupt)
    {
        __report_Underrun(_F("!FIFO_UND "), PIPE_C_ID);
        IntArgs.bFIFOUnderrun_PipeCInterrupt &= __option_mask_ints;

    }


    if (IntArgs.bPipeA_Underrun)
    {
        __report_Underrun(_F("!PIPE_UND "), PIPE_A_ID);
        IntArgs.bPipeA_Underrun &= __option_mask_ints;

    }

    if (IntArgs.bPipeB_Underrun)
    {
        __report_Underrun(_F("!PIPE_UND "), PIPE_B_ID);
        IntArgs.bPipeB_Underrun &= __option_mask_ints;

    }

    if (IntArgs.bPipeC_Underrun)
    {
        __report_Underrun(_F("!PIPE_UND "), PIPE_C_ID);
        IntArgs.bPipeC_Underrun &= __option_mask_ints;
    }


    return igdkmd_EventNotifyInterrupt_56(pHwDev, IntArgs);
}


//@TODO: Synchronous pipe & port CRC reporting triggered on CRC done INT for now.
//       In the future independent port/pipe tracing would allow for detecting of DP corruptions
//       when pipe is not active but DP perfomrs scanouts.


NTSTATUS __hooked_EventNotifyInterrupt_52(PVOID pHwDev, SB_INTERRUPT_ARGS_52 IntArgs)
{

    if (ValDiState&VALDISTATE_TRACING_FLAG)
    {

        if (__option_trace_flip)
        {
            if (IntArgs.bPipeA_Plane1FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_A_ID, 1);
                IntArgs.bPipeA_Plane1FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeA_Plane2FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_A_ID, 2);
                IntArgs.bPipeA_Plane2FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeA_Plane3FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_A_ID, 3);
                IntArgs.bPipeA_Plane3FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeA_Plane4FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_A_ID, 4);
                IntArgs.bPipeA_Plane4FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane1FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_B_ID, 1);
                IntArgs.bPipeB_Plane1FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane2FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_B_ID, 2);
                IntArgs.bPipeB_Plane2FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane3FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_B_ID, 3);
                IntArgs.bPipeB_Plane3FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane4FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_B_ID, 4);
                IntArgs.bPipeB_Plane4FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeC_Plane1FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_C_ID, 1);
                IntArgs.bPipeC_Plane1FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeC_Plane2FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_C_ID, 2);
                IntArgs.bPipeC_Plane2FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeC_Plane3FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_C_ID, 3);
                IntArgs.bPipeC_Plane3FlipDoneInterrupt &= __option_mask_ints;
            }


            /*
            if (IntArgs.bPipeA_Plane1FlipQueueEmptyInterrupt)
            {
            __report_FlipQueueEmpt(PIPE_A_ID, 1);
            IntArgs.bPipeA_Plane1FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeA_Plane2FlipQueueEmptyInterrupt)
            {
            __report_FlipQueueEmpt(PIPE_A_ID, 2);
            IntArgs.bPipeA_Plane2FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeA_Plane3FlipQueueEmptyInterrupt)
            {
            __report_FlipQueueEmpt(PIPE_A_ID, 3);
            IntArgs.bPipeA_Plane3FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeA_Plane4FlipQueueEmptyInterrupt)
            {
            __report_FlipQueueEmpt(PIPE_A_ID, 4);
            IntArgs.bPipeA_Plane4FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane1FlipQueueEmptyInterrupt)
            {
            __report_FlipQueueEmpt(PIPE_B_ID, 1);
            IntArgs.bPipeB_Plane1FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane2FlipQueueEmptyInterrupt)
            {
            __report_FlipQueueEmpt(PIPE_B_ID, 2);
            IntArgs.bPipeB_Plane2FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane3FlipQueueEmptyInterrupt)
            {
            __report_FlipQueueEmpt(PIPE_B_ID, 3);
            IntArgs.bPipeB_Plane3FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane4FlipQueueEmptyInterrupt)
            {
            __report_FlipQueueEmpt(PIPE_B_ID, 4);
            IntArgs.bPipeB_Plane4FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeC_Plane1FlipQueueEmptyInterrupt)
            {
            __report_FlipQueueEmpt(PIPE_C_ID, 1);
            IntArgs.bPipeC_Plane1FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeC_Plane2FlipQueueEmptyInterrupt)
            {
            __report_FlipQueueEmpt(PIPE_C_ID, 2);
            IntArgs.bPipeC_Plane2FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeC_Plane3FlipQueueEmptyInterrupt)
            {
            __report_FlipQueueEmpt(PIPE_C_ID, 3);
            IntArgs.bPipeC_Plane3FlipQueueEmptyInterrupt &= __option_mask_ints;
            }
            */
        }


        if (__option_trace_with_pipe_CRC_done)
        {
            if (IntArgs.bCRC_Done_PipeAInterrupt)
            {
                __report_SoftSync(PIPE_A_ID);
                IntArgs.bCRC_Done_PipeAInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bCRC_Done_PipeBInterrupt)
            {
                __report_SoftSync(PIPE_B_ID);
                IntArgs.bCRC_Done_PipeBInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bCRC_Done_PipeCInterrupt)
            {
                __report_SoftSync(PIPE_C_ID);
                IntArgs.bCRC_Done_PipeCInterrupt &= __option_mask_ints;
            }
        }
        else
        {
            if (IntArgs.bVBlank_PipeAInterrupt | IntArgs.bVSync_PipeAInterrupt)
                __schedule_pipeportCRCFetch(PIPE_A_ID);
            if (IntArgs.bVBlank_PipeBInterrupt | IntArgs.bVSync_PipeBInterrupt)
                __schedule_pipeportCRCFetch(PIPE_B_ID);
            if (IntArgs.bVBlank_PipeCInterrupt | IntArgs.bVSync_PipeCInterrupt)
                __schedule_pipeportCRCFetch(PIPE_C_ID);

            /*
            if (IntArgs.bVBlank_PipeAInterrupt)
            __report_portCRC(PIPE_A_ID);
            if (IntArgs.bVBlank_PipeBInterrupt)
            __report_portCRC(PIPE_B_ID);
            if (IntArgs.bVBlank_PipeCInterrupt)
            __report_portCRC(PIPE_C_ID);
            */
        }
    }

    if (IntArgs.bFIFOUnderrun_PipeAInterrupt)
    {
        __report_Underrun(_F("!FIFO_UND "), PIPE_A_ID);
        IntArgs.bFIFOUnderrun_PipeAInterrupt &= __option_mask_ints;

    }

    if (IntArgs.bFIFOUnderrun_PipeBInterrupt)
    {
        __report_Underrun(_F("!FIFO_UND "), PIPE_B_ID);
        IntArgs.bFIFOUnderrun_PipeBInterrupt &= __option_mask_ints;

    }

    if (IntArgs.bFIFOUnderrun_PipeCInterrupt)
    {
        __report_Underrun(_F("!FIFO_UND "), PIPE_C_ID);
        IntArgs.bFIFOUnderrun_PipeCInterrupt &= __option_mask_ints;

    }


    if (IntArgs.bPipeA_Underrun)
    {
        __report_Underrun(_F("!PIPE_UND "), PIPE_A_ID);
        IntArgs.bPipeA_Underrun &= __option_mask_ints;

    }

    if (IntArgs.bPipeB_Underrun)
    {
        __report_Underrun(_F("!PIPE_UND "), PIPE_B_ID);
        IntArgs.bPipeB_Underrun &= __option_mask_ints;

    }

    if (IntArgs.bPipeC_Underrun)
    {
        __report_Underrun(_F("!PIPE_UND "), PIPE_C_ID);
        IntArgs.bPipeC_Underrun &= __option_mask_ints;
    }


    return igdkmd_EventNotifyInterrupt_52(pHwDev, IntArgs);
}


NTSTATUS __hooked_EventNotifyInterrupt_48(PVOID pHwDev, SB_INTERRUPT_ARGS_48 IntArgs)
{

    if (ValDiState&VALDISTATE_TRACING_FLAG)
    {
        if (__option_trace_flip)
        {
            if (IntArgs.bPipeA_Plane1FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_A_ID, 1);
                IntArgs.bPipeA_Plane1FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeA_Plane2FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_A_ID, 2);
                IntArgs.bPipeA_Plane2FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeA_Plane3FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_A_ID, 3);
                IntArgs.bPipeA_Plane3FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeA_Plane4FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_A_ID, 4);
                IntArgs.bPipeA_Plane4FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane1FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_B_ID, 1);
                IntArgs.bPipeB_Plane1FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane2FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_B_ID, 2);
                IntArgs.bPipeB_Plane2FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane3FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_B_ID, 3);
                IntArgs.bPipeB_Plane3FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane4FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_B_ID, 4);
                IntArgs.bPipeB_Plane4FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeC_Plane1FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_C_ID, 1);
                IntArgs.bPipeC_Plane1FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeC_Plane2FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_C_ID, 2);
                IntArgs.bPipeC_Plane2FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeC_Plane3FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_C_ID, 3);
                IntArgs.bPipeC_Plane3FlipDoneInterrupt &= __option_mask_ints;
            }


            /*
            if (IntArgs.bPipeA_Plane1FlipQueueEmptyInterrupt)
            {
                __report_FlipQueueEmpt(PIPE_A_ID, 1);
                IntArgs.bPipeA_Plane1FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeA_Plane2FlipQueueEmptyInterrupt)
            {
                __report_FlipQueueEmpt(PIPE_A_ID, 2);
                IntArgs.bPipeA_Plane2FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeA_Plane3FlipQueueEmptyInterrupt)
            {
                __report_FlipQueueEmpt(PIPE_A_ID, 3);
                IntArgs.bPipeA_Plane3FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeA_Plane4FlipQueueEmptyInterrupt)
            {
                __report_FlipQueueEmpt(PIPE_A_ID, 4);
                IntArgs.bPipeA_Plane4FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane1FlipQueueEmptyInterrupt)
            {
                __report_FlipQueueEmpt(PIPE_B_ID, 1);
                IntArgs.bPipeB_Plane1FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane2FlipQueueEmptyInterrupt)
            {
                __report_FlipQueueEmpt(PIPE_B_ID, 2);
                IntArgs.bPipeB_Plane2FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane3FlipQueueEmptyInterrupt)
            {
                __report_FlipQueueEmpt(PIPE_B_ID, 3);
                IntArgs.bPipeB_Plane3FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane4FlipQueueEmptyInterrupt)
            {
                __report_FlipQueueEmpt(PIPE_B_ID, 4);
                IntArgs.bPipeB_Plane4FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeC_Plane1FlipQueueEmptyInterrupt)
            {
                __report_FlipQueueEmpt(PIPE_C_ID, 1);
                IntArgs.bPipeC_Plane1FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeC_Plane2FlipQueueEmptyInterrupt)
            {
                __report_FlipQueueEmpt(PIPE_C_ID, 2);
                IntArgs.bPipeC_Plane2FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeC_Plane3FlipQueueEmptyInterrupt)
            {
                __report_FlipQueueEmpt(PIPE_C_ID, 3);
                IntArgs.bPipeC_Plane3FlipQueueEmptyInterrupt &= __option_mask_ints;
            }
            */
        }


        if (__option_trace_with_pipe_CRC_done)
        {
            if (IntArgs.bCRC_Done_PipeAInterrupt)
            {
                __report_SoftSync(PIPE_A_ID);
                IntArgs.bCRC_Done_PipeAInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bCRC_Done_PipeBInterrupt)
            {
                __report_SoftSync(PIPE_B_ID);
                IntArgs.bCRC_Done_PipeBInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bCRC_Done_PipeCInterrupt)
            {
                __report_SoftSync(PIPE_C_ID);
                IntArgs.bCRC_Done_PipeCInterrupt &= __option_mask_ints;
            }
        }
        else
        {
            if (IntArgs.bVBlank_PipeAInterrupt | IntArgs.bVSync_PipeAInterrupt)
                __schedule_pipeportCRCFetch(PIPE_A_ID);
            if (IntArgs.bVBlank_PipeBInterrupt | IntArgs.bVSync_PipeBInterrupt)
                __schedule_pipeportCRCFetch(PIPE_B_ID);
            if (IntArgs.bVBlank_PipeCInterrupt | IntArgs.bVSync_PipeCInterrupt)
                __schedule_pipeportCRCFetch(PIPE_C_ID);

            /*
            if (IntArgs.bVBlank_PipeAInterrupt)
                __report_portCRC(PIPE_A_ID);
            if (IntArgs.bVBlank_PipeBInterrupt)
                __report_portCRC(PIPE_B_ID);
            if (IntArgs.bVBlank_PipeCInterrupt)
                __report_portCRC(PIPE_C_ID);
            */
        }
    }

    if (IntArgs.bFIFOUnderrun_PipeAInterrupt)
    {
        __report_Underrun(_F("!FIFO_UND "), PIPE_A_ID);
        IntArgs.bFIFOUnderrun_PipeAInterrupt &= __option_mask_ints;

    }

    if (IntArgs.bFIFOUnderrun_PipeBInterrupt)
    {
        __report_Underrun(_F("!FIFO_UND "), PIPE_B_ID);
        IntArgs.bFIFOUnderrun_PipeBInterrupt &= __option_mask_ints;

    }

    if (IntArgs.bFIFOUnderrun_PipeCInterrupt)
    {
        __report_Underrun(_F("!FIFO_UND "), PIPE_C_ID);
        IntArgs.bFIFOUnderrun_PipeCInterrupt &= __option_mask_ints;

    }


    if (IntArgs.bPipeA_Underrun)
    {
        __report_Underrun(_F("!PIPE_UND "), PIPE_A_ID);
        IntArgs.bPipeA_Underrun &= __option_mask_ints;

    }

    if (IntArgs.bPipeB_Underrun)
    {
        __report_Underrun(_F("!PIPE_UND "), PIPE_B_ID);
        IntArgs.bPipeB_Underrun &= __option_mask_ints;

    }

    if (IntArgs.bPipeC_Underrun)
    {
        __report_Underrun(_F("!PIPE_UND "), PIPE_C_ID);
        IntArgs.bPipeC_Underrun &= __option_mask_ints;
    }

    return igdkmd_EventNotifyInterrupt_48(pHwDev, IntArgs);
}

//-------------------------------------------------------------------------------------------------
NTSTATUS __hooked_EventNotifyInterrupt_28(PVOID pHwDev, SB_INTERRUPT_ARGS_28 IntArgs)
{
    /*
    if (IntArgs.bBlitterASContextSwitch)
        igdkmd_getPipeToPortConfig();
    */


    if (ValDiState&VALDISTATE_TRACING_FLAG)
    {
        if (__option_trace_flip)
        {
            if (IntArgs.bPipeA_Plane1FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_A_ID, 1);
                IntArgs.bPipeA_Plane1FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeA_Plane2FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_A_ID, 2);
                IntArgs.bPipeA_Plane2FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeA_Plane3FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_A_ID, 3);
                IntArgs.bPipeA_Plane3FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeA_Plane4FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_A_ID, 4);
                IntArgs.bPipeA_Plane4FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane1FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_B_ID, 1);
                IntArgs.bPipeB_Plane1FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane2FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_B_ID, 2);
                IntArgs.bPipeB_Plane2FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane3FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_B_ID, 3);
                IntArgs.bPipeB_Plane3FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane4FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_B_ID, 4);
                IntArgs.bPipeB_Plane4FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeC_Plane1FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_C_ID, 1);
                IntArgs.bPipeC_Plane1FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeC_Plane2FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_C_ID, 2);
                IntArgs.bPipeC_Plane2FlipDoneInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeC_Plane3FlipDoneInterrupt)
            {
                __report_FlipDone(PIPE_C_ID, 3);
                IntArgs.bPipeC_Plane3FlipDoneInterrupt &= __option_mask_ints;
            }


            /*
            if (IntArgs.bPipeA_Plane1FlipQueueEmptyInterrupt)
            {
                __report_FlipQueueEmpt(PIPE_A_ID, 1);
                IntArgs.bPipeA_Plane1FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeA_Plane2FlipQueueEmptyInterrupt)
            {
                __report_FlipQueueEmpt(PIPE_A_ID, 2);
                IntArgs.bPipeA_Plane2FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeA_Plane3FlipQueueEmptyInterrupt)
            {
                __report_FlipQueueEmpt(PIPE_A_ID, 3);
                IntArgs.bPipeA_Plane3FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeA_Plane4FlipQueueEmptyInterrupt)
            {
                __report_FlipQueueEmpt(PIPE_A_ID, 4);
                IntArgs.bPipeA_Plane4FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane1FlipQueueEmptyInterrupt)
            {
                __report_FlipQueueEmpt(PIPE_B_ID, 1);
                IntArgs.bPipeB_Plane1FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane2FlipQueueEmptyInterrupt)
            {
                __report_FlipQueueEmpt(PIPE_B_ID, 2);
                IntArgs.bPipeB_Plane2FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane3FlipQueueEmptyInterrupt)
            {
                __report_FlipQueueEmpt(PIPE_B_ID, 3);
                IntArgs.bPipeB_Plane3FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeB_Plane4FlipQueueEmptyInterrupt)
            {
                __report_FlipQueueEmpt(PIPE_B_ID, 4);
                IntArgs.bPipeB_Plane4FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeC_Plane1FlipQueueEmptyInterrupt)
            {
                __report_FlipQueueEmpt(PIPE_C_ID, 1);
                IntArgs.bPipeC_Plane1FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeC_Plane2FlipQueueEmptyInterrupt)
            {
                __report_FlipQueueEmpt(PIPE_C_ID, 2);
                IntArgs.bPipeC_Plane2FlipQueueEmptyInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bPipeC_Plane3FlipQueueEmptyInterrupt)
            {
                __report_FlipQueueEmpt(PIPE_C_ID, 3);
                IntArgs.bPipeC_Plane3FlipQueueEmptyInterrupt &= __option_mask_ints;
            }
            */
        }


        if (__option_trace_with_pipe_CRC_done)
        {
            if (IntArgs.bCRC_Done_PipeAInterrupt)
            {
                __report_SoftSync(PIPE_A_ID);
                IntArgs.bCRC_Done_PipeAInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bCRC_Done_PipeBInterrupt)
            {
                __report_SoftSync(PIPE_B_ID);
                IntArgs.bCRC_Done_PipeBInterrupt &= __option_mask_ints;
            }

            if (IntArgs.bCRC_Done_PipeCInterrupt)
            {
                __report_SoftSync(PIPE_C_ID);
                IntArgs.bCRC_Done_PipeCInterrupt &= __option_mask_ints;
            }
        }
        else
        {
            if (IntArgs.bVBlank_PipeAInterrupt | IntArgs.bVSync_PipeAInterrupt)
                __schedule_pipeportCRCFetch(PIPE_A_ID);
            if (IntArgs.bVBlank_PipeBInterrupt | IntArgs.bVSync_PipeBInterrupt)
                __schedule_pipeportCRCFetch(PIPE_B_ID);
            if (IntArgs.bVBlank_PipeCInterrupt | IntArgs.bVSync_PipeCInterrupt)
                __schedule_pipeportCRCFetch(PIPE_C_ID);

            /*
            if (IntArgs.bVBlank_PipeAInterrupt)
                __report_portCRC(PIPE_A_ID);
            if (IntArgs.bVBlank_PipeBInterrupt)
                __report_portCRC(PIPE_B_ID);
            if (IntArgs.bVBlank_PipeCInterrupt)
                __report_portCRC(PIPE_C_ID);
            */
        }
    }

    if (IntArgs.bFIFOUnderrun_PipeAInterrupt)
    {
        __report_Underrun(_F("!FIFO_UND "), PIPE_A_ID);
        IntArgs.bFIFOUnderrun_PipeAInterrupt &= __option_mask_ints;

    }

    if (IntArgs.bFIFOUnderrun_PipeBInterrupt)
    {
        __report_Underrun(_F("!FIFO_UND "), PIPE_B_ID);
        IntArgs.bFIFOUnderrun_PipeBInterrupt &= __option_mask_ints;

    }

    if (IntArgs.bFIFOUnderrun_PipeCInterrupt)
    {
        __report_Underrun(_F("!FIFO_UND "), PIPE_C_ID);
        IntArgs.bFIFOUnderrun_PipeCInterrupt &= __option_mask_ints;

    }


    if (IntArgs.bPipeA_Underrun)
    {
        __report_Underrun(_F("!PIPE_UND "), PIPE_A_ID);
        IntArgs.bPipeA_Underrun &= __option_mask_ints;

    }

    if (IntArgs.bPipeB_Underrun)
    {
        __report_Underrun(_F("!PIPE_UND "), PIPE_B_ID);
        IntArgs.bPipeB_Underrun &= __option_mask_ints;

    }

    if (IntArgs.bPipeC_Underrun)
    {
        __report_Underrun(_F("!PIPE_UND "), PIPE_C_ID);
        IntArgs.bPipeC_Underrun &= __option_mask_ints;
    }

    return igdkmd_EventNotifyInterrupt_28(pHwDev, IntArgs);
}







///////////////////////////////////////////////////////////////////////////////////////////////////
INT igdkmd_getAdapterInfo(INT infoType, ULONG infoDataSize, PVOID targetBufferPtr)
{
    DXGKARG_QUERYADAPTERINFO QueryAdapterInfo = { 0 };

    if (!igdkmd_DxgkDdiQueryAdapterInfo)
    {
        ELOG("NULL address for [DxgkDdiQueryAdapterInfo].\n");
        return -1;
    }

    QueryAdapterInfo.Type = infoType;
    QueryAdapterInfo.pOutputData = targetBufferPtr;
    QueryAdapterInfo.OutputDataSize = infoDataSize;

    if (NT_SUCCESS(igdkmd_DxgkDdiQueryAdapterInfo(igdkmd_hwContext, &QueryAdapterInfo)))
        return 0;

    return -1;
}


///////////////////////////////////////////////////////////////////////////////////////////////////
BOOLEAN inRange(ULONG low, ULONG high, ULONG x)
{
    return (((LONG)x - (LONG)high)*((LONG)x - (LONG)low) <= 0);
}





///////////////////////////////////////////////////////////////////////////////////////////////////
#define DPC_TIMEOUT 100
VOID MessageCollectorDpcRoutine(
    _In_     struct _KDPC *Dpc,
    _In_opt_ PVOID        DeferredContext,
    _In_opt_ PVOID        SystemArgument1,
    _In_opt_ PVOID        SystemArgument2
)
{
    //	USHORT timeout = DPC_TIMEOUT;

    UNREFERENCED_PARAMETER(Dpc);
    UNREFERENCED_PARAMETER(SystemArgument1);
    UNREFERENCED_PARAMETER(SystemArgument2);

    ULONG pipeId = *(ULONG*)&DeferredContext;
    ULONG crc;

    /*
    getCRC(pipeId, &crc);
    while ((timeout--)&&(crc == (ULONG)(-1)))
    {
        KeStallExecutionProcessor(100);
        crc = getCRC(pipeId, &crc);
    }
    */

    PVOID addrList[] = { &pipeId, &crc };
    ULONG sizesList[] = { sizeof(ULONG), sizeof(ULONG) };
    addToLog(_F("CRC READ [PIPE_ID; CRC_VALUE]: "), addrList, sizesList, 2);

}

///////////////////////////////////////////////////////////////////////////////////////////////////
ULONG __hooked_igdkmd_SetMode(PVOID this, PVOID pSetModeArgs)
{
    ULONG pipeId = *(ULONG*)((PTR_T)pSetModeArgs + pipeId__SB_MODE_ARGS);
    PVOID addrList[1];
    ULONG sizesList[1];

    addrList[0] = &pipeId;
    sizesList[0] = sizeof(ULONG);
    addToLog(_F(">>SETMODE "), addrList, sizesList, 1);
    ULONG res = igdkmd_SetMode(this, pSetModeArgs);
    addToLog(_F("<<SETMODE "), addrList, sizesList, 1);
    return res;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
ULONG __hooked_igdkmd_SetDisplayPowerState(PVOID this, PVOID pDisplayPwrSetArgs)
{
    PVOID addrList[2];
    ULONG sizesList[2];

    addrList[0] = &pDisplayPwrSetArgs;
    sizesList[0] = DisplayPwrSetArgs_Size;
    addToLog(_F(">>SETDISPLAYPOWERSTATE "), addrList, sizesList, 1);

    ULONG res = igdkmd_SetDisplayPowerState(this, pDisplayPwrSetArgs);
    addrList[1] = &res;
    sizesList[1] = sizeof(ULONG);
    addToLog(_F("<<SETDISPLAYPOWERSTATE "), addrList, sizesList, 2);
    return res;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
ULONG __hooked_igdkmd_NotifyModeSetComplete(PVOID this, PVOID pSetModeArgs)
{
    ULONG pipeId = *(ULONG*)((PTR_T)pSetModeArgs + pipeId__SB_MODE_ARGS);
    PVOID addrList[4];
    ULONG sizesList[4];

    addrList[0] = &pipeId;
    sizesList[0] = sizeof(ULONG);
    ULONG res = igdkmd_NotifyModeSetComplete(this, pSetModeArgs);
    addrList[1] = &res;
    sizesList[1] = sizeof(ULONG);
    addToLog(_F("MODESET_COMPLETE "), addrList, sizesList, 2);
    return res;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
USHORT igdkmd_NotifyPowerState_Args_size = 0;
ULONG __hooked_igdkmd_NotifyPowerState(PVOID pThis, PVOID pArgs)
{
    PVOID addrList[] = { pArgs };
    ULONG sizesList[] = { igdkmd_NotifyPowerState_Args_size };

    addToLog(_F("PWR_NOTIFY "), addrList, sizesList, 1 | SPLIT_4BB);

    return igdkmd_NotifyPowerState(pThis, pArgs);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
USHORT igdkmd_BlankVideo_Args_size = 0;
ULONG __hooked_igdkmd_BlankVideo(PVOID pThis, PVOID pArgs)
{
    ULONG res = igdkmd_BlankVideo(pThis, pArgs);

    igdkmd_getPipeToPortConfig();

    /*
    PSB_BLANKVIDEO_ARGS p = (PSB_BLANKVIDEO_ARGS)pArgs;
    if (p->ulVideoOn)
        enablePipeCRC(p->ulPipeIndex);
    */


    PVOID addrList[] = { pArgs };
    ULONG sizesList[] = { igdkmd_BlankVideo_Args_size };
    addToLog(_F("BLANK_PIPE "), addrList, sizesList, 1 | SPLIT_4BB);

    return res;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
//IRR
///////////////////////////////////////////////////////////////////////////////////////////////////
VOID intSrv()
{
    ULONG ireg;
    igdkmd_readMMIOData(DE_PIPE_INTERRUPT_ISR_A, &ireg, sizeof(ireg));
    if (ireg&DE_PIPE_VBLANK_MASK)
    {
        addToLog(_F("VSYNC [PIPE_ID] 0"), NULL, NULL, 0);
        KeInsertQueueDpc(&DpcGetCRC[0], NULL, NULL);
    }

    igdkmd_readMMIOData(DE_PIPE_INTERRUPT_ISR_B, &ireg, sizeof(ireg));
    if (ireg&DE_PIPE_VBLANK_MASK)
    {
        addToLog(_F("VSYNC [PIPE_ID] 1"), NULL, NULL, 0);
        KeInsertQueueDpc(&DpcGetCRC[1], NULL, NULL);
    }

    igdkmd_readMMIOData(DE_PIPE_INTERRUPT_ISR_C, &ireg, sizeof(ireg));
    if (ireg&DE_PIPE_VBLANK_MASK)
    {
        addToLog(_F("VSYNC [PIPE_ID] 2"), NULL, NULL, 0);
        KeInsertQueueDpc(&DpcGetCRC[2], NULL, NULL);
    }

    igdkmd_readMMIOData(DE_PIPE_INTERRUPT_ISR_D, &ireg, sizeof(ireg));
    if (ireg&DE_PIPE_VBLANK_MASK)
    {
        addToLog(_F("VSYNC [PIPE_ID] 3"), NULL, NULL, 0);
        KeInsertQueueDpc(&DpcGetCRC[3], NULL, NULL);
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
NTSTATUS __hooked_DxgkDdiControlInterrupt(
    _In_ const HANDLE              hAdapter,
    _In_ const DXGK_INTERRUPT_TYPE InterruptType,
    _In_       BOOLEAN             Enable
)
{
    NTSTATUS status = igdkmd_DxgkDdiControlInterrupt(hAdapter, InterruptType, Enable);
    return status;
}

__pragma(warning(pop))