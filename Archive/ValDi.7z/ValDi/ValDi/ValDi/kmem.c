#include "kmem.h"
#include <string.h>

#define MIN(a,b) (a<b)?a:b

PVOID kmalloc(SIZE_T size)

{
    return ExAllocatePoolWithTag(NonPagedPool, size, 'kmtM');
}

PVOID kmallocP(SIZE_T size)

{
    return ExAllocatePoolWithTag(PagedPool, size, 'kmtM');
}

PVOID kcalloc(SIZE_T size, SIZE_T numOfElements)
{
    PVOID ptr;
    size *= numOfElements;
    ptr = kmalloc(size);
    if (ptr)
        RtlZeroMemory(ptr, size);
    return ptr;
}

VOID kfree(PVOID ptr)
{
    if (ptr)
        ExFreePoolWithTag(ptr, 'kmtM');
}

PVOID krealloc(PVOID ptr, SIZE_T oldSize, SIZE_T newSize)
{
    PVOID newPtr = kmalloc(newSize);
    
    if (ptr)
    {
        RtlCopyMemory(newPtr, ptr, MIN(oldSize, newSize));
        kfree(ptr);
    }

    return newPtr;
}