#include "globals.h"
#include "Hooks.h"
#include "DFT.h"
#include <stdlib.h>
#include <stdio.h>
#include "logger.h"
#include "Helpers.h"
#include "registers.h"
#include "igdkmd_patcher\igdkmd_intc.h"

KDPC                               ppDPC[MAX_PIPES];
extern ULONG igdkmd_patcher_status;

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __dummy_report_SoftSync(ULONG pipeId)
{
    UNREFERENCED_PARAMETER(pipeId);
}


///////////////////////////////////////////////////////////////////////////////////////////////////
LONG getPipeCRC(ULONG pipeId, ULONG* pipe_crc)
{
    ULONG pipe_CTL_address;
    ULONG pipe_RES_address;
    ULONG data1, data2;
    LONG retV = 0;

    switch (pipeId)
    {
    case 0:
        pipe_CTL_address = PIPE_CD_CRC_CTL_A;
        pipe_RES_address = PIPE_CD_CRC_RES_A;
        break;
    case 1:
        pipe_CTL_address = PIPE_CD_CRC_CTL_B;
        pipe_RES_address = PIPE_CD_CRC_RES_B;
        break;
    case 2:
        pipe_CTL_address = PIPE_CD_CRC_CTL_C;
        pipe_RES_address = PIPE_CD_CRC_RES_C;
        break;
    case 3:
        pipe_CTL_address = PIPE_CD_CRC_CTL_D;
        pipe_RES_address = PIPE_CD_CRC_RES_D;
        break;
    default:
        return -2;
    }

    *pipe_crc = (ULONG)-1;

    igdkmd_readMMIOData(pipe_CTL_address, &data1, sizeof(data1));
    if (data1 & PIPE_CRC_CTL_READY)
    {
        igdkmd_readMMIOData(pipe_RES_address, &data2, sizeof(data1));
        igdkmd_writeMMIOData(pipe_CTL_address, &data1, sizeof(data1));
        *pipe_crc = data2;
        retV |= 1;
    }
    return retV;
}


///////////////////////////////////////////////////////////////////////////////////////////////////
LONG getPortCRC(ULONG pipeId, ULONG* port_crc)
{
    ULONG data1;

    ULONG port_CTL_address;
    ULONG port_RES_address;
    ULONG port_SCR_address;

    PIPE_MAPS *pMaps = __getPipeStatusPtr();

    LONG retV = 0;

    switch (pMaps->pipeToPortConfig[pipeId])
    {
    case 11:
        port_CTL_address = DDI_CRC_CTL_A;
        port_RES_address = DDI_CRC_RES_A;
        port_SCR_address = DDI_SRC_RESET_A;
        break;
    case 12:
        port_CTL_address = DDI_CRC_CTL_B;
        port_RES_address = DDI_CRC_RES_B;
        port_SCR_address = DDI_SRC_RESET_B;
        break;
    case 13:
        port_CTL_address = DDI_CRC_CTL_C;
        port_RES_address = DDI_CRC_RES_C;
        port_SCR_address = DDI_SRC_RESET_C;
        break;
    case 14:
        port_CTL_address = DDI_CRC_CTL_D;
        port_RES_address = DDI_CRC_RES_D;
        port_SCR_address = DDI_SRC_RESET_D;
        break;
    default:
        return -2;
    }

    *port_crc = (ULONG)-1;

    igdkmd_readMMIOData(port_CTL_address, &data1, sizeof(data1));
    if (data1 & DDI_CRC_READY)
    {
        igdkmd_writeMMIOData(port_CTL_address, &data1, sizeof(data1));
        igdkmd_readMMIOData(port_RES_address, &data1, sizeof(data1));
        *port_crc = data1;
        retV |= 1;
    }

    return retV;
}


///////////////////////////////////////////////////////////////////////////////////////////////////
LONG getDBUF_STATUS(ULONG *ds)
{
    ULONG data1;
    igdkmd_readMMIOData(DBUF_STATUS, &data1, sizeof(data1));
    igdkmd_writeMMIOData(DBUF_STATUS, &data1, sizeof(data1));
    *ds = data1;
    return 0;
}


///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __report_SoftSync_poolPipeCRC_DPC(
    _In_     struct _KDPC *Dpc,
    _In_opt_ PVOID        DeferredContext,
    _In_opt_ PVOID        SystemArgument1,
    _In_opt_ PVOID        SystemArgument2
)
{
    UNREFERENCED_PARAMETER(Dpc);
    UNREFERENCED_PARAMETER(DeferredContext);
    UNREFERENCED_PARAMETER(SystemArgument2);

    ULONG attempts = 20;
    const ULONG stallFor = 1;

    ULONG pipeId;

    LONG flagCRC;
    ULONG portCRC, pipeCRC, dbstatus;

    RtlCopyMemory(&pipeId, &SystemArgument1, sizeof(pipeId));

    hStats.softSyncs[pipeId]++;

    flagCRC = getPipeCRC(pipeId, &pipeCRC);
    while (!flagCRC && attempts--)
    {
        KeStallExecutionProcessor(stallFor);
        flagCRC = getPipeCRC(pipeId, &pipeCRC);
    }

    flagCRC &= getPortCRC(pipeId, &portCRC);
    getDBUF_STATUS(&dbstatus);

    ULONG portId = __getPipeStatusPtr()->pipeToPortConfig[pipeId];
    portId -= INTDPA_PORT;

    PVOID addrList[] = { &pipeId, &pipeCRC, &portId, &portCRC, &flagCRC, &dbstatus };
    ULONG sizesList[] = { sizeof(ULONG), sizeof(ULONG), sizeof(ULONG), sizeof(ULONG), sizeof(ULONG), sizeof(ULONG) };
    addToLog(_F("PIPEPORTCRC "), addrList, sizesList, 6);
}

///////////////////////////////////////////////////////////////////////////////////////////////////

VOID __schedule_pipeportCRCFetch(ULONG pipeId)
{
    /*
    intTiming[pipeId] = GetTimeStamp();
    if (!KeInsertQueueDpc(&ppDPC[pipeId], (PVOID)pipeId, NULL))
    {
    //KDPC_WATCHDOG_INFORMATION wdi;
    //KeQueryDpcWatchdogInformation(&wdi);
    //PVOID addrList[] = { &pipeId, &wdi.DpcTimeCount, &wdi.DpcTimeLimit, &wdi.DpcWatchdogCount, &wdi.DpcWatchdogLimit};
    //ULONG sizesList[] = { sizeof(ULONG), sizeof(ULONG), sizeof(ULONG), sizeof(ULONG), sizeof(ULONG) };

    PVOID addrList[] = { &pipeId};
    ULONG sizesList[] = { sizeof(ULONG)};

    addToLog(_F("!DROPPED_DPC_CRC "), addrList, sizesList, 1);
    }
    */

    __report_SoftSync_poolPipeCRC_DPC(NULL, NULL, (PVOID)pipeId, NULL);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __report_SoftSync(ULONG pipeId)
{
    hStats.softSyncs[pipeId]++;

    ULONG portCRC, pipeCRC, flagCRC, dbstatus;

    flagCRC = getPortCRC(pipeId, &portCRC);
    flagCRC &= getPipeCRC(pipeId, &pipeCRC);
    getDBUF_STATUS(&dbstatus);

    ULONG portId = __getPipeStatusPtr()->pipeToPortConfig[pipeId];
    portId -= INTDPA_PORT;

    PVOID addrList[] = { &pipeId, &pipeCRC, &portId, &portCRC, &flagCRC, &dbstatus };
    ULONG sizesList[] = { sizeof(ULONG), sizeof(ULONG), sizeof(ULONG), sizeof(ULONG), sizeof(ULONG), sizeof(ULONG) };
    addToLog(_F("PIPEPORTCRC "), addrList, sizesList, 6);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __report_portCRC(ULONG pipeId)
{
    ULONG portCRC, flagCRC, dbstatus;
    flagCRC = getPortCRC(pipeId, &portCRC);
    getDBUF_STATUS(&dbstatus);

    ULONG portId = __getPipeStatusPtr()->pipeToPortConfig[pipeId];
    portId -= INTDPA_PORT;

    PVOID addrList[] = { &portId, &portCRC, &flagCRC, &dbstatus };
    ULONG sizesList[] = { sizeof(ULONG), sizeof(ULONG), sizeof(ULONG), sizeof(ULONG) };
    addToLog(_F("PORTCRC "), addrList, sizesList, 4);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID __report_pipeCRC(ULONG pipeId)
{
    ULONG pipeCRC;

    getPipeCRC(pipeId, &pipeCRC);

    PVOID addrList[] = { &pipeId, &pipeCRC };
    ULONG sizesList[] = { sizeof(ULONG), sizeof(ULONG) };
    addToLog(_F("PIPECRC "), addrList, sizesList, 2);
}



///////////////////////////////////////////////////////////////////////////////////////////////////
VOID  enablePipeCRC(ULONG pipeId)
{
    ULONG data;

    ULONG eFlag = 0;

    if (__option_trace_pipe_underruns)
        eFlag |= DE_PIPE_UNDERRUN_BIT;

    if (__option_trace_with_pipe_CRC_done)
        eFlag |= DE_PIPE_CRCDONE_BIT;

    if (__option_trace_flip)
        eFlag |= DE_PIPE_FLIPDONE_BITS;


    if (pipeId == PIPE_A_ID)
    {
        data = PIPE_CRC_CTL_INT;
        igdkmd_writeMMIOData(PIPE_CD_CRC_CTL_A, &data, sizeof(data));

        igdkmd_readMMIOData(DE_PIPE_INTERRUPT_IMR_A, &data, sizeof(data));
        data &= ~eFlag;
        igdkmd_writeMMIOData(DE_PIPE_INTERRUPT_IMR_A, &data, sizeof(data));

        igdkmd_readMMIOData(DE_PIPE_INTERRUPT_IER_A, &data, sizeof(data));
        data |= eFlag;
        igdkmd_writeMMIOData(DE_PIPE_INTERRUPT_IER_A, &data, sizeof(data));

    }
    else if (pipeId == PIPE_B_ID)
    {

        data = PIPE_CRC_CTL_INT;
        igdkmd_writeMMIOData(PIPE_CD_CRC_CTL_B, &data, sizeof(data));

        igdkmd_readMMIOData(DE_PIPE_INTERRUPT_IMR_B, &data, sizeof(data));
        data &= ~eFlag;
        igdkmd_writeMMIOData(DE_PIPE_INTERRUPT_IMR_B, &data, sizeof(data));

        igdkmd_readMMIOData(DE_PIPE_INTERRUPT_IER_B, &data, sizeof(data));
        data |= eFlag;
        igdkmd_writeMMIOData(DE_PIPE_INTERRUPT_IER_B, &data, sizeof(data));

    }
    else if (pipeId == PIPE_C_ID)
    {

        data = PIPE_CRC_CTL_INT;
        igdkmd_writeMMIOData(PIPE_CD_CRC_CTL_C, &data, sizeof(data));

        igdkmd_readMMIOData(DE_PIPE_INTERRUPT_IMR_C, &data, sizeof(data));
        data &= ~eFlag;
        igdkmd_writeMMIOData(DE_PIPE_INTERRUPT_IMR_C, &data, sizeof(data));

        igdkmd_readMMIOData(DE_PIPE_INTERRUPT_IER_C, &data, sizeof(data));
        data |= eFlag;
        igdkmd_writeMMIOData(DE_PIPE_INTERRUPT_IER_C, &data, sizeof(data));

    }
    else if (pipeId == PIPE_D_ID)
    {

        data = PIPE_CRC_CTL_INT;
        igdkmd_writeMMIOData(PIPE_CD_CRC_CTL_D, &data, sizeof(data));

        igdkmd_readMMIOData(DE_PIPE_INTERRUPT_IMR_D, &data, sizeof(data));
        data &= ~eFlag;
        igdkmd_writeMMIOData(DE_PIPE_INTERRUPT_IMR_D, &data, sizeof(data));

        igdkmd_readMMIOData(DE_PIPE_INTERRUPT_IER_D, &data, sizeof(data));
        data |= eFlag;
        igdkmd_writeMMIOData(DE_PIPE_INTERRUPT_IER_D, &data, sizeof(data));

    }

}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID enablePortCRC(ULONG portId)
{
    ULONG data = DDI_CRC_ENABLE;
    ULONG port_offset = 0, scr_offset = 0;

    switch (portId)
    {
    case PORT_A_ID: port_offset = DDI_CRC_CTL_A; scr_offset = DDI_SRC_RESET_A; break;
    case PORT_B_ID: port_offset = DDI_CRC_CTL_B; scr_offset = DDI_SRC_RESET_B; break;
    case PORT_C_ID: port_offset = DDI_CRC_CTL_C; scr_offset = DDI_SRC_RESET_C; break;
    case PORT_D_ID: port_offset = DDI_CRC_CTL_D; scr_offset = DDI_SRC_RESET_D; break;
    default: return;
    }

    igdkmd_writeMMIOData(port_offset, &data, sizeof(data));

    if (__option_scrumbler_reset)
    {
        data = 1;
        igdkmd_writeMMIOData(scr_offset, &data, sizeof(data));
    }

}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID syncPipePort()
{
    if (igdkmd_patcher_status == 0)
    {
        return;
    }
    ULONG data = PIPE_CRC_CTL_INT;
    igdkmd_writeMMIOData(PIPE_CD_CRC_CTL_A, &data, sizeof(data));
    igdkmd_writeMMIOData(PIPE_CD_CRC_CTL_B, &data, sizeof(data));
    igdkmd_writeMMIOData(PIPE_CD_CRC_CTL_C, &data, sizeof(data));
    igdkmd_writeMMIOData(PIPE_CD_CRC_CTL_D, &data, sizeof(data));

    enablePortCRC(PORT_A_ID);
    enablePortCRC(PORT_B_ID);
    enablePortCRC(PORT_C_ID);
    enablePortCRC(PORT_D_ID);
}


////////////////////////////////////////////////////////////////////
//
// Setup_CRC: Method to do initialization of CRC related variables
// Initialization DPC to capture PIPE CRC. 
// These DPC needs to be removed from the queue during driver unload
//
////////////////////////////////////////////////////////////////////
VOID Setup_CRC() {
    for (int i = 0; i < MAX_PIPES; i++) {
        KeInitializeThreadedDpc(&ppDPC[i], __report_SoftSync_poolPipeCRC_DPC, NULL);
        KeSetImportanceDpc(&ppDPC[i], HighImportance);
    }    
}


////////////////////////////////////////////////////////////////////
//
// TearDown_CRC: Method to do clean up CRC related variables
// During initialization 3 DPC has been scheduled to capture CRC. 
// These DPC needs to be removed from the queue during driver unload
//
////////////////////////////////////////////////////////////////////
VOID TearDown_CRC()
{
    for (int i = MAX_PIPES - 1; i >= 0; i++) {
        KeRemoveQueueDpc(&ppDPC[i]);
    }
}
