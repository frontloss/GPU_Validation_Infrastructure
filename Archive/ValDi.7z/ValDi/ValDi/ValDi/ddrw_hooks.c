#include "globals.h"
#include "Hooks.h"
#include "DFT.h"
#include "ddrw_hooks.h"
#include "Helpers.h"
#include "crc.h"
#include "ddrw\ddrw_displayerrordef.h"
#include "kmem.h"

//Extern interfaces 
extern ULONG    igdkmd_patcher_status;
extern VOID     Patch_MMIOInterface();
extern int      CommitPatchPoint(PPATCHPOINT pp);
extern PVOID    FindPatchPoint(PIGDKMD_FUNCTION_PATCH_REQUEST pRequest);


#define DD_SUCCESS      0x0

// Hooked function defnitions
NTSTATUS __hooked_DxgkDdiStartDevice_DDRW(_In_ const PVOID MiniportDeviceContext, _In_ PDXGK_START_INFO DxgkStartInfo, _In_ PDXGKRNL_INTERFACE DxgkInterface, _Out_ PULONG NumberOfVideoPresentSources, _Out_ PULONG NumberOfChildren);
NTSTATUS __hooked_DisplayOSLInitialize(PVOID pHwDev, PVOID pDisplayInitArg);
NTSTATUS __hooked_EventNotifyIsr_DDRW(PVOID pHwDev, PSB_INTERRUPT_ARGS pIntArgs);
ULONG __hooked_ReadDDC_DDRW(PVOID pDHLContext, PDD_READ_DDC_ARGUMENTS IntArgs);
ULONG __hooked_AuxAccess_DDRW(PVOID pDHLContext, PDD_AUX_ARGUMENTS IntArgs);

//Native or Original DisplayOSLInitialize function pointer which will called inside hooked function
NTSTATUS(*igdkmd_DisplayOSLInitialize)(PVOID pHwDev, PVOID pDisplayInitArg) = NULL;

//Native or Original DisplayOSLInitialize function pointer which will called inside hooked function
ULONG(*igdkmd_OpregionProtocolGetVbt)(PVOID pOpregionContext, DD_GET_VBT *pGetVbtData) = NULL;


////////////////////////////////////////////////////////////////////
//
// __hooked_DisplayOSLInitialize: Hooked function for igdkmd DisplayOSLInitialize()
// This function need to hooks so that AuxAccess function can be patched
// before first AuxAccess() call. This function written exclusively to support EDP
// simulation during boot
////////////////////////////////////////////////////////////////////
NTSTATUS __hooked_DisplayOSLInitialize(PVOID pHwDev, PVOID pDisplayInitArg)
{
    BOOL patch_complete = FALSE;
    PVOID pDisplayHAL_base = NULL;
    //PTR_T _pSymbolRVA = 0;

    PSYMBOLINFO PSI_pReadDDC = GetModSymbol(igdkmd_patcher_modInfoPtr, "ReadDDC@DD_DISPLAY_HAL_SERVICES");
    PSYMBOLINFO PSI_pAuxAccess = GetModSymbol(igdkmd_patcher_modInfoPtr, "AUXAccess@_DD_DISPLAY_HAL_SERVICES");
    PSYMBOLINFO PSI_pDisplayHotPlugAPort = GetModSymbol(igdkmd_patcher_modInfoPtr, "DisplayHotPlugPortADpc");
    PSYMBOLINFO PSI_pDisplayHotPlugBPort = GetModSymbol(igdkmd_patcher_modInfoPtr, "DisplayHotPlugPortBDpc");
    PSYMBOLINFO PSI_pDisplayHotPlugCPort = GetModSymbol(igdkmd_patcher_modInfoPtr, "DisplayHotPlugPortCDpc");
    PSYMBOLINFO PSI_pDisplayHotPlugDPort = GetModSymbol(igdkmd_patcher_modInfoPtr, "DisplayHotPlugPortDDpc");
    PSYMBOLINFO PSI_pDisplayHotPlugEPort = GetModSymbol(igdkmd_patcher_modInfoPtr, "DisplayHotPlugPortEDpc");
    //PSYMBOLINFO PSI_PDisplayOslSetPowerState = GetModSymbol(igdkmd_patcher_modInfoPtr, "DisplayOslSetPowerState");

    igdkmd_funcptr_table = (PIGDKMD_FUNC_INTERFACE)kmalloc(sizeof(IGDKMD_FUNC_INTERFACE));
    proxy_funcptr_table = (PIGDKMD_PROXY_INTERFACE)kmalloc(sizeof(IGDKMD_PROXY_INTERFACE));
    igdkmd_rva_table = (PIGDKMD_RVA_CONTEXT)kmalloc(sizeof(IGDKMD_RVA_CONTEXT));

    do {
        BREAK_ON_NULL(PSI_pReadDDC);
        BREAK_ON_NULL(PSI_pAuxAccess);
        BREAK_ON_NULL(PSI_pDisplayHotPlugAPort);
        BREAK_ON_NULL(PSI_pDisplayHotPlugBPort);
        BREAK_ON_NULL(PSI_pDisplayHotPlugCPort);
        BREAK_ON_NULL(PSI_pDisplayHotPlugDPort);
        BREAK_ON_NULL(PSI_pDisplayHotPlugEPort);        
        
        igdkmd_funcptr_table->DisplayHotPlugPortADpc = NULL;
        igdkmd_funcptr_table->DisplayHotPlugPortBDpc = NULL;
        igdkmd_funcptr_table->DisplayHotPlugPortCDpc = NULL;
        igdkmd_funcptr_table->DisplayHotPlugPortDDpc = NULL;
        igdkmd_funcptr_table->DisplayHotPlugPortEDpc = NULL;

        pDisplayHAL_base = igdkmd_GetHALInterface();
        BREAK_ON_NULL(pDisplayHAL_base);

        //Initialize proxy function table
		proxy_funcptr_table->NotifyIsr = __hooked_EventNotifyIsr_DDRW;

#if 0
		// Using GfxValSim for device simulation purpose
        proxy_funcptr_table->AuxAccess = __hooked_AuxAccess_DDRW;
        proxy_funcptr_table->ReadDDC = __hooked_ReadDDC_DDRW;
             

        //Populate RVA table with igdkmd function RVA. This RVA will be used to undo patching        
        igdkmd_rva_table->DisplayHotPlugAPort_RVA = ((PTR_T)igdkmd_patcher_modInfoPtr->imageBase + PSI_pDisplayHotPlugAPort->rva);
        igdkmd_rva_table->DisplayHotPlugBPort_RVA = ((PTR_T)igdkmd_patcher_modInfoPtr->imageBase + PSI_pDisplayHotPlugBPort->rva);
        igdkmd_rva_table->DisplayHotPlugCPort_RVA = ((PTR_T)igdkmd_patcher_modInfoPtr->imageBase + PSI_pDisplayHotPlugCPort->rva);
        igdkmd_rva_table->DisplayHotPlugDPort_RVA = ((PTR_T)igdkmd_patcher_modInfoPtr->imageBase + PSI_pDisplayHotPlugDPort->rva);
        igdkmd_rva_table->DisplayHotPlugEPort_RVA = ((PTR_T)igdkmd_patcher_modInfoPtr->imageBase + PSI_pDisplayHotPlugEPort->rva);        

        //Cache the igdkmd function pointer
        F_ASSIGN(igdkmd_funcptr_table->DisplayHotPlugPortADpc = (PVOID)igdkmd_rva_table->DisplayHotPlugAPort_RVA);
        F_ASSIGN(igdkmd_funcptr_table->DisplayHotPlugPortBDpc = (PVOID)igdkmd_rva_table->DisplayHotPlugBPort_RVA);
        F_ASSIGN(igdkmd_funcptr_table->DisplayHotPlugPortCDpc = (PVOID)igdkmd_rva_table->DisplayHotPlugCPort_RVA);
        F_ASSIGN(igdkmd_funcptr_table->DisplayHotPlugPortDDpc = (PVOID)igdkmd_rva_table->DisplayHotPlugDPort_RVA);
        F_ASSIGN(igdkmd_funcptr_table->DisplayHotPlugPortEDpc = (PVOID)igdkmd_rva_table->DisplayHotPlugEPort_RVA);        
        
        _pSymbolRVA = (PTR_T)pDisplayHAL_base + (PTR_T)PSI_pReadDDC->rva;
        BREAK_IF_FALSE(_pSymbolRVA);

        igdkmd_rva_table->ReadDDC_RVA = _pSymbolRVA;
        F_ASSIGN(igdkmd_funcptr_table->ReadDDC = *(PVOID*)_pSymbolRVA;)

        _pSymbolRVA = (PTR_T)pDisplayHAL_base + (PTR_T)PSI_pAuxAccess->rva;
        
        BREAK_IF_FALSE(_pSymbolRVA);
        igdkmd_rva_table->AuxAccess_RVA = _pSymbolRVA;
        F_ASSIGN(igdkmd_funcptr_table->AuxAccess = *(PVOID*)_pSymbolRVA;)
#endif

        patch_complete = TRUE;
    } while (FALSE);

    if (patch_complete == FALSE) {
        //Rollback patching
        kfree(igdkmd_funcptr_table);
        kfree(proxy_funcptr_table);
        kfree(igdkmd_rva_table);
    }
#if 0
	// Using GfxValSim for device simulation purpose
	else {
        //Commit patching
        //Replace original function with hooked function        

        F_ASSIGN(*(PVOID*)igdkmd_rva_table->ReadDDC_RVA = proxy_funcptr_table->ReadDDC;)
        F_ASSIGN(*(PVOID*)igdkmd_rva_table->AuxAccess_RVA = proxy_funcptr_table->AuxAccess;)        
    }
#endif 

    return igdkmd_DisplayOSLInitialize(pHwDev, pDisplayInitArg);
}


////////////////////////////////////////////////////////////////////
//
// __hooked_OpregionProtocolGetVbt: Hooked function for simulate VBT
// 
////////////////////////////////////////////////////////////////////
ULONG __hooked_OpregionProtocolGetVbt(PVOID pOpregionContext, DD_GET_VBT *pGetVbtData)
{
	// Original OpregionProtocolGetVbt (igdkmd64.sys) function to fetch VBT
    ULONG status = igdkmd_OpregionProtocolGetVbt(pOpregionContext, pGetVbtData);

	// If status is good, then pass through VBT simulation handle and cache the VBT
    if (status == 0) {
        CacheVBT(pGetVbtData->pVbtData);
        SimulateVBT(pGetVbtData->pVbtData);
    }
    return status;
}


////////////////////////////////////////////////////////////////////
//
// __hooked_DxgkDdiStartDevice_DDRW: Hooked function for igdkmd DxgkDdiStartDevice()
// 
////////////////////////////////////////////////////////////////////
NTSTATUS __hooked_DxgkDdiStartDevice_DDRW(_In_ const PVOID MiniportDeviceContext, 
								_In_ PDXGK_START_INFO DxgkStartInfo,
								_In_ PDXGKRNL_INTERFACE DxgkInterface,
								_Out_ PULONG NumberOfVideoPresentSources, 
								_Out_ PULONG NumberOfChildren)
{
    PTR_T _pIntVtbl = 0;
    PTR_T _pfnEventNotifyIsr = 0;
    PATCHPOINT p1;

    PSYMBOLINFO pGfxInitDisplay = GetModSymbol(igdkmd_patcher_modInfoPtr, "GfxInitDisplay");
    PSYMBOLINFO pDisplayOSLInitialize = GetModSymbol(igdkmd_patcher_modInfoPtr, "DisplayOSLInitialize");
    PSYMBOLINFO PSI_pIntVtbl = GetModSymbol(igdkmd_patcher_modInfoPtr, "pIntVtbl@HW_DEV_EXT");
    PSYMBOLINFO PSI_pfnEventNotifyIsr = GetModSymbol(igdkmd_patcher_modInfoPtr, "pfnEventNotifyIsr@INTERRUPT_SERVICES");
       
	// Symbol information for VbtParserGetVBT and OpregionProtocolGetVbt function
    //PSYMBOLINFO PSI_pVbtParserGetVBT = GetModSymbol(igdkmd_patcher_modInfoPtr, "VbtParserGetVBT");
    //PSYMBOLINFO PSI_pOpregionProtocolGetVbt = GetModSymbol(igdkmd_patcher_modInfoPtr, "OpregionProtocolGetVbt");

    do {
        BREAK_ON_NULL(pGfxInitDisplay);
        BREAK_ON_NULL(pDisplayOSLInitialize);
        BREAK_ON_NULL(PSI_pIntVtbl);
        BREAK_ON_NULL(PSI_pfnEventNotifyIsr);
      
		// START: Patching GfxInitDisplay()
		// Patch DisplayOSLInitialize call inside GfxInitDisplay() function
        IGDKMD_FUNCTION_PATCH_REQUEST stRequest = { 0 };
        stRequest.start_address = (PTR_T)igdkmd_patcher_modInfoPtr->imageBase + (PTR_T)pGfxInitDisplay->rva;
        stRequest.target_address = (PTR_T)igdkmd_patcher_modInfoPtr->imageBase + (PTR_T)pDisplayOSLInitialize->rva;
        stRequest.target_size = pGfxInitDisplay->size;
        PVOID pFuncPatchPoint = FindPatchPoint(&stRequest);

        if (pFuncPatchPoint)
        {
			//Prepare patch point details for function call patching
            p1.orgData = 0;
            ADD_ASSIGN(p1.vaPatchPoint = pFuncPatchPoint;)
            p1.patchPointSize = 5;
            p1.vaTrampolineSection = 0x0;
            ADD_ASSIGN(p1.vaDestination = (PVOID)__hooked_DisplayOSLInitialize;)
            ADD_ASSIGN(p1.vaPostCall = (PVOID)(stRequest.target_address);)
            F_ASSIGN(igdkmd_DisplayOSLInitialize = p1.vaPostCall;)
            CommitPatchPoint(&p1);
        }
        else
        {
            VLOG("[DisplayOSLInitialize] patch point not found - already patched?\n");
            break;
        }
		// END: Patching GfxInitDisplay()

#if 0
		// START: Patching VbtParserGetVBT()
		// Patch OpregionProtocolGetVbt call inside VbtParserGetVBT() function
        stRequest.start_address = (PTR_T)igdkmd_patcher_modInfoPtr->imageBase + (PTR_T)PSI_pVbtParserGetVBT->rva;
        stRequest.target_address = (PTR_T)igdkmd_patcher_modInfoPtr->imageBase + (PTR_T)PSI_pOpregionProtocolGetVbt->rva;
        stRequest.target_size = PSI_pVbtParserGetVBT->size;
        pFuncPatchPoint = FindPatchPoint(&stRequest);
      
        if (pFuncPatchPoint)
        {
			//Prepare patch point details for function call patching
            p1.orgData = 0;
            ADD_ASSIGN(p1.vaPatchPoint = pFuncPatchPoint;)
            p1.patchPointSize = 5;
            p1.vaTrampolineSection = 0x0;
            ADD_ASSIGN(p1.vaDestination = (PVOID)__hooked_OpregionProtocolGetVbt;)
            ADD_ASSIGN(p1.vaPostCall = (PVOID)(stRequest.target_address);)
            F_ASSIGN(igdkmd_OpregionProtocolGetVbt = p1.vaPostCall;)

            CommitPatchPoint(&p1);
        }
        else
        {
            VLOG("[OpregionProtocolGetVbt] patch point not found - already patched?\n");
            break;
        }
		// END: Patching VbtParserGetVBT()
#endif
    } while (FALSE);



	// Call original DxgkDdiStartDevice function in igdkmd64.sys
    NTSTATUS status = igdkmd_DxgkDdiStartDevice(MiniportDeviceContext, 
										DxgkStartInfo, DxgkInterface, 
										NumberOfVideoPresentSources, 
										NumberOfChildren);

    if (!NT_SUCCESS(status)) {
        return status;
    }

	// On successfull call of original DxgkDdiStartDevice function, patch ISR and MMIO interfaces
    do {
        if (igdkmd_funcptr_table == NULL ||
            proxy_funcptr_table == NULL ||
            igdkmd_rva_table == NULL)
        {
            break;
        }
        
		// Compute virtual address from relative virtual address (RVA) and base address
		// ISR interface is a function pointer within MiniportDeviceContext->pIntVtbl
        _pIntVtbl = (PTR_T)MiniportDeviceContext + (PTR_T)PSI_pIntVtbl->rva;
        _pfnEventNotifyIsr = *(PTR_T*)_pIntVtbl + (PTR_T)PSI_pfnEventNotifyIsr->rva;
        BREAK_IF_FALSE(_pfnEventNotifyIsr);

		// Store the original function pointer inside cache table
        F_ASSIGN(igdkmd_funcptr_table->NotifyIsr = *(PVOID*)_pfnEventNotifyIsr;)

		// Store the computed virtual address of ISR interface, this will be useful
	    // during driver unload
        igdkmd_rva_table->NotifyISR_RVA = _pfnEventNotifyIsr;

		// Swap hooked function pointer with the original function pointer
        F_ASSIGN(*(PVOID*)_pfnEventNotifyIsr = proxy_funcptr_table->NotifyIsr;)

		// Set patching status
        igdkmd_patcher_status = 1;

		// Call to a function to patch MMIO interface
        Patch_MMIOInterface();
    } while (FALSE);


    return status;
}


////////////////////////////////////////////////////////////////////
//
// __hooked_EventNotifyIsr_DDRW: Hooked function for igdkmd NotifyISR()
// @TODO: Synchronous pipe & port CRC reporting triggered on CRC done INT for now.
// In the future independent port/pipe tracing would allow for detecting
// of DP corruptions when pipe is not active but DP perfoms scanouts.
//
////////////////////////////////////////////////////////////////////
NTSTATUS __hooked_EventNotifyIsr_DDRW(PVOID pHwDev, PSB_INTERRUPT_ARGS pIntArgs)
{

    if (ValDiState&VALDISTATE_TRACING_FLAG)
    {
        if (__option_trace_with_pipe_CRC_done)
        {
			// Log CRC value based on CRC done interrupt
			if (pIntArgs->bCRC_Done_PipeAInterrupt)
			{
				__report_SoftSync(PIPE_A_ID);
				pIntArgs->bCRC_Done_PipeAInterrupt &= __option_mask_ints;
			}

			if (pIntArgs->bCRC_Done_PipeBInterrupt)
			{
				__report_SoftSync(PIPE_B_ID);
				pIntArgs->bCRC_Done_PipeBInterrupt &= __option_mask_ints;
			}

			if (pIntArgs->bCRC_Done_PipeCInterrupt)
			{
				__report_SoftSync(PIPE_C_ID);
				pIntArgs->bCRC_Done_PipeCInterrupt &= __option_mask_ints;
			}
        }
        else
        {
			// Log CRC value based on VBlank or VSync interrupt
			if (pIntArgs->bVBlank_PipeAInterrupt | pIntArgs->bVSync_PipeAInterrupt)
				__schedule_pipeportCRCFetch(PIPE_A_ID);
			if (pIntArgs->bVBlank_PipeBInterrupt | pIntArgs->bVSync_PipeBInterrupt)
				__schedule_pipeportCRCFetch(PIPE_B_ID);
			if (pIntArgs->bVBlank_PipeCInterrupt | pIntArgs->bVSync_PipeCInterrupt)
				__schedule_pipeportCRCFetch(PIPE_C_ID);
        }
    }	

    if (pIntArgs->bFIFOUnderrun_PipeAInterrupt)
        __report_Underrun(_F("!FIFO_UND "), PIPE_A_ID);

    if (pIntArgs->bFIFOUnderrun_PipeBInterrupt)
        __report_Underrun(_F("!FIFO_UND "), PIPE_B_ID);

    if (pIntArgs->bFIFOUnderrun_PipeCInterrupt)
        __report_Underrun(_F("!FIFO_UND "), PIPE_C_ID);

    if (pIntArgs->bPipeA_Underrun)
        __report_Underrun(_F("!PIPE_UND "), PIPE_A_ID);

    if (pIntArgs->bPipeB_Underrun)
        __report_Underrun(_F("!PIPE_UND "), PIPE_B_ID);

    if (pIntArgs->bPipeC_Underrun)
        __report_Underrun(_F("!PIPE_UND "), PIPE_C_ID);


    return igdkmd_funcptr_table->NotifyIsr(pHwDev, pIntArgs);
}


////////////////////////////////////////////////////////////////////
//
// __hooked_ReadDDC_DDRW: Hooked function for igdkmd ReadDDC()
//
////////////////////////////////////////////////////////////////////
ULONG __hooked_ReadDDC_DDRW(PVOID pDHLContext, PDD_READ_DDC_ARGUMENTS pIntArgs)
{
    int status = Read_SimulatedEDID(pIntArgs->Port, pIntArgs);
    if (status) {
        return DD_SUCCESS;
    }

    return igdkmd_funcptr_table->ReadDDC(pDHLContext, pIntArgs);
}


////////////////////////////////////////////////////////////////////
//
// __hooked_AuxAccess_DDRW: Hooked function for igdkmd AuxAccess()
//
////////////////////////////////////////////////////////////////////
ULONG __hooked_AuxAccess_DDRW(PVOID pDHLContext, PDD_AUX_ARGUMENTS pIntArgs)
{
    if (pIntArgs->Operation == DD_AUX_READ || pIntArgs->Operation == DD_AUX_WRITE)
    {
        int status = HandleAuxAccess(pIntArgs->Operation, pIntArgs->DisplayPort, pIntArgs->DPCDAddress, pIntArgs->BufferSize, pIntArgs->pBuffer);
        if (status == 0)
        {
			return DD_SUCCESS;
        }
    }
    return igdkmd_funcptr_table->AuxAccess(pDHLContext, pIntArgs);
}


////////////////////////////////////////////////////////////////////
//
// Call_HotPlugUnPlug_DPC: Method to trigger DPC for given port
//
////////////////////////////////////////////////////////////////////
VOID Call_HotPlugUnPlug_DPC(ULONG port) {
    PIGDKMD_FUNC_INTERFACE pInterface = igdkmd_funcptr_table;

    do {
        BREAK_ON_NULL(igdkmd_hwContext);
        BREAK_ON_NULL(pInterface);
        BREAK_ON_NULL(pInterface->DisplayHotPlugPortADpc);
        BREAK_ON_NULL(pInterface->DisplayHotPlugPortBDpc);
        BREAK_ON_NULL(pInterface->DisplayHotPlugPortCDpc);
        BREAK_ON_NULL(pInterface->DisplayHotPlugPortDDpc);
        BREAK_ON_NULL(pInterface->DisplayHotPlugPortEDpc);

        switch (port)
        {
        case PORT_A_ID:
            pInterface->DisplayHotPlugPortADpc(igdkmd_hwContext);
            break;
        case PORT_B_ID:
            pInterface->DisplayHotPlugPortBDpc(igdkmd_hwContext);
            break;
        case PORT_C_ID:
            pInterface->DisplayHotPlugPortCDpc(igdkmd_hwContext);
            break;
        case PORT_D_ID:
            pInterface->DisplayHotPlugPortDDpc(igdkmd_hwContext);
            break;
        case PORT_E_ID:
            pInterface->DisplayHotPlugPortEDpc(igdkmd_hwContext);
            break;

        default:
            break;
        }
    } while (FALSE);
}


////////////////////////////////////////////////////////////////////
//
// TearDown_DDRW_Hooks: Method to do clean up DDRW hooks related variables
// Restore original function pointer using Patch context structure
//
////////////////////////////////////////////////////////////////////
VOID TearDown_DDRW_Hooks() {
    F_ASSIGN(*(PVOID*)igdkmd_rva_table->NotifyISR_RVA = igdkmd_funcptr_table->NotifyIsr);
    F_ASSIGN(*(PVOID*)igdkmd_rva_table->ReadDDC_RVA = igdkmd_funcptr_table->ReadDDC);
    F_ASSIGN(*(PVOID*)igdkmd_rva_table->AuxAccess_RVA = igdkmd_funcptr_table->AuxAccess);

    if (igdkmd_rva_table) {
        kfree(igdkmd_rva_table);
    }

    if (igdkmd_funcptr_table)
    {
        kfree(igdkmd_funcptr_table);
    }

    if (NULL != proxy_funcptr_table)
    {
        kfree(proxy_funcptr_table);
    }
}