#include "Driver.h"
#include "kmem.h"
#include "Hooks.h"
#include "Helpers.h"
#include "Patcher.h"
#include "DFT.h"
#include <wdm.h>
#include <stdio.h>
#include <ntdef.h>
#include "igdkmd_patcher\igdkmd_patcher.h"
#include "GfxValStub\GfxValStub_bridge.h"
#include "logger.h"
#include "config.h"
#include "crc.h"



extern VOID         TearDown_MMIOHooks();
extern VALDI_PATCH_STORE patchStore;

////////////////////////////////////////////////////////////////////////////////////////////////////
_tB txtBuffer = { 0 };

KEVENT ValDiCloseEvent;
KDPC   MessageCollectorDPC;
ULONG tickIncrement = 0;
PDEVICE_OBJECT ValDiDeviceObjectPtr;

//KEVENT helperThreadGating;
KEVENT logBarrier;

////////////////////////////////////////////////////////////////////////////////////////////////////
//DEFAULTS
////////////////////////////////////////////////////////////////////////////////////////////////////
//@TODO: Fixed module name - customization to be added (Windows registry).
PATCHING_RULEZ prulez[] = { { "igdkmd64.sys","igdkmdn64.sys","igdkmdN64.sys", igdkmd_patcher, igdkmd_patcher_cleanup } };
#define VALDI_DEFAULT_SYMBOLFILE L"\\SystemRoot\\System32\\drivers\\igdkmd64.vsm";
DECLARE_GLOBAL_CONST_UNICODE_STRING(srvPrefix, L"\\Registry\\Machine\\System\\CurrentControlSet\\Services\\");

////////////////////////////////////////////////////////////////////////////////////////////////////
//AUX COMPILER CONFIGURATION
////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma comment (lib, "ntoskrnl.lib")

////////////////////////////////////////////////////////////////////////////////////////////////////
//INTERNAL LOGS
////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct _MSG_SLOT
{
    volatile LONG  busyFlag;
    CHAR  msg[MESSAGE_SIZE];
} MSG_SLOT;

MSG_SLOT _iMsgs[MESSAGE_SLOTS] = { 0 };

VOID vLog(const char* txt)
{
    int i;
    for (i = 0; i < MESSAGE_SLOTS; i++)
    {
        if (!InterlockedCompareExchange(&_iMsgs[i].busyFlag, 1, 0))
        {
            strncpy(_iMsgs[i].msg, txt, MESSAGE_SIZE - 1);
            return;
        }
    }

    for (i = 1; i < MESSAGE_SLOTS; i++)
        InterlockedExchange(&_iMsgs[i].busyFlag, 0);

    strncpy(_iMsgs[0].msg, txt, MESSAGE_SIZE - 1);
}


////////////////////////////////////////////////////////////////////////////////////////////////////
//DEFINE SECTION
////////////////////////////////////////////////////////////////////////////////////////////////////
#define USER_NAME   L"\\DosDevices\\ValDi"
#define SYSTEM_NAME L"\\Device\\ValDi"

#define DECLARE_GLOBAL_CONST_UNICODE_STRING(_var, _str) \
extern const __declspec(selectany) UNICODE_STRING _var = RTL_CONSTANT_STRING(_str)

/*
#define DECLARE_UNICODE_STRING_SIZE(_var, _size) \
WCHAR _var ## _buffer[_size]; \
__pragma(warning(push)) \
__pragma(warning(disable:4221)) \
__pragma(warning(disable:4204)) \
UNICODE_STRING _var = {0, (_size) * sizeof(WCHAR) , _var ## _buffer } \
__pragma(warning(pop))
*/

////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct _DEVICE_EXTENSION
{
    PVALDI_STATE_BLOCK vsb;
}DEVICE_EXTENSION, *PDEVICE_EXTENSION;

////////////////////////////////////////////////////////////////////////////////////////////////////
NTSTATUS Dispatch(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp);
NTSTATUS DeviceControl(PDEVICE_OBJECT DeviceObject, PIRP Irp);
NTSTATUS Unload(IN PDRIVER_OBJECT DriverObject);
DECLARE_GLOBAL_CONST_UNICODE_STRING(asterixUS, L"*");

volatile ULONG ValDiState = VALDISTATE_UNINITIALIZED;


////////////////////////////////////////////////////////////////////////////////////////////////////
VOID ProcessLoadImageCallback(IN PUNICODE_STRING FullImageName, IN HANDLE ProcessId, IN PIMAGE_INFO ImageInfo)
{
    UNICODE_STRING baseName;
    CHAR tmpBuff[MAX_PATH];
    CHAR aBuff[KMT_U2A_BUFFER_SIZE];

    GetBaseFileName(FullImageName, &baseName);

    if (!ProcessId)
    {
        u2a(&baseName, aBuff, KMT_U2A_BUFFER_SIZE);
        sprintf(tmpBuff, "%s", aBuff);
        tmpBuff[baseName.Length / 2] = '\0';

        BYTE guid[16];
        ULONG age;

        GetFileGUID(FullImageName, guid, &age);

        u2a(&baseName, aBuff, KMT_U2A_BUFFER_SIZE);
        VLOG("[Image load] NAME: %s   Id:%u  0x%llX\n", aBuff, (ULONG)((PTR_T)(ProcessId)), (ULONGLONG)(PTR_T)ImageInfo->ImageBase);

        int rulezCount = sizeof(prulez) / sizeof(prulez[0]);
        int i;

        for (i = 0; i < rulezCount; i++)
        {
            if (!strcmp(prulez[0].modShortName1, aBuff)
				|| (!strcmp(prulez[0].modShortName2, aBuff))
				|| (!strcmp(prulez[0].modShortName3, aBuff)))
            {
                PATCHED_MODINFO modInfo;
                RtlCopyMemory(&modInfo.guid, guid, sizeof(GUID));
                modInfo.age = age;
                strncpy(modInfo.modName, aBuff, MAX_PATH - 1);
                modInfo.imageBase = ImageInfo->ImageBase;
                if (!LoadVSM(&modInfo, *FullImageName))
                {
                    const BYTE happyBytes[] = { 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC , 0xCC, 0xCC, 0xCC, 0xCC };
                    ULONGLONG base_address = (ULONGLONG)ImageInfo->ImageBase;                   
                    patchStore.patch_count = 0;
                    patchStore.next_idx = 0;

                    for (int offset = 0x1000; offset < ImageInfo->ImageSize - 12;)
                    {
                        if (*(BYTE*)(base_address + offset) == 0xCC)
                        {
                            if (RtlCompareMemory((BYTE*)(base_address + offset), happyBytes, sizeof(happyBytes)) == sizeof(happyBytes))
                            {
                                patchStore.igdkmd_patch_point_list[patchStore.patch_count] = (base_address + offset);                                
                                patchStore.patch_count += 1;                                
                                offset += sizeof(happyBytes) * 12;
                                if (patchStore.patch_count == 10)
                                {
                                    break;
                                }
                            }
                        }
                        offset += sizeof(happyBytes);
                    }

                    if (patchStore.patch_count > 0) {
                        igdkmd_patchOfThePatches = patchStore.igdkmd_patch_point_list[patchStore.next_idx];
                        patchStore.next_idx += 1;
                    }
                    prulez[0].fPatcher(&modInfo);
                }
            }
        }
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////
VOID ProcessCreateCallback(PEPROCESS Process, HANDLE ProcessId, PPS_CREATE_NOTIFY_INFO CreateInfo)
{
    UNREFERENCED_PARAMETER(Process);
    UNREFERENCED_PARAMETER(ProcessId);

    CHAR tmpBuff[MAX_PATH] = { 0 };

    if (CreateInfo)
    {
        CHAR aBuff[KMT_U2A_BUFFER_SIZE];
        u2a(CreateInfo->ImageFileName, aBuff, KMT_U2A_BUFFER_SIZE);

        sprintf(tmpBuff, "%s", aBuff);
        stripToBaseName(tmpBuff);
        VLOG("[Process starts]>  NAME: %s   PID:%llu\n", tmpBuff, (ULONG64)ProcessId);
    }
    else
    {
        VLOG("[Process terminates]> PID:%llu\n", (ULONG64)ProcessId);
    }

}


////////////////////////////////////////////////////////////////////////////////////////////////////
NTSTATUS DriverEntry(_In_ PDRIVER_OBJECT DriverObject, _In_ PUNICODE_STRING RegistryPath)
{
    NTSTATUS          status;
    PDEVICE_OBJECT    pDeviceObject;
    PDEVICE_EXTENSION pDeviceExtension;
    UNICODE_STRING    usSystemName;
    UNICODE_STRING    usUserName;

    LARGE_INTEGER     li;

    UNREFERENCED_PARAMETER(RegistryPath);

    li.QuadPart = 0;

    tickIncrement = KeQueryTimeIncrement();

    KeInitializeEvent(&ValDiCloseEvent, NotificationEvent, FALSE);
    KeInitializeEvent(&logBarrier, NotificationEvent, FALSE);
    //KeInitializeEvent(&helperThreadGating, NotificationEvent, TRUE);       

    //General setup
    RtlInitUnicodeString(&usSystemName, SYSTEM_NAME);
    status = IoCreateDevice(DriverObject, sizeof(DEVICE_EXTENSION), &usSystemName, FILE_DEVICE_UNKNOWN, FILE_DEVICE_SECURE_OPEN, TRUE, &pDeviceObject);
    if (!NT_SUCCESS(status))
    {
        ELOG("IoCreateDevice returned 0x%X\n", status);
        return status;
    }

    DriverObject->MajorFunction[IRP_MJ_CREATE] = DriverObject->MajorFunction[IRP_MJ_CLOSE] = DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = Dispatch;
    DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = DeviceControl;
    DriverObject->DriverUnload = Unload;

    RtlInitUnicodeString(&usUserName, USER_NAME);
    status = IoCreateSymbolicLink(&usUserName, &usSystemName);
    if (!NT_SUCCESS(status))
    {
        IoDeleteDevice(pDeviceObject);
        ELOG("IoCreateSymbolicLink returned 0x%X\n", status);
        return status;
    }

    ValDiDeviceObjectPtr = pDeviceObject;

    //Setup device extention
    pDeviceExtension = pDeviceObject->DeviceExtension;
    pDeviceExtension->vsb = kmalloc(sizeof(VALDI_STATE_BLOCK));
    if (!pDeviceExtension->vsb)
    {
        ELOG("KMT init error: SB allocation failed.\n");
        return STATUS_INSUFFICIENT_RESOURCES;
    }

    strcpy((char*)txtBuffer.dbgMarker, "VALDI_DBG_MARKER1");

    txtBuffer.logBuffer = kcalloc(sizeof(TXTBUFFER), 1);
    txtBuffer.currP = &txtBuffer.logBuffer->buffer[0];

    uniDumpFilePath.MaximumLength = MAX_PATH;
    uniDumpFilePath.Length = 0;
    uniDumpFilePath.Buffer = kcalloc(sizeof(WCHAR), MAX_PATH);

    RtlCopyUnicodeString(&regPath, RegistryPath);
    Initialize_DFT();

    ValDiState = VALDISTATE_RUNNING;

    //Create helper thread
    static HANDLE hThread = NULL;
    status = PsCreateSystemThread(&hThread, 0, NULL, NULL, NULL, ValDiHelperThread, pDeviceExtension);
    if (!NT_SUCCESS(status))
    {
        ELOG("ValDi init error: helper thread create failed.\n");
        return status;
    }

    Setup_Logger();
    Setup_CRC();


    //addToLog = _addToLog;

    //Disable by default
    //ValDiState |= VALDISTATE_TRACING_FLAG;

    //Setup callbacks
    /*
    status = PsSetCreateProcessNotifyRoutineEx(ProcessCreateCallback, FALSE);
    if (!NT_SUCCESS(status))
    {
        ELOG("KMT init error: ProcessCreateCallback registration failed.\n");
        return status;
    }
    */

    status = PsSetLoadImageNotifyRoutine(ProcessLoadImageCallback);
    if (!NT_SUCCESS(status))
    {
        ELOG("KMT init error: ProcessLoadImageCallback registration failed.\n");
        return status;
    }

    PLOG("Starting ValDi kernel module.\n");

    return status;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
NTSTATUS Unload(IN PDRIVER_OBJECT DriverObject)
{
    PDEVICE_OBJECT         pDeviceObject = DriverObject->DeviceObject;
    PDEVICE_EXTENSION      pDeviceExtension = pDeviceObject->DeviceExtension;
    UNICODE_STRING         usUserName;

    PLOG("Unloading ValDi kernel module.\n");

    addToLog = _dummy_addToLog;

    InterlockedExchange((volatile LONG*)&ValDiState, VALDISTATE_DEMISED);

    KeWaitForSingleObject(&ValDiCloseEvent, Executive, KernelMode, FALSE, NULL);

    dumpFileHandle = NULL;

    uniDumpFilePath.MaximumLength = 0;
    uniDumpFilePath.Length = 0;
    if (uniDumpFilePath.Buffer)
        kfree(uniDumpFilePath.Buffer);
    uniDumpFilePath.Buffer = NULL;

    kfree(pDeviceExtension->vsb);

    //Clean up hooks data
    TearDown_DFTConfig();
    TearDown_DDRW_Hooks();
    TearDown_CRC();
    TearDown_MMIOHooks();
    TearDown_Logger();

    RtlInitUnicodeString(&usUserName, USER_NAME);
    IoDeleteSymbolicLink(&usUserName);
    IoDeleteDevice(pDeviceObject);

    return STATUS_SUCCESS;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
NTSTATUS DeviceControl(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
    ULONG op;
    PIO_STACK_LOCATION ioStack;
    NTSTATUS status = STATUS_INVALID_PARAMETER;

    UNREFERENCED_PARAMETER(DeviceObject);

    ioStack = IoGetCurrentIrpStackLocation(Irp);
    op = ioStack->Parameters.DeviceIoControl.IoControlCode;

    switch (op)
    {

    case IOCTL_VALDI__IGDKMD_GET_ADAPTER_INFO:
    {
        if (ioStack->Parameters.DeviceIoControl.InputBufferLength != sizeof(VALDI_ADAPTERINFO_IN))
        {
            status = STATUS_INVALID_PARAMETER;
            break;
        }

        PVALDI_ADAPTERINFO_IN  pIn = (PVALDI_ADAPTERINFO_IN)Irp->AssociatedIrp.SystemBuffer;
        PVOID pOut = (PVOID)MmGetSystemAddressForMdlSafe(Irp->MdlAddress, NormalPagePriority);

        if (ioStack->Parameters.DeviceIoControl.OutputBufferLength < pIn->expectedDataSize)
            return STATUS_INVALID_PARAMETER;

        if (igdkmd_getAdapterInfo(pIn->infoType, pIn->expectedDataSize, pOut))
            status = STATUS_UNSUCCESSFUL;
        else
            status = STATUS_SUCCESS;

    }break;

    case IOCTL_VALDI__IGDKMD_READ_MMIO:
    {
        if (ioStack->Parameters.DeviceIoControl.InputBufferLength != sizeof(VALDI_MMIODATA))
        {
            status = STATUS_INVALID_PARAMETER;
            break;
        }

        PVALDI_MMIODATA  pIn = (PVALDI_MMIODATA)Irp->AssociatedIrp.SystemBuffer;

        if (ioStack->Parameters.DeviceIoControl.OutputBufferLength < pIn->size)
        {
            status = STATUS_INVALID_PARAMETER;
            break;
        }

        PVOID pOut = (PVOID)MmGetSystemAddressForMdlSafe(Irp->MdlAddress, NormalPagePriority);

        if (igdkmd_readMMIOData(pIn->address, pOut, pIn->size))
            status = STATUS_UNSUCCESSFUL;
        else
            status = STATUS_SUCCESS;

    }break;

    case IOCTL_VALDI__IGDKMD_WRITE_MMIO:
    {
        if (ioStack->Parameters.DeviceIoControl.InputBufferLength <= sizeof(VALDI_MMIODATA))
        {
            status = STATUS_INVALID_PARAMETER;
            break;
        }

        PVALDI_MMIODATA  pIn = (PVALDI_MMIODATA)Irp->AssociatedIrp.SystemBuffer;

        if (ioStack->Parameters.DeviceIoControl.InputBufferLength < sizeof(VALDI_MMIODATA) + pIn->size)
        {
            status = STATUS_INVALID_PARAMETER;
            break;
        }

        if (igdkmd_writeMMIOData(pIn->address, (PVOID)((PTR_T)pIn + sizeof(VALDI_MMIODATA)), pIn->size))
            status = STATUS_UNSUCCESSFUL;
        else
            status = STATUS_SUCCESS;
    }break;


    case IOCTL_VALDI__IGDKMD_RESUME_MMIOWRITE_TRACING:
    {
        //igdkmd_requests.request_resumeTracing = 1;
        ValDiResumeTracing();
        status = STATUS_SUCCESS;
    }break;

    case IOCTL_VALDI__IGDKMD_SUSPEND_MMIOWRITE_TRACING:
    {
        ValDiSuspendTracing();
        //igdkmd_requests.request_pauseTracing = 1;
        status = STATUS_SUCCESS;
    }break;

    case IOCTL_VALDI__IGDKMD_FINALIZE_MMIOWRITE_TRACING:
    {
        ValDiFinalizeTracing();
        //igdkmd_requests.request_finalizeTracing = 1;
        status = STATUS_SUCCESS;
    }break;

    case IOCTL_VALDI__IGDKMD_RESTART_MMIOWRITE_TRACING:
    {
        ValDiRestartTracing();
        //igdkmd_requests.request_restartTracing = 1;
        status = STATUS_SUCCESS;
    }break;

    case IOCTL_VALDI__IGDKMD_SET_BSOD_TRIGGERS:
    {
        if (ioStack->Parameters.DeviceIoControl.InputBufferLength != sizeof(VALDI_BSOD_TRIGGERS_IN))
        {
            status = STATUS_INVALID_PARAMETER;
            break;
        }

        PVALDI_BSOD_TRIGGERS_IN  pIn = (PVALDI_BSOD_TRIGGERS_IN)Irp->AssociatedIrp.SystemBuffer;
        if (pIn->pipeID >= MAX_PIPES)
        {
            status = STATUS_INVALID_PARAMETER;
            break;
        }

        igdkmd_requests.request_updateBSODTriggerFlags[pIn->pipeID] = pIn->BSoDTriggersFlag;

        status = STATUS_SUCCESS;
    }break;


    case IOCTL_VALDI__IGDKMD_GET_PIPE_TO_PORT_MAPPINGS:
    {
        if (ioStack->Parameters.DeviceIoControl.OutputBufferLength < sizeof(PIPE_MAPS))
        {
            status = STATUS_INVALID_PARAMETER;
            break;
        }

        PVOID pOut = (PVOID)MmGetSystemAddressForMdlSafe(Irp->MdlAddress, NormalPagePriority);
        RtlCopyMemory(pOut, __getPipeStatusPtr(), sizeof(PIPE_MAPS));
        status = STATUS_SUCCESS;

    }break;


    case IOCTL_VALDI__GET_STATE:
    {
        if (ioStack->Parameters.DeviceIoControl.OutputBufferLength != sizeof(ULONG))
        {
            status = STATUS_INVALID_PARAMETER;
            break;
        }

        PVOID pOut = (PVOID)MmGetSystemAddressForMdlSafe(Irp->MdlAddress, NormalPagePriority);
        *(ULONG*)pOut = ValDiState;
        status = STATUS_SUCCESS;

    }break;

    case IOCTL_VALDI__SET_PIPE_VISIBILITY:
    {
        if (ioStack->Parameters.DeviceIoControl.InputBufferLength != sizeof(VALDI_SET_PIPE_VISIBILITY_IN))
        {
            status = STATUS_INVALID_PARAMETER;
            break;
        }

        PVALDI_SET_PIPE_VISIBILITY_IN  pIn = (PVALDI_SET_PIPE_VISIBILITY_IN)Irp->AssociatedIrp.SystemBuffer;

        if (pIn->pipeId >= MAX_PIPES)
        {
            status = STATUS_INVALID_PARAMETER;
            break;
        }

        if (__setPipeVisibility(pIn->pipeId, (UCHAR)pIn->enableFlag))
        {
            status = STATUS_UNSUCCESSFUL;
            break;
        }
        else
        {
            status = STATUS_SUCCESS;
        }

    }break;

    case IOCTL_VALDI__GET_HOOK_STATS:
    {
        if (ioStack->Parameters.DeviceIoControl.OutputBufferLength != sizeof(VALDI_HOOK_STATS))
        {
            status = STATUS_INVALID_PARAMETER;
            break;
        }

        PVOID pOut = (PVOID)MmGetSystemAddressForMdlSafe(Irp->MdlAddress, NormalPagePriority);
        RtlCopyMemory(pOut, &hStats, sizeof(hStats));
        status = STATUS_SUCCESS;
    }break;

    case IOCTL_VALDI__INSERT_TXT_MARKER:
    {
        if (ioStack->Parameters.DeviceIoControl.InputBufferLength != sizeof(VALDI_TXT_MARKER_IN))
        {
            status = STATUS_INVALID_PARAMETER;
            break;
        }

        PVALDI_TXT_MARKER_IN  pIn = (PVALDI_TXT_MARKER_IN)Irp->AssociatedIrp.SystemBuffer;

        USHORT slen = (USHORT)strlen(pIn->txtBuff);
        if (slen > VALDI_MAX_TXT_MARKER_LENGTH)
        {
            status = STATUS_INVALID_PARAMETER;
            break;
        }

        ADD_DLOG(pIn->txtBuff);

        status = STATUS_SUCCESS;
    }break;

    case IOCTL_VALDI__GET_MSGS:
    {
        if (ioStack->Parameters.DeviceIoControl.OutputBufferLength != MESSAGE_SIZE*MESSAGE_SLOTS)
        {
            status = STATUS_INVALID_PARAMETER;
            break;
        }

        PVOID pOut = (PVOID)MmGetSystemAddressForMdlSafe(Irp->MdlAddress, NormalPagePriority);
        CHAR* c = (CHAR*)pOut;
        c[0] = '\0';

        for (int i = 0; i < MESSAGE_SLOTS; i++)
        {
            if (_iMsgs[i].busyFlag)
            {
                strcat(c, _iMsgs[i].msg);
                InterlockedExchange(&_iMsgs[i].busyFlag, 0);
            }
        }
        status = STATUS_SUCCESS;
    }break;

    case IOCTL_VALDI__GFXVALSTUB:
    {
        status = ServiceGfxValStub(Irp);
    }break;

    case IOCTL_AUX_ACCESS:
    {
        PVOID pOut = (PVOID)MmGetSystemAddressForMdlSafe(Irp->MdlAddress, NormalPagePriority);
        ULONG eRet = __AUXAccess(pOut);
        if (eRet)
        {
            ELOG("AUXAccess returned error: 0x%X\n", eRet)
                status = STATUS_UNSUCCESSFUL;
        }
        else
            status = STATUS_SUCCESS;

    }break;

    case IOCTL_PLUG_UNPLUG_PORT:
    {
        if (ioStack->Parameters.DeviceIoControl.InputBufferLength != sizeof(VALDI_PLUG_UNPLUG_PORT_IN))
        {
            status = STATUS_INVALID_PARAMETER;
            break;
        }

        PVALDI_PLUG_UNPLUG_PORT_IN  pIn = (PVALDI_PLUG_UNPLUG_PORT_IN)Irp->AssociatedIrp.SystemBuffer;

        Handle_PlugUnPlug(pIn->portId, pIn->onResume);
        status = STATUS_SUCCESS;

    }break;

    default:
        ELOG("Invalid IOCTL code: 0x%X.\n", op);
        break;
    }



    Irp->IoStatus.Information = 0;
    Irp->IoStatus.Status = status;
    IoCompleteRequest(Irp, IO_NO_INCREMENT);
    return status;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
NTSTATUS Dispatch(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp)
{
    PDEVICE_EXTENSION  pDeviceExtension;
    PIO_STACK_LOCATION pIrpStack;

    ULONG              ulInformation = 0L;
    NTSTATUS           status = STATUS_NOT_IMPLEMENTED;

    pDeviceExtension = (PDEVICE_EXTENSION)DeviceObject->DeviceExtension;
    pIrpStack = IoGetCurrentIrpStackLocation(Irp);

    switch (pIrpStack->MajorFunction)
    {
    case IRP_MJ_CREATE:
        status = STATUS_SUCCESS;
        break;

    case IRP_MJ_CLOSE:

        status = STATUS_SUCCESS;
        break;

    default:
        status = STATUS_NOT_IMPLEMENTED;
        break;
    }

    Irp->IoStatus.Status = status;
    Irp->IoStatus.Information = ulInformation;
    IoCompleteRequest(Irp, IO_NO_INCREMENT);

    return status;
}
