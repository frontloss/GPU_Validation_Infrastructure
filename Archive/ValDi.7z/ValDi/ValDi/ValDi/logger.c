
#include "globals.h"
#include "Hooks.h"
#include "Helpers.h"
#include "kmem.h"
#include "Patcher.h"
#include "DFT.h"
#include <stdlib.h>
#include <stdio.h>
#include "logger.h"
#include "crc.h"

extern IGDKMD_PATCHER_REQUESTS            igdkmd_requests;

/////////////////////////////////////////////////////////////////////////////////////////////////////
//KERNEL objects
/////////////////////////////////////////////////////////////////////////////////////////////////////
KDPC                               dpcSwapLogBuffers;
KTIMER                             TimerSwapBuffers;
IO_STATUS_BLOCK                    logger_ioStatusBlock;

#define MAX_CHUNKS_ON_BOARD 16
VALDI_LOG_CHUNK logBoard[MAX_CHUNKS_ON_BOARD] = { 0 };

///////////////////////////////////////////////////////////////////////////////////////////////////
//DATA DUMPING
///////////////////////////////////////////////////////////////////////////////////////////////////
HANDLE                      dumpFileHandle = NULL;
UNICODE_STRING              uniDumpFilePath = { 0 };
WCHAR                       alt_uniDumpFilePath_buffer[MAX_PATH] = { 0 };
UNICODE_STRING              alt_uniDumpFilePath = { 0, MAX_PATH * 2,  alt_uniDumpFilePath_buffer };
UCHAR                       dbgMarker[] = "VALDI_DEBUG_MARKER";


volatile ULONG64 nextLogTicket = 0;
ULONG64 lastLogTicket = 0;
ULONG   time_increment = 0;


///////////////////////////////////////////////////////////////////////////////////////////////////
//Log buffering
///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
//HOOKING STATISTICS
///////////////////////////////////////////////////////////////////////////////////////////////////
VALDI_HOOK_STATS hStats = { 0 };


///////////////////////////////////////////////////////////////////////////////////////////////////
const LONG chunkCountLimit = TXTBUFFERSIZE / MAX_CHUNK_SIZE;
static ULONG64 lastSwapTimeStamp = 0;
volatile LONG pendingLogSwap = 0;



VOID _SwapLogBuffers(
    _In_     struct _KDPC *Dpc,
    _In_opt_ PVOID        DeferredContext,
    _In_opt_ PVOID        SystemArgument1,
    _In_opt_ PVOID        SystemArgument2
)
{
    UNREFERENCED_PARAMETER(Dpc);
    UNREFERENCED_PARAMETER(DeferredContext);
    UNREFERENCED_PARAMETER(SystemArgument2);

    if (InterlockedCompareExchange(&pendingLogSwap, 1, 0))
        return;

    *(INT*)&SystemArgument1 |= igdkmd_requests.request_finalizeTracing | igdkmd_requests.request_restartTracing | igdkmd_requests.request_finalizeTracingAck;
    {
        ULONG64 currentTimeStamp = GetTimeStamp();

        if (txtBuffer.chunkCount)
            if ((txtBuffer.chunkCount > (3 * chunkCountLimit / 4)) || ((currentTimeStamp - lastSwapTimeStamp) > 500000) || SystemArgument1)
            {
                lastSwapTimeStamp = currentTimeStamp;

                for (int i = 0; i < MAX_CHUNKS_ON_BOARD; i++)
                {
                    if (logBoard[i].pBuffAddress == NULL)
                    {
                        PTXTBUFFER nextBuff = kcalloc(sizeof(TXTBUFFER), 1);
                        if (!nextBuff)
                        {
                            txtBuffer.overflowFlag = 1;
                            goto _EXIT_POINT;
                        }

                        logBoard[i].pBuffAddress = txtBuffer.logBuffer;
                        logBoard[i].ticketNumber = ++nextLogTicket;
                        logBoard[i].timeStamp = currentTimeStamp;

                        InterlockedExchange64((volatile LONG64*)&txtBuffer.currP, (PTR_T)&nextBuff->buffer[0]);
                        txtBuffer.logBuffer = nextBuff;
                        InterlockedExchange((volatile LONG*)&txtBuffer.chunkCount, 0);
                        break;
                    }
                }
            }
        KeSetEvent(&logBarrier, 0, FALSE);
    }

_EXIT_POINT:
    InterlockedExchange(&pendingLogSwap, 0);
}


///////////////////////////////////////////////////////////////////////////////////////////////////
VOID _ScheduleSwapBuffers(int force)
{
    KeInsertQueueDpc(&dpcSwapLogBuffers, (PVOID)force, NULL);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID _appendLog(PVOID where2w, const PVOID data, USHORT size)
{
    RtlCopyMemory(where2w, data, size);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID appendString(PVOID where2w, const char* str, USHORT slen)
{
    PTR_T p = (PTR_T)where2w;
    UCHAR type = DTYPE_STR;

    _appendLog((PVOID)p, &type, sizeof(type)); p += sizeof(type);
    _appendLog((PVOID)p, &slen, sizeof(slen)); p += sizeof(slen);
    _appendLog((PVOID)p, (const PVOID)str, slen);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID appendBinData(PVOID where2w, PVOID data, USHORT len)
{
    PTR_T p = (PTR_T)where2w;
    UCHAR type = DTYPE_BIN;

    _appendLog((PVOID)p, &type, sizeof(type)); p += sizeof(type);
    _appendLog((PVOID)p, &len, sizeof(len));  p += sizeof(len);
    _appendLog((PVOID)p, data, len);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID append4BBinData(PVOID where2w, PVOID data, USHORT len)
{
    PTR_T p = (PTR_T)where2w;
    UCHAR type = DTYPE_BIN4BB;

    _appendLog((PVOID)p, &type, sizeof(type)); p += sizeof(type);
    _appendLog((PVOID)p, &len, sizeof(len));  p += sizeof(len);
    _appendLog((PVOID)p, data, len);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID appendDecData(PVOID where2w, PVOID data, USHORT len)
{
    PTR_T p = (PTR_T)where2w;
    UCHAR type = DTYPE_DEC;

    _appendLog((PVOID)p, &type, sizeof(type)); p += sizeof(type);
    _appendLog((PVOID)p, &len, sizeof(len));  p += sizeof(len);
    _appendLog((PVOID)p, data, len);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID appendNewLine(PVOID where2w)
{
    PTR_T p = (PTR_T)where2w;
    UCHAR type = DTYPE_STR;
    USHORT slen = 1;
    _appendLog((PVOID)p, &type, sizeof(type)); p += sizeof(type);
    _appendLog((PVOID)p, &slen, sizeof(slen)); p += sizeof(slen);
    _appendLog((PVOID)p, &type, slen);
}



///////////////////////////////////////////////////////////////////////////////////////////////////
VOID _dummy_addToLog(const char* fname, USHORT strbytes, PVOID* addrList, ULONG* sizesList, ULONG listLength)
{
    UNREFERENCED_PARAMETER(fname);
    UNREFERENCED_PARAMETER(strbytes);
    UNREFERENCED_PARAMETER(addrList);
    UNREFERENCED_PARAMETER(sizesList);
    UNREFERENCED_PARAMETER(listLength);
}

VOID addDirectToLog(const char* txt, USHORT strbytes)
{
    ULONGLONG timeStamp;
    timeStamp = GetTimeStamp();
    PTR_T where2w;

    USHORT slen = (USHORT)(SECTION_HEADER_SIZE*(3) + sizeof(timeStamp) + 1 + strbytes);

    if (InterlockedAdd((volatile LONG*)&txtBuffer.chunkCount, 1) >= chunkCountLimit)
    {
        txtBuffer.overflowFlag = 1;
        return;
    }

    where2w = (PTR_T)InterlockedExchangeAdd64((volatile LONG64*)&txtBuffer.currP, slen);
    appendDecData((PVOID)where2w, &timeStamp, sizeof(timeStamp)); where2w += SECTION_HEADER_SIZE + sizeof(timeStamp);
    appendString((PVOID)where2w, txt, strbytes); where2w += SECTION_HEADER_SIZE + strbytes;
    appendNewLine((PVOID)where2w);
}


VOID _addToLog(const char* fname, USHORT strbytes, PVOID* addrList, ULONG* sizesList, ULONG listLength)
{
    ULONG i;
    ULONGLONG timeStamp;
    timeStamp = GetTimeStamp();
    PTR_T where2w;
    ULONG split4bb = listLength&SPLIT_4BB;
    listLength &= ~SPLIT_4BB;

    USHORT slen = (USHORT)(SECTION_HEADER_SIZE*(listLength + 5) + sizeof(timeStamp) + 3 + strbytes);

    for (i = 0; i < listLength; i++)
    {
        slen += (USHORT)(sizesList[i] & 0xFFFF);
    }

    if (slen > MAX_CHUNK_SIZE)
        return;

    if (InterlockedAdd((volatile LONG*)&txtBuffer.chunkCount, 1) >= chunkCountLimit)
    {
        txtBuffer.overflowFlag = 1;
        return;
    }

    where2w = (PTR_T)InterlockedExchangeAdd64((volatile LONG64*)&txtBuffer.currP, slen);
    appendDecData((PVOID)where2w, &timeStamp, sizeof(timeStamp)); where2w += SECTION_HEADER_SIZE + sizeof(timeStamp);

    UCHAR uc = (UCHAR)KeGetCurrentProcessorNumber();
    appendBinData((PVOID)where2w, &uc, sizeof(uc)); where2w += SECTION_HEADER_SIZE + sizeof(UCHAR);
    uc = KeGetCurrentIrql();
    appendBinData((PVOID)where2w, &uc, sizeof(uc)); where2w += SECTION_HEADER_SIZE + sizeof(UCHAR);

    appendString((PVOID)where2w, fname, strbytes); where2w += SECTION_HEADER_SIZE + strbytes;

    {
        if (split4bb)
        {
            for (i = 0; i < listLength; i++)
            {
                if (sizesList[i] & DEC_FORMAT)
                {
                    appendDecData((PVOID)where2w, addrList[i], (USHORT)(sizesList[i] & 0xFFFF)); where2w += SECTION_HEADER_SIZE + sizesList[i] & 0xFFFF;
                }
                else
                {
                    append4BBinData((PVOID)where2w, addrList[i], (USHORT)sizesList[i]); where2w += SECTION_HEADER_SIZE + sizesList[i];
                }
            }
        }
        else
        {
            for (i = 0; i < listLength; i++)
            {
                if (sizesList[i] & DEC_FORMAT)
                {
                    appendDecData((PVOID)where2w, addrList[i], (USHORT)(sizesList[i] & 0xFFFF)); where2w += SECTION_HEADER_SIZE + sizesList[i] & 0xFFFF;
                }
                else
                {
                    appendBinData((PVOID)where2w, addrList[i], (USHORT)sizesList[i]); where2w += SECTION_HEADER_SIZE + sizesList[i];
                }
            }
        }
    }

    appendNewLine((PVOID)where2w);
}

volatile VOID(*addToLog)(const char* fname, USHORT strbytes, PVOID* addrList, ULONG* sizesList, ULONG listLength) = _dummy_addToLog;


///////////////////////////////////////////////////////////////////////////////////////////////////
VOID ValDiRestartTracing()
{
    addToLog = _dummy_addToLog;
    igdkmd_requests.request_restartTracing = 1;
    //KeSetEvent(&helperThreadGating, 0, FALSE);
    KeClearEvent(&logBarrier);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID ValDiFinalizeTracing()
{
    addToLog = _dummy_addToLog;
    igdkmd_requests.request_finalizeTracing = 1;
    //KeSetEvent(&helperThreadGating, 0, FALSE);
    KeClearEvent(&logBarrier);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID ValDiSuspendTracing()
{
    addToLog = _dummy_addToLog;
    igdkmd_requests.request_pauseTracing = 1;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VOID ValDiResumeTracing()
{
    addToLog = _addToLog;
    igdkmd_requests.request_resumeTracing = 1;
    //KeSetEvent(&helperThreadGating, 0, FALSE);
}



///////////////////////////////////////////////////////////////////////////////////////////////////
VOID NTAPI ValDiHelperThread(PVOID p)
{
    UNREFERENCED_PARAMETER(p);
    NTSTATUS            ntstatus;
    //  LARGE_INTEGER       long_sleepFor = { 0 };
    LARGE_INTEGER       short_sleepFor = { 0 };
    OBJECT_ATTRIBUTES   objAttr;
    CHAR                aBuff[KMT_U2A_BUFFER_SIZE];

    time_increment = KeQueryTimeIncrement();

    //long_sleepFor.QuadPart = -10000;
    short_sleepFor.QuadPart = -10000;

    while (ValDiState&VALDISTATE_RUNNING)
    {

        BOOLEAN calledWait = FALSE;
        BOOLEAN emptyPass = FALSE;

        if (lastLogTicket != nextLogTicket)
            while (!emptyPass)
            {
                emptyPass = TRUE;

                for (int i = 0; i < MAX_CHUNKS_ON_BOARD; i++)
                {
                    if (logBoard[i].ticketNumber == lastLogTicket + 1)
                    {
                        ULONG64 timeDelta = GetTimeStamp() - logBoard[i].timeStamp;
                        if (timeDelta < 10000)
                        {
                            KeDelayExecutionThread(KernelMode, TRUE, &short_sleepFor);
                            calledWait = TRUE;
                        }

                        if (dumpFileHandle)
                        {
                            LogToFile(logBoard[i].pBuffAddress, &logger_ioStatusBlock);
                        }

                        lastLogTicket++;
                        kfree(logBoard[i].pBuffAddress);
                        logBoard[i].pBuffAddress = NULL;
                        emptyPass = FALSE;
                    }
                }
            }

        if (!calledWait)
            KeDelayExecutionThread(KernelMode, TRUE, &short_sleepFor);


        //Pausing tracing
        if (igdkmd_requests.request_pauseTracing)
        {
            InterlockedAnd((volatile LONG*)&ValDiState, ~VALDISTATE_TRACING_FLAG);
            //KeClearEvent(&helperThreadGating);
            ADD_DLOG("TRACING SUSPENDED");
            igdkmd_requests.request_pauseTracing = 0;
        }

        //Resume tracing
        if (igdkmd_requests.request_resumeTracing)
        {
            syncPipePort();
            InterlockedOr((volatile LONG*)&ValDiState, VALDISTATE_TRACING_FLAG);
            ADD_DLOG("TRACING RESUMED");
            igdkmd_requests.request_resumeTracing = 0;
            addToLog = _addToLog;
        }

        //Restart tracing
        if (igdkmd_requests.request_restartTracing)
        {
            KeWaitForSingleObject(&logBarrier, Executive, KernelMode, FALSE, NULL);

            if (dumpFileHandle)
                ZwClose(dumpFileHandle);

            LoadConfiguration();
            LoadDFTConfig();

            if (!alt_uniDumpFilePath.Length)
                GenDumpName(&uniDumpFilePath);
            else
                RtlCopyUnicodeString(&uniDumpFilePath, &alt_uniDumpFilePath);

            if (uniDumpFilePath.Length)
            {
                InitializeObjectAttributes(&objAttr, &uniDumpFilePath, OBJ_CASE_INSENSITIVE | OBJ_KERNEL_HANDLE, NULL, NULL);
                ntstatus = ZwCreateFile(&dumpFileHandle, GENERIC_WRITE, &objAttr, &logger_ioStatusBlock, NULL, FILE_ATTRIBUTE_NORMAL, FILE_SHARE_READ, FILE_OVERWRITE_IF, FILE_SYNCHRONOUS_IO_NONALERT, NULL, 0);
                if (!NT_SUCCESS(ntstatus))
                {
                    u2a(&uniDumpFilePath, aBuff, KMT_U2A_BUFFER_SIZE);
                    ELOG("Log file [%s] open failed.\n", aBuff);
                    InterlockedAnd((volatile LONG*)&ValDiState, ~VALDISTATE_TRACING_FLAG);
                }
                else
                {
                    u2a(&uniDumpFilePath, aBuff, KMT_U2A_BUFFER_SIZE);
                    PLOG("Creating log file: [%s]\n", aBuff);
                }
            }

            igdkmd_getPipeToPortConfig();
            syncPipePort();
            InterlockedOr((volatile LONG*)&ValDiState, VALDISTATE_TRACING_FLAG);
            igdkmd_requests.request_restartTracing = 0;

            addToLog = _addToLog;
        }

        if (igdkmd_requests.request_finalizeTracingAck)
        {
            if (dumpFileHandle)
                ZwClose(dumpFileHandle);

            dumpFileHandle = NULL;
            igdkmd_requests.request_finalizeTracingAck = 0;
        }

        if (igdkmd_requests.request_finalizeTracing)
        {
            KeWaitForSingleObject(&logBarrier, Executive, KernelMode, FALSE, NULL);
            InterlockedAnd((volatile LONG*)&ValDiState, ~VALDISTATE_TRACING_FLAG);

            igdkmd_requests.request_finalizeTracingAck = 1;
            igdkmd_requests.request_finalizeTracing = 0;
        }
    }

    if (dumpFileHandle)
        ZwClose(dumpFileHandle);

    PLOG("ValDi helper thread terminating.\n");
    KeSetEvent(&ValDiCloseEvent, 0, FALSE);

    PsTerminateSystemThread(STATUS_SUCCESS);
}


///////////////////////////////////////////////////////////////////////////////
//
// Setup_Logger: Method to initialize logger thread
//
///////////////////////////////////////////////////////////////////////////////
void Setup_Logger()
{
    LARGE_INTEGER dueTime = { 0 };
    LONG period_in_ms = 100;

    KeInitializeThreadedDpc(&dpcSwapLogBuffers, _SwapLogBuffers, NULL);

    //Swap buffer at every 100 ms
    KeInitializeTimer(&TimerSwapBuffers);
    KeSetTimerEx(&TimerSwapBuffers, dueTime, period_in_ms, &dpcSwapLogBuffers);
}


///////////////////////////////////////////////////////////////////////////////
//
// TearDown_Logger: Method to de-initialize logger thread
//
///////////////////////////////////////////////////////////////////////////////
VOID TearDown_Logger()
{
    KeRemoveQueueDpc(&dpcSwapLogBuffers);
}


/////////////////////////////////////////////////////////////////////
// Timestamp of the last logged message
static ULONGLONG lastLogTimeStamp = 0;

////////////////////////////////////////////////////////////////////
//
// LogToFile: Method to log buffer to log file
//
////////////////////////////////////////////////////////////////////
VOID LogToFile(PTXTBUFFER p, PIO_STATUS_BLOCK ioStatusBlock)
{
    ULONG curr = 0;
    USHORT i;
    NTSTATUS ntstatus;
    USHORT slen;
    USHORT sdelta;
    CHAR bstr[18];
    ULONGLONG timeStamp;
    timeStamp = GetTimeStamp();

    if (txtBuffer.overflowFlag)
    {
        CHAR errMsg[128] = "!LOG_BUFF_OVERFLOW\n";
        ZwWriteFile(dumpFileHandle, NULL, NULL, NULL, ioStatusBlock, errMsg, (ULONG)strlen(errMsg), NULL, NULL);
        txtBuffer.overflowFlag = 0;
    }

    if (txtBuffer.droppedCRCFlag)
    {
        CHAR errMsg[128] = "!DROPPED_CRC\n";
        ZwWriteFile(dumpFileHandle, NULL, NULL, NULL, ioStatusBlock, errMsg, (ULONG)strlen(errMsg), NULL, NULL);
        txtBuffer.droppedCRCFlag = 0;
    }

    lastLogTimeStamp = timeStamp;

    while (curr < TXTBUFFERSIZE)
    {
        UCHAR type = p->buffer[curr];
        ULONGLONG d;
        curr++;

        switch (type)
        {
        case DTYPE_STR:
        {
            slen = *(USHORT*)&p->buffer[curr];
            if (slen > 128)
                return;
            curr += 2;
            ntstatus = ZwWriteFile(dumpFileHandle, NULL, NULL, NULL, ioStatusBlock, &p->buffer[curr], slen, NULL, NULL);
            if (ntstatus != STATUS_SUCCESS)
            {
                ELOG("ValDi dump write failed.\n");
            }
            curr += slen;
        }
        break;

        case DTYPE_DEC:
        case DTYPE_BIN4BB:
        case DTYPE_BIN:
        {
            slen = *(USHORT*)&p->buffer[curr];
            curr += 2;
            for (i = 0; i < slen;)
            {
                sdelta = (USHORT)(slen - i);

                bstr[0] = '\0';

                if ((sdelta >= 8) && (type != DTYPE_BIN4BB))
                {
                    d = *(ULONGLONG*)&p->buffer[curr + i];
                    i += 8;
                }
                else if (sdelta >= 4)
                {
                    d = *(ULONG*)&p->buffer[curr + i];
                    i += 4;
                }
                else if (sdelta >= 2)
                {
                    d = *(USHORT*)&p->buffer[curr + i];
                    i += 2;
                }
                else
                {
                    d = *(UCHAR*)&p->buffer[curr + i];
                    i += 1;
                }

                _ui64toa_s(d, bstr, 18, (type&DTYPE_BIN) ? 16 : 10);
                strcat(bstr, " ");

                ntstatus = ZwWriteFile(dumpFileHandle, NULL, NULL, NULL, ioStatusBlock, bstr, (ULONG)strlen(bstr), NULL, NULL);
                if (ntstatus != STATUS_SUCCESS)
                {
                    ELOG("ValDi dump write failed.\n");
                }
            }
            curr += slen;

            strcpy(bstr, "; ");
            ntstatus = ZwWriteFile(dumpFileHandle, NULL, NULL, NULL, ioStatusBlock, bstr, (ULONG)strlen(bstr), NULL, NULL);
            if (ntstatus != STATUS_SUCCESS)
            {
                ELOG("ValDi dump write failed.\n");
            }
        }
        default:
            break;
        }
    }
}
