#pragma once

#include <stdio.h>
#include <stdlib.h>
#include "globals.h"
#include "igdkmd_patcher\igdkmd_patcher.h"


#define MAX_SYMINFO_COUNT 128

#define OVR_SIGN 0xABCDABCD


extern KEVENT ValDiCloseEvent;

typedef struct _PATCHED_MODINFO
{
    CHAR          modName[MAX_PATH];
    PVOID         imageBase;
    ULONG         age;
    GUID          guid;

    ULONG         symInfoSize;
    PSYMBOLINFO   symInfo;

}PATCHED_MODINFO, *PPATCHED_MODINFO;

extern PPATCHED_MODINFO igdkmd_patcher_modInfoPtr;


typedef INT(*FPACTHER_T)(PPATCHED_MODINFO);

typedef struct _PATCHING_RULEZ
{
    CHAR          modShortName1[32];
	CHAR		  modShortName2[32];
	CHAR		  modShortName3[32];
    FPACTHER_T    fPatcher;
    VOID          (*fPatcherCleanup)();

}PATCHING_RULEZ, *PPATCHING_RULEZ;

typedef struct _VALDI_STATE_BLOCK
{
    ULONG      mode;
    ULONG      state;
    PEX_TIMER  hpTimer;
}VALDI_STATE_BLOCK, *PVALDI_STATE_BLOCK;


extern volatile ULONG ValDiState;
extern IGDKMD_PATCHER_REQUESTS igdkmd_requests;


extern ULONG txtBuffSizeDelta;

extern ULONG tickIncrement;

extern PDEVICE_OBJECT ValDiDeviceObjectPtr;

extern UNICODE_STRING regPath;

typedef struct _DPC_HEADER
{
    ULONG address;
    USHORT size;
}DPC_HEADER, *PDPC_HEADER;

VOID NTAPI ValDiHelperThread(PVOID p);

extern PTR_T igdkmd_patchOfThePatches;
extern HANDLE dumpFileHandle;
extern KEVENT helperThreadGating;
extern KEVENT logBarrier;

