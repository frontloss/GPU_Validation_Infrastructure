#pragma once
#include <ntdef.h>

// arg types
#define DD_IN IN
#define DD_OUT OUT
#define DD_IN_OUT

typedef CHAR DDS8; // signed 8 bit data type
typedef UCHAR DDU8; // unsigned 8 bit data type
typedef SHORT DDS16; // signed 16 bit data type
typedef USHORT DDU16; // unsigned 16 bit data type
typedef LONG DDS32; // signed 32 bit data type
typedef ULONG DDU32; // unsigned 32 bit data type
typedef LONG64 DDS64; // signed 64 bit data type
typedef ULONG64 DDU64; // unsigned 64 bit data type


#define __RESERVED2(x,y)  x##y // defn. internal to this file
#define __RESERVED1(x,y)  __RESERVED2(x,y)  // defn. internal to this file
#define __RANDOMNUMBER __LINE__ // __COUNTER__   // defn. internal to this file
#define UNIQUENAME(ValueName) __RESERVED1(ValueName, __RANDOMNUMBER)

                       //-----------------------------------------------------------------------------
                       // Macro: DD_BITFIELD_RANGE
                       // PURPOSE: Calculates the number of bits between the startbit and the endbit
                       // and count is inclusive of both bits. The bits are 0 based.
                       //-----------------------------------------------------------------------------
#define DD_BITFIELD_RANGE(ulLowBit, ulHighBit)     ((ulHighBit)-(ulLowBit)+1)

                       //-----------------------------------------------------------------------------
                       // Macro: DD_BITFIELD_BIT
                       // PURPOSE: Used to declare single bit width
                       //-----------------------------------------------------------------------------
#define DD_BITFIELD_BIT(bit) 1
