#pragma once
#include <wdm.h>
#include <stdio.h>
#include <ntdef.h>

#include "globals.h"

#ifndef CONFIG_H
#define CONFIG_H

extern UNICODE_STRING              regPath;

///////////////////////////////////////////////////////////////////////////////////////////////////
//GENERAL CONFIGURATION
extern  INT                                __option_trace_with_pipe_CRC_done;
extern  INT                                __option_trace_MMIO;
extern  INT                                __option_scrumbler_reset;
extern  INT                                __option_trace_pipe_underruns;
extern  INT                                __option_mask_ints;
extern  INT                                __option_locky_look_enabled;
extern  INT                                __option_trace_flip;
extern  INT                                __option_mmio_timings;
extern VOID LoadConfiguration();

#endif CONFIG_H