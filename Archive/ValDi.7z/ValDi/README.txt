Steps to build and test ValDi project:

Requirements:
Visual Studio 2015 update 3
Windows Driver Kit(WDK) 10

1. Installing Visual Studio professional 2015 with update 3
	Method 1:
	a. Install from below path which is update 1
		http://gfxsoftware.intel.com/Ops/TNE/USP_Proj/portal/Installations/install.asp?Modules=VS2015_1,VS2015_lic&TitleStr=MS%20Visual%20Studio%202015%20Professional%20Update%201
	b. While installing proceed with custom installation 
		Make sure to select 'Programming Languages --> Visual C++' to install the compiler and v140 platform toolset
		Make sure to select Windows 10 SDK related check marks
	c. Apply license for the same from the same URL path above
	
	Method 2:
	a. Install update 3 version directly from below path
		https://go.microsoft.com/fwlink/?LinkId=691129
	b. While installing proceed with custom installation 
		Make sure to select 'Programming Languages --> Visual C++' to install the compiler and v140 platform toolset
		Make sure to select Windows 10 SDK related check marks
	c. Apply license for the same from path given in Method1
	d. Apply the patch released for update 3 
		https://msdn.microsoft.com/en-us/library/mt752379.aspx

	At any point to have a look on installed features of VS2015 or modify the same
	open control panel -> Add remove program -> Visual Studio * -> change
	
	Known Issues:
	a. Visual Studio 2015 Update 2 will not work
	b. Requirement to log in when opening VS2015 - If it asks you to login, just select “Not now” and it won’t ask you anymore

2. Project path
	gfx_ValDisplay\mainline\DisplayAutomation2.0\Src\ValDi\ValDi
	gfx_ValDisplay\mainline\DisplayAutomation2.0\Src\ValDi\PreValDi
	gfx_ValDisplay\mainline\DisplayAutomation2.0\Src\ValDi\PostValDi
	gfx_ValDisplay\mainline\DisplayAutomation2.0\Src\ValDi\ValDiTest

3. Changes to be done for project solution
	a. If the solution is created with previous versions of Visual studio, the tools identify the
		same as soon as its opened and ask to modify the same, press OK when asked
	b. Right click on solution -> Retarget solution -> Target platform version = 10.0.*
		If there are not selection options with respect to 'Target platform version'
		then it specifies that WDK is not installed properly
	c. Right click on project -> properties -> configuration properties -> General
		Verify 
		Target Platform = Windows 10
		Target Platform version = 10.0.*
		Platform toolset = WindowsKernalModeDriver10.0 (for ValDi solution)
		Platform toolset = v140 (for other solutions)
	d. Ensure all the paths/references mentioned in configuration properties are valid
	e. Build the solution for x64 platform
	
4. Once the projects are built successfully below files are generated accordingly
	a. ValDi:
		valdi64.cat
		ValDi64.cer
		ValDi64.inf
		ValDi64.pdb
		ValDi64.sys
    b. PreValDi:
		PreValDi.exe
		PreValDi.pdb
    c. PostValDi:
		PostValDi.exe
		PostValDi.pdb
    d. ValDiTest
		ValDiTest.exe
		ValDiLib64.dll

5. Driver installation on to test machine
	a. Get any stable release package of the display driver from 'ubit'
	b. Open Device manager -> Display adapter -> right click on existing driver -> update driver software
	c. Brows my compter for driver software -> let me pick from list of device drivers -> Have disk -> browse
	d. Point to 'igdlh64.inf' file in the package downloaded from ubit and complete the installation 
	e. Copy/Replace 'igdkmd64.pdb' file from the package to 'C:\Windows\System32\drivers'
	f. Generate a VSM file by entering the command PreValDi.exe - p <igdkmd64.pdb path>
	g. Copy/Replace 'igdkmd64.VSM' file from the package to 'C:\Windows\System32\drivers'
	h. Copy the files mentioned in step-4a to the test machine 'ValDi\x64\' folder
	i. Copy the files mentioned in step-4b 4c 4d to the test machine 'ValDi\' folder
	j. install Microsoft Visual c++ 2015 re distributable (runtime) to resolve any dll missing issue 

6. Verifying ValDi
	a. Run PreValDi.exe -h to know available methods to prepare symbols and stub files
		PreValDi.exe -p C:\Windows\System32\drivers\igdkmd64.pdb
	b. Run pre.bat (to be present in 'ValDi\' folder)
	c. Run post.bat (to be present in 'ValDi\' folder)
	d. Logs are generated in \AppCrash* folder with *.valdi extension
		