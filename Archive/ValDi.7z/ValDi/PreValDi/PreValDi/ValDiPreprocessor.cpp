/**
* @file ValDi_Preprocessor.cpp 
* @addtogroup CDll_ValDi
* @brief To generate VSM file from igdkmd64.PDB file based on pre-defined symbol table.
* <ul>
* <li><b>Pre-Display validation APIs</b> \n
* </ul>
* <li> @ref main					\n \copybrief main \n
* <li> @ref StringToWString			\n \copybrief StringToWString \n
* <li> @ref ExePath					\n \copybrief ExePath \n
* <li> @ref PrintHelp				\n \copybrief PrintHelp \n
* <li> @ref CheckDIA				\n \copybrief CheckDIA \n
* </li>
*
* @author Krzysztof Olinski
*/

/***********************************************************************************************
* INTEL CONFIDENTIAL. Copyright (c) 2016 Intel Corporation All Rights Reserved.
*  <br>The source code contained or described herein and all documents related to the source code
*  ("Material") are owned by Intel Corporation or its suppliers or licensors. Title to the
*  Material remains with Intel Corporation or its suppliers and licensors. The Material contains
*  trade secrets and proprietary and confidential information of Intel or its suppliers and licensors.
*  The Material is protected by worldwide copyright and trade secret laws and treaty provisions.
*  No part of the Material may be used, copied, reproduced, modified, published, uploaded, posted,
*  transmitted, distributed, or disclosed in any way without Intel�s prior express written permission.
*  <br>No license under any patent, copyright, trade secret or other intellectual property right is
*  granted to or conferred upon you by disclosure or delivery of the Materials, either expressly,
*  by implication, inducement, estoppel or otherwise. Any license under such intellectual property
*  rights must be express and approved by Intel in writing.
*/

#include <stdio.h>
#include <string>
#include <dia2.h>
#include "ValDiPreprocessor.h"

#pragma comment(lib, "version.lib")

/**
* @brief			Method to display various options available in  
*					PreValDi application on console
*
* @return			void
*/
void PrintHelp()
{
	std::string vInfo = GetVersionInfo("ProductVersion");
#ifdef _WIN64
	printf("\nPreValDi 64b %s [%s]\n", vInfo.c_str(), __TIMESTAMP__);
#else
	printf("\nPreValDi 32b %s [%s]\n", vInfo.c_str(), __TIMESTAMP__);
#endif

	printf("Usage: PreValDi.exe [flags]:\n");
	printf("-p <path_to_drv_PDB> -v <rw/legacy>		prepares symbol info for kernel module \n");
	printf("-b <path_to_drv_PDB>					generates GVSTUB python bindings file\n");
	printf("-bp <path_to_drv_PDB> -v <rw/legacy>	generates VSM symbols & GVSTUB python bindings\n");
	printf("-i										installs ValDi kernel service\n");
	printf("-r										removes ValDi kernel service\n");
	printf("-h										prints help\n\n");
}

/**
* @brief			Get the path to windows executable(exe) file of ValDi Module
*
* @return           std::string
*/
std::string ExePath() 
{
	char buffer[MAX_PATH];
	GetModuleFileNameA(NULL, buffer, MAX_PATH);
	std::string::size_type pos = std::string(buffer).find_last_of("\\/");
	return std::string(buffer).substr(0, pos + 1);
}

/**
* @brief			Converts narrow string to wide string
*
* @param[in]        inputString - Reference to the narrow string
*
* @return			std::wstring
*/
std::wstring StringToWString(const std::string &inputString)
{
	std::wstring outputString(inputString.begin(), inputString.end());
	return outputString;
}

/**
* @brief			Method to check if Microsoft Debug Interface Access is attached
*
* @return			0 = Success
*				   -1 = Failure
*/
int CheckDIA()
{
	HKEY hKey;
	char txtGUID[128];

	sprintf(txtGUID, "\\CLSID\\{%08lX-%04hX-%04hX-%02hhX%02hhX-%02hhX%02hhX%02hhX%02hhX%02hhX%02hhX}",
		__uuidof(DiaSource).Data1, __uuidof(DiaSource).Data2, __uuidof(DiaSource).Data3,
		__uuidof(DiaSource).Data4[0], __uuidof(DiaSource).Data4[1], __uuidof(DiaSource).Data4[2], __uuidof(DiaSource).Data4[3],
		__uuidof(DiaSource).Data4[4], __uuidof(DiaSource).Data4[5], __uuidof(DiaSource).Data4[6], __uuidof(DiaSource).Data4[7]);

	/* Receive a register key handle to the above GUID*/
	long n = RegOpenKeyEx(HKEY_CLASSES_ROOT, TEXT(txtGUID), 0, KEY_QUERY_VALUE, &hKey);
	RegCloseKey(hKey);

	if (n == ERROR_SUCCESS)
	{
		/* Return if DIA is already registered*/
		return 0;
	}
	else
	{
		/* Register microsoft debug interface*/
		std::string msdiaPath = ExePath();
		msdiaPath += "msdia110.dll /s";
		SHELLEXECUTEINFO shi = { 0 };
		shi.cbSize = sizeof(SHELLEXECUTEINFO);
		shi.fMask = SEE_MASK_NOCLOSEPROCESS;
		shi.lpParameters = msdiaPath.c_str();
		shi.lpFile = "regsvr32";
		shi.nShow = SW_SHOWNORMAL;
		ShellExecuteEx(&shi);
		if (GetLastError())
		{
			PREVALDI_LOG("Could not register MSDIA component.\n");
			return -1;
		}
	}
	return 0;
}

/**
* @brief			Entry point to PreValiDi console application
*
* @param[in]        argc - number of command line arguments passed
* @param[in]        argv - reference to command line arguments
*
* @return			0 = Success
*				   -1 = Failure
*/
int main(int argc, CHAR* argv[])
{
	printf("PreValDi - preprocessor for ValDi kernel module.\n\n");
	/* Return if cmd line arguments are less than 2*/
	if (argc < 2)
	{
		PrintHelp();
		return 0;
	}

	/* Print help option*/
	if (!strcmp(argv[1], "-h"))
	{
		PrintHelp();
		return 0;
	}

	/* Option to process PDB*/
	if (!strcmp(argv[1], "-p"))
	{
		printf("Processing PDB...\n");
		CoInitializeEx(NULL, COINIT_MULTITHREADED);

		if (CheckDIA())
			return -1;

		if (argc == 5) {
			printf("Processing PDB for driver version : %s \n", argv[3]);

			if (!strcmp(argv[3], "-v")) {
				if (!strcmp(argv[4], "rw")) {
					printf("Generate VSM for re-write driver, ensure PDB file from re-write driver");
					return ProcPDB(argv[2], 1);
				}
				else {
					printf("Invalid driver version, use 'rw' for re-write driver\n");
				}
			}
		}
		printf("Generating VSM file for mainline driver, ensure PDB file from mainline driver");
		return ProcPDB(argv[2], 0);
	}

	/* Option to generate GVSTUB python bindings*/
	if (!strcmp(argv[1], "-b"))
	{
		printf("Processing PDB...\n");
		CoInitializeEx(NULL, COINIT_MULTITHREADED);

		if (CheckDIA())
			return -1;

		return ProcPDBforPythonBindings(argv[2]);
	}

	/* Option to generate both VSM symbols and GVSTUB python bindings*/
	if (!strcmp(argv[1], "-bp"))
	{
		printf("Processing PDB...\n");
		CoInitializeEx(NULL, COINIT_MULTITHREADED);

		if (CheckDIA())
			return -1;

		if (argc == 5) {
			printf("Processing PDB for driver version : %s \n", argv[3]);

			if (!strcmp(argv[3], "-v")) {
				if (!strcmp(argv[4], "rw")) {
					printf("Generate Python binding for re-write driver, ensure PDB file from re-write driver");
					return ProcPDB(argv[2], 1) | ProcPDBforPythonBindings(argv[2]);
				}
				else {
					printf("Invalid driver version, use 'rw' for re-write driver\n");
				}
			}
		}
		printf("Generating Python bindings for mainline driver, ensure PDB file from mainline driver");

		return ProcPDB(argv[2], 0) | ProcPDBforPythonBindings(argv[2]);
	}

	/* Option to install ValDi kernel service*/
	if (!strcmp(argv[1], "-i"))
	{
		std::string lastMsg;
		int r = InstallKernelTracingModule(lastMsg);
		return r;
	}

	/* Option to remove ValDi kernel service*/
	if (!strcmp(argv[1], "-r"))
	{
		return RemoveKernelTracingModule();
	}

	/* Default print help*/
	PrintHelp();
	return 0;

}

