/**
* @file PDB_Handler.cpp
* @addtogroup CDll_ValDi
* @brief Handles all Program DataBase(PDB), debugging and project state processing.
* <ul>
* <li><b>PDB Handler APIs</b> \n
* </ul>
* <li> @ref GetBaseTypeName					\n \copybrief GetBaseTypeName \n \n
* <li> @ref DIASource						\n \copybrief DIASource \n
* <li> @ref PDBSymbolInfo_Init				\n \copybrief PDBSymbolInfo_Init \n
* <li> @ref DDRW_SymbolInfo_Init			\n \copybrief DDRW_SymbolInfo_Init \n
* <li> @ref Legacy_SymbolInfo_Init			\n \copybrief Legacy_SymbolInfo_Init \n
* <li> @ref MakeBaseName					\n \copybrief MakeBaseName \n \n
* <li> @ref MakeFileName					\n \copybrief MakeFileName \n
* <li> @ref GetSymbolSize					\n \copybrief GetSymbolSize \n
* <li> @ref DumpSymbolInfo					\n \copybrief DumpSymbolInfo \n
* <li> @ref ListUDTSections					\n \copybrief ListUDTSections \n
* <li> @ref DumpUDTSection					\n \copybrief DumpUDTSection \n \n
* <li> @ref DumpPythonBindingsInfo			\n \copybrief DumpPythonBindingsInfo \n
* <li> @ref ProcPDB							\n \copybrief ProcPDB \n
* <li> @ref ProcPDBforPythonBindings		\n \copybrief ProcPDBforPythonBindings \n
* </li>
*
* @author Krzysztof Olinski
*/

/***********************************************************************************************
* INTEL CONFIDENTIAL. Copyright (c) 2016 Intel Corporation All Rights Reserved.
*  <br>The source code contained or described herein and all documents related to the source code
*  ("Material") are owned by Intel Corporation or its suppliers or licensors. Title to the
*  Material remains with Intel Corporation or its suppliers and licensors. The Material contains
*  trade secrets and proprietary and confidential information of Intel or its suppliers and licensors.
*  The Material is protected by worldwide copyright and trade secret laws and treaty provisions.
*  No part of the Material may be used, copied, reproduced, modified, published, uploaded, posted,
*  transmitted, distributed, or disclosed in any way without Intel�s prior express written permission.
*  <br>No license under any patent, copyright, trade secret or other intellectual property right is
*  granted to or conferred upon you by disclosure or delivery of the Materials, either expressly,
*  by implication, inducement, estoppel or otherwise. Any license under such intellectual property
*  rights must be express and approved by Intel in writing.
*/
#include <stdio.h>
#include <Windows.h>
#include <string>
#include <iostream>
#include <map>
#include <fstream>
#include <vector>
#include "ValDiPreprocessor.h"
#include <atlbase.h>
#include <Dia2.h>
#include "..\..\ValDi\ValDi\globals.h"

//Macros to specify Mainline or DDRW pdb
#define MAINLINE_PDB 0
#define DDRW_PDB 1

/* Macro to insert function symbol details into pre-defined table*/
#define INSERT_ENTRY(r, name)												\
    {																		\
        SYMBOLINFO symbolInfo;												\
        memset(&symbolInfo, 0, sizeof(symbolInfo));							\
        strcpy(symbolInfo.shortName, name);									\
        entriesToDump.push_back(pair<string, SYMBOLINFO>(r, symbolInfo));	\
    }

/* Macro to insert symbol details of function pointer member of a structure into pre-defined table*/
#define INSERT_MEMBER(parent, child, name)													\
    {																						\
        SYMBOLINFO symbolInfo;																\
        memset(&symbolInfo, 0, sizeof(symbolInfo));											\
        strcpy(symbolInfo.shortName, name);													\
        memberSymbol_t memberSymbol;														\
        memberSymbol.parentName = parent;													\
        memberSymbol.childName = child;														\
        membersToDump.push_back(pair<memberSymbol_t, SYMBOLINFO>(memberSymbol, symbolInfo));\
    }

/* Macro to write the contents into file*/
#define WRITE2FILE(...)								\
    {												\
        CHAR prePad[128];							\
        CHAR buff[896];								\
        CHAR lineBuffer[1024];						\
        memset(prePad, ' ', cnL->indent);			\
        prePad[cnL->indent] = '\0';					\
        sprintf(buff, __VA_ARGS__);					\
        sprintf(lineBuffer, "%s%s", prePad, buff);	\
        cnL->txtBuf += lineBuffer;					\
     }

using namespace std;

typedef struct _memberSymbol
{
	string parentName;
	string childName;
}memberSymbol_t;

typedef struct _NESTEDLEVEL
{
	string	txtBuf;
	ULONG	indent;
} NESTEDLEVEL;

typedef struct _CLASSDESCRIPTOR
{
	string			name;
	string			declaration;
	vector<string>	deps;
}CLASSDESCRIPTOR;

vector<pair<string, SYMBOLINFO> > entriesToDump;
vector<pair<memberSymbol_t, SYMBOLINFO> > membersToDump;

const char PREVALDI_MAGIC[] = PREVALDI_MAGIC_STR;

/**
* @brief			Fetch the base type name based on received type info and size
*
* @param[in]        dwInfo - type info
* @param[in]        ulLen - type size
*
* @return			string
*/
string GetBaseTypeName(DWORD dwInfo, ULONG ulLen)
{
	string baseTypeName;

	baseTypeName = "ctypes.c_";

	switch (dwInfo) 
	{
		case btUInt:
			baseTypeName += "u";

		case btInt:
			switch (ulLen) 
			{
				case 1:
					baseTypeName += "byte";
					break;

				case 2:
					baseTypeName += "short";
					break;

				case 4:
					baseTypeName += "int";
					break;

				case 8:
					baseTypeName += "longlong";
					break;
			} 
			break;

		case btChar: 
			baseTypeName += "char"; 
			break;

		case btWChar: 
			baseTypeName += "wchar"; 
			break;

		case btBool: 
			baseTypeName += "bool"; 
			break;

		case btLong: 
			baseTypeName += "long"; 
			break;

		case btULong: 
			baseTypeName += "ulong"; 
			break;

		default:
			dwInfo = 0xFFFFFFFF;
	}

	if (dwInfo == 0xFFFFFFFF)
	{
		switch (ulLen) {
		case 1:
			baseTypeName += "byte";
			break;

		case 2:
			baseTypeName += "short";
			break;

		case 4:
			baseTypeName += "int";
			break;

		case 8:
			baseTypeName += "longlong";
			break;
		}
	}

	return baseTypeName;
}

/**
* @brief			MEthod to fetch Debug interface access source
*
* @param[out]		source - DIA source
*
* @return			HRESULT
*/
HRESULT DIASource(CComPtr<IDiaDataSource>& source)
{
	HRESULT hr = CoCreateInstance(__uuidof(DiaSource), NULL, CLSCTX_INPROC_SERVER, __uuidof(IDiaDataSource), (void**)&source);

	if (FAILED(hr))
		return hr;

	return S_OK;
}

/**
* @brief			Re-write driver symbol info initialization
*
* @return			void
*/
void DDRW_SymbolInfo_Init()
{
	INSERT_ENTRY("DriverEntry", "DriverEntry");
	INSERT_ENTRY("DxgkInitialize", "DxgkInitialize");
	INSERT_ENTRY("KmReadMMIO_Data", "KmReadMMIO_Data");
	INSERT_ENTRY("KmWriteMMIO_Data", "KmWriteMMIO_Data");

	//Hooks to patching AuxAccess 
	INSERT_ENTRY("GfxInitDisplay", "GfxInitDisplay");
	INSERT_ENTRY("DisplayOSLInitialize", "DisplayOSLInitialize");

	//Hooks to patch VBT parser
	INSERT_ENTRY("OpregionProtocolGetVbt", "OpregionProtocolGetVbt");
	INSERT_ENTRY("VbtParserGetVBT", "VbtParserGetVBT");

	INSERT_ENTRY("GetHALInterface", "GetHALInterface");
	INSERT_ENTRY("DisplayHotPlugPortADpc", "DisplayHotPlugPortADpc");
	INSERT_ENTRY("DisplayHotPlugPortBDpc", "DisplayHotPlugPortBDpc");
	INSERT_ENTRY("DisplayHotPlugPortCDpc", "DisplayHotPlugPortCDpc");
	INSERT_ENTRY("DisplayHotPlugPortDDpc", "DisplayHotPlugPortDDpc");
	INSERT_ENTRY("DisplayHotPlugPortEDpc", "DisplayHotPlugPortEDpc");
	INSERT_ENTRY("DisplayInterruptServices", "DisplayInterruptServices");
	

	

	INSERT_MEMBER("_HW_DEVICE_EXTENSION", "pIntVtbl", "pIntVtbl@HW_DEV_EXT");
	INSERT_MEMBER("_HW_DEVICE_EXTENSION", "pMiniVtbl", "pMiniVtbl@HW_DEV_EXT");
	INSERT_MEMBER("_HW_DEVICE_EXTENSION", "pDisplayContext", "pDisplayContext@HW_DEV_EXT");

	INSERT_MEMBER("_DD_DISPLAY_HAL_SERVICES", "AUXAccess", "AUXAccess@_DD_DISPLAY_HAL_SERVICES");
	INSERT_MEMBER("_DD_DISPLAY_HAL_SERVICES", "ReadDDC", "ReadDDC@DD_DISPLAY_HAL_SERVICES");

	INSERT_MEMBER("_INTERRUPT_SERVICES", "pfnEventNotifyIsr", "pfnEventNotifyIsr@INTERRUPT_SERVICES");
	INSERT_MEMBER("_INTERRUPT_SERVICES", "pfnInterruptServices", "pfnInterruptServices@INTERRUPT_SERVICES");
	INSERT_MEMBER("_INTERRUPT_SERVICES", "pfnGetInterruptSource", "pfnGetInterruptSource@INTERRUPT_SERVICES");
	
	INSERT_MEMBER("_MINI_SERVICES", "pfnPCIWriteCfgReg", "pfnPCIWriteCfgReg@MINI_SERVICES")
	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOWriteDataOffset", "pfnMMIOWriteDataOffset@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOWriteUcharOffset", "pfnMMIOWriteUcharOffset@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOWriteUshortOffset", "pfnMMIOWriteUshortOffset@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOWriteUlongOffset", "pfnMMIOWriteUlongOffset@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOWriteAndUlongOffset", "pfnMMIOWriteAndUlongOffset@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOWriteOrUlongOffset", "pfnMMIOWriteOrUlongOffset@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOWriteXorUlongOffset", "pfnMMIOWriteXorUlongOffset@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOWriteMaskedUchar", "pfnMMIOWriteMaskedUchar@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOWriteMaskedUshort", "pfnMMIOWriteMaskedUshort@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOWriteMaskedUlong", "pfnMMIOWriteMaskedUlong@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnIOPortWriteUlongOffset", "pfnIOPortWriteUlongOffset@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMappedReadUlong", "pfnMappedReadUlong@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMappedWriteUlong", "pfnMappedWriteUlong@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOReadDataOffset", "pfnMMIOReadDataOffset@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOReadUcharOffset", "pfnMMIOReadUcharOffset@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOReadUshortOffset", "pfnMMIOReadUshortOffset@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOReadUlongOffset", "pfnMMIOReadUlongOffset@MINI_SERVICES");

}

/**
* @brief			Legacy driver symbol info initialization
*
* @return			void
*/
void Legacy_SymbolInfo_Init()
{
	//@TODO: List of symbols to be dumped will be loaded from external configuration file.
	//       Fixed list for PoC.
	INSERT_ENTRY("DriverEntry", "DriverEntry");
	INSERT_ENTRY("DxgkInitialize", "DxgkInitialize");
	INSERT_ENTRY("KmReadMMIO_Data", "KmReadMMIO_Data");
	INSERT_ENTRY("KmWriteMMIO_Data", "KmWriteMMIO_Data");
	INSERT_ENTRY("s_pGMCHPointer", "s_pGMCHPointer");
	INSERT_ENTRY("s_pCSLPointer", "s_pCSLPointer");
	INSERT_ENTRY("_SB_INTERRUPT_ARGS", "_SB_INTERRUPT_ARGS");
	INSERT_ENTRY("_PIPE_CONFIG", "_PIPE_CONFIG");
	INSERT_ENTRY("_IGFX_SET_SOURCE_VISIBILITY_ARG", "_IGFX_SET_SOURCE_VISIBILITY_ARG");
	INSERT_ENTRY("GfxSetSourceVisibility", "GfxSetSourceVisibility");
	INSERT_ENTRY("GfxValStub_ConfigureUnderRunInterrupt", "GfxValStub_ConfigureUnderRunInterrupt");
	INSERT_ENTRY("_IGFX_DISPLAY_PWR_SET_ARGS", "_IGFX_DISPLAY_PWR_SET_ARGS");
	INSERT_ENTRY("_SB_ADAPTERPOWERSTATE_ARGS", "_SB_ADAPTERPOWERSTATE_ARGS");
	INSERT_ENTRY("_SB_BLANKVIDEO_ARGS", "_SB_BLANKVIDEO_ARGS");
	INSERT_ENTRY("GfxValStub_DisplayFeatureHandler", "GfxValStub_DisplayFeatureHandler");
	INSERT_ENTRY("DoDDriverEntry", "DoDDriverEntry");
	INSERT_ENTRY("DxgkInitializeDisplayOnlyDriver", "DxgkInitializeDisplayOnlyDriver");

	INSERT_MEMBER("_HW_DEVICE_EXTENSION", "pIntVtbl", "pIntVtbl@HW_DEV_EXT");
	INSERT_MEMBER("_HW_DEVICE_EXTENSION", "pMiniVtbl", "pMiniVtbl@HW_DEV_EXT");
	INSERT_MEMBER("_INTERRUPT_SERVICES", "pfnEventNotifyIsr", "pfnEvNotIsr@INT_SRV");
	INSERT_MEMBER("_INTERRUPT_SERVICES", "pfnEventService", "pfnEventService@INT_SRV");
	INSERT_MEMBER("_INTERRUPT_SERVICES", "pfnUpdateHandlers", "pfnUpdateHandlers@INT_SRV");
	INSERT_MEMBER("_SB_SETMODE_ARGS", "ulPipeIndex", "ulPipeIndex@SB_MODE_ARGS");
	INSERT_MEMBER("_SB_SERVICES", "pfnSetMode", "pfnSetMode@SW_BIOS");
	INSERT_MEMBER("_SB_SERVICES", "pfnNotifyModeSetComplete", "pfnNotifyModeSetComplete@SW_BIOS");
	INSERT_MEMBER("_SB_SERVICES", "pfnHotPlug", "pfnHotPlug@SW_BIOS");
	INSERT_MEMBER("_SB_SERVICES", "pfnSetDisplayPowerState", "pfnSetDisplayPowerState@SW_BIOS");
	INSERT_MEMBER("_SB_SERVICES", "pfnBlankVideo", "pfnBlankVideo@SW_BIOS");

	INSERT_MEMBER("_MINI_SERVICES", "pfnPCIWriteCfgReg", "pfnPCIWriteCfgReg@MINI_SERVICES")
	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOWriteDataOffset", "pfnMMIOWriteDataOffset@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOWriteUcharOffset", "pfnMMIOWriteUcharOffset@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOWriteUshortOffset", "pfnMMIOWriteUshortOffset@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOWriteUlongOffset", "pfnMMIOWriteUlongOffset@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOWriteAndUlongOffset", "pfnMMIOWriteAndUlongOffset@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOWriteOrUlongOffset", "pfnMMIOWriteOrUlongOffset@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOWriteXorUlongOffset", "pfnMMIOWriteXorUlongOffset@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOWriteMaskedUchar", "pfnMMIOWriteMaskedUchar@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOWriteMaskedUshort", "pfnMMIOWriteMaskedUshort@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOWriteMaskedUlong", "pfnMMIOWriteMaskedUlong@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnIOPortWriteUlongOffset", "pfnIOPortWriteUlongOffset@MINI_SERVICES");

	INSERT_MEMBER("_MINI_SERVICES", "pfnMappedReadUlong", "pfnMappedReadUlong@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMappedWriteUlong", "pfnMappedWriteUlong@MINI_SERVICES");

	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOReadDataOffset", "pfnMMIOReadDataOffset@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOReadUcharOffset", "pfnMMIOReadUcharOffset@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOReadUshortOffset", "pfnMMIOReadUshortOffset@MINI_SERVICES");
	INSERT_MEMBER("_MINI_SERVICES", "pfnMMIOReadUlongOffset", "pfnMMIOReadUlongOffset@MINI_SERVICES");

	INSERT_MEMBER("_GMCHBASE", "m_stGMCHConfig*", "GMCH_CONFIG@GMCHBASE");
	INSERT_MEMBER("_GMCHBASE", "NotifyPowerState", "NotifyPowerState@GMCHBASE");

	INSERT_MEMBER("_GMCH_CONFIG", "stPipeConfig", "PIPE_CONFIG@GMCH_CONFIG");
	INSERT_MEMBER("_PIPE_CONFIG", "stPipeToPortConfig", "PIPE_PORT_CONFIG@PIPE_CONFIG");
	INSERT_MEMBER("_PIPE_PORT_CONFIG", "nPorts", "activePorts");

	INSERT_MEMBER("_PIPE_PORT_CONFIG", "ePort", "PORT_TYPES@PIPE_PORT");

	INSERT_MEMBER("_SB_SERVICES", "pfnInterruptServices", "pfnInterruptServices@SW_BIOS");
	INSERT_MEMBER("_HW_DEVICE_EXTENSION", "SwBios", "SwBios@HW_DEV_EXT");

	INSERT_MEMBER("_GMCHBASE", "AUXAccess", "AUXAccess@GMCHBASE");
	INSERT_MEMBER("GFX_ESCAPE_KM_DAF_REC", "Action", "Action@GFX_ESCAPE_KM_DAF_REC");
	INSERT_MEMBER("GFX_ESCAPE_HEADER", "EscapeCode", "EscapeCode@GFX_ESCAPE_HEADER");
}

/**
* @brief			Initialize PDB symbol information
*
* @param[in]        rewritePDB - 1 = Re-write driver
*								 0 = Legacy driver
*
* @return			void
*/
void PDBSymbolInfo_Init(int rewritePDB)
{
	if (rewritePDB) {
		DDRW_SymbolInfo_Init();
	}
	else {
		Legacy_SymbolInfo_Init();
	}
}

/**
* @brief			Get the base name from PDB path
*
* @param[out]       outFileName - path to PDB 
*
* @return			void
*/
void MakeBaseName(string &outFileName)
{
	const size_t didx = outFileName.rfind('.');
	if (string::npos != didx)
	{
		outFileName.erase(didx);
	}
}

/**
* @brief			Get the file name from PDB path
*
* @param[out]       outFileName - path to PDB 
*
* @return			void
*/
void MakeFileName(string &outFileName)
{
	const size_t didx = outFileName.rfind('\\');
	if (string::npos != didx)
	{
		outFileName.erase(0, didx + 1);
	}
}

/**
* @brief			Method to get the symbol size
*
* @param[in]        pSymbol - DIA Symbol
*
* @return			ULONG
*/
ULONG GetSymbolSize(IDiaSymbol* pSymbol)
{
	ULONG size = 0;

	ULONGLONG length;
	pSymbol->get_length(&length);

	if (length)
	{
		return (ULONG)length;
	}
	else
	{
		ULONG mul = 1;

		IDiaSymbol* pSymbolType;

		pSymbol->get_type(&pSymbolType);

		/*
		pSymbolType->get_count(&dw);
		if (dw)
		mul = dw;
		*/

		pSymbolType->get_length(&length);
		size = (ULONG)length*mul;
		pSymbolType->Release();
	}

	return size;
}

/**
* @brief			Dump symbol info
*
* @param[in]        pathToPDB - Path to PDB file
* @param[in]        rewritePDB - 1=re-write, 0=legacy
*
* @return			0 = Success
*				   -1 = Failure
*/
int DumpSymbolInfo(string pathToPDB, int rewritePDB)
{
	CComPtr<IDiaDataSource> pSource;
	CComPtr<IDiaSession>    pSession;
	wstring					wpath;
	ULONG                   count = 0;
	FILE                    *outF;
	LONG                    ppos = 0;
	int						ret = 0;

	PDBSymbolInfo_Init(rewritePDB);

	HRESULT hr = DIASource(pSource);

	if (FAILED(hr))
	{
		PREVALDI_LOG("CoCreate failed for MSDIA class.\n");
		return -1;
	}

	if (!PathFileExistsA(pathToPDB.c_str()))
	{
		PREVALDI_LOG("Invalid PDB path.\n");
		return -1;
	}

	wpath.assign(pathToPDB.begin(), pathToPDB.end());
	pSource->loadDataFromPdb(wpath.c_str());
	if (FAILED(hr))
	{
		PREVALDI_LOG("Could not open PDB file.\n");
		return -1;
	}

	string outFileName = pathToPDB;
	MakeBaseName(outFileName);
	outFileName += ".VSM";
	outF = fopen(outFileName.c_str(), "wb");
	if (!outF)
	{
		PREVALDI_LOG("Could not create the output file.\n");
		return -1;
	}

	fwrite(PREVALDI_MAGIC, sizeof(PREVALDI_MAGIC) - 1, 1, outF);

	if (FAILED(pSource->openSession(&pSession)))
	{
		PREVALDI_LOG("Could not open DIA session.\n");
		return -1;
	}

	CComPtr<IDiaSymbol> pGlobal;
	GUID guid = {};
	pSession->get_globalScope(&pGlobal);
	pGlobal->get_guid(&guid);
	fwrite(&guid, sizeof(guid), 1, outF);

	DWORD age;
	pGlobal->get_age(&age);
	fwrite(&age, sizeof(age), 1, outF);

	ppos = ftell(outF);
	fwrite(&count, sizeof(count), 1, outF);

	unsigned int i;
	if (entriesToDump.size())
		PREVALDI_LOG("Looking for symbols:\n");

	for (i = 0; i < entriesToDump.size(); i++)
	{
		IDiaEnumSymbols *pEnumSymbols;

		PREVALDI_LOG("    %s ", entriesToDump[i].first.c_str());

		wstring w = StringToWString(entriesToDump[i].first.c_str());

		if (SUCCEEDED(pGlobal->findChildren(SymTagNull, w.c_str(), nsfRegularExpression, &pEnumSymbols)))
		{
			IDiaSymbol *pSymbol;
			ULONG celt = 0;

			if (SUCCEEDED(pEnumSymbols->Next(1, &pSymbol, &celt)) && (celt == 1))
			{
				DWORD dw = 0;

				pSymbol->get_relativeVirtualAddress(&dw);
				entriesToDump[i].second.rva = dw;
				PREVALDI_LOG("\t\t0x%X", dw);

				entriesToDump[i].second.size = GetSymbolSize(pSymbol);

				PREVALDI_LOG("      \t(%u)\n", entriesToDump[i].second.size);

				pSymbol->Release();
			}
			else
			{
				PREVALDI_LOG("  NOT FOUND\n");
				ret = -1;
			}
			pEnumSymbols->Release();

			fwrite(&entriesToDump[i].second, sizeof(SYMBOLINFO), 1, outF);
			count++;
		}
	}

	if (membersToDump.size())
		PREVALDI_LOG("\nLooking for members:\n");

	for (i = 0; i < membersToDump.size(); i++)
	{
		IDiaEnumSymbols *pEnumParentSymbols;

		PREVALDI_LOG("    %s", membersToDump[i].first.parentName.c_str());

		wstring w = StringToWString(membersToDump[i].first.parentName.c_str());

		if (SUCCEEDED(pGlobal->findChildren(SymTagNull, w.c_str(), nsfRegularExpression, &pEnumParentSymbols)))
		{
			IDiaSymbol *pParentSymbol;
			ULONG celt = 0;

			if (SUCCEEDED(pEnumParentSymbols->Next(1, &pParentSymbol, &celt)) && (celt == 1))
			{
				wstring w = StringToWString(membersToDump[i].first.childName.c_str());
				IDiaEnumSymbols *pEnumChildSymbols;

				pParentSymbol->findChildren(SymTagNull, w.c_str(), nsfRegularExpression, &pEnumChildSymbols);

				IDiaSymbol *pChildSymbol;

				if (SUCCEEDED(pEnumChildSymbols->Next(1, &pChildSymbol, &celt)) && (celt == 1))
				{
					LONG ul = 0;

					pChildSymbol->get_offset(&ul);
					membersToDump[i].second.rva = ul;

					membersToDump[i].second.size = GetSymbolSize(pChildSymbol);

					pChildSymbol->Release();
					PREVALDI_LOG(".%s\t   0x%X ", membersToDump[i].first.childName.c_str(), membersToDump[i].second.rva);
					PREVALDI_LOG(" (%u) \n", membersToDump[i].second.size);

					fwrite(&membersToDump[i].second, sizeof(SYMBOLINFO), 1, outF);
					count++;
				}
				else
				{
					PREVALDI_LOG(".%s        \t NOT FOUND\n", membersToDump[i].first.childName.c_str());
					ret = -1;
				}

				pParentSymbol->Release();
				pEnumChildSymbols->Release();
			}
			else
			{
				PREVALDI_LOG("  NOT FOUND\n");
				ret = -1;
			}


			pEnumParentSymbols->Release();
		}

	}

	fseek(outF, ppos, SEEK_SET);
	fwrite(&count, sizeof(count), 1, outF);
	fclose(outF);
	PREVALDI_LOG("\nOutput saved to: %s\n\n", outFileName.c_str());

	return ret;
}

/**
* @brief			List All UDT sections and push them to a file
*
* @param[in]        pSymbolFilter
* @param[in]        pGlobal
* @param[in]        treadAsPacked
*
* @return			vector<CLASSDESCRIPTOR>
*/
vector<CLASSDESCRIPTOR> ListUDTSections(const char* pSymbolFilter, CComPtr<IDiaSymbol> pGlobal, bool treadAsPacked = false)
{
	wstring w = StringToWString(pSymbolFilter);
	DWORD celt = 0;

	CComPtr<IDiaEnumSymbols> pEnumStructs;

	BOOL unionMember;
	INT  unionNum;
	vector<CLASSDESCRIPTOR> classDescriptor;

	pGlobal->findChildren(SymTagUDT, w.c_str(), nsfRegularExpression, &pEnumStructs);

	for (CComPtr<IDiaSymbol> pSymbol; pEnumStructs->Next(1, &pSymbol, &celt) == S_OK; pSymbol = nullptr)
	{
		USES_CONVERSION;
		CComBSTR symname;

		CLASSDESCRIPTOR cDesc;

		unionNum = 0;
		unionMember = false;

		NESTEDLEVEL nL0;
		NESTEDLEVEL nL1;

		nL0.indent = nL1.indent = 0;

		NESTEDLEVEL* cnL = &nL0;

		pSymbol->get_name(&symname);


		cDesc.name = "C";
		cDesc.name += W2CA(symname);
		WRITE2FILE("class %s(ctypes.Structure):\n", cDesc.name.c_str());


		cnL->indent += 4;

		if (treadAsPacked)
		{
			WRITE2FILE("_pack_ = 1\n", W2CA(symname));
		}

		WRITE2FILE("_fields_ = [\n");

		CComPtr<IDiaEnumSymbols> pEnumEntries;
		pSymbol->findChildren(SymTagNull, nullptr, 0, &pEnumEntries);

		vector<CComPtr<IDiaSymbol>> pEntries;
		for (CComPtr<IDiaSymbol> pEntry; pEnumEntries->Next(1, &pEntry, &celt) == S_OK; pEntry = nullptr)
			pEntries.push_back(pEntry);


		for (int i = 0; i < pEntries.size(); i++)
		{
			CComPtr<IDiaSymbol> pEntry = pEntries[i];

			if (i + 1 < pEntries.size())
			{
				LONG offset1, offset2;
				pEntries[i]->get_offset(&offset1);
				pEntries[i + 1]->get_offset(&offset2);

				if ((offset1 == offset2) && (!unionMember))
				{
					unionMember = true;
					string uName = "u";
					uName += to_string(unionNum);
					string utName = cDesc.name;
					utName += "__";
					utName += uName;
					WRITE2FILE("('%s', %s),\n", uName.c_str(), utName.c_str());
					cnL = &nL1;
					WRITE2FILE("class %s(ctypes.Union):\n", utName.c_str());
					cnL->indent += 4;
					if (treadAsPacked)
						WRITE2FILE("_pack_ = 1\n");
					WRITE2FILE("_fields_ = [\n");
				}
				else if ((offset1 != offset2) && (unionMember))
				{
					WRITE2FILE("]\n");
					cDesc.declaration += cnL->txtBuf;
					cnL->indent = 0;
					cnL->txtBuf.clear();
					cnL = &nL0;
					unionMember = false;
				}
			}


			string memb;
			pEntry->get_name(&symname);

			string strSymName;
			strSymName += W2CA(symname);

			memb = "('";
			memb += strSymName;
			memb += "', ";

			CComPtr<IDiaSymbol> pStype;
			DWORD Tag;
			pEntry->get_type(&pStype);



			if (FAILED(pStype->get_symTag(&Tag)))
			{
				PREVALDI_LOG("<get_symTag> failed.\n");
				return vector<CLASSDESCRIPTOR>();
			}

			if (Tag == SymTagBaseType)
			{
				DWORD bType;
				ULONGLONG bSize;
				pStype->get_baseType(&bType);
				pStype->get_length(&bSize);
				memb += " " + GetBaseTypeName(bType, (ULONG)bSize);
			}
			else if (Tag == SymTagEnum)
			{
				ULONGLONG bSize;
				pStype->get_length(&bSize);
				memb += " " + GetBaseTypeName(btInt, (ULONG)bSize);
			}
			else if (Tag == SymTagPointerType)
			{
				memb += " ctypes.c_void_p";
			}
			else if (Tag == SymTagArrayType)
			{
				DWORD count;

				pStype->get_count(&count);

				CComPtr<IDiaSymbol> pFirstElementType;
				pStype->get_type(&pFirstElementType);
				pFirstElementType->get_symTag(&Tag);

				memb += "(";

				if (Tag == SymTagBaseType)
				{
					DWORD bType;
					ULONGLONG bSize;
					pFirstElementType->get_baseType(&bType);
					pFirstElementType->get_length(&bSize);
					memb += GetBaseTypeName(bType, (ULONG)bSize);
				}
				else
				{
					if (Tag == SymTagUDT)
					{

						pFirstElementType->get_name(&symname);
						string strSymName = "C";
						strSymName += W2CA(symname);
						memb += strSymName;
						if (find(cDesc.deps.begin(), cDesc.deps.end(), strSymName) == cDesc.deps.end())
							cDesc.deps.push_back(strSymName);

					}
					else
					{
						ULONGLONG bSize;
						pFirstElementType->get_length(&bSize);

						memb += "(ctypes.c_ubyte*";
						memb += to_string(bSize);
						memb += ")";
					}

				}

				memb += "*";
				memb += to_string(count);
				memb += ")";
			}
			else
			{
				string s;

				if (Tag == SymTagUDT)
				{
					pStype->get_name(&symname);
					s = "C";
					s += W2CA(symname);
				}

				if ((s.length() == 0) || (s.find("<") != std::string::npos))
				{
					ULONGLONG bSize;
					pStype->get_length(&bSize);

					memb += "(ctypes.c_ubyte*";
					memb += to_string(bSize);
					memb += ")";
				}
				else
				{
					memb += s;
					if (find(cDesc.deps.begin(), cDesc.deps.end(), s) == cDesc.deps.end())
						cDesc.deps.push_back(s);
				}
			}

			memb += "),\n";

			WRITE2FILE("%s", memb.c_str());


			if ((i + 1 == pEntries.size()) && (unionMember))
			{
				WRITE2FILE("]\n\n");
				cDesc.declaration += cnL->txtBuf;
				cnL = &nL0;
			}
		}

		WRITE2FILE("]\n\n");
		cDesc.declaration += cnL->txtBuf;
		classDescriptor.push_back(cDesc);
	}

	return classDescriptor;
}

/**
* @brief			Dumps UDT information to specified output file
*
* @param[in]        pOutFile - File handle to output file
* @param[in]        pSymbolFilter
* @param[in]        pGlobal
* @param[in]        treadAsPacked
*
* @return			0 = Success
*/
int DumpUDTSection(FILE* pOutFile, const char* pSymbolFilter, CComPtr<IDiaSymbol> pGlobal, bool treadAsPacked = false)
{
	vector<CLASSDESCRIPTOR> classDescriptor = ListUDTSections(pSymbolFilter, pGlobal, treadAsPacked);
	CHAR lineBuffer[1024];

	/* resolve object dependencies*/
	while (classDescriptor.size())
	{
		vector<CLASSDESCRIPTOR>::iterator it, resolvedDep = classDescriptor.end();
		for (it = classDescriptor.begin(); it != classDescriptor.end(); ++it)
		{
			if (it->deps.size() == 0)
			{
				fwrite(it->declaration.c_str(), it->declaration.size(), 1, pOutFile);
				resolvedDep = it;
				break;
			}
		}

		if (resolvedDep == classDescriptor.end())
		{
			sprintf(lineBuffer, "#Object(s) with not resolved dependecies:\n");
			fwrite(lineBuffer, strlen(lineBuffer), 1, pOutFile);
			for (it = classDescriptor.begin(); it != classDescriptor.end(); ++it)
			{
				fwrite(it->declaration.c_str(), it->declaration.size(), 1, pOutFile);
			}
			break;
		}

		/* Remove resolved dependecy*/
		string resolvedName = resolvedDep->name;

		if (resolvedName == "_GVSTUB_CREATE_RES_ARGS")
		{
			lineBuffer[0] = '\0';
		}

		classDescriptor.erase(resolvedDep);

		for (it = classDescriptor.begin(); it != classDescriptor.end(); ++it)
		{
			vector<string>::iterator is = find(it->deps.begin(), it->deps.end(), resolvedName);
			if (is != it->deps.end())
			{
				it->deps.erase(is);
			}
		}

	}
	return 0;
}

/**
* @brief			Dump all enumerations used
*
* @param[in]        pOutFile - Output file handle
* @param[in]        pSymbolFilter; either GVSTUB or GMCH_AUX
* @param[in]        pGlobal - scope
*
* @return			0 = Success
*/
int DumpEnumSection(FILE* pOutFile, const char* pSymbolFilter, CComPtr<IDiaSymbol> pGlobal)
{
	/* Dump all GVSTUB enums*/
	CComPtr<IDiaEnumSymbols> pEnumSymbols;
	wstring wStr = StringToWString(pSymbolFilter);
	DWORD celt = 0;
	CHAR lineBuffer[1024];

	pGlobal->findChildren(SymTagEnum, wStr.c_str(), nsfRegularExpression, &pEnumSymbols);

	for (CComPtr<IDiaSymbol> pSymbol; pEnumSymbols->Next(1, &pSymbol, &celt) == S_OK; pSymbol = nullptr)
	{
		USES_CONVERSION;
		CComBSTR symname;
		pSymbol->get_name(&symname);
		sprintf(lineBuffer, "\n\n#Enum %s\n", W2CA(symname));
		fwrite(lineBuffer, strlen(lineBuffer), 1, pOutFile);

		CComPtr<IDiaEnumSymbols> enumValues;
		pSymbol->findChildren(SymTagData, nullptr, 0, &enumValues);

		for (CComPtr<IDiaSymbol> value; enumValues->Next(1, &value, &celt) == S_OK; value = nullptr)
		{
			CComBSTR symname;
			CComVariant var;

			value->get_name(&symname);
			value->get_value(&var);
			var.ChangeType(VT_BSTR);
			sprintf(lineBuffer, "C_%s = %s\n", W2CA(symname), W2CA(var.bstrVal));
			fwrite(lineBuffer, strlen(lineBuffer), 1, pOutFile);
		}
	}

	sprintf(lineBuffer, "\n\n\n");
	fwrite(lineBuffer, strlen(lineBuffer), 1, pOutFile);
	return 0;
}

/**
* @brief			Dump python bindings info after processing PDB
*
* @param[in]        pathToPDB - Path to PDB file
*
* @return			0 = Success
*				   -1 = Failure
*/
int DumpPythonBindingsInfo(string pathToPDB)
{
	CComPtr<IDiaDataSource> pSource;
	CComPtr<IDiaSession>    pSession;
	wstring					wPath;
	ULONG                   count = 0;
	FILE					*outputFile;
	CHAR                    lineBuffer[1024];

	/* Get DIA source handle*/
	HRESULT hr = DIASource(pSource);

	if (FAILED(hr))
	{
		PREVALDI_LOG("CoCreate failed for MSDIA class.\n");
		return -1;
	}

	if (!PathFileExistsA(pathToPDB.c_str()))
	{
		PREVALDI_LOG("Invalid PDB path.\n");
		return -1;
	}

	wPath.assign(pathToPDB.begin(), pathToPDB.end());
	pSource->loadDataFromPdb(wPath.c_str());
	if (FAILED(hr))
	{
		PREVALDI_LOG("Could not open PDB file.\n");
		return -1;
	}

	if (FAILED(pSource->openSession(&pSession)))
	{
		PREVALDI_LOG("Could not open DIA session.\n");
		return -1;
	}

	string outFileName = pathToPDB;
	MakeBaseName(outFileName);
	MakeFileName(outFileName);
	outFileName += "_stubs.py";
	outputFile = fopen(outFileName.c_str(), "w");
	if (!outputFile)
	{
		PREVALDI_LOG("Could not create the output file.\n");
		return -1;
	}

	sprintf(lineBuffer, "#This file was generated by PreValDi.\n\n");
	fwrite(lineBuffer, strlen(lineBuffer), 1, outputFile);

	sprintf(lineBuffer, "import ctypes\n");
	fwrite(lineBuffer, strlen(lineBuffer), 1, outputFile);

	CComPtr<IDiaSymbol> pGlobal;
	pSession->get_globalScope(&pGlobal);

	/* Filter GVSTUB symbol and dump in the output file*/
	DumpEnumSection(outputFile, "*GVSTUB*", pGlobal);
	DumpUDTSection(outputFile, "*GVSTUB*", pGlobal, true);

	/* Filter GMCH_AUX symbol and dump in the output file*/
	DumpEnumSection(outputFile, "*GMCH_AUX*", pGlobal);
	DumpUDTSection(outputFile, "*GMCH_AUX*", pGlobal);

	fclose(outputFile);
	PREVALDI_LOG("\nOutput saved to: %s\n\n", outFileName.c_str());

	return 0;
}

/**
* @brief			Method to process PDB file
*
* @param[out]		pPathToPDB - Path to PDB file
* @param[in]		rewritePDB - 0 = Legacy driver PDB
*								 1 = Display driver Re-Write PDB
*
* @return           0 = Success
*				   -1 = Failure
*/
int ProcPDB(const char* pPathToPDB, int rewritePDB)
{
	int ret;
	if (!pPathToPDB)
	{
		PREVALDI_LOG("Invalid argument.\n");
		return -1;
	}


	//Dump DDRW driver symbol info initially
	ret = DumpSymbolInfo(pPathToPDB, DDRW_PDB);
	if (ret == 0){
		return ret;
	}
	else {
		//If not DDRW PDB clear the DDRW symbols info
		entriesToDump.clear();
		membersToDump.clear();

		//Dump mainilne driver symbol info
		return DumpSymbolInfo(pPathToPDB, MAINLINE_PDB);
	}
}

/**
* @brief			Process PDB file for Python bindings
*
* @param[in]        pPathToPDB - Path to PDB file
*
* @return			0 = Success
*				   -1 = Failure
*/
int ProcPDBforPythonBindings(const char* pPathToPDB)
{
	if (!pPathToPDB)
	{
		PREVALDI_LOG("Invalid argument.\n");
		return -1;
	}

	return DumpPythonBindingsInfo(pPathToPDB);
}