/**
* @file ValDi_Preprocessor.h
* @addtogroup CDll_ValDi
* @brief Preprocessor binary to generate VSM file from igdkmd64.PDB file based on pre-defined symbol table.
* <ul>
* <li><b>Pre-Display validation APIs</b> \n
* </ul>
* <li> @ref StringToWString				\n \copybrief StringToWString \n
* <li> @ref ExePath						\n \copybrief ExePath \n
* <li> @ref ProcPDB						\n \copybrief ProcPDB \n
* <li> @ref ProcPDBforPythonBindings	\n \copybrief ProcPDBforPythonBindings \n
* <li> @ref InstallKernelTracingModule	\n \copybrief InstallKernelTracingModule \n \n
* <li> @ref RemoveKernelTracingModule 	\n \copybrief RemoveKernelTracingModule \n
* <li> @ref GetVersionInfo 				\n \copybrief GetVersionInfo \n
* </li>
*
* @author Krzysztof Olinski
*/

/***********************************************************************************************
* INTEL CONFIDENTIAL. Copyright (c) 2016 Intel Corporation All Rights Reserved.
*  <br>The source code contained or described herein and all documents related to the source code
*  ("Material") are owned by Intel Corporation or its suppliers or licensors. Title to the
*  Material remains with Intel Corporation or its suppliers and licensors. The Material contains
*  trade secrets and proprietary and confidential information of Intel or its suppliers and licensors.
*  The Material is protected by worldwide copyright and trade secret laws and treaty provisions.
*  No part of the Material may be used, copied, reproduced, modified, published, uploaded, posted,
*  transmitted, distributed, or disclosed in any way without Intel�s prior express written permission.
*  <br>No license under any patent, copyright, trade secret or other intellectual property right is
*  granted to or conferred upon you by disclosure or delivery of the Materials, either expressly,
*  by implication, inducement, estoppel or otherwise. Any license under such intellectual property
*  rights must be express and approved by Intel in writing.
*/


/* Avoid multi inclusion of header file*/
#pragma once
#include <string>

/* Macro to log*/
#define PREVALDI_LOG(...) printf(__VA_ARGS__)

#ifndef SHOW_ERROR
/* Display error message on console*/
#define SHOW_ERROR																		\
{																						\
    DWORD e = GetLastError();															\
    if (e)																				\
            {																			\
        char buf[256] = {0};															\
        FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM|FORMAT_MESSAGE_IGNORE_INSERTS, NULL, e,\
					MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), buf, 256, NULL);			\
        PREVALDI_LOG("Error: %s", buf);													\
            }																			\
}
#endif

/**
* @brief			Converts narrow string to wide string
*
* @param[in]        str - Reference to the narrow string 
*
* @return			std::wstring
*/
std::wstring StringToWString(const std::string &str);

/**
* @brief			Get the path to windows executable(exe) file of ValDi Module
*
* @return           std::string
*/
std::string ExePath();

/**
* @brief			Method to process PDB file
*
* @param[out]		pPathToPDB - Path to PDB file
* @param[in]		rewritePDB - 0 = Display driver Re-Write PDB
*								 1 = Legacy driver PDB
*
* @return           0 = Success
*				   -1 = Failure
*/
int ProcPDB(const char* pPathToPDB, int rewritePDB);

/**
* @brief			Process PDB file for python binding scripts generation
*
* @param[in]		pPathToPDB - Path to PDB file
*
* @return           0 = Success
*				   -1 = Failure
*/
int ProcPDBforPythonBindings(const char* pPathToPDB);

/**
* @brief			Hooks kernal tracing module
*
* @param[out]		lastMsg -  - Error messages are stored if any
*
* @return           0 = Success
*				   -1 = Failure
*/
int InstallKernelTracingModule(std::string &lastMsg);

/**
* @brief			Removes kernel tracing services
*
* @return           0 = Success
*				   -1 = Failure
*/
int RemoveKernelTracingModule();

/**
* @brief			Get display driver version info 
*
* @param[out]		pField - query string (ex: ProductInformation)
*
* @return           std::string
*/
std::string GetVersionInfo(const char *pField);