/**
* @file Service_Handler.cpp
* @addtogroup CDll_ValDi
* @brief Defines all the methods required for core services.
* <ul>
* <li><b>Pre-Display validation APIs</b> \n
* </ul>
* <li> @ref GetVersionInfo					\n \copybrief GetVersionInfo \n \n
* <li> @ref GetMachineRegValue				\n \copybrief GetMachineRegValue \n
* <li> @ref GetMachineStringRegKey			\n \copybrief GetMachineStringRegKey \n
* <li> @ref CheckService					\n \copybrief CheckService \n
* <li> @ref InstallKernelTracingModule		\n \copybrief InstallKernelTracingModule \n
* <li> @ref RemoveKernelTracingModule		\n \copybrief RemoveKernelTracingModule \n
* </li>
*
* @author Krzysztof Olinski
*/

/***********************************************************************************************
* INTEL CONFIDENTIAL. Copyright (c) 2016 Intel Corporation All Rights Reserved.
*  <br>The source code contained or described herein and all documents related to the source code
*  ("Material") are owned by Intel Corporation or its suppliers or licensors. Title to the
*  Material remains with Intel Corporation or its suppliers and licensors. The Material contains
*  trade secrets and proprietary and confidential information of Intel or its suppliers and licensors.
*  The Material is protected by worldwide copyright and trade secret laws and treaty provisions.
*  No part of the Material may be used, copied, reproduced, modified, published, uploaded, posted,
*  transmitted, distributed, or disclosed in any way without Intel�s prior express written permission.
*  <br>No license under any patent, copyright, trade secret or other intellectual property right is
*  granted to or conferred upon you by disclosure or delivery of the Materials, either expressly,
*  by implication, inducement, estoppel or otherwise. Any license under such intellectual property
*  rights must be express and approved by Intel in writing.
*/
#include "ValDiPreprocessor.h"

#include <Windows.h>
#include <Newdev.h>

#pragma comment(lib, "Newdev.lib")
#pragma comment(lib, "Version.lib")

/**
* @brief			Get display driver version info
*
* @param[in]        pField - query string (ex: ProductInformation)
*
* @return			string
*/
std::string GetVersionInfo(const char *pField)
{
    std::string strResult;

    char szModPath[MAX_PATH];
    szModPath[0] = '\0';
	/* Get present module name(display) and store it in szModPath buffer*/
    GetModuleFileName(NULL, szModPath, sizeof(szModPath));
    DWORD dwHandle;
	/* Size of version info in bytes*/
    DWORD dwSize = GetFileVersionInfoSize(szModPath, &dwHandle);

    if (dwSize > 0)
    {
        BYTE* pbBuf = static_cast<BYTE*>(alloca(dwSize));
        if (GetFileVersionInfo(szModPath, dwHandle, dwSize, pbBuf))
        {
            UINT uiSize;
            BYTE* lpb;
            if (VerQueryValue(pbBuf,
                "\\VarFileInfo\\Translation",
                (void**)&lpb,
                &uiSize))
            {
                WORD* lpw = (WORD*)lpb;
                char strQuery[MAX_PATH];
                sprintf(strQuery, "\\StringFileInfo\\%04x%04x\\%s", lpw[0], lpw[1], pField);
                if (VerQueryValue(pbBuf,
                    strQuery,
                    (void**)&lpb,
                    &uiSize) && uiSize > 0)
                {
                    strResult = (LPCSTR)lpb;
                }
            }
        }
    }

    return strResult;
}

/**
* @brief			To get machine(HKEY_LOCAL_MACHINE) registry value
*
* @param[in]        pPath - Register path
* @param[in]        pKeyName - Register key name to query
*
* @return			DWORD
*/
DWORD GetMachineRegValue(const char *pPath, const char *pKeyName)
{
    HKEY hKey;
    DWORD buffer = 0;
    LONG result;
    unsigned long type = REG_DWORD, size = 1024;

    result = RegOpenKeyEx(HKEY_LOCAL_MACHINE, pPath, 0, KEY_READ, &hKey);
    if (result == ERROR_SUCCESS)
    {
        RegQueryValueEx(hKey, pKeyName, NULL, &type, (LPBYTE)&buffer, &size);
        RegCloseKey(hKey);
    }

    return buffer;

}

/**
* @brief			To get machine string registry key TODO
*
* @param[in]        pPath - Register path
* @param[in]        pKeyName - Register key name to query
*
* @return			string
*/
std::string GetMachineStringRegKey(const char *pPath, const char *pKeyName)
{
    HKEY hKey;
    CHAR buffer[1024] = { 0 };
    LONG result;

    unsigned long type = REG_SZ, size = 1024;

    result = RegOpenKeyEx(HKEY_LOCAL_MACHINE, pPath, 0, KEY_READ, &hKey);
    if (result == ERROR_SUCCESS)
    {
        RegQueryValueEx(hKey, pKeyName, NULL, &type, (LPBYTE)&buffer, &size);
        RegCloseKey(hKey);
    }

    return buffer;
}


/**
* @brief			Method to check if ValDi service is available
*
* @param[in]        setState - 0x4  = Start service
*							   0x20 = Stop service
*
* @return			0 = Success
*				   -1 = Failure
*/
int CheckService(int setState)
{
    SC_HANDLE schSCManager;
    schSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
    if (schSCManager == NULL)
    {
        SHOW_ERROR;
        return -1;
    }

    SC_HANDLE serviceHandle = OpenService(schSCManager, "ValDi", SC_MANAGER_ALL_ACCESS);
    if (serviceHandle == NULL)
    {
        DWORD le = GetLastError();
        if (le == ERROR_SERVICE_DOES_NOT_EXIST)
        {
            PREVALDI_LOG("Service not detected.\n");
            CloseServiceHandle(schSCManager);
            return 0;
        }
        else
        {
            SHOW_ERROR;
            CloseServiceHandle(schSCManager);
            return -1;
        }
    }

    SERVICE_STATUS_PROCESS status;
    DWORD bytesNeeded;
    QueryServiceStatusEx(serviceHandle, SC_STATUS_PROCESS_INFO, (LPBYTE)&status, sizeof(SERVICE_STATUS_PROCESS), &bytesNeeded);

    if (!setState)
    {
        CloseServiceHandle(serviceHandle);
        CloseServiceHandle(schSCManager);
        return status.dwCurrentState;
    }

	/* If ValDi is currently not running and there is an external trigger to start it*/
    if ((status.dwCurrentState != SERVICE_RUNNING) && (setState == SERVICE_RUNNING))
    {
        BOOL b = StartService(serviceHandle, NULL, NULL);
        if (b)
        {
            CloseServiceHandle(serviceHandle);
            CloseServiceHandle(schSCManager);
            PREVALDI_LOG("Service started.\n");
            return SERVICE_RUNNING;
        }
        else
        {
            SHOW_ERROR;
            CloseServiceHandle(serviceHandle);
            CloseServiceHandle(schSCManager);
            return -1;
        }
    }
	/* If ValDi is currently running and there is an external trigger to stop it*/
    else if ((status.dwCurrentState == SERVICE_RUNNING) && (setState == SERVICE_STOP))
    {
        SERVICE_STATUS ls;
        BOOL b = ControlService(serviceHandle, SERVICE_CONTROL_STOP, (LPSERVICE_STATUS)&ls);
        if (b)
        {
            CloseServiceHandle(serviceHandle);
            CloseServiceHandle(schSCManager);
            return ls.dwCurrentState;
        }
        else
        {
            SHOW_ERROR;
            CloseServiceHandle(serviceHandle);
            CloseServiceHandle(schSCManager);
            return -1;
        }
    }

    CloseServiceHandle(serviceHandle);
    CloseServiceHandle(schSCManager);
    return status.dwCurrentState;
}

/**
* @brief			Method to install kernel tracing module
*
* @param[out]       lastMsg - Error messages are stored if any
*
* @return			0 = Success
*				   -1 = Failure
*/
int InstallKernelTracingModule(std::string &lastMsg)
{
    std::string drvPath = ExePath();
    std::string kmodName = "ValDi.sys";
    std::string regName = "ValDi.reg";
    std::string infName = "ValDi.inf";
    std::string fullPath;

    int services = CheckService(0);

    if (services < 0)
        return -1;

    if (services == SERVICE_RUNNING)
    {
        PREVALDI_LOG("ValDi service is already running.\n");
        return 0;
    }

    if ((services != SERVICE_STOPPED) && (services > 0))
    {
        PREVALDI_LOG("ValDi service is not stopped!\nRestart the machine and rerun the deployment routine.\n");
        return -1;
    }

	/* Construct driver path based on installed windows OS versiion */
    std::string verName = GetMachineStringRegKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion", "ProductName");
    if (verName.find("Windows 10") != std::wstring::npos)
    {
#ifdef _WIN64
        drvPath += "";
#else
        drvPath += "";
#endif
    }
    else if (verName.find("Windows 8.1") != std::wstring::npos)
    {
#ifdef _WIN64
        drvPath += "";
#else
        drvPath += "";
#endif
    }
    else
    {
        lastMsg = "OS version not supported!\n";
        PREVALDI_LOG(lastMsg.c_str());
        return -1;
    }

	CHAR dummyPath[64];
	if (GetSystemWow64Directory(dummyPath, 64) == ERROR_CALL_NOT_IMPLEMENTED)
	{
		/* 32 bit windows OS - ValDi path */
	    kmodName = "ValDi.sys";
	    regName = "ValDi.reg";
	    infName = "ValDi.inf";
	}
	else
	{
		/* 64 bit windows OS - ValDi path */
	    kmodName = "x64\\ValDi64.sys";
	    regName = "x64\\ValDi64.reg";
	    infName = "x64\\ValDi64.inf";
	}

	/* Construct final command to be executed to install tracing module*/
    fullPath = drvPath + infName;
    std::string installCmd = "rundll32 syssetup, SetupInfObjectInstallAction DefaultInstall 128 ";
    installCmd += fullPath;
    system(installCmd.c_str());

    if (CheckService(SERVICE_RUNNING) == SERVICE_RUNNING)
    {
        lastMsg = "ValDi installed successfully.\n";
        PREVALDI_LOG(lastMsg.c_str());
        return 0;
    }

    return -1;
}

/**
* @brief			Method to remove kernel tracing module
*
* @return			0 = Success
*				   -1 = Failure
*/
int RemoveKernelTracingModule()
{
    int servs = CheckService(0);
	/* If ValDi service is present then proceed to remove it*/
    if (servs)
    {
        /* Remove previous installation.*/
        SC_HANDLE schSCManager;
        schSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
        if (schSCManager == NULL)
        {
            SHOW_ERROR;
            return -1;
        }

        SC_HANDLE serviceHandle = OpenService(schSCManager, "ValDi", SC_MANAGER_ALL_ACCESS);
        if (!DeleteService(serviceHandle))
        {
            SHOW_ERROR;
            CloseServiceHandle(schSCManager);
            return -1;
        }
        else
            printf("Service marked for removal.\nPlease reboot the machine.\n");

        CloseServiceHandle(serviceHandle);
        CloseServiceHandle(schSCManager);
    }
    
    return 0;
}