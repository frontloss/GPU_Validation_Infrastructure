﻿# ValDi
Display validation infrastructure

The ValDi project comprises four components:

**PreValDi** – utility for parsing tested module PDB symbol file to generate VSM dump required by the ValDI kernel module

**PostValDi** – postprocessor for ValDi log files

**ValDiTest** – simple test application presenting user<->kernel space communication

**ValDi kernel module** – validation kernel module 

