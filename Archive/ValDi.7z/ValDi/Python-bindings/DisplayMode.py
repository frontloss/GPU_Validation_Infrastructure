import os
import ctypes
import datetime

from ccdapi_header import *

def ModeStr(dm):
    text = str(dm.dmPelsWidth)+'x'+str(dm.dmPelsHeight)+'@'+str(dm.dmDisplayFrequency)
    if dm.dmDisplayFlags & DM_INTERLACED:
        text += 'I'
    if dm.dmBitsPerPel != 32:
        text += ','+str(dm.dmBitsPerPel)+'bpp'
    if dm.dmDisplayFixedOutput == DMDFO_STRETCH:
        text += ',STRETCH'
    if dm.dmDisplayFixedOutput == DMDFO_CENTER:
        text += ',CENTER'
    return text
    
def GetCurrentMode(deviceName):
    dm = DEVMODEA()
    dm.dmSize = ctypes.sizeof(dm)
    if ctypes.windll.user32.EnumDisplaySettingsA(deviceName, -1, ctypes.byref(dm)):
        return dm
    return None

def GetMode(deviceName, mode):
    dm = DEVMODEA()
    dm.dmSize = ctypes.sizeof(dm)
    mi = 0
    highestScore = 0
    bestDm = DEVMODEA()
    while ctypes.windll.user32.EnumDisplaySettingsA(deviceName, mi, ctypes.byref(dm)):
        if mode == 'maxPixelClock':
            score = dm.dmPelsWidth*dm.dmPelsHeight*dm.dmDisplayFrequency*dm.dmBitsPerPel+2-dm.dmDisplayFixedOutput
        elif mode == 'maxResolution':
            score = dm.dmPelsWidth*dm.dmPelsHeight+dm.dmDisplayFrequency+2-dm.dmDisplayFixedOutput
        elif mode == 'maxFrequency':
            score = 10000000*dm.dmDisplayFrequency+dm.dmPelsWidth*dm.dmPelsHeight
        else:
            score = (mode == ModeStr(dm) or mode == str(mi))
        if score > highestScore:
            highestScore = score
            pointer(bestDm)[0] = dm
        mi += 1
    
    if highestScore > 0:
        cm = GetCurrentMode(deviceName)
        copyFields = cm.dmFields & ~bestDm.dmFields
        if copyFields & DM_POSITION:
            bestDm.dmPositionX = cm.dmPositionX
            bestDm.dmPositionY = cm.dmPositionY
            bestDm.dmFields |= DM_POSITION
            copyFields &= ~DM_POSITION
        if copyFields & DM_DISPLAYFIXEDOUTPUT:
            #bestDm.dmDisplayFixedOutput = cm.dmDisplayFixedOutput
            bestDm.dmFields |= DM_DISPLAYFIXEDOUTPUT
            copyFields &= ~DM_DISPLAYFIXEDOUTPUT
        #print hex(copyFields)
        bestDm.dmDeviceName = cm.dmDeviceName
        return bestDm
    return None

def ShowModes(deviceName):
    dm = DEVMODEA()
    dm.dmSize = ctypes.sizeof(dm)
    mi = 0
    while ctypes.windll.user32.EnumDisplaySettingsA(deviceName, mi, ctypes.byref(dm)):
        print str(mi)+': '+ModeStr(dm)
        mi += 1

def ShowTopology(showModes):
    da = DISPLAY_DEVICEA()
    da.cb = ctypes.sizeof(da)
    ind = 0
    cnt = 0
    while ctypes.windll.user32.EnumDisplayDevicesA(None, ind, ctypes.byref(da), 0):
        if da.StateFlags & 1:
            cm = GetCurrentMode(da.DeviceName)
            text = da.DeviceName+': '+ModeStr(cm)
            if da.StateFlags & 4:
                text += ' (primary)'
            else:
                text += ' ('+str(cm.dmPositionX)+','+str(cm.dmPositionY)+')'
            print text
            for mode in ['maxPixelClock', 'maxResolution', 'maxFrequency']:
                print '  '+mode+' for: '+ModeStr(GetMode(da.DeviceName, mode))
            cnt += 1
            if showModes:
                ShowModes(da.DeviceName)
        ind += 1
    return cnt
    
def help():
    print sys.argv[0]+' -show | -mode <mode> [ -device <device>]'
    exit(1)

if __name__ == '__main__':
    showModes = 0
    argIndex = 1
    device = ''
    mode = ''

    while len(sys.argv) > argIndex:
        if len(sys.argv) > argIndex+1:
            if sys.argv[argIndex] == '-device':
                device = sys.argv[argIndex+1]
            elif sys.argv[argIndex] == '-mode':
                mode = sys.argv[argIndex+1]
            else:
                help()
            argIndex += 1
        elif sys.argv[argIndex] == '-show':
            showModes = 1
        else:
            help()
        argIndex += 1
    
    ShowTopology(showModes)
    if mode == '':
        exit(0)
    da = DISPLAY_DEVICEA()
    da.cb = ctypes.sizeof(da)
    ind = 0
    while ctypes.windll.user32.EnumDisplayDevicesA(None, ind, ctypes.byref(da), 0):
        ind += 1
        if device != '' and device != da.DeviceName and device != str(ind-1):
            continue
        if da.StateFlags & 1:
            cm = GetCurrentMode(da.DeviceName)
            mm = GetMode(da.DeviceName, mode)
            if mm is None:
                print 'Mode '+mode+' not found for '+da.DeviceName
                continue
            if ModeStr(cm) != ModeStr(mm):
                print 'Setting '+ModeStr(mm)+' for '+da.DeviceName
                for f in mm._fields_:
                    if getattr(cm, f[0]) != getattr(mm, f[0]):
                        print 'Changing '+f[0]+' from', getattr(cm, f[0]), 'to', getattr(mm, f[0])
                if ctypes.windll.user32.ChangeDisplaySettingsExA(da.DeviceName, ctypes.byref(mm), 0, 0, 0):
                    print 'ERROR'
