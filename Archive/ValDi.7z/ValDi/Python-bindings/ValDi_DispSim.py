import glob
import os
import sys
import ctypes

from ValDi_Base import *
from igdkmd64_stubs import  *
from ccdapi_header import *
from ValDi_DispGetData import *

class GfxStubSimClass(ValDi_BaseClass):
    
    ################################################################################################
    def __init__(self):
        if not self.enabledFramework:
            self.enableGfxValStubFramework()
            
        if not C_GVSTUB_FEATURE_DEV_SIM in self.enabledFeatures:
            if self.enableGfxValStubFeature(C_GVSTUB_FEATURE_DEV_SIM):
                raise Exception('GfxStubSim failed')
    
    ################################################################################################
    def getPortTypeForUID(self,  displayUID):
        listOfDisplays = self.enumDisplays()
        for i in listOfDisplays:
            if i[0] == displayUID:
                return i[1]
        
        return 0

    ################################################################################################
    def getFreeUIDForPort(self,  ePortType):
        
        portIsFree = 1
        firstUID = 0
        
        listOfDisplays = self.enumDisplays()
        for i in listOfDisplays:
            if i[1] == ePortType:
                if firstUID == 0:
                    firstUID = i[0]
                if i[2] == 1:
                    portIsFree = 0
                    break
        
        if portIsFree:
            return firstUID
        
        return 0

    ################################################################################################
    def cacheDPCDData(self, displayUID, transactionIndex, address, data):
        args = C_GVSTUB_DISPLAY_FEATURE_ARGS()
        args.stDisplayFeatureMetaData.ulVersion = C_GVSTUB_DISPLAY_FEATURE_ACCESS_VERSION
        args.stDisplayFeatureMetaData.ulSize = ctypes.sizeof(C_GVSTUB_META_DATA) + ctypes.sizeof(C_GVSTUB_DEV_SIM_CACHE_DPCD_DATA_ARGS)
        args.stDisplayFeatureMetaData.ulServiceType = C_GVSTUB_DEV_SIM_CACHE_DPCD_DATA
        args.u0.stDPCDInfo.ulDisplayUID = displayUID
        args.u0.stDPCDInfo.ulDPCDAddress = address
        args.u0.stDPCDInfo.ulSize = min(len(data),  C_GVSTUB_MAX_DPCD_DATA)
        
        DPCD_Data = (ctypes.c_ubyte*len(data))(*data)
        ctypes.memmove(ctypes.addressof(args.u0.stDPCDInfo.ucDPCDData),  ctypes.addressof(DPCD_Data),  args.u0.stDPCDInfo.ulSize)
        args.u0.stDPCDInfo.ulIndex = transactionIndex
        [errFlag,  args] = self.ValDiAPI.gfxValStub(args)
        if errFlag != 0:
            print('DPCD cache failed!\n')
            return -1
        
    ###############################################################################################    
    def patchDPCD(self,  displayUID):
        data = [0xFF, 0xFF, 0xFF]
        self.cacheDPCDData(displayUID, 1, 0x202, data)

        data = [0x0]
        self.cacheDPCDData(displayUID, 2, 0x101, data)
        self.cacheDPCDData(displayUID, 3, 0x200, data)
        self.cacheDPCDData(displayUID, 4, 0x206, data)
    
        data = [0xA4, 0x1F, 0xBC, 0x34, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
        self.cacheDPCDData(displayUID, 5, 0x10, data)

        data = [0x1]
        self.cacheDPCDData(displayUID, 6, 0x600, data)
        self.cacheDPCDData(displayUID, 7, 0x205, data)
    
    ###############################################################################################
    def plugToPort(self,  displayUID, ePortType, lowPowConnect,  EDID_file,  DPCD_file):
        args = C_GVSTUB_DISPLAY_FEATURE_ARGS()
        
        [errCode,  EDID_Data] = self.loadBinFile(EDID_file)
        if errCode != 0:
            print('EDID file read failed!\n')
            return -1
        portName = self.portTypeName(ePortType)
        m = re.search('C_GVSTUB_INTDP(.?)_PORT', portName)
        if m:
            [errCode,  DPCD_Data] = self.loadBinFile(DPCD_file, 14)
            if errCode != 0:
                print('DPCD file read failed!\n')
                return -1
            
            #cache DPCD
            if len(DPCD_Data) >= 14:
                self.cacheDPCDData(displayUID, 0, 0, DPCD_Data)
                self.patchDPCD(displayUID)
            else:
                print('DPCD file is too short!\n')
                return -1

        print 'Attaching '+EDID_file+' to port '+str(ePortType)+'('+portName+') with UID '+hex(displayUID)
        #attach display
        args.stDisplayFeatureMetaData.ulSize = ctypes.sizeof(C_GVSTUB_META_DATA) + ctypes.sizeof(C_GVSTUB_GET_SET_SIMULATE_DEVICE_ARGS)
        args.stDisplayFeatureMetaData.ulServiceType = C_GVSTUB_GET_SET_SIMULATE_DEVICE
        args.u0.stGetSetSimulateDevice.ulNumDevices = 1
        args.u0.stGetSetSimulateDevice.stDeviceInfo[0].OpType = C_GVSTUB_OP_SET
        args.u0.stGetSetSimulateDevice.stDeviceInfo[0].bAttach = 1
        args.u0.stGetSetSimulateDevice.stDeviceInfo[0].ulDisplayUID = displayUID
        args.u0.stGetSetSimulateDevice.stDeviceInfo[0].ulPortType = ePortType
        args.u0.stGetSetSimulateDevice.stDeviceInfo[0].bSimConnnectionInLowPower = lowPowConnect
        ctypes.memmove(args.u0.stGetSetSimulateDevice.stDeviceInfo[0].ucDisplayEdid,  EDID_Data,  ctypes.sizeof(EDID_Data))
        [errFlag,  args] = self.ValDiAPI.gfxValStub(args)
        if errFlag != 0:
            print('Set sim device failed!\n')
            return -1
            
        return 0
        
    ################################################################################################
    def unplugPort(self, displayUID, ePortType):
        args = C_GVSTUB_DISPLAY_FEATURE_ARGS()
        args.stDisplayFeatureMetaData.ulVersion = C_GVSTUB_DISPLAY_FEATURE_ACCESS_VERSION
        args.stDisplayFeatureMetaData.ulSize = ctypes.sizeof(C_GVSTUB_META_DATA) + ctypes.sizeof(C_GVSTUB_GET_SET_SIMULATE_DEVICE_ARGS)
        args.stDisplayFeatureMetaData.ulServiceType = C_GVSTUB_GET_SET_SIMULATE_DEVICE
        args.u0.stGetSetSimulateDevice.ulNumDevices = 1
        args.u0.stGetSetSimulateDevice.stDeviceInfo[0].OpType = C_GVSTUB_OP_SET
        args.u0.stGetSetSimulateDevice.stDeviceInfo[0].bAttach = 0
                
        args.u0.stGetSetSimulateDevice.stDeviceInfo[0].ulDisplayUID = displayUID
        args.u0.stGetSetSimulateDevice.stDeviceInfo[0].ulPortType = ePortType
        
        [errFlag,  args] = self.ValDiAPI.gfxValStub(args)
        if errFlag != 0:
            print('Set sim device failed!\n')
            return -1
        
        return 0

    ################################################################################################
    def ddiIndex(self, portType):
        portName = self.portTypeName(portType)
        m = re.search('C_GVSTUB_INTDP(.?)_PORT', portName)
        if m:
            return m.group(1)
        m = re.search('C_GVSTUB_DVO(.?)_PORT', portName)
        if m:
            return m.group(1)
        m = re.search('C_GVSTUB_INTHDMI(.?)_PORT', portName)
        if m:
            return m.group(1)
        return None
        
    ################################################################################################
    def isDDIInUse(self, portType):
        index = self.ddiIndex(portType)
        if index is None:
            return 0
        listOfDisplays = self.enumDisplays()
        for i in listOfDisplays:
            if i[2] == 1:
                if self.ddiIndex(i[1]) == index:
                    return 1
        return 0

    ################################################################################################
    def enumAttachedDisplays(self):
        # enumerate attached displays suitable for CRC testing
        # (skip virtual, audio capable and blacklisted) 
        listOfDisplays = []
        dispGetData = DispGetData_Class()
        for i in self.enumDisplays():
            if i[2] == 1:
                if i[1] == C_GVSTUB_TPV_PORT:
                    continue
                edid = dispGetData.getEDIDForUID(i[0])
                parsedEDID = dispGetData.parseEDID(edid)
                if 'audioSupported' in parsedEDID.keys():
                    if parsedEDID['audioSupported']:
                        # DDI CRC will be unpredictable
                        continue
                if 'id' in parsedEDID.keys():
                    if parsedEDID['id'] == 'CLB.2770.fitHeadless4k':
                        # this dongle is incorrectly detected as audio capable
                        continue
                listOfDisplays.append(i)
        return listOfDisplays
        
    ################################################################################################
    def showDisplayConfig(self, logLevel = 0):
        print 'Attached targets:'
        dispGetData = DispGetData_Class()
        listOfDisplays = self.enumDisplays()
        ports = dict()
        for i in listOfDisplays:
            if i[2] == 1:
                print ' Target: id: '+hex(i[0])+', port: '+str(i[1])+'('+self.portTypeName(i[1])+')'
                edid = dispGetData.getEDIDForUID(i[0])
                parsedEDID = dispGetData.parseEDID(edid, logLevel)
                if 'id' in parsedEDID.keys():
                    print '  Attached device: '+parsedEDID['id']
                    if 'audioSupported' in parsedEDID.keys():
                        if parsedEDID['audioSupported']:
                            print '  Audio capable device!'
            if i[1] in ports.keys():
                if i[2]:
                    ports[i[1]] = 1
            else:
                ports[i[1]] = i[2]
            if self.isDDIInUse(i[1]):
                ports[i[1]] = 1
        print 'Not attached ports:'
        for i in ports.keys():
            if not ports[i]:
                print ' '+self.portTypeName(i)+': '+(' '.join([hex(d[0]) for d in listOfDisplays if d[1] == i]))
        numPathArrayElements = ctypes.c_uint32()
        pNumPathArrayElements = ctypes.byref(numPathArrayElements)
        numModeInfoArrayElements = ctypes.c_uint32()
        pNumModeInfoArrayElements = ctypes.byref(numModeInfoArrayElements)

        errFlag = ctypes.windll.user32.GetDisplayConfigBufferSizes(QDC_ONLY_ACTIVE_PATHS, pNumPathArrayElements, pNumModeInfoArrayElements)
        if errFlag != 0:
            print 'GetDisplayConfigBufferSizes failed (error '+str(errFlag)+')!'
            return -1

        pPathInfoArray = (DISPLAYCONFIG_PATH_INFO * numPathArrayElements.value)()
        pModeInfoArray = (DISPLAYCONFIG_MODE_INFO * numModeInfoArrayElements.value)()

        errFlag = ctypes.windll.user32.QueryDisplayConfig(QDC_ONLY_ACTIVE_PATHS, pNumPathArrayElements, pPathInfoArray, pNumModeInfoArrayElements, pModeInfoArray, None)
        if errFlag != 0:
            print 'QueryDisplayConfig failed (error '+str(errFlag)+')!'
            return -1

        print 'Active paths:'
        for path in pPathInfoArray:
            print ' Target: id: '+hex(path.targetInfo.id)+', mode idx: '+str(path.targetInfo.modeInfoIdx) \
                +'; Source: id: '+str(path.sourceInfo.id)+', mode idx: '+str(path.sourceInfo.modeInfoIdx)
        print 'Modes:'    
        for modeIdx in range(len(pModeInfoArray)):
            if pModeInfoArray[modeIdx].infoType == 1:
                print ' '+str(modeIdx)+': source '+str(pModeInfoArray[modeIdx].id)+': ' \
                    +str(pModeInfoArray[modeIdx].mode.sourceMode.width)+'x'+str(pModeInfoArray[modeIdx].mode.sourceMode.height)
            else:
                print ' '+str(modeIdx)+': target '+hex(pModeInfoArray[modeIdx].id)+': ' \
                    +str(pModeInfoArray[modeIdx].mode.targetMode.targetVideoSignalInfo.activeSize.cx) \
                    +'x'+str(pModeInfoArray[modeIdx].mode.targetMode.targetVideoSignalInfo.activeSize.cy)
        return 0
                

    ################################################################################################
    def forceSingleDisplay(self, displayUID):
        errFlag = ctypes.windll.user32.SetDisplayConfig(0, None, 0, None, SDC_APPLY | SDC_TOPOLOGY_INTERNAL)
        if errFlag != 0:
            print 'SetDisplayConfig(SDC_TOPOLOGY_INTERNAL) failed (error '+str(errFlag)+')!'
            return -1
        if displayUID == 0:
            return
        errFlag = ctypes.windll.user32.SetDisplayConfig(0, None, 0, None, SDC_APPLY | SDC_TOPOLOGY_EXTEND)
        if errFlag != 0:
            print 'SetDisplayConfig(SDC_TOPOLOGY_EXTEND) failed (error '+str(errFlag)+')!'
            return -1

        numPathArrayElements = ctypes.c_uint32()
        pNumPathArrayElements = ctypes.byref(numPathArrayElements)
        numModeInfoArrayElements = ctypes.c_uint32()
        pNumModeInfoArrayElements = ctypes.byref(numModeInfoArrayElements)

        errFlag = ctypes.windll.user32.GetDisplayConfigBufferSizes(QDC_ONLY_ACTIVE_PATHS, pNumPathArrayElements, pNumModeInfoArrayElements)
        if errFlag != 0:
            print 'GetDisplayConfigBufferSizes failed (error '+str(errFlag)+')!'
            return -1

        pPathInfoArray = (DISPLAYCONFIG_PATH_INFO * numPathArrayElements.value)()
        pModeInfoArray = (DISPLAYCONFIG_MODE_INFO * numModeInfoArrayElements.value)()

        errFlag = ctypes.windll.user32.QueryDisplayConfig(QDC_ONLY_ACTIVE_PATHS, pNumPathArrayElements, pPathInfoArray, pNumModeInfoArrayElements, pModeInfoArray, None)
        if errFlag != 0:
            print 'QueryDisplayConfig failed (error '+str(errFlag)+')!'
            return -1
        # look for our displayUID
        found = 0
        cfgChanged = 0
        for path in pPathInfoArray:
            if path.targetInfo.id == displayUID:
                found = 1
                if pModeInfoArray[path.sourceInfo.modeInfoIdx].mode.sourceMode.position.x or pModeInfoArray[path.sourceInfo.modeInfoIdx].mode.sourceMode.position.y:
                    print 'Changing source display offset: ' \
                        +str(pModeInfoArray[path.sourceInfo.modeInfoIdx].mode.sourceMode.position.x)+','+str(pModeInfoArray[path.sourceInfo.modeInfoIdx].mode.sourceMode.position.y)+' to 0,0'
                    pModeInfoArray[path.sourceInfo.modeInfoIdx].mode.sourceMode.position.x = 0
                    pModeInfoArray[path.sourceInfo.modeInfoIdx].mode.sourceMode.position.y = 0
                    cfgChanged = 1
                if pModeInfoArray[path.sourceInfo.modeInfoIdx].mode.sourceMode.width != pModeInfoArray[path.targetInfo.modeInfoIdx].mode.targetMode.targetVideoSignalInfo.activeSize.cx\
                    or pModeInfoArray[path.sourceInfo.modeInfoIdx].mode.sourceMode.height != pModeInfoArray[path.targetInfo.modeInfoIdx].mode.targetMode.targetVideoSignalInfo.activeSize.cy:
                    print 'Changing source resolution ' \
                        +str(pModeInfoArray[path.sourceInfo.modeInfoIdx].mode.sourceMode.width)+'x'+str(pModeInfoArray[path.sourceInfo.modeInfoIdx].mode.sourceMode.height) \
                        +' to native target resolution '+str(pModeInfoArray[path.targetInfo.modeInfoIdx].mode.targetMode.targetVideoSignalInfo.activeSize.cx) \
                        +'x'+str(pModeInfoArray[path.targetInfo.modeInfoIdx].mode.targetMode.targetVideoSignalInfo.activeSize.cy)
                    pModeInfoArray[path.sourceInfo.modeInfoIdx].mode.sourceMode.width = pModeInfoArray[path.targetInfo.modeInfoIdx].mode.targetMode.targetVideoSignalInfo.activeSize.cx
                    pModeInfoArray[path.sourceInfo.modeInfoIdx].mode.sourceMode.height = pModeInfoArray[path.targetInfo.modeInfoIdx].mode.targetMode.targetVideoSignalInfo.activeSize.cy    
                    cfgChanged = 1
        if found:
            for pathIdx in range(len(pPathInfoArray)):
                if pPathInfoArray[pathIdx].targetInfo.id != displayUID:
                    print 'Disabling target '+hex(pPathInfoArray[pathIdx].targetInfo.id)
                    pPathInfoArray[pathIdx].flags = 0
                    cfgChanged = 1
            if cfgChanged:
                errFlag = ctypes.windll.user32.SetDisplayConfig(numPathArrayElements, pPathInfoArray, numModeInfoArrayElements, pModeInfoArray, SDC_APPLY | SDC_USE_SUPPLIED_DISPLAY_CONFIG)
                if errFlag != 0:
                    print 'SetDisplayConfig failed (error '+str(errFlag)+')!'
                    return -1
        return 0

    ################################################################################################
    def forceSingleSource(self):
        numPathArrayElements = ctypes.c_uint32()
        pNumPathArrayElements = ctypes.byref(numPathArrayElements)
        numModeInfoArrayElements = ctypes.c_uint32()
        pNumModeInfoArrayElements = ctypes.byref(numModeInfoArrayElements)

        errFlag = ctypes.windll.user32.GetDisplayConfigBufferSizes(QDC_ONLY_ACTIVE_PATHS, pNumPathArrayElements, pNumModeInfoArrayElements)
        if errFlag != 0:
            print 'GetDisplayConfigBufferSizes failed (error '+str(errFlag)+')!'
            return -1

        pPathInfoArray = (DISPLAYCONFIG_PATH_INFO * numPathArrayElements.value)()
        pModeInfoArray = (DISPLAYCONFIG_MODE_INFO * numModeInfoArrayElements.value)()

        errFlag = ctypes.windll.user32.QueryDisplayConfig(QDC_ONLY_ACTIVE_PATHS, pNumPathArrayElements, pPathInfoArray, pNumModeInfoArrayElements, pModeInfoArray, None)
        if errFlag != 0:
            print 'QueryDisplayConfig failed (error '+str(errFlag)+')!'
            return -1
        sourceId = -1
        modeIdx = -1
        cfgChanged = 0
        for pathIdx in range(len(pPathInfoArray)):
            if sourceId == -1:
                sourceId = pPathInfoArray[pathIdx].sourceInfo.id
                modeIdx = pPathInfoArray[pathIdx].sourceInfo.modeInfoIdx
            elif pPathInfoArray[pathIdx].sourceInfo.id != sourceId:
                pPathInfoArray[pathIdx].sourceInfo.id = sourceId
                pPathInfoArray[pathIdx].sourceInfo.modeInfoIdx = modeIdx
                print 'Changing source id to '+str(sourceId)+' for path '+str(pathIdx)
                cfgChanged = 1
        if cfgChanged:
            errFlag = ctypes.windll.user32.SetDisplayConfig(numPathArrayElements, pPathInfoArray, numModeInfoArrayElements, pModeInfoArray, SDC_APPLY | SDC_USE_SUPPLIED_DISPLAY_CONFIG)
            if errFlag != 0:
                print 'SetDisplayConfig failed (error '+str(errFlag)+')!'
                return -1
        return 0

    ################################################################################################
    def forceSourceResolution(self, maxWidth, maxHeight):
        numPathArrayElements = ctypes.c_uint32()
        pNumPathArrayElements = ctypes.byref(numPathArrayElements)
        numModeInfoArrayElements = ctypes.c_uint32()
        pNumModeInfoArrayElements = ctypes.byref(numModeInfoArrayElements)

        errFlag = ctypes.windll.user32.GetDisplayConfigBufferSizes(QDC_ONLY_ACTIVE_PATHS, pNumPathArrayElements, pNumModeInfoArrayElements)
        if errFlag != 0:
            print 'GetDisplayConfigBufferSizes failed (error '+str(errFlag)+')!'
            return -1

        pPathInfoArray = (DISPLAYCONFIG_PATH_INFO * numPathArrayElements.value)()
        pModeInfoArray = (DISPLAYCONFIG_MODE_INFO * numModeInfoArrayElements.value)()

        errFlag = ctypes.windll.user32.QueryDisplayConfig(QDC_ONLY_ACTIVE_PATHS, pNumPathArrayElements, pPathInfoArray, pNumModeInfoArrayElements, pModeInfoArray, None)
        if errFlag != 0:
            print 'QueryDisplayConfig failed (error '+str(errFlag)+')!'
            return -1
        if maxWidth == 0:
            # look for max resolution
            maxWidth = 0
            maxHeight = 0
            for mode in pModeInfoArray:
                if mode.infoType == 2:
                    if mode.mode.targetMode.targetVideoSignalInfo.activeSize.cx*mode.mode.targetMode.targetVideoSignalInfo.activeSize.cy > maxWidth*maxHeight:
                        maxWidth = mode.mode.targetMode.targetVideoSignalInfo.activeSize.cx
                        maxHeight = mode.mode.targetMode.targetVideoSignalInfo.activeSize.cy
        print 'Forcing source resolution: '+str(maxWidth)+'x'+str(maxHeight)
        for mode in pModeInfoArray:
            if mode.infoType == 1:
                if mode.mode.sourceMode.width != maxWidth or mode.mode.sourceMode.height != maxHeight:
                    mode.mode.sourceMode.width = maxWidth
                    mode.mode.sourceMode.height = maxHeight
                    errFlag = ctypes.windll.user32.SetDisplayConfig(numPathArrayElements, pPathInfoArray, numModeInfoArrayElements, pModeInfoArray, SDC_APPLY | SDC_USE_SUPPLIED_DISPLAY_CONFIG)
                    if errFlag != 0:
                        print 'SetDisplayConfig failed (error '+str(errFlag)+')!'
                        return -1
                    break
        return 0

####################################################################################################
##EXAMPLE###########################################################################################
####################################################################################################
if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == 'disable':
        #clear all previous config
        b = ValDi_BaseClass()
        b.disableGfxValStubFeature(C_GVSTUB_FEATURE_DEV_SIM)
        sys.exit(0)
        
    GfxStubSim = GfxStubSimClass()
    GfxStubSim.showDisplayConfig()
    if len(sys.argv) > 1 and sys.argv[1] == 'show':
        sys.exit(0)

    forceSD = 0
    forceCLONE = 0
    forceMaxRes = 0
    forceEXTEND = 0
    requiredDisplayNum = 0
    edidFiles = ''
    argIndex = 1

    if len(sys.argv) > argIndex and sys.argv[argIndex] == 'SD':
        forceSD = 1
        argIndex += 1
    if len(sys.argv) > argIndex and sys.argv[argIndex] == 'CLONE':
        forceCLONE = 1
        argIndex += 1
    if len(sys.argv) > argIndex and sys.argv[argIndex] == 'CLONE_MAX':
        forceCLONE = 1
        forceMaxRes = 1
        argIndex += 1
    if len(sys.argv) > argIndex and sys.argv[argIndex] == 'EXTEND':
        forceEXTEND = 1
        argIndex += 1
    if len(sys.argv) > argIndex and sys.argv[argIndex] == '1':
        requiredDisplayNum = 1
        argIndex += 1
    if len(sys.argv) > argIndex and sys.argv[argIndex] == '2':
        requiredDisplayNum = 2
        argIndex += 1
    if len(sys.argv) > argIndex and sys.argv[argIndex] == '3':
        requiredDisplayNum = 3
        argIndex += 1

    if len(sys.argv) > argIndex:
        edidFiles = sys.argv[argIndex]
        argIndex += 1
    freePortUID = 0
    requestedUID = 0
    if len(sys.argv) > argIndex:
        requestedUID = int(sys.argv[argIndex], 0)
        argIndex += 1

    if (requiredDisplayNum > 0
        and requiredDisplayNum <= len(GfxStubSim.enumAttachedDisplays())):
        print 'Required number of displays ('+str(requiredDisplayNum) \
              +') already reached ('+str(len(GfxStubSim.enumAttachedDisplays()))+')'
    elif len(edidFiles) > 0:
        for edidFile in glob.glob(edidFiles):
            name,ext = os.path.splitext(edidFile)
            if os.path.isfile(name+'_DPCD.bin'):
                testPorts = [C_GVSTUB_INTDPA_PORT, C_GVSTUB_INTDPB_PORT, C_GVSTUB_INTDPC_PORT, C_GVSTUB_INTDPD_PORT, C_GVSTUB_INTDPE_PORT]
            else:
                testPorts = [C_GVSTUB_DVOA_PORT, C_GVSTUB_DVOB_PORT, C_GVSTUB_DVOC_PORT, C_GVSTUB_DVOD_PORT]
            freePortUID = 0
            portType = 0
            if requestedUID > 0:
                freePortUID = requestedUID
                portType = GfxStubSim.getPortTypeForUID(requestedUID)
                GfxStubSim.plugToPort(freePortUID, portType, 0,  edidFile,  name+'_DPCD.bin')
                time.sleep(1)
                GfxStubSim.showDisplayConfig()
                if GfxStubSim.getFreeUIDForPort(portType) != 0:
                    print ' Display UID still not attached!'
                    GfxStubSim.unplugPort(freePortUID, portType)
            else:
                for p in testPorts:
                    freePortUID = GfxStubSim.getFreeUIDForPort(p)
                    if freePortUID > 0 and not GfxStubSim.isDDIInUse(p):
                        portType = p
                        GfxStubSim.plugToPort(freePortUID, portType, 0,  edidFile,  name+'_DPCD.bin')
                        time.sleep(1)
                        if GfxStubSim.getFreeUIDForPort(portType) == 0:
                            GfxStubSim.showDisplayConfig()
                            break
                        else:
                            print 'Display UID still not attached! - looking for another port' 
                            GfxStubSim.unplugPort(freePortUID, portType)
            if freePortUID == 0:
                print 'Free port not available for '+edidFile
            else:
                break
        if freePortUID == 0:
            print 'Display not attached!'
            exit(1)

    if forceSD:
        print 'Forcing single display with UID '+hex(freePortUID)
        GfxStubSim.forceSingleDisplay(freePortUID)
        GfxStubSim.showDisplayConfig()
    elif forceCLONE:
        print 'Forcing CLONE for all targets'
        errFlag = ctypes.windll.user32.SetDisplayConfig(0, None, 0, None, SDC_APPLY | SDC_TOPOLOGY_CLONE)
        if errFlag != 0:
            print 'SetDisplayConfig(SDC_TOPOLOGY_CLONE) failed (error '+str(errFlag)+')!'
        GfxStubSim.forceSingleSource()
        if forceMaxRes:
            GfxStubSim.forceSourceResolution(0, 0)
        GfxStubSim.showDisplayConfig()
    elif forceEXTEND:
        print 'Forcing EXTEND for all targets'
        errFlag = ctypes.windll.user32.SetDisplayConfig(0, None, 0, None, SDC_APPLY | SDC_TOPOLOGY_EXTEND)
        if errFlag != 0:
            print 'SetDisplayConfig(SDC_TOPOLOGY_EXTEND) failed (error '+str(errFlag)+')!'
        GfxStubSim.showDisplayConfig()
