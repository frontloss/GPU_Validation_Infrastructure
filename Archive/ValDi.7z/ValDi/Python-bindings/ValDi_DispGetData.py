from ValDi_Base import *
from igdkmd64_stubs import  *
import os
import sys

dpAuxChannels = [4,  1,  2,  3]

class DispGetData_Class(ValDi_BaseClass):
    
    binPath = '.'
    
    ################################################################################################
    def __init__(self):
        if not self.enabledFramework:
            self.enableGfxValStubFramework()
    
    ################################################################################################
    def setStorePath(self,  path):
        self.binPath = path

    ################################################################################################
    def getEDIDForUID(self,  displayUID):
        edid = []
        args = C_GVSTUB_DISPLAY_FEATURE_ARGS()
    
        args.stDisplayFeatureMetaData.ulSize = ctypes.sizeof(C_GVSTUB_META_DATA) + ctypes.sizeof( C_GVSTUB_GET_EDID_ARGS)
        args.stDisplayFeatureMetaData.ulServiceType = C_GVSTUB_GET_EDID
    
        args.u0.stEDID.ulDisplayUID = displayUID
    
        args.stDisplayFeatureMetaData.ulStatus = 0
        bN = 0
        while args.stDisplayFeatureMetaData.ulStatus == C_GVSTUB_DISPLAY_FEATURE_STATUS_SUCCESS:
            args.u0.stEDID.ulEdidBlockNum = bN
            bN +=1
            [errFlag,  args]  = self.ValDiAPI.gfxValStub(args)
            if args.stDisplayFeatureMetaData.ulStatus == C_GVSTUB_DISPLAY_FEATURE_STATUS_SUCCESS:
                edid.append(args.u0.stEDID.ucEdidData)
        return edid        
    
    ################################################################################################
    def dtdToString(self, data):
        #print ''.join(['{:02X} '.format(i) for i in data])
        pixelClock = (data[0] | (data[1] << 8))*10000.0
        width = data[2]+((data[4]&0xf0) << 4)
        blankWidth = data[3]+((data[4]&0x0f) << 8)
        height = data[5] +((data[7]&0xf0) << 4)
        blankHeight = data[6] +((data[7]&0x0f) << 8)
        result = str(width)+'x'+str(height)
        pixelsPerFrame = (width+blankWidth)*(height+blankHeight)
        if pixelsPerFrame:
            result += '@'+str(round(pixelClock/pixelsPerFrame, 2))+'Hz'
        return result

    ################################################################################################
    def parseEDID(self,  edid, logLevel = 0):
        #print edid
        parsedEDID = dict()
        for bi in range(len(edid)):
            if logLevel:
                print ' Block #'+str(bi)
            #print ''.join(['{:02X} '.format(i) for i in edid[bi]])
            if bi == 0:
                manID = (edid[bi][8] << 8) | edid[bi][9]
                parsedEDID['manufacturer'] = chr(ord('A')-1+((manID >> 10)&0x1f))+chr(ord('A')-1+((manID >> 5)&0x1f))+chr(ord('A')-1+(manID&0x1f))
                parsedEDID['product'] = '{:02X}{:02X}'.format(edid[bi][11], edid[bi][10])
                parsedEDID['id'] = parsedEDID['manufacturer']+'.'+parsedEDID['product']
                if logLevel:
                    print '  Manufacturer: '+parsedEDID['manufacturer']
                    print '  Product: '+parsedEDID['product']
                    print '  EDID version: '+str(edid[bi][18])+'.'+str(edid[bi][19])
                    print '  Descriptors:'
                for i in range(4):
                    name = ''
                    for c in edid[bi][54+18*i+5:54+18*i+18]:
                        if c == 10:
                            break;
                        name += chr(c)
                    if edid[bi][54+18*i] or edid[bi][54+18*i+1]:
                        if logLevel:
                            print '   Detailed Timing Descriptor ('+self.dtdToString(edid[bi][54+18*i:54+18*(i+1)])+')'
                    else:
                        if edid[bi][54+18*i+3] == 0xfc:
                            if logLevel:
                                print '   Monitor name: '+name
                            parsedEDID['monitorName'] = name
                        if edid[bi][54+18*i+3] == 0xfe:
                            if logLevel:
                                print '   Text: '+name
                        if edid[bi][54+18*i+3] == 0xff:
                            if logLevel:
                                print '   Monitor serial number: '+name
                if logLevel:
                    print '  Extensions: '+str(edid[bi][126])
            else:
                if logLevel:
                    print '  Extension tag: '+str(edid[bi][0])
                if edid[bi][0] == 2:
                    parsedEDID['audioSupported'] = (edid[bi][3]&0x40) != 0
                    if logLevel:
                        print '  Version: '+str(edid[bi][1])
                        print '  Caps: '+hex(edid[bi][3])
                        print '  Audio supported: '+str(parsedEDID['audioSupported'])
                        i = 4
                        while i < edid[bi][2]:
                            dataType = edid[bi][i] >> 5
                            dataLen = edid[bi][i] & 0x1f
                            if dataType == 1:
                                print '  Audio Data Block: '+str(dataLen)+'B: '+''.join(['{:02X} '.format(ii) for ii in edid[bi][i+1:i+1+dataLen]])
                                print '   Audio format '+str((edid[bi][i+1]>>3)&0xf)+', '+str((edid[bi][i+1]&0x3)+1)+' channels'
                            elif dataType == 2:
                                print '  Video Data Block: '+str(dataLen)+'B: '+''.join(['{:02X} '.format(ii) for ii in edid[bi][i+1:i+1+dataLen]])
                            elif dataType == 3:
                                print '  Vendor Specific Data Block: '+str(dataLen)+'B: '+''.join(['{:02X} '.format(ii) for ii in edid[bi][i+1:i+1+dataLen]])
                            elif dataType == 4:
                                print '  Speaker Allocation Data Block: '+str(dataLen)+'B: '+''.join(['{:02X} '.format(ii) for ii in edid[bi][i+1:i+1+dataLen]])
                            else:
                                print '  Data Block Type '+str(dataType)+': '+str(dataLen)+'B: '+''.join(['{:02X} '.format(ii) for ii in edid[bi][i+1:i+1+dataLen]])
                            i += 1+dataLen
                        print '  Descriptors:'
                        for i in range(edid[bi][2], 109, 18):
                            if edid[bi][i] == 0 and edid[bi][i+1] == 0:
                                break
                            print '   Detailed Timing Descriptor ('+self.dtdToString(edid[bi][i:i+18])+')'
        if 'monitorName' in parsedEDID.keys():
            parsedEDID['id'] += '.'+parsedEDID['monitorName'].replace(' ', '_')
        return parsedEDID

    ################################################################################################
    def storeEDIDForUID(self,  displayUID):

        edid = self.getEDIDForUID(displayUID)
        print 'EDID for UID '+hex(displayUID)+':'
        parsedEDID = self.parseEDID(edid, 2)
        if 'id' in parsedEDID.keys():
            edidFileName = parsedEDID['id']
            edidFileName += '.EDID'
        
            edidFileName = os.path.join(self.binPath,  edidFileName)
            if os.path.exists(edidFileName):
                print 'File already exists: '+edidFileName
                return parsedEDID['id']
            edidFile = open(edidFileName,  'wb')
    
            for block in edid:
                edidFile.write(block)
        
            edidFile.close()
            print 'Saved as: '+edidFileName
            return parsedEDID['id']
    
    ################################################################################################
    def getDPCDForPortType(self,  ePortType, len = 7*256, address = 0):
        
        if ePortType < C_GVSTUB_INTDPA_PORT or ePortType > C_GVSTUB_INTDPD_PORT:
            return
            
        readChunkSize = 16
        DPCDBuffer = (ctypes.c_ubyte*len)(0)
        offset = 0
        auxAccessArgs = C_GMCH_AUX_ARGUMENTS()
        auxAccessArgs.eDisplayPort = ePortType
        auxAccessArgs.eOperation = C_GMCH_AUX_READ
        auxAccessArgs.ucAuxChannelType = dpAuxChannels[ ePortType- C_GVSTUB_INTDPA_PORT]
        auxAccessArgs.pucBuffer = ctypes.addressof(DPCDBuffer)
        auxAccessArgs.ucBufferSize = readChunkSize
        while len > 0:
            auxAccessArgs.pucBuffer = ctypes.addressof(DPCDBuffer)+offset
            auxAccessArgs.ucBufferSize = readChunkSize if len > readChunkSize else len
            auxAccessArgs.ulDPCDAddress = address+offset
            [errFlag,  auxAccessArgs]  = self.ValDiAPI.AUXAccess(auxAccessArgs)
            len -= auxAccessArgs.ucBufferSize
            offset += auxAccessArgs.ucBufferSize

        return DPCDBuffer
    
    ################################################################################################
    def printDPCD(self, DPCDBuffer):
        for offset in range(0, len(DPCDBuffer), 16):
            sb = DPCDBuffer[offset:offset+16]
            if any(sb):
                print ' {:03X}: '.format(offset)+''.join(['{:02X} '.format(i) for i in sb])
        print ' DPCD_REV: '+str(DPCDBuffer[0]>>4)+'.'+str(DPCDBuffer[0]&0xf)
        print ' LINK_RATE: MAX: '+str(DPCDBuffer[1]*0.27)+'Gbps'+', SET: '+str(DPCDBuffer[0x100]*0.27)+'Gbps'
        print ' LANE_COUNT: MAX: '+str(DPCDBuffer[2]&0x1f)+', SET: '+str(DPCDBuffer[0x101]&0x1f) \
              +('' if len(DPCDBuffer) < 0x204 else ', STATUS mask: {:02X}{:02X}: '.format(DPCDBuffer[0x203], DPCDBuffer[0x202])) 
        if DPCDBuffer[2]&0x80:
            print ' ENHANCED_FRAME_CAP supported'
        if DPCDBuffer[5]&1:
            print ' DOWNSTREAMPORT_PRESENT:'
            for i in range(DPCDBuffer[7]&0xf):
                pt = DPCDBuffer[0x80+i]&0x7
                portType = 'Unknown'
                if pt == 0: portType = 'DP'
                elif pt == 1: portType = 'Analog'
                elif pt == 2: portType = 'DVI'
                elif pt == 3: portType = 'HDMI'
                print '  PORT'+str(i)+': '+portType
    
    ################################################################################################
    def storeDPCDForPortType(self,  ePortType, displayID):
        
        if ePortType < C_GVSTUB_INTDPA_PORT or ePortType > C_GVSTUB_INTDPD_PORT:
            return

        DPCDBuffer = self.getDPCDForPortType(ePortType)
        print 'DPCD for port '+self.portTypeName(ePortType)+':'
        self.printDPCD(DPCDBuffer)

        dpcdFileName = displayID
        dpcdFileName += '_DPCD.bin'

        dpcdFileName = os.path.join(self.binPath,  dpcdFileName)
        if os.path.exists(dpcdFileName):
            print 'File already exists: '+dpcdFileName
            return
        dpcdFile = open(dpcdFileName,  'wb')
        dpcdFile.write(DPCDBuffer)
        dpcdFile.close()
        print 'Saved as: '+dpcdFileName
    
    ################################################################################################
    def storeDataForCurrentConfig(self):
        
        listOfDisplays = self.enumDisplays()
        if not listOfDisplays is None:
            for d in listOfDisplays:
                if d[2] == 1:
                    id = self.storeEDIDForUID(d[0])
                    self.storeDPCDForPortType(d[1], id)
                
                
                
####################################################################################################
##EXAMPLE
####################################################################################################
if __name__ == '__main__':
    dispGetData = DispGetData_Class()
    dispGetData.setStorePath('c:\\ValDi\\bin')
    if len(sys.argv) > 1:
        edidFileName = sys.argv[1]
        edid = []
        print 'EDID:'
        with open(edidFileName,  'rb') as edidFile:
            while True:
                buffer = edidFile.read(128)
                if len(buffer) != 128:
                    break
                edid.append((ctypes.c_ubyte*128).from_buffer_copy(buffer))
        edidFile.close()
        dispGetData.parseEDID(edid, 2)
        name,ext = os.path.splitext(edidFileName)
        dpcdFileName = name+'_DPCD.bin'
        if os.path.isfile(dpcdFileName):
            print 'DPCD:'
            with open(dpcdFileName,  'rb') as dpcdFile:
                buffer = dpcdFile.read()
                dispGetData.printDPCD((ctypes.c_ubyte*len(buffer)).from_buffer_copy(buffer))
    else:
        dispGetData.storeDataForCurrentConfig()
    
