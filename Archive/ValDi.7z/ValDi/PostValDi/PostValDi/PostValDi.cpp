// PostValDi.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <Windows.h>
#include <stdio.h>
#include <string.h>
#include <string>
#include <vector>
#include <map>
#include <fstream>
#include <sstream>
#include <conio.h>


#pragma comment(lib, "version.lib")

using namespace std;

// MAX_PIPES value includes future extensions and pipe for virtual display
#define MAX_PIPES        5
#define MAX_PORTS        5
#define TIMESTAMP_INDEX  0
#define BASE_KEY_INDEX   3
#define MARKER_KEY_INDEX 0

#define PLOG(...)\
    {\
        printf(__VA_ARGS__);\
        fprintf(outLog, __VA_ARGS__);\
    }

typedef struct
{
    unsigned long long crcCount;
    unsigned long long presented;
    unsigned long lastPortCRC;
} CRC_STAT, *PCRC_STAT;


typedef struct
{
    unsigned long maxT, minT;
    unsigned long long cumT;
    unsigned long long attempts;
}MMIO_STATS, *PMMIO_STATS;

///////////////////////////////////////////////////////////////////////////////////////////////////
std::string GetVersionInfo(const char *field)
{
    std::string strResult;

    char szModPath[MAX_PATH];
    szModPath[0] = '\0';
    GetModuleFileName(NULL, szModPath, sizeof(szModPath));
    DWORD dwHandle;
    DWORD dwSize = GetFileVersionInfoSize(szModPath, &dwHandle);

    if (dwSize > 0)
    {
        BYTE* pbBuf = static_cast<BYTE*>(alloca(dwSize));
        if (GetFileVersionInfo(szModPath, dwHandle, dwSize, pbBuf))
        {
            UINT uiSize;
            BYTE* lpb;
            if (VerQueryValue(pbBuf,
                "\\VarFileInfo\\Translation",
                (void**)&lpb,
                &uiSize))
            {
                WORD* lpw = (WORD*)lpb;
                char strQuery[MAX_PATH];
                sprintf(strQuery, "\\StringFileInfo\\%04x%04x\\%s", lpw[0], lpw[1], field);
                if (VerQueryValue(pbBuf,
                    strQuery,
                    (void**)&lpb,
                    &uiSize) && uiSize > 0)
                {
                    strResult = (LPCSTR)lpb;
                }
            }
        }
    }

    return strResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void printHelp()
{
    std::string vinfo = GetVersionInfo("ProductVersion");
#ifdef _WIN64
    printf("\nPostValDi 64b %s [%s]\n", vinfo.c_str(), __TIMESTAMP__);
#else
    printf("\nPostValDi 32b %s [%s]\n", vinfo.c_str(), __TIMESTAMP__);
#endif

    printf("PostValDi - pproc for ValDi logs.\n");
    printf("Command line arguments:\n");
    printf("-h                  prints this help\n");
    printf("<path_to_log_file>  path to log file\n\n");
}

///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
int learningFlag = 1;
int testingFlag = 1;

#define MASK_NOT_SET 0
#define MASK_SET 1
#define MASK_RESET_ON_NEXT_CHECK -2
int testPipeMask[MAX_PIPES] = { MASK_NOT_SET };
int testPortMask[MAX_PORTS] = { MASK_NOT_SET };


unsigned int numOfCorruptedCRC = 0;
unsigned int numOfPipePortCRCMismatch = 0;
unsigned int numOfMissingCRC = 0;
unsigned int numOfErrorStatusFlag = 0;
unsigned int numOfUnderruns = 0;
unsigned int numOfLogErrors = 0;

unsigned long lastPortCRC[MAX_PORTS] = { 0 };

string currentTestName;

FILE* outLog;

map<unsigned long long, CRC_STAT> crcBank[MAX_PIPES];
map<unsigned long, unsigned long> mmioReg;
map<unsigned long long, MMIO_STATS> mmioWriteStats;
map<unsigned long long, MMIO_STATS> mmioReadStats;

//-------------------------------------------------------------------------------------------------
void split(const string &s, const char* delim, vector<string> & v){
    char * dup = strdup(s.c_str());
    char * token = strtok(dup, delim);
    v.clear();
    while (token != NULL){
        v.push_back(string(token));
        token = strtok(NULL, delim);
    }
    free(dup);
}

//-------------------------------------------------------------------------------------------------
void dumpMMIO()
{
    stringstream stream;

    map<unsigned long, unsigned long>::const_iterator it;

    if (currentTestName.size())
        fprintf(outLog, "Test name: %s\n", currentTestName.c_str());

    if (mmioReg.size() == 0)
    {
        fprintf(outLog, "(Empty MMIO list)");
    }
    else
    {
        fprintf(outLog, "-MMIO Registers dump-----------------------------------------------------\n");
        for (it = mmioReg.begin(); it != mmioReg.end(); ++it)
        {
            fprintf(outLog, "%X:%X  ", it->first, it->second);
        }
        fprintf(outLog, "\n-------------------------------------------------------------------------\n");
    }

    fprintf(outLog, "\n");
}

//-------------------------------------------------------------------------------------------------
void updatePipeCRC(unsigned long long timestamp, unsigned long pipeId, unsigned long portId, std::string crc_str, unsigned long validFlag)
{
    unsigned long crc = 0xffffffff;

    if (crc_str.length())
        crc = stoul(crc_str, 0, 16);

    if ((!validFlag) && (crc == 0xffffffff))
    {
        fprintf(outLog, "[%llu] Missing PIPE_%u CRC on SYNC \n", timestamp, pipeId);
        dumpMMIO();
        numOfMissingCRC++;
    }


    if (learningFlag)
    {
        map<unsigned long long, CRC_STAT>::iterator it = crcBank[pipeId].find(crc);
        if (it != crcBank[pipeId].end())
        {
            it->second.crcCount++;
            if (it->second.lastPortCRC != lastPortCRC[portId])
            {
                //printf("Warning different pipe CRC for already registered port CRC.\n");
            }
        }
        else
        {
            CRC_STAT crcStat = { 0 };
            crcStat.crcCount = 1;
            crcStat.lastPortCRC = lastPortCRC[portId];
            crcStat.presented = 0;
            crcBank[pipeId].insert(pair<unsigned long, CRC_STAT>(crc, crcStat));
        }
    }

    if (testingFlag)
    {
        map<unsigned long long, CRC_STAT>::iterator it = crcBank[pipeId].find(crc);
        if (it == crcBank[pipeId].end())
        {
            fprintf(outLog, "[%llu] Corrupted PIPE_%u CRC: %X\n", timestamp, pipeId, crc);
            dumpMMIO();
            numOfCorruptedCRC++;
        }

        if ((it->second.lastPortCRC != lastPortCRC[portId]) && (lastPortCRC[portId]))
        {
            fprintf(outLog, "[%llu] PIPE_%u -> PORT_%u CRC mismatch: [%X -> %X (%X)]\n", timestamp, pipeId, portId, crc, lastPortCRC[pipeId], it->second.lastPortCRC);
            dumpMMIO();
            numOfPipePortCRCMismatch++;
            it->second.lastPortCRC = lastPortCRC[portId];
        }
        else
        {
            it->second.presented++;
        }
    
    }
}

//-------------------------------------------------------------------------------------------------
void updatePortCRC(unsigned long long timestamp, unsigned long portId, std::string crc_str, unsigned long validFlag, std::string dbuff_str)
{
    unsigned long crc = stoul(crc_str, 0, 16);
    unsigned long dbuf = stoul(dbuff_str, 0, 16);

    if (testingFlag)
    {
        if ((!validFlag) && (crc == 0xffffffff))
        {
            fprintf(outLog, "[%llu] Missing PORT_%u CRC on SYNC \n", timestamp, portId);
            dumpMMIO();
            numOfMissingCRC++;
        }
        else
            lastPortCRC[portId] = crc;

        if (dbuf & 0x80000000)
        {
            fprintf(outLog, "[%llu] DBUF overwrite flag set \n", timestamp);
            dumpMMIO();
            numOfErrorStatusFlag++;
        }
    }
}

//-------------------------------------------------------------------------------------------------
void updatePipePortCRC(unsigned long long timestamp, std::string pipeId_str, std::string pipeCRC_str, std::string portId_str, std::string portCRC_str, std::string validFlag_str, std::string dbuff_str)
{
    unsigned long pipeId = stoul(pipeId_str, 0, 16);
    unsigned long portId = stoul(portId_str, 0, 16);
    unsigned long validFlag = stoul(validFlag_str, 0, 16);

    if (testPipeMask[pipeId] >= MASK_SET)
        return;

    if (testPipeMask[pipeId] == MASK_RESET_ON_NEXT_CHECK)
    {
        if (validFlag)
           testPipeMask[pipeId] = MASK_NOT_SET;

        return;
    }

    //@TODO: Seems that pipe is not yet attached to DP - ignore for now...
    if (portId > MAX_PORTS)
        return;

    updatePortCRC(timestamp, portId, portCRC_str, validFlag, dbuff_str);
    updatePipeCRC(timestamp, pipeId, portId, pipeCRC_str, validFlag);
}

//-------------------------------------------------------------------------------------------------
void updateMMIO(std::string offset_str, std::string value_str, unsigned int _offset)
{
    unsigned long offset = stoul(offset_str, 0, 16) + _offset;
    unsigned long value = stoul(value_str, 0, 16);

    mmioReg.insert(pair<unsigned long, unsigned long>(offset, value));
}

//-------------------------------------------------------------------------------------------------
void updateMMIOWriteTimings(std::string delta_str, std::string offset_str, int items = 0)
{
    unsigned long delta = stoul(delta_str, 0, 10);
    unsigned long offset = stoul(offset_str, 0, 16);

    unsigned long long combined_offset = ((unsigned long long)items << 32);
    combined_offset |= offset;

    map<unsigned long long, MMIO_STATS>::iterator it = mmioWriteStats.find(combined_offset);
    if (it != mmioWriteStats.end())
    {
        it->second.attempts++;
        it->second.cumT += delta;
        it->second.maxT = (delta > it->second.maxT) ? delta : it->second.maxT;
        it->second.minT = (delta < it->second.minT) ? delta : it->second.minT;
    }
    else
    {
        MMIO_STATS mstats;
        mstats.attempts = 1;
        mstats.cumT = delta;
        mstats.maxT = delta;
        mstats.minT = delta;
        mmioWriteStats.insert(pair<unsigned long long, MMIO_STATS>(combined_offset, mstats));
    }
}

//-------------------------------------------------------------------------------------------------
void updateMMIOReadTimings(std::string delta_str, std::string offset_str, int items = 0)
{
    unsigned long delta = stoul(delta_str, 0, 10);
    unsigned long offset = stoul(offset_str, 0, 16);

    unsigned long long combined_offset = ((unsigned long long)items << 32);
    combined_offset |= offset;

    map<unsigned long long, MMIO_STATS>::iterator it = mmioReadStats.find(combined_offset);
    if (it != mmioReadStats.end())
    {
        it->second.attempts++;
        it->second.cumT += delta;
        it->second.maxT = (delta > it->second.maxT) ? delta : it->second.maxT;
        it->second.minT = (delta < it->second.minT) ? delta : it->second.minT;
    }
    else
    {
        MMIO_STATS mstats;
        mstats.attempts = 1;
        mstats.cumT = delta;
        mstats.maxT = delta;
        mstats.minT = delta;
        mmioReadStats.insert(pair<unsigned long long, MMIO_STATS>(combined_offset, mstats));
    }
}

//-------------------------------------------------------------------------------------------------
int filterException(int code, PEXCEPTION_POINTERS ex) {

    PLOG("Parsing error - exception (0x%X)\n", code);
    return EXCEPTION_EXECUTE_HANDLER;
}


int parseFile(const char* fpath, const char* foutpath)
{
    std::ifstream ifs(fpath);
    std::vector<std::string> lineItems;
    std::string line;
    int i;
    long long curr, total;
    float pupdate, lupdate = 0.0f;

    crcBank[0].clear();
    crcBank[1].clear();
    crcBank[2].clear();

    mmioReg.clear();

    if (!ifs.is_open())
    {
        printf("Could not open the input log file.\n");
        return -1;
    }


    outLog = fopen(foutpath, "w");

    if (!outLog)
    {
        ifs.close();
        printf("Could not open the output log file.\n");
        return -1;
    }


    ifs.seekg(0, std::ios::end);
    total = ifs.tellg();
    ifs.seekg(0, std::ios::beg);

    //@TODO: Only direct write/read MMIO are parsed.
    //       Masked, bit-ops to be added.


    __try
    {

        while (std::getline(ifs, line))
        {
            // skip empty lines:
            if (line.empty())
                continue;

            curr = ifs.tellg();
            pupdate = (float)curr;
            pupdate /= total;
            pupdate *= 100;

            if (pupdate - lupdate > 1.0f)
            {
                lupdate = pupdate;
                printf("%3.1f%%                                                              \r", lupdate);
            }

            split(line, "; \n", lineItems);

            if (lineItems.size() <= 1)
            {
                if (lineItems[MARKER_KEY_INDEX] == "#TEST_WORKLOAD_PHASE_START")
                    testingFlag = 1;
                else if (lineItems[MARKER_KEY_INDEX] == "#TEST_WORKLOAD_PHASE_END")
                testingFlag = 0;
                else if (lineItems[MARKER_KEY_INDEX] == "#DUMP_MMIO")
                {
                    unsigned long long timestamp = stoull(lineItems[TIMESTAMP_INDEX], 0, 10);
                    fprintf(outLog, "[%llu] On demand MMIO dump.\n", timestamp);
                    dumpMMIO();
                }
                else if (lineItems[MARKER_KEY_INDEX] == "#MIXED_MODE_TESTING_START")
                {
                    testingFlag = learningFlag = 1;
                }
                else if (lineItems[MARKER_KEY_INDEX] == "#MIXED_MODE_TESTING_END")
                {
                    testingFlag = learningFlag = 0;
                }
                else if (lineItems[MARKER_KEY_INDEX] == "!LOG_BUFF_OVERFLOW")
                {
                    numOfLogErrors++;
                }
            }
            else if (lineItems.size() <= 2)
            {
                if (lineItems[MARKER_KEY_INDEX] == "#REFERENCE_CRC_COLLECTING_PHASE_START")
                    learningFlag = 1;
                else if (lineItems[MARKER_KEY_INDEX] == "#REFERENCE_CRC_COLLECTING_PHASE_END")
                {
                    map<unsigned long long, CRC_STAT>::const_iterator it;

                    for (i = 0; i < MAX_PIPES; i++)
                    {
                        if (crcBank[i].size())
                        {
                            PLOG("Uniqe CRCs (%u) for PIPE_%u:\n", crcBank[i].size(), i);
                            for (it = crcBank[i].begin(); it != crcBank[i].end(); ++it)
                                printf("[%lu]", it->second);
                            printf("\n");
                        }
                    }

                    learningFlag = 0;
                }
                

            }
            else if (lineItems.size() <= 4)
            {

            }
            //Other regular patterns----------------------
            else if (lineItems.size() <= 6)
            {
                if (lineItems[BASE_KEY_INDEX] == ">>SETMODE")
                {
                    unsigned long pipeId = stoul(lineItems[BASE_KEY_INDEX + 1], 0, 10);
                    _ASSERT(pipeId < MAX_PIPES);
                    if (pipeId < MAX_PIPES)
                    {
                        if (testPipeMask[pipeId] > 0)
                            testPipeMask[pipeId] += MASK_SET;
                        else
                            testPipeMask[pipeId] = MASK_SET;
                    }
                }
                else if (lineItems[BASE_KEY_INDEX] == "<<SETMODE")
                {
                    unsigned long pipeId = stoul(lineItems[BASE_KEY_INDEX + 1], 0, 10);
                    _ASSERT(pipeId < MAX_PIPES);
                    if (pipeId < MAX_PIPES)
                    {
                        if (testPipeMask[pipeId] > 0)
                            testPipeMask[pipeId] -= MASK_SET;

                        if (testPipeMask[pipeId] == 0)
                            testPipeMask[pipeId] = MASK_RESET_ON_NEXT_CHECK;

                        crcBank[pipeId].clear();
                    }
                }
                else if (lineItems[BASE_KEY_INDEX] == "!PIPE_UND")
                {
                    unsigned long pipeId = stoul(lineItems[BASE_KEY_INDEX + 1], 0, 10);
                    _ASSERT(pipeId < MAX_PIPES);
                    if (pipeId < MAX_PIPES)
                    {
                        if (testPipeMask[pipeId] == MASK_NOT_SET)
                        {
                            unsigned long long timestamp = stoull(lineItems[TIMESTAMP_INDEX], 0, 10);
                            fprintf(outLog, "[%llu] PIPE_%u Underrun \n", timestamp, pipeId);
                            dumpMMIO();
                            numOfUnderruns++;
                        }
                    }
                }
                else if (lineItems[BASE_KEY_INDEX] == "!FIFO_UND")
                {
                    unsigned long pipeId = stoul(lineItems[BASE_KEY_INDEX + 1], 0, 10);
                    _ASSERT(pipeId < MAX_PIPES);
                    if (pipeId < MAX_PIPES)
                    {
                        if (testPipeMask[pipeId] == MASK_NOT_SET)
                        {
                            unsigned long long timestamp = stoull(lineItems[TIMESTAMP_INDEX], 0, 10);
                            fprintf(outLog, "[%llu] FIFO PIPE_%u Underrun %c\n", timestamp, pipeId);
                            dumpMMIO();
                            numOfUnderruns++;
                        }
                    }
                }

                if (lineItems[BASE_KEY_INDEX] == "BLANK_PIPE")
                {
                    unsigned long pipeId = stoul(lineItems[BASE_KEY_INDEX + 1], 0, 10);
                    unsigned long makeVisible = stoul(lineItems[BASE_KEY_INDEX + 2], 0, 10);

                    _ASSERT(pipeId < MAX_PIPES);
                    if (pipeId < MAX_PIPES)
                    {
                        if (makeVisible)
                        {
                            if (testPipeMask[pipeId] > 0)
                                testPipeMask[pipeId] -= MASK_SET;

                            if (testPipeMask[pipeId] == 0)
                                testPipeMask[pipeId] = MASK_RESET_ON_NEXT_CHECK;

                            crcBank[pipeId].clear();
                        }
                        else
                        {
                            if (testPipeMask[pipeId] > 0)
                                testPipeMask[pipeId] += MASK_SET;
                            else
                                testPipeMask[pipeId] = MASK_SET;
                        }
                    }
                }
                /*
                else if (lineItems[BASE_KEY_INDEX] == "PIPECRC")
                {
                    unsigned long pipeId = stoul(lineItems[BASE_KEY_INDEX + 1], 0, 10);
                    unsigned long long timestamp = stoull(lineItems[TIMESTAMP_INDEX], 0, 10);
                    updatePipeCRC(timestamp, pipeId, lineItems[BASE_KEY_INDEX + 2], 1);
                }
                */
                else if ((lineItems[BASE_KEY_INDEX] == "W") ||
                    (lineItems[BASE_KEY_INDEX] == "R"))
                {
                    updateMMIO(lineItems[BASE_KEY_INDEX + 1], lineItems[BASE_KEY_INDEX + 2], 0);
                }

            }
            else if (lineItems.size() <= 8)
            {

                if (lineItems[BASE_KEY_INDEX] == "PORTCRC")
                {
                    unsigned long portId = stoul(lineItems[BASE_KEY_INDEX + 1], 0, 10);
                    unsigned long validFlag = stoul(lineItems[BASE_KEY_INDEX + 3], 0, 10);
                    unsigned long long timestamp = stoull(lineItems[TIMESTAMP_INDEX], 0, 10);
                    updatePortCRC(timestamp, portId, lineItems[BASE_KEY_INDEX + 2], validFlag, lineItems[BASE_KEY_INDEX + 4]);
                }
                else if (lineItems[BASE_KEY_INDEX] == "^W")
                {
                    updateMMIOWriteTimings(lineItems[BASE_KEY_INDEX + 1], lineItems[BASE_KEY_INDEX + 2]);
                }
                else if (lineItems[BASE_KEY_INDEX] == "^R")
                {
                    updateMMIOReadTimings(lineItems[BASE_KEY_INDEX + 1], lineItems[BASE_KEY_INDEX + 2]);
                }

            }
            else if (lineItems.size() <= 10)
            {

                if (lineItems[BASE_KEY_INDEX] == "PIPEPORTCRC")
                {
                    unsigned long long timestamp = stoull(lineItems[TIMESTAMP_INDEX], 0, 10);
                    updatePipePortCRC(timestamp, lineItems[BASE_KEY_INDEX + 1], lineItems[BASE_KEY_INDEX + 2], lineItems[BASE_KEY_INDEX + 3], lineItems[BASE_KEY_INDEX + 4], lineItems[BASE_KEY_INDEX + 5], lineItems[BASE_KEY_INDEX + 6]);
                }
                else if (lineItems[BASE_KEY_INDEX] == "!DROPPED_DPC_CRC")
                {
                    unsigned long pipeId = stoul(lineItems[BASE_KEY_INDEX + 1], 0, 10);
                    
                    if (testPipeMask[pipeId] == MASK_NOT_SET)
                        numOfLogErrors++;
                }

            }



            //Variable length (>4)------------------------
            if (lineItems.size() > 4)
            {
                if (lineItems[MARKER_KEY_INDEX] == "#TEST_NAME")
                {
                    currentTestName = "";
                    for (int c = MARKER_KEY_INDEX + 1; c < lineItems.size(); c++)
                        currentTestName += lineItems[c] + " ";
                }
                else if ((lineItems[BASE_KEY_INDEX] == "WD") ||
                    (lineItems[BASE_KEY_INDEX] == "RD"))
                {
                    int items = (int)lineItems.size() - 6;
                    for (int c = 0; c < items; c++)
                        updateMMIO(lineItems[BASE_KEY_INDEX + 1], lineItems[BASE_KEY_INDEX + 2 + c], c);
                }
                else if (lineItems[BASE_KEY_INDEX] == "^WD")
                {
                    int items = (int)lineItems.size() - 7;
                    updateMMIOWriteTimings(lineItems[BASE_KEY_INDEX + 1], lineItems[BASE_KEY_INDEX + 2], items);
                }
                else if (lineItems[BASE_KEY_INDEX] == "^RD")
                {
                    int items = (int)lineItems.size() - 7;
                    updateMMIOReadTimings(lineItems[BASE_KEY_INDEX + 1], lineItems[BASE_KEY_INDEX + 2], items);
                }
            }
            

        }
        
        printf("100%%                          \n", lupdate);
        
        //print summary
        PLOG("\n====================================\n");
        //PLOG("Invalid CRCs :               %u\n", numOfCorruptedCRC);
        PLOG("Missing CRCs on SYNC INT:    %u\n", numOfMissingCRC);
        PLOG("Pipe/port CRC mismatch :     %u\n", numOfPipePortCRCMismatch);
        PLOG("Error status flags set :     %u\n", numOfErrorStatusFlag);
        PLOG("Underrun INT:                %u\n", numOfUnderruns);
        PLOG("Log errors:                  %u\n", numOfLogErrors);
        PLOG("---------------------------------------\n");
        PLOG("Total issues:                %u\n",
            numOfMissingCRC +
            numOfPipePortCRCMismatch +
            numOfErrorStatusFlag +
            numOfUnderruns +
            numOfLogErrors
            );

        if (mmioReadStats.size() > 0)
        {
            PLOG("\n=[MMIO READ TIMINGS]================\n");
            PLOG("[OFFSET(items)]     [ATTEMPTS]        [MAX]        [CUM]        [MIN]\n");
            map<unsigned long long, MMIO_STATS>::const_iterator it;
            for (it = mmioReadStats.begin(); it != mmioReadStats.end(); it++)
            {
                unsigned long offset = (unsigned long)(it->first & 0xFFFFFFFF);
                unsigned long items = (unsigned long)(it->first >> 32);

                if (items)
                    PLOG("%8X(%u)        %10u   %10u   %10llu   %10u\n", offset, items, it->second.attempts, it->second.maxT, (it->second.cumT / it->second.attempts), it->second.minT)
                else
                    PLOG("%8X            %10u   %10u   %10llu   %10u\n", offset, it->second.attempts, it->second.maxT, it->second.cumT, it->second.minT);
            }
            PLOG("====================================\n");
        }

        if (mmioReadStats.size() > 0)
        {
            PLOG("\n=[MMIO WRITE TIMINGS]===============\n");
            PLOG("[OFFSET(items)]     [ATTEMPTS]        [MAX]        [CUM]        [MIN]\n");
            map<unsigned long long, MMIO_STATS>::const_iterator it;
            for (it = mmioWriteStats.begin(); it != mmioWriteStats.end(); it++)
            {
                unsigned long offset = (unsigned long)(it->first & 0xFFFFFFFF);
                unsigned long items = (unsigned long)(it->first >> 32);

                if (items)
                    PLOG("%8X(%u)        %10u   %10u   %10llu   %10u\n", offset, items, it->second.attempts, it->second.maxT, it->second.cumT, it->second.minT)
                else
                    PLOG("%8X            %10u   %10u   %10llu   %10u\n", offset, it->second.attempts, it->second.maxT, it->second.cumT, it->second.minT);
            }
            PLOG("====================================\n");
        }


    }
    __except (filterException(GetExceptionCode(), GetExceptionInformation()))
    {
        PLOG("Faulty line: [%s]", line.c_str());
        return -1;
    }

    return 0;

}

///////////////////////////////////////////////////////////////////////////////////////////////////
int main(int argc, char* argv[])
{
    int currArg = 1;
    int r = 0;

    if (argc < 2)
    {
        printHelp();
        return 0;
    }

    while (currArg < argc)
    {
        if (!strcmp(argv[currArg], "-h"))
        {
            printHelp();
            currArg++;
        }
        else
        {
            printf("Processing...\n");
            
            std::string outFName = argv[currArg];
            outFName += ".out";
            
            r = parseFile(argv[currArg], outFName.c_str());
            
            if (r < 0)
            {
                printf("Unsuccessful log file processing.\n");
            }
            currArg++;
        }
    }

    return r;
}