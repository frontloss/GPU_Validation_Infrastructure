#include "vHelpers.h"
#include "..\TalkToValdi\TalkToValDi.h"
#include <Realtimeapiset.h>


#include <Windows.h>
#include <powrprof.h>
#pragma comment(lib, "PowrProf.lib")

/*
///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
CCRCResults* CCRCResults::s_instance = NULL;

VOID CCRCResults::sync()
{
    DWORD currentTick = GetTickCount();
    while (currentTick > lastRead)
        Sleep(50);
}

//////////////////////////////////////////////////////////////////////////////////////////////////
int CCRCResults::getUniquePipeCRCList(ULONG portId, std::map<ULONG, CRC_stats> &crcList, ULONGLONG &intCnt)
{
    int res = 0;

    EnterCriticalSection(&CriticalSection);
    if (portId < MAX_DPORTS)
        crcList = pipeCRCData[portId];
    else
        res = -1;
    
    intCnt = vint[portId];
    LeaveCriticalSection(&CriticalSection);

    return res;
}


//////////////////////////////////////////////////////////////////////////////////////////////////
void CCRCResults::clearPipeCRCList(ULONG portId)
{
    EnterCriticalSection(&CriticalSection);
    if (portId < MAX_DPORTS)
        pipeCRCData[portId].clear();
    LeaveCriticalSection(&CriticalSection);
}

//////////////////////////////////////////////////////////////////////////////////////////////////

DWORD WINAPI CCRCResults_thread(LPVOID lpParam)
{
    unsigned int i;
    int portId;
    CCRCResults* myInstance = (CCRCResults*)lpParam;
    std::map<ULONG, CRC_stats>::iterator im;

    sCRCData* pBufferedCRCData = &myInstance->bufferedCRCData;

    while (!myInstance->killme_flag)
    {
        if (!ValDi_GetCRCData(pBufferedCRCData))
        {
            EnterCriticalSection(&myInstance->CriticalSection);
            myInstance->recordsRead += pBufferedCRCData->index;
            for (i = 0; i < pBufferedCRCData->index; i++)
            {	
                portId = pBufferedCRCData->buffer[i].portId;
                
                _ASSERT(portId < MAX_DPORTS);
                    
                im = myInstance->pipeCRCData[portId].find(pBufferedCRCData->buffer[i].CRC);

                if (im != myInstance->pipeCRCData[portId].end())
                {
                    im->second.count++;
                    if (im->second.lastTimeStamp < pBufferedCRCData->buffer[i].timeStamp)
                        im->second.lastTimeStamp = pBufferedCRCData->buffer[i].timeStamp;
                }
                else
                {
                    CRC_stats s = { 0 };
                    s.count++;
                    s.lastTimeStamp = pBufferedCRCData->buffer[i].timeStamp;
                    myInstance->pipeCRCData[portId].insert(std::pair<ULONG, CRC_stats>(pBufferedCRCData->buffer[i].CRC, s));
                }
            }

            LeaveCriticalSection(&myInstance->CriticalSection);
        }

        myInstance->lastRead = GetTickCount();
        Sleep(100);
    };

    delete myInstance;
    CCRCResults::s_instance = NULL;

    return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////

CCRCResults::CCRCResults()
{
    if (s_instance)
        return;

    InitializeCriticalSection(&CriticalSection);

    killme_flag = 0;

    CreateThread(NULL, 0, CCRCResults_thread, this, 0, NULL); 
    sync();
};

///////////////////////////////////////////////////////////////////////////////////////////////////
CCRCResults::~CCRCResults()
{
    DeleteCriticalSection(&CriticalSection);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
*/


///////////////////////////////////////////////////////////////////////////////////////////////////


    void   clearAllPipeCRCList();
    void   clearPipeCRCList(ULONG pipeID);
    int    flushCRCBuffer();
    int    waitForTimeStamp(ULONGLONG timestamp, ULONG timeout);
    int    getUniquePipeCRCList(ULONG pipeID, std::vector<ULONG, CRC_stats> &crcList);




///////////////////////////////////////////////////////////////////////////////////////////////////
void sendKey()
{
    INPUT in[1];
    KEYBDINPUT kb;
    kb.wVk = VK_HOME;
    in[0].type = INPUT_KEYBOARD;
    in[0].ki = kb;
    SendInput(1, in, sizeof(in));
}

///////////////////////////////////////////////////////////////////////////////////////////////////
int dimmDisplay()
{
    SendNotifyMessage(HWND_BROADCAST, WM_SYSCOMMAND, SC_MONITORPOWER, (LPARAM)1);
    return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
int sleepDisplaysFor(unsigned long msecs)
{
    SendNotifyMessage(HWND_BROADCAST, WM_SYSCOMMAND, SC_MONITORPOWER, (LPARAM)2);
    Sleep(msecs);
    sendKey();
    return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
int sleepOSFor(unsigned msecs)
{
    
    HANDLE wTimer = CreateWaitableTimer(NULL, FALSE, NULL);
    if (!wTimer)
        return -1;

    LARGE_INTEGER li;
    li.QuadPart = msecs * -10000LL;

    if (!SetWaitableTimer(wTimer, &li, 0, NULL, NULL, TRUE))
        return -1;

    SetSuspendState(FALSE, TRUE, FALSE);
    WaitForSingleObject(wTimer, INFINITE);
    sendKey();
    CloseHandle(wTimer);
    return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
std::string GetVersionInfo(const char *field)
{
    std::string strResult;

    char szModPath[MAX_PATH];
    szModPath[0] = '\0';
    GetModuleFileName(NULL, szModPath, sizeof(szModPath));
    DWORD dwHandle;
    DWORD dwSize = GetFileVersionInfoSize(szModPath, &dwHandle);

    if (dwSize > 0)
    {
        BYTE* pbBuf = static_cast<BYTE*>(alloca(dwSize));
        if (GetFileVersionInfo(szModPath, dwHandle, dwSize, pbBuf))
        {
            UINT uiSize;
            BYTE* lpb;
            if (VerQueryValue(pbBuf,
                "\\VarFileInfo\\Translation",
                (void**)&lpb,
                &uiSize))
            {
                WORD* lpw = (WORD*)lpb;
                char strQuery[MAX_PATH];
                sprintf(strQuery, "\\StringFileInfo\\%04x%04x\\%s", lpw[0], lpw[1], field);
                if (VerQueryValue(pbBuf,
                    strQuery,
                    (void**)&lpb,
                    &uiSize) && uiSize > 0)
                {
                    strResult = (LPCSTR)lpb;
                }
            }
        }
    }

    return strResult;
}
