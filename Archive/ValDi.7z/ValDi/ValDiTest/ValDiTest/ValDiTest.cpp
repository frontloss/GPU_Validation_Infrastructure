#include <Windows.h>
#include "..\TalkToValdi\TalkToValDi.h"
#include <stdio.h>
#include <conio.h>
#include "igdkmd_intc.h"
#include "vHelpers.h"

#define PRINTTOSTD

#ifdef PRINTTOSTD
#define PRINTF(...)\
   {\
       printf(__VA_ARGS__);\
   }
#else
#define PRINTF(...)\
      {\
       char tmpBuff[4096];\
       sprintf(tmpBuff, __VA_ARGS__);\
       OutputDebugStringA(tmpBuff);\
      }
#endif

#define _SECOND ((_int64) 10000000)
#define _MINUTE (60 * _SECOND)
#define _HOUR   (60 * _MINUTE)
#define _DAY    (24 * _HOUR)

#define LOW_POWER_STATE_TRUE	TRUE
#define LOW_POWER_STATE_FALSE	FALSE

#define CALL_VALDI(__fName__, ...) \
{\
    if(ValDi_##__fName(__VA_ARGS__))\
    fprintf(err, "[%s] failed: %s\n", ValDi_GetLastErrorStr());\
    exit(-1);\
}\

#pragma comment(lib, "version.lib")

const char* PIPE_NAMES[] = {
    "PIPE_A",
    "PIPE_B",
    "PIPE_C"
};

const char* PORT_NAMES[] = {
    "NULL_PORT_TYPE",
    "ANALOG_PORT",
    "DVOA_PORT",
    "DVOB_PORT",
    "DVOC_PORT",
    "DVOD_PORT",
    "LVDS_PORT",
    "INTDPE_PORT",
    "INTHDMIB_PORT",
    "INTHDMIC_PORT",
    "INTHDMID_PORT",
    "INT_DVI_PORT",
    "INTDPA_PORT",
    "INTDPB_PORT",
    "INTDPC_PORT",
    "INTDPD_PORT",
    "TPV_PORT",
    "INTMIPIA_PORT",
    "INTMIPIC_PORT",
    "WIGIG_PORT",
    "DVOF_PORT",
    "INTHDMIF_PORT",
    "INTDPF_PORT",
    "MAX_PORTS"
};

///////////////////////////////////////////////////////////////////////////////////////////////////
int printHelp()
{
    std::string vinfo = GetVersionInfo("ProductVersion");
#ifdef _WIN64
    printf("\nValDiTest 64b %s [%s]\n", vinfo.c_str(), __TIMESTAMP__);
#else
    printf("\nValDiTest 32b %s [%s]\n", vinfo.c_str(), __TIMESTAMP__);
#endif
    printf("\n");
    printf("Usage: ValDiTest.exe [flags]\n");
    printf("List of flags:\n");
    printf("-h                         Displays command line help.\n");
    printf("-finalize                  Finalizes tracing.\n");
    printf("-suspend                   Suspends tracing.\n");
    printf("-resume                    Resumes tracing.\n");
    printf("-restart                   Restarts tracing.\n");
    printf("-insmark <marker>          Inserts text marker.\n");
    printf("-state                     Retrives ValDi state flag.\n");
    printf("\n");

    return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
int main(int argc, CHAR* argv[])
{

    CONSOLE_CURSOR_INFO CURSOR;
    ULONG ValDiState;
    PIPE_MAPS pipeMaps;
    CURSOR.dwSize = 1;
    CURSOR.bVisible = FALSE;
    SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &CURSOR);

    if (argc > 1)
    {

        int retVal = 0;

        if (!strcmp(argv[1], "-finalize"))
            retVal = ValDi_FinalizeTracing();
        
        else if (!strcmp(argv[1], "-suspend"))
            retVal = ValDi_SuspendTracing();

        else if (!strcmp(argv[1], "-resume"))
            retVal =  ValDi_ResumeTracing();

        else if (!strcmp(argv[1], "-restart"))
            retVal = ValDi_RestartTracing();

        else if (!strcmp(argv[1], "-insmark"))
        {

            int res = 0;
            if (argc <= 2)
            {
                printf("No marker string.\n");
                return -1;
            }

            std::string marker;
            for (int i = 2; i < argc; i++)
            {
                marker += argv[i];
                marker += " ";
            }

            retVal = ValDi_InsertTxtMarker(marker.c_str());
        }

        else if (!strcmp(argv[1], "-state"))
            retVal = ValDi_GetState();

        else if (!strcmp(argv[1], "-h"))
            retVal = printHelp();

        if (retVal != 0)
        {
            printf("%s\n", ValDi_GetLastErrorStr());
        }

        return retVal;
  
    }

    printf("No cmd line arguments - switching to interactive mode.\n");
    printf("Info: run with '-h' to display cmd line help.\n\n");

    
    if (ValDi_GetState() == 0xFFFFFFFF)
    {
        printf("Connecting to ValDi... (run 'PreValDi -i' to install)");
        while (ValDi_GetState() == 0xFFFFFFFF)
        {
            Sleep(50);
        }
        printf("\n");
    }

    ValDi_InsertTxtMarker("Launching ValDiTest user app.");

#ifdef PRINTTOSTD
    printf("Ouput on STD...\n");
#else
    printf("Ouput on DebugOutput...\n");
#endif
    printf("[s] - suspend tracing\n");
    printf("[r] - resume tracing\n");
    printf("[f] - finalize trace file\n");
    printf("[z] - restart tracing\n");
    printf("[m] - sleep monitor for 5 sec.\n");
    printf("[p] - sleep OS for 5 sec.\n");
    printf("[x] - exit\n");
    printf("\n");
    printf("[4] - insert MIXED_MODE_TESTING_START marker\n");
    printf("[5] - insert MIXED_MODE_TESTING_END marker\n");
    printf("[6] - insert REFERENCE_CRC_COLLECTING_PHASE_START marker\n");
    printf("[7] - insert REFERENCE_CRC_COLLECTING_PHASE_END marker\n");
    printf("[8] - insert TEST_WORKLOAD_PHASE_START marker\n");
    printf("[9] - insert TEST_WORKLOAD_PHASE_END marker\n");
    printf("[0] - insert DUMP_MMIO marker\n");
	printf("[a] - Plug/UnPlug port A\n");
	printf("[b] - Plug/UnPlug port B\n");
	printf("[c] - Plug/UnPlug port C\n");
	printf("[d] - Plug/UnPlug port D\n");
	printf("[e] - Plug/UnPlug port E\n");
    printf("\n");

    printf("---------------------------------------------------------------\n");

    VALDI_HOOK_STATS hStats = { 0 };
    CHAR msgBuffer[MESSAGE_SLOTS*MESSAGE_SIZE];


    while (1)
    {

        if (_kbhit())
        {
            char key = _getch();

            PRINTF("                                                                                                           \r");

            if (key == 's')
            {
                ValDi_SuspendTracing();
                PRINTF(">Tracing suspended.\n");
            }
            else if (key == 'r')
            {
                ValDi_ResumeTracing();
                PRINTF(">Tracing resumed.\n");
            }
            else if (key == 'f')
            {
                ValDi_FinalizeTracing();
                PRINTF(">Tracing finalized.\n");
            }
            else if (key == 'z')
            {
                ValDi_RestartTracing();
                PRINTF(">Tracing restarted.\n");
            }
            else if (key == 'm')
            {
                sleepDisplaysFor(5000);
            }
            else if (key == 'p')
            {
                sleepOSFor(5000);
            }
            else if (key == 'x')
                break;			
            else if (key == '4')
            {
                ValDi_InsertTxtMarker("MIXED_MODE_TESTING_START");
                PRINTF(">Marker inserted.\n");
            }
            else if (key == '5')
            {
                ValDi_InsertTxtMarker("MIXED_MODE_TESTING_END");
                PRINTF(">Marker inserted.\n");
            }
            else if (key == '6')
            {
                ValDi_InsertTxtMarker("REFERENCE_CRC_COLLECTING_PHASE_START");
                PRINTF(">Marker inserted.\n");
            }
            else if (key == '7')
            {
                ValDi_InsertTxtMarker("REFERENCE_CRC_COLLECTING_PHASE_END");
                PRINTF(">Marker inserted.\n");
            }
            else if (key == '8')
            {
                ValDi_InsertTxtMarker("TEST_WORKLOAD_PHASE_START");
                PRINTF(">Marker inserted.\n");
            }
            else if (key == '9')
            {
                ValDi_InsertTxtMarker("TEST_WORKLOAD_PHASE_END");
                PRINTF(">Marker inserted.\n");
            }
            else if (key == '0')
            {
                ValDi_InsertTxtMarker("DUMP_MMIO");
                PRINTF(">Marker inserted.\n");
            }
			else if (key == 'a')
			{
				ValDi_HotPlugUnPlug(PORTA_ID, LOW_POWER_STATE_FALSE);
			}
			else if (key == 'b')
			{
				ValDi_HotPlugUnPlug(PORTB_ID, LOW_POWER_STATE_FALSE);
			}
			else if (key == 'c')
			{
				ValDi_HotPlugUnPlug(PORTC_ID, LOW_POWER_STATE_FALSE);
			}
			else if (key == 'd')
			{
				ValDi_HotPlugUnPlug(PORTD_ID, LOW_POWER_STATE_FALSE);
			}
			else if (key == 'e')
			{
				ValDi_HotPlugUnPlug(PORTE_ID, LOW_POWER_STATE_FALSE);
			}

        }

        ValDiState = ValDi_GetState();
        ValDi_GetHookStats(&hStats);
        ValDi_GetPipeToPortMapping(&pipeMaps);
        
        msgBuffer[0] = '\0';
        ValDi_GetMessages(msgBuffer, MESSAGE_SLOTS*MESSAGE_SIZE);
        if (strlen(msgBuffer))
        {
            PRINTF("                                                                                        \r");
            PRINTF("%s", msgBuffer);
        }

        PRINTF("|State [0x%X] |Pipe2Port [%s][%s][%s] |SwSync [%llu][%llu][%llu]             \r", 
            ValDiState,
            PORT_NAMES[pipeMaps.pipeToPortConfig[0] + 1],
            PORT_NAMES[pipeMaps.pipeToPortConfig[1] + 1],
            PORT_NAMES[pipeMaps.pipeToPortConfig[2] + 1],
            hStats.softSyncs[0], 
            hStats.softSyncs[1], 
            hStats.softSyncs[2]
            );
        
        Sleep(500);
    }

    ValDi_InsertTxtMarker("Exiting ValDiTest user app.");

    printf("\nExiting...\n");

    return 0;
}
