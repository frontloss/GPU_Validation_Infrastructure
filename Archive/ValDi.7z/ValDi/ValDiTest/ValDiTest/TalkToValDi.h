#pragma once
#include <Windows.h>

#define MAX_PIPES  3
#define MAX_DPORTS 4

///////////////////////////////////////////////////////////////////////////////////////////////////
//GLOBALS SECTION
///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
#define BSOD_ON_PIPE_UNDERRUN              0x4

#define VALDISTATE_UNINITIALIZED           0x00
#define VALDISTATE_RUNNING                 0x01
#define VALDISTATE_DEMISED                 0x02

#define VALDISTATE_TRACING_FLAG            0x08

#define VALDISTATE_BUFFER_OVERFLOW         0x10

#define MAX_MMIOWRITE_RECORDS              4096

typedef struct _PIPE_MAPS
{
    ULONG pipeToPortConfig[MAX_PIPES];
}PIPE_MAPS, *PPIPE_MAPS;


///////////////////////////////////////////////////////////////////////////////////////////////////
//VDS STRUCTS
///////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct _SYMBOLINFO
{
    CHAR        shortName[64];
    ULONG       size;
    ULONGLONG   rva;
}SYMBOLINFO, *PSYMBOLINFO;

#define PREVALDI_MAGIC_STR "PVALDI0"

///////////////////////////////////////////////////////////////////////////////////////////////////
//IOCTLS
///////////////////////////////////////////////////////////////////////////////////////////////////
#define FILE_DEVICE_VALDI                                0xCF83

//-------------------------------------------------------------------------------------------------
typedef struct _VALDI_ADAPTERINFO_IN
{
    UINT infoType;
    UINT expectedDataSize;
}VALDI_ADAPTERINFO_IN, *PVALDI_ADAPTERINFO_IN;

#define IOCTL_VALDI__IGDKMD_GET_ADAPTER_INFO             CTL_CODE(FILE_DEVICE_VALDI, 2052, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)

//-------------------------------------------------------------------------------------------------
typedef struct _VALDI_MMIODATA
{
    ULONG    address;
    ULONG    size;
}VALDI_MMIODATA, *PVALDI_MMIODATA;

#define IOCTL_VALDI__IGDKMD_READ_MMIO                    CTL_CODE(FILE_DEVICE_VALDI, 2053, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)
#define IOCTL_VALDI__IGDKMD_WRITE_MMIO                   CTL_CODE(FILE_DEVICE_VALDI, 2054, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)

//-------------------------------------------------------------------------------------------------
#define IOCTL_VALDI__IGDKMD_RESUME_MMIOWRITE_TRACING     CTL_CODE(FILE_DEVICE_VALDI, 2055, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)
#define IOCTL_VALDI__IGDKMD_SUSPEND_MMIOWRITE_TRACING    CTL_CODE(FILE_DEVICE_VALDI, 2056, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)
#define IOCTL_VALDI__IGDKMD_FINALIZE_MMIOWRITE_TRACING   CTL_CODE(FILE_DEVICE_VALDI, 2057, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)
#define IOCTL_VALDI__IGDKMD_RESTART_MMIOWRITE_TRACING    CTL_CODE(FILE_DEVICE_VALDI, 2058, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)

//-------------------------------------------------------------------------------------------------
typedef struct _VALDI_BSOD_TRIGGERS_IN
{
    ULONG pipeID;
    ULONG BSoDTriggersFlag;
}VALDI_BSOD_TRIGGERS_IN, *PVALDI_BSOD_TRIGGERS_IN;

#define IOCTL_VALDI__IGDKMD_SET_BSOD_TRIGGERS            CTL_CODE(FILE_DEVICE_VALDI, 2059, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)

//-------------------------------------------------------------------------------------------------
//OUT: PIPE_STATUS
#define IOCTL_VALDI__IGDKMD_GET_PIPE_TO_PORT_MAPPINGS    CTL_CODE(FILE_DEVICE_VALDI, 2060, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)

//------------------------------------------------------------------------------------------------
#define IOCTL_VALDI__GET_STATE                           CTL_CODE(FILE_DEVICE_VALDI, 2061, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)

//-------------------------------------------------------------------------------------------------
typedef struct _VALDI_SET_PIPE_VISIBILITY_IN
{
    ULONG pipeId;
    ULONG enableFlag;
}VALDI_SET_PIPE_VISIBILITY_IN, *PVALDI_SET_PIPE_VISIBILITY_IN;

#define IOCTL_VALDI__SET_PIPE_VISIBILITY                 CTL_CODE(FILE_DEVICE_VALDI, 2062, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)

//-------------------------------------------------------------------------------------------------
typedef struct _VALDI_HOOK_STATS
{
    ULONGLONG softSyncs[MAX_PIPES];
    ULONGLONG underrunds[MAX_PIPES];
} VALDI_HOOK_STATS, *PVALDI_HOOK_STATS;

#define IOCTL_VALDI__GET_HOOK_STATS                      CTL_CODE(FILE_DEVICE_VALDI, 2063, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)

//-------------------------------------------------------------------------------------------------
#define VALDI_MAX_TXT_MARKER_LENGTH 63
typedef struct _VALDI_TXT_MARKER_IN
{
    CHAR txtBuff[VALDI_MAX_TXT_MARKER_LENGTH + 1];
}VALDI_TXT_MARKER_IN, *PVALDI_TXT_MARKER_IN;

#define IOCTL_VALDI__INSERT_TXT_MARKER                   CTL_CODE(FILE_DEVICE_VALDI, 2064, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)

//-------------------------------------------------------------------------------------------------
#define IOCTL_VALDI__ENABLE_WM_CORRUPTION                CTL_CODE(FILE_DEVICE_VALDI, 4000, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)
#define IOCTL_VALDI__DISABLE_WM_CORRUPTION               CTL_CODE(FILE_DEVICE_VALDI, 4001, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)

///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
//USER SPACE API
///////////////////////////////////////////////////////////////////////////////////////////////////
#define PIPEA_ID   0x0
#define PIPEB_ID   0x1
#define PIPEC_ID   0x2

#define PORTA_ID   0x0
#define PORTB_ID   0x1
#define PORTC_ID   0x2
#define PORTD_ID   0x3


//Returns last error code string
//INPUT:		  NONE
//
//RETURN:		 Pointer to char string representing the last error.
//
CHAR* ValDi_GetLastErrorStr();

//Retreives ValDi state flag.
//INPUT:          NONE
//
//RETURN:         ULONG representing current ValDi state:
//                       VALDISTATE_UNINITIALIZED    0x00
//                       VALDISTATE_RUNNING          0x01
//                       VALDISTATE_DEMISED          0x02
//                  or 0xFFFFFFFF on error.
ULONG ValDi_GetState();

//Retrieves adapter vendor specific data.
//INPUT:         <infoType> Enum identifying DDI info type (ex. DXGK_QUERYADAPTERINFOTYPE).
//               <size>     Expected return block size.
//               <data>     Pointer to a block of data to be stored to.
//
//RETURN:        Success (0) or error (-1) flag.
//
INT   ValDi_GetAdapterInfo(UINT infoType, UINT size, PVOID data);

//Reads MIMO registers' values.
//INPUT:         <address>  Address of a MIMO register at the beginning of block.
//               <size>     Size of the block to be read from.
//               <data>     Pointer to a block of data to be read from.
//
//RETURN:        Success (0) or error (-1) flag.
//
INT   ValDi_ReadMMIO(ULONG address, ULONG size, PVOID data);

//Writes MIMO registers' values.
//INPUT:         <address>  Address of a MIMO register at the beginning of block.
//               <size>     Size of the block to be written to.
//               <data>     Pointer to a block of data to be written to.
//
//RETURN:        Success (0) or error (-1) flag.
//
INT   ValDi_WriteMMIO(ULONG address, ULONG size, PVOID data);


//Configures BsOD trigger flags
//INPUT:         <portId>  ID of the port: PORTA_ID, PORTB_ID, PORTC_ID or PIPED_ID.
//               <flags>   A combination of the following values:
//                                BSOD_ON_CRC_PIPE_ERROR     - Triggers BugChekc when a pipe CRC does not any of the values in 'Valid CRC Bank'.
//                                BSOD_ON_CRC_PIPE_NOCHANGE  - Triggers BugCheck when no CRC change has been detected between consecutive frames.
//                                BSOD_ON_PIPE_UNDERRUN      - Triggets BugCheck when UNDERRUN interrupt is assigned to a given pipe.
//
//RETURN:        Success (0) or error (-1) flag.
//
INT   ValDi_SetBSoDTriggers(ULONG pipeID, ULONG flags);

//Retrives a structure representing pipe-to-port mapping.
//INPUT:         <ptp> A structure of PIPE_STATUS type.
//
//RETURN:        Success (0) or error (-1) flag.
//
INT   ValDi_GetPipeToPortMapping(PPIPE_MAPS ptp);

//Resumes/starts MMIO_WRITE tracing routine.
//INPUT:         NONE
//
//RETURN:        Success (0) or error (-1) flag.
//
INT   ValDi_ResumeTracing();

//Suspends MMIO_WRITE tracing reoutine.
//INPUT:         NONE
//
//RETURN:        Success (0) or error (-1) flag.
//
INT   ValDi_SuspendTracing();

//Finalizes MMIO_WRITE tracing reoutine.
//INPUT:         NONE
//
//RETURN:        Success (0) or error (-1) flag.
//
INT   ValDi_FinalizeTracing();

//Restarts MMIO_WRITE tracing reoutine.
//INPUT:         NONE
//
//RETURN:        Success (0) or error (-1) flag.
//
INT   ValDi_RestartTracing();

//Sets/unsets PIPE_X visibility attribute.
//INPUT:          <pipeID>  ID of te pipe: PIPEA_ID, PIPEB_ID or PIPEC_ID.
//                <enableFlag> Boolean value (TRUE) for enable, (FALSE) for disable.
//
//RETURN:        Success (0) or error (-1) flag.
//
INT   ValDi_SetPipeVisibility(ULONG pipeId, BOOLEAN enableFlag);



//Retrives basic hook stats
//INPUT:         <hStatsPtr> A pointer to VALDI_HOOK_STATS struct for data storage.
//
//RETURN:        Success (0) or error (-1) flag.
//
INT   ValDi_GetHookStats(PVALDI_HOOK_STATS hStatsPtr);


//Inserts txt marker into ValDi trace log file.
//INPUT:        <txtM> A pointer to VALDI_TXT_MARKER_IN struct.
//
//RETURN:        Success (0) or error (-1) flag.
//
INT   ValDi_InsertTxtMarker(const char* txtM);


INT ValDi_EnableWatermarkCorruptions(PULONG pipeId);
INT ValDi_DisableWatermarkCorruptions(PULONG pipeId);