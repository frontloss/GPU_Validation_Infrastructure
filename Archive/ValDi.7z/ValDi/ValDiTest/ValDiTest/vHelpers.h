#pragma once

#include <utility>
#include <vector>
#include <map>
#include <sstream>
#include "..\TalkToValdi\TalkToValDi.h"




typedef struct _CRC_stats
{
    ULONGLONG lastTimeStamp;
    ULONGLONG count;
}CRC_stats, *PCRC_stats;


typedef std::map<ULONG, CRC_stats> crc_map_t;
typedef std::pair<ULONG, CRC_stats> crc_pair_t;

///////////////////////////////////////////////////////////////////////////////////////////////////
/*
class CCRCResults
{
private:


public:

    CCRCResults();

    static CCRCResults* s_instance;

    CRITICAL_SECTION           CriticalSection;
    ULONGLONG                  lastRead;
    ULONGLONG                  recordsRead;
    ULONG                      killme_flag;
    HANDLE                     m_thread;
    std::map<ULONG, CRC_stats> pipeCRCData[MAX_DPORTS];
    sCRCData                   bufferedCRCData;
    
    ULONGLONG                  vint[MAX_PIPES];

    void          clearPipeCRCList(ULONG portId);
    void          sync();
    int           getUniquePipeCRCList(ULONG portId, std::map<ULONG, CRC_stats> &crcList, ULONGLONG &intCnt);
    void          release(){ killme_flag = 1; }
    ULONGLONG     getRecordsRead() { return recordsRead; }


    static CCRCResults* getInstance()
    {
        if (!s_instance)
        {
            s_instance = new CCRCResults();
        }

        return s_instance;
    }

    ~CCRCResults();
};
*/

///////////////////////////////////////////////////////////////////////////////////////////////////
template <class T>
inline std::string to_string(const T& t)
{
    std::stringstream ss;
    ss << t;
    return ss.str();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
int sleepDisplaysFor(unsigned long msecs);
int sleepOSFor(unsigned msecs);
int dimmDisplay();
std::string GetVersionInfo(const char *field);
