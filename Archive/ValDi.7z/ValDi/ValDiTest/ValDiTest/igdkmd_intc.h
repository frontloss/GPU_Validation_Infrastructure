#pragma once

///////////////////////////////////////////////////////////////////////////////////////////////////
#define CRC_CONTROL_A             0x64050
#define CRC_RESULT_A              0x64064

#define CRC_CONTROL_B             0x64150
#define CRC_RESULT_B              0x64164

#define CRC_CONTROL_C             0x64250
#define CRC_RESULT_C              0x64264

#define CRC_CONTROL_D             0x64350
#define CRC_RESULT_D              0x64364

#define CRC_CONTROL_TRIGGER       0x83000000
#define CRC_CONTROL_READYMASK     0x01000000
#define CRC_CONTROL_CHANGEMASK    0x02000000
#define CRC_CONTROL_ENABLEDMASK   0x80000000

///////////////////////////////////////////////////////////////////////////////////////////////////
//  Display port type enumeration
typedef enum {
	NULL_PORT_TYPE = -1,
	ANALOG_PORT = 0,
	DVOA_PORT,
	DVOB_PORT,
	DVOC_PORT,
	DVOD_PORT,
	LVDS_PORT,
	INTDPE_PORT,
	INTHDMIB_PORT,
	INTHDMIC_PORT,
	INTHDMID_PORT,
	INT_DVI_PORT, //NA
	INTDPA_PORT, //Embedded DP For ILK
	INTDPB_PORT,
	INTDPC_PORT,
	INTDPD_PORT,
	TPV_PORT,  //This is for all the TPV Ports..
	INTMIPIA_PORT,
	INTMIPIC_PORT,
	WIGIG_PORT,
	DVOF_PORT,
	INTHDMIF_PORT,
	INTDPF_PORT,
	MAX_PORTS
} PORT_TYPES, *PPORT_TYPES;

#pragma warning( disable: 4214 )
#pragma warning( disable: 4201 )
// Data Structure for Interrupt operations
typedef enum _INTERRUPT_OPERATION
{ 
    ENABLE_INTERRUPT      = 1,
    DISABLE_INTERRUPT     = 2,
    MASK_INTERRUPT        = 3,
    UNMASK_INTERRUPT      = 4,
    GET_DISABLED_INTERRUPTS = 5 // Flag To Detect Disabled Interrupts also.
} INTERRUPT_OPERATION;


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//NOTE: Any change in the interrrupt args structure below has to be reflected in the enum definitions above.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Interrupt Args structure
typedef struct _SB_INTERRUPT_ARGS
{
    INTERRUPT_OPERATION eOperation; // Data structure for interrupt operations
    ULONG ulPrivateData; // Private Interrupt Data. This will not be used in ILK and GT since enabling/disabling of all interrupts has become much simpler.. 

    ULONG PlatformUsesGen11InterruptArchitecture : 1; // Let Event handler code know that all non-display engines are handled by new Selector methods
    ULONG SelectorInterruptsOccurred             : 1; // New for Gen11+  ::  This bit means one of the hierarchical interrupts (has to use selector register) has occurred and needs to be handled by GEN11+ handler
    ULONG LegacyInterruptsOccurred               : 1; // New for Gen11+  ::  This bit means use the IntArgs below for handling the interrupts
    
    IN BOOLEAN HierarchicalInterruptService      : 1; // This bit means request for Hirearchial Interrupt services

    IN ULONG ulEngineClass;                           // Can re-use ulValue in union
    IN ULONG ulEngineIntrpt;                          // Can re-use ulValue1 in union

    union
    {
        ULONG ulValue;
        struct
        {
            //1. Hot Plug Interrupts Definitions - Starts Here

            ULONG    bIntegratedCRTInterrupt    : 1;    // Bit 0
            ULONG    ulReservedBit              : 1;    // Bit 1
            ULONG    bInterruptReserved1        : 1;    // Bit 2
            ULONG    bInterruptReserved2        : 1;    // Bit 3 //From Gen6 onwards,no need to register for this event as sDVO on Port C is disabled..
            ULONG    bIntDP_HDMIAInterrupt      : 1;    // Bit 4  //New Introduction from ILK onwards
            ULONG    bIntDP_HDMIBInterrupt      : 1;    // Bit 5
            ULONG    bIntDP_HDMICInterrupt      : 1;    // Bit 6
            ULONG    bIntDP_HDMIDInterrupt      : 1;    // Bit 7
            ULONG    bIntDP_HDMIA_SPInterrupt   : 1;    // Bit 8 //New Introduction from ILK onwards
            ULONG    bIntDP_HDMIB_SPInterrupt   : 1;    // Bit 9
            ULONG    bIntDP_HDMIC_SPInterrupt   : 1;    // Bit 10
            ULONG    bIntDP_HDMID_SPInterrupt   : 1;    // Bit 11            

            //1. Hot Plug Interrupts Definitions - Ends Here

            //2. Render Geyserville Interrupts Definitions - Starts Here

            //Render Geyserville Interrupts common till ILK Platform
            ULONG    bRen_Gey_SoftwareCommandCompleteInterrupt    : 1; // bit 12 // Render GeyserVille Interrupt             
            ULONG    bRen_Gey_EvaluatedFrequencyChangeInterrupt   : 1; // bit 13 // Render GeyserVille Interrupt            

            //New Render Geyserville Interrupts exists only in ILK
            ULONG    bRen_Gey_AvgBusyThreshold                    : 1; // bit 14 // Render GeyserVille Interrupt
            ULONG    bRen_Gey_ContinuousBusyThreshold             : 1; // bit 15 // Render GeyserVille Interrupt            

            //Render Geyserville Common between ILK and GT
            ULONG    bRen_Gey_UpEvaluationIntervalInterrupt       : 1; // bit 16 // Render GeyserVille Interrupt 
            ULONG    bRen_Gey_DownEvaluationIntervalInterrupt     : 1; // bit 17 // Render GeyserVille Interrupt

            //Render Geyserville Introduced from GT
            ULONG    bRen_Gey_Controller_Disable_StateInterrupt   : 1; // bit 18 // Render GeyserVille Interrupt

            //2. Render Geyserville Interrupts Definitions - Ends Here


            //3. Basic Render Interrupt Definitions - Starts Here

            ULONG    bDebugInterrupt                           : 1; // Bit 19 Gen4 Onwards
            ULONG    bPipeControlNotifyInterrupt               : 1; // Bit 20 Gen4 Onwards
            ULONG    bRenderUserInterrupt                      : 1; // Bit 21 Render Cmd UI      
            ULONG    bRenderMMIOSyncFlushStatus                : 1; // Bit 22
            ULONG    bRenderWatchDogCounterExcd                : 1; // Bit 23 //ILK Onwards           
            ULONG    bRenderASContextSwitch                    : 1; // Bit 24 //ILK Onwards           
            ULONG    bRenderPageFault                          : 1; // Bit 25 //ILK Onwards           

            //3. Basic Render Interrupt Definitions - Ends Here          

            //4. Media/Video Interrupt Definitions - Starts Here
            ULONG    bVideoUserInterrupt                       : 1; // Bit 26 Gen4 Onwards
            ULONG    bVideoDecPipelineCntrExceed               : 1; // Bit 27 Gen4 Onwards..Same as Video Command Streamer WatchDog Counter Exceeded in GT            
            //Following are valid from GT
            ULONG    bVideoMIFlush_DWNotify                    : 1; // Bit 28
            ULONG    bVideoMMIOSyncFlushStatus                 : 1; // Bit 29                 
            ULONG    bVideoASContextSwitch                     : 1; // Bit 30
            ULONG    bVideoPageFault                           : 1; // Bit 31

            //4. Media/Video Interrupt Definitions - Ends Here

        };
    };

    union
    {
        ULONG ulValue1;
        struct
        {
            //5. Remaining Power Conservation Interrupt Starts here            
            ULONG    bLBPC_PipeAInterrupt        : 1;    // Bit 0 - crestline and after. Doesnt exist from ILK Onwards            
            ULONG    bLBPC_PipeBInterrupt        : 1;    // Bit 1 - crestline and after. Doesnt exist from ILK Onwards            
            ULONG    bDPST_HistInterrupt         : 1;    // Bit 2 - crestline and after            
            ULONG    bDPST_PhaseInInterrupt      : 1;    // Bit 3 - crestline and after           

            //Valid from GT Onwards
            ULONG    bPCUDriverMBEvent                         : 1; // Bit 4
            ULONG    bPCRenderFreqDownwardDuringRC6Timeout     : 1; // Bit 5
            ULONG    bPC_RPUpThresholdIntr                     : 1; // Bit 6
            ULONG    bPC_RPDownThresholdIntr                   : 1; // Bit 7

            //5. Remaining Power Conservation Interrupt Ends here

            //6. Blitter Interrupts from GT Onwards Starts here

            ULONG    bBlitterASContextSwitch          : 1; // Bit 8            
            ULONG    bBlitterMIFlush_DWNotify         : 1; // Bit 9
            ULONG    bBlitterMMIOSyncFlushStatus      : 1; // Bit 10
            ULONG    bBlitterMI_User_Interrupt        : 1; // Bit 11
            ULONG    bBlitterPageFault                : 1; // Bit 12
            //6. Blitter Interrupts from GT Onwards Ends here    


            //7. Misc Interrupts Category Starts here
            ULONG    bVSync_PipeAInterrupt            : 1;    // Bit 13 //Not Required
            ULONG    bVSync_PipeBInterrupt            : 1;    // Bit 14 //Not Required
            ULONG    bVBlank_PipeAInterrupt           : 1;    // Bit 15
            ULONG    bVBlank_PipeBInterrupt           : 1;    // Bit 16            
            ULONG    bGSESystemLevel                  : 1;    // Bit 17  Valid from ILK Replacement for ASLE Interrupt           
            ULONG    bVblankTPV                       : 1;    // BIT 18 //Used for TPV Vblank Interrupt
            ULONG    bASLEInterrupt                   : 1;    // Bit 19  Need to remove Once MP Cleans up the ASLE INterrupt Stuff
            ULONG    bAllFirstLevelInterrupts         : 1;    // BIT 20 //Used for Enabling/Disabling of Interrupts..

            //7. Misc Interrupts Category Ends here

            //8. New added Interrupts
            ULONG    bSpritePlaneAFlipDoneInterrupt   : 1;    // BIT 21 //Used for Enabling/Disabling of Sprite Plane A Flip Done Interrupt..
            ULONG    bSpritePlaneBFlipDoneInterrupt   : 1;    // BIT 22 //Used for Enabling/Disabling of Sprite Plane B Flip Done Interrupt..

            ULONG    bVSync_PipeCInterrupt            : 1;    // BIT 23
            ULONG    bVBlank_PipeCInterrupt           : 1;    // BIT 24
            ULONG    bSpritePlaneCFlipDoneInterrupt   : 1;    // BIT 25

            ULONG    bAudioHDCPRequestInterruptA      : 1;    // BIT 26 //Audio HDCP request for transcoder A
            ULONG    bAudioHDCPRequestInterruptB      : 1;    // BIT 27 //Audio HDCP request for transcoder B
            ULONG    bAudioHDCPRequestInterruptC      : 1;    // BIT 28 //Audio HDCP request for transcoder C
            ULONG    bAudioHDCPRequestInterrupt       : 1;    // BIT 29 //Audio HDCP request for pre ilk platforms            

            ULONG   bPerfMonBufferHalfFullInterrupt   : 1;    // BIT 30

            ULONG   ulReserved_Bit31                 : 1;    // Bit 31

        };
    };

    union
    {
        ULONG ulValue2;
        struct
        {
            // This sections contains error/debug status bits
            ULONG bFIFOUnderrun_PipeAInterrupt                          : 1; // bit 0 
            ULONG bCRC_Error_PipeAInterrupt                             : 1; // bit 1
            ULONG bCRC_Done_PipeAInterrupt                              : 1; // bit 2

            ULONG bFIFOUnderrun_PipeBInterrupt                          : 1; // bit 3
            ULONG bCRC_Error_PipeBInterrupt                             : 1; // bit 4
            ULONG bCRC_Done_PipeBInterrupt                              : 1; // bit 5

            ULONG bFIFOUnderrun_PipeCInterrupt                          : 1; // bit 6
            ULONG bCRC_Error_PipeCInterrupt                             : 1; // bit 7
            ULONG bCRC_Done_PipeCInterrupt                              : 1; // bit 8

            // VE (Video Enhancement) Interrupt Definitions - Starts Here - Valid from Gen7_5 (HSW+) onward
            ULONG bVEUserInterrupt                                      : 1; // bit 9
            ULONG bVEMMIOSyncFlushStatus                                : 1; // bit 10
            ULONG bVECmdParserMasterError                               : 1; // bit 11
            ULONG bVEMIFlush_DWNotify                                   : 1; // bit 12
            // VE (Video Enhancement) Interrupt Definitions - Ends Here

            // other interrupt bits that don't fit into the previous dwords
            ULONG bRenderParityError                                    : 1; // Bit 13 Gen7 Onwards

            ULONG bVideoPavpUnsolicitedAttack                           : 1; // Bit 14 Gen7 Onwards

            //Below are valid from BDW
            ULONG bVideoUserInterrupt2                                  : 1; // Bit 15 
            ULONG bVideoDecPipelineCntrExceed2                          : 1; // Bit 16 
            ULONG bVideoMIFlush_DWNotify2                               : 1; // Bit 17
            ULONG bVideoMMIOSyncFlushStatus2                            : 1; // Bit 18                 
            ULONG bVideoASContextSwitch2                                : 1; // Bit 19
            ULONG bVideoPageFault2                                      : 1; // Bit 20
            ULONG bVideoPavpUnsolicitedAttack2                          : 1; // Bit 21

            ULONG bGuCSHIMError                                         : 1;    // bit 22
            ULONG bGuCDMAINTError                                       : 1;    // bit 23                
            ULONG bGuCDMADone                                           : 1;    // bit 24                
            ULONG bGuCDoorBellRang                                      : 1;    // bit 25
            ULONG bGuCIOMMUSentMsgtoGuc                                 : 1;    // bit 26
            ULONG bGuCSemaphoreSignaled                                 : 1;    // bit 27
            ULONG bGuCDisplayEventRecieved                              : 1;    // bit 28
            ULONG bGuCExecutionError                                    : 1;    // bit 29
            ULONG bGuCInterruptToHost                                   : 1;    // bit 30

            ULONG bCSTRInvalidTileDetection                             : 1;    // bits 31
        };
    };

    union
    {
        ULONG ulValue3;
        struct
        {
            // This sections contains VEC/WiDi interrupts
            ULONG bVECSContextSwitchInterrupt                           : 1; // bit 0
            ULONG bVECSWaitOnSemaphore                                  : 1; // bit 1
            ULONG bWDBoxInterrupt                                       : 1; // bit 2
            ULONG bDPST_HistInterruptPipeB                              : 1;// bit 3
            ULONG bDPST_PhaseInInterruptPipeB                           : 1; // bit 4
            ULONG bDPST_HistInterruptPipeC                              : 1;// bit 5
            ULONG bDPST_PhaseInInterruptPipeC                           : 1; // bit 6 

            ULONG bPipeA_Plane1FlipDoneInterrupt                        : 1; //bit 7
            ULONG bPipeA_Plane2FlipDoneInterrupt                        : 1; //bit 8
            ULONG bPipeA_Plane3FlipDoneInterrupt                        : 1; //bit 9

            ULONG bPipeB_Plane1FlipDoneInterrupt                        : 1; //bit 10
            ULONG bPipeB_Plane2FlipDoneInterrupt                        : 1; //bit 11
            ULONG bPipeB_Plane3FlipDoneInterrupt                        : 1; //bit 12

            ULONG bPipeC_Plane1FlipDoneInterrupt                        : 1; //bit 13
            ULONG bPipeC_Plane2FlipDoneInterrupt                        : 1; //bit 14
            ULONG bPipeC_Plane3FlipDoneInterrupt                        : 1; //bit 15

            ULONG bPipeA_Plane1FlipQueueEmptyInterrupt                  : 1; //bit 16
            ULONG bPipeA_Plane2FlipQueueEmptyInterrupt                  : 1; //bit 17
            ULONG bPipeA_Plane3FlipQueueEmptyInterrupt                  : 1; //bit 18

            ULONG bPipeB_Plane1FlipQueueEmptyInterrupt                  : 1; //bit 19
            ULONG bPipeB_Plane2FlipQueueEmptyInterrupt                  : 1; //bit 20
            ULONG bPipeB_Plane3FlipQueueEmptyInterrupt                  : 1; //bit 21

            ULONG bPipeC_Plane1FlipQueueEmptyInterrupt                  : 1; //bit 22
            ULONG bPipeC_Plane2FlipQueueEmptyInterrupt                  : 1; //bit 23
            ULONG bPipeC_Plane3FlipQueueEmptyInterrupt                  : 1; //bit 24

            ULONG bDEMiscSVMWaitDescriptorCompleted                     : 1; // bit 25
            ULONG bDEMiscSVMVTDFault                                    : 1; // bit 26
            ULONG bDEMiscSVMPRQEvent                                    : 1; // bit 27


            ULONG bPipeA_Plane4FlipDoneInterrupt                        : 1; // bit 28
            ULONG bPipeB_Plane4FlipDoneInterrupt                        : 1; // bit 29
            ULONG bPSR2GTCLockLoss                                      : 1; // bit 30
            ULONG bVECSWatchDogCounterExcd								: 1; // bit 31
        };
    };
    union
    {
        ULONG ulValue4;
        struct
        {
            ULONG bMIPIAInterrupt                                       : 1; // bit 0
            ULONG bMIPICInterrupt                                       : 1; // bit 1
            ULONG bLPEPipeAInterrupt                                    : 1; // bit 2
            ULONG bLPEPipeBInterrupt                                    : 1; // bit 3

            ULONG bISPInterrupt                                         : 1; // bit 4
            ULONG bVEDBlockInterrupt                                    : 1; // bit 5
            ULONG bVEDPowerInterrupt                                    : 1; // bit 6
            ULONG bPipeA_Plane4FlipQueueEmptyInterrupt                  : 1; // bit 7

            ULONG bPipeB_Plane4FlipQueueEmptyInterrupt                  : 1; // bit 8
            ULONG bLPEPipeCInterrupt                                    : 1; // bit 9
            ULONG bGTPMCoreToUncoreTrapInterrupt                        : 1; //bit 10
            ULONG bWDBoxEndofFrameInterrupt                             : 1; //bit 11 corresponds to WDBOX_END_OF_FRAME_INTERRUPT = 0X800, in INTERRUPT_UNION_VALUE_4
            
            ULONG bIntDP_HDMIEInterrupt                                 : 1; // Bit 12// skl ddi - e hot plug interrupt
            ULONG bIntDP_HDMIE_SPInterrupt                              : 1; // Bit 13
            ULONG bRenderTDLRetryInterrupt                              : 1; // bit 14
            ULONG bPinningContextSwitch                                 : 1; // Bit 15
            ULONG bPinningUserInterrupt                                 : 1; // Bit 16
            ULONG bDEMisc_WDCombinedInterrupt                           : 1; // bit 17 corresponds to DEMISC_WD_COMBINED_INTERRUPT  = 0x20000, in INTERRUPT_UNION_VALUE_4

            ULONG bPipeA_Underrun                                       : 1; // bit 18
            ULONG bPipeB_Underrun                                       : 1; // bit 19
            ULONG bPipeC_Underrun                                       : 1; // bit 20
            ULONG bPipeC_Plane4FlipDoneInterrupt                        : 1; // bit 21
            ULONG bInvalidGTTPageTableEntry                             : 1; // bit 22
            ULONG bInvalidPageTableEntryData                            : 1; // bit 23
            ULONG bVSync_PipeDInterrupt                                 : 1; // BIT 24
            ULONG bVBlank_PipeDInterrupt                                : 1; // BIT 25
            ULONG bIntDP_HDMIFInterrupt                                 : 1; // Bit 26// ddi - f hot plug interrupt 
            ULONG ulReserved_Bits31_27                                  : 5; // bits 31:27
        };
    };
    union
    {
        ULONG ulValue5;
        struct
        {
            ULONG PipeA_Plane1GTTFaultStatus                            : 1; //bit 0
            ULONG PipeA_Plane2GTTFaultStatus                            : 1; //bit 1
            ULONG PipeA_Plane3GTTFaultStatus                            : 1; //bit 2
            ULONG PipeA_Plane4GTTFaultStatus                            : 1; //bit 3
            ULONG PipeA_CursorGTTFaultStatus                            : 1; //bit 4

            ULONG PipeB_Plane1GTTFaultStatus                            : 1; //bit 5
            ULONG PipeB_Plane2GTTFaultStatus                            : 1; //bit 6
            ULONG PipeB_Plane3GTTFaultStatus                            : 1; //bit 7
            ULONG PipeB_Plane4GTTFaultStatus                            : 1; //bit 8
            ULONG PipeB_CursorGTTFaultStatus                            : 1; //bit 9

            ULONG PipeC_Plane1GTTFaultStatus                            : 1; //bit 10
            ULONG PipeC_Plane2GTTFaultStatus                            : 1; //bit 11
            ULONG PipeC_Plane3GTTFaultStatus                            : 1; //bit 12
            ULONG PipeC_Plane4GTTFaultStatus                            : 1; //bit 13
            ULONG PipeC_CursorGTTFaultStatus                            : 1; //bit 14

			ULONG IntDP_HDMIB_SCDCInterrupt							: 1; //bit 15
			ULONG IntDP_HDMIC_SCDCInterrupt							: 1; //bit 16
			ULONG IntDP_HDMID_SCDCInterrupt							: 1; //bit 17
			ULONG IntDP_HDMIE_SCDCInterrupt							: 1; //bit 18
			ULONG IntDP_HDMIF_SCDCInterrupt							: 1; //bit 19

            ULONG ulReserved_Bits31_20                                  : 12; // bits 31:20
        };
	};

}SB_INTERRUPT_ARGS, *PSB_INTERRUPT_ARGS;

#pragma warning( default: 4214 )
#pragma warning( default: 4201 )