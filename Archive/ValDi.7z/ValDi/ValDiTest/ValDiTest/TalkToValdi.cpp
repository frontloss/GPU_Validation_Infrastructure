#include "TalkToValDi.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#define MAX_STR_ERROR_LENGTH 256

static CHAR lastErrorStr[MAX_STR_ERROR_LENGTH] = { 0 };

static HANDLE ValDiHandle = NULL;
const CHAR VALDI_ERROR_DEVICE_NOT_INITIALIZED[] = "ValDi not initialized.";

const int IOCTL_SLEEP_ME = 100;
const int IOCTL_ATTEMPTS = 10;

////////////////////////////////////////////////////////////////////////////////////////////////////
CHAR* ValDi_GetLastErrorStr()
{
    return lastErrorStr;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
INT ValDi_VerifyState(ULONG expected, ULONG mask)
{
    INT    attempts = IOCTL_ATTEMPTS;
    ULONG  state = ValDi_GetState();
    while (((state&mask) != expected) && attempts)
    {
        Sleep(IOCTL_SLEEP_ME);
        attempts--;
        state = ValDi_GetState();
    }
    
    if ((state&mask) != expected)
    {
        _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "ValDi state not set.");
        return -1;
    }

    return 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
INT ValDi_init()
{
    if (!((ValDiHandle == 0) || (ValDiHandle == INVALID_HANDLE_VALUE)))
        return -1;

    ValDiHandle = CreateFile("\\\\.\\ValDi",
        GENERIC_READ | GENERIC_WRITE,
        0,
        0,
        OPEN_EXISTING,
        FILE_FLAG_OVERLAPPED,
        0);

    if (ValDiHandle == INVALID_HANDLE_VALUE)
    {
        char buf[256]; FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), buf, 256, NULL);
        _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "ValDi init error: %s", buf);
        return -1;
    }

    return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
ULONG ValDi_GetState()
{
    ULONG out;
    DWORD bytesRet;

    if ((!ValDiHandle) || (ValDiHandle == INVALID_HANDLE_VALUE))
    {
        if (ValDi_init())
        {
            _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "%s", VALDI_ERROR_DEVICE_NOT_INITIALIZED);
            return (ULONG)(-1);
        }
    }

    if (!DeviceIoControl(ValDiHandle, IOCTL_VALDI__GET_STATE, NULL, 0, &out, sizeof(ULONG), &bytesRet, 0))
    {
        char buf[256]; FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), buf, 256, NULL);
        _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "ValDi [VALDI_GetState] failed: %s\n", buf);
        return (ULONG)(-1);
    }

    return out;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
INT ValDi_GetAdapterInfo(UINT infoType, UINT size, PVOID data)
{
    VALDI_ADAPTERINFO_IN dIn;	
    DWORD bytesRet;


    if ((!ValDiHandle) || (ValDiHandle == INVALID_HANDLE_VALUE))
    {
        if (ValDi_init())
        {
            _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "%s", VALDI_ERROR_DEVICE_NOT_INITIALIZED);
            return -1;
        }
    }

    dIn.infoType = infoType; 
    dIn.expectedDataSize = size;

    if (!DeviceIoControl(ValDiHandle, IOCTL_VALDI__IGDKMD_GET_ADAPTER_INFO, &dIn, sizeof(dIn), data, size, &bytesRet, 0))
    {
        char buf[256]; FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), buf, 256, NULL);
        _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "ValDi [GetAdapterInfo] failed: %s\n", buf);
        return -1;
    }

    return 0;

}

///////////////////////////////////////////////////////////////////////////////////////////////////
INT ValDi_ReadMMIO(ULONG address, ULONG size, PVOID data)
{
    VALDI_MMIODATA dIn;
    DWORD bytesRet;

    dIn.address = address;
    dIn.size = size;


    if ((!ValDiHandle) || (ValDiHandle == INVALID_HANDLE_VALUE))
    {
        if (ValDi_init())
        {
            _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "%s", VALDI_ERROR_DEVICE_NOT_INITIALIZED);
            return -1;
        }
    }

    if (!DeviceIoControl(ValDiHandle, IOCTL_VALDI__IGDKMD_READ_MMIO, &dIn, sizeof(dIn), data, size, &bytesRet, 0))
    {
        char buf[256]; FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), buf, 256, NULL);
        _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "ValDi [ReadMMIO] failed: %s\n", buf);
        return -1;
    }

    return 0;

}

///////////////////////////////////////////////////////////////////////////////////////////////////
INT ValDi_WriteMMIO(ULONG address, ULONG size, PVOID data)
{
    VALDI_MMIODATA dIn;
    DWORD bytesRet;

    dIn.address = address;
    dIn.size = size;

    if ((!ValDiHandle) || (ValDiHandle == INVALID_HANDLE_VALUE))
    {
        if (ValDi_init())
        {
            _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "%s", VALDI_ERROR_DEVICE_NOT_INITIALIZED);
            return -1;
        }
    }

    PVOID iData = malloc(sizeof(VALDI_MMIODATA) + size);
    assert(iData);

    memcpy(iData, &dIn, sizeof(VALDI_MMIODATA));
    memcpy((PVOID)((BYTE*)iData + sizeof(VALDI_MMIODATA)), data, size);

    if (!DeviceIoControl(ValDiHandle, IOCTL_VALDI__IGDKMD_WRITE_MMIO, iData, sizeof(VALDI_MMIODATA) + size, NULL, 0, &bytesRet, 0))
    {
        char buf[256]; FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), buf, 256, NULL);
        _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "ValDi [ValDi_WriteMMIO] failed: %s\n", buf);
        return -1;
    }


    return 0;

}


///////////////////////////////////////////////////////////////////////////////////////////////////
INT   ValDi_SetBSoDTriggers(ULONG pipeID, ULONG flags)
{
    VALDI_BSOD_TRIGGERS_IN BSoDTriggers;
    DWORD bytesRet;

    BSoDTriggers.pipeID = pipeID;
    BSoDTriggers.BSoDTriggersFlag = flags;

    if ((!ValDiHandle) || (ValDiHandle == INVALID_HANDLE_VALUE))
    {
        if (ValDi_init())
        {
            _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "%s", VALDI_ERROR_DEVICE_NOT_INITIALIZED);
            return -1;
        }
    }

    if (!DeviceIoControl(ValDiHandle, IOCTL_VALDI__IGDKMD_SET_BSOD_TRIGGERS, &BSoDTriggers, sizeof(VALDI_BSOD_TRIGGERS_IN), NULL, 0, &bytesRet, 0))
    {
        char buf[256]; FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), buf, 256, NULL);
        _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "ValDi [ValDi_SetBSoDTriggers] failed: %s\n", buf);
        return -1;
    }

    return 0;

}

///////////////////////////////////////////////////////////////////////////////////////////////////
INT   ValDi_GetPipeToPortMapping(PPIPE_MAPS ptp)
{
    DWORD bytesRet;

    if ((!ValDiHandle) || (ValDiHandle == INVALID_HANDLE_VALUE))
    {
        if (ValDi_init())
        {
            _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "%s", VALDI_ERROR_DEVICE_NOT_INITIALIZED);
            return -1;
        }
    }

    if (!DeviceIoControl(ValDiHandle, IOCTL_VALDI__IGDKMD_GET_PIPE_TO_PORT_MAPPINGS, NULL, 0, ptp, sizeof(PIPE_MAPS), &bytesRet, 0))
    {
        char buf[256]; FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), buf, 256, NULL);
        _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "ValDi [ValDi_GetPipeToPortMapping] failed: %s\n", buf);
        return -1;
    }

    return 0;

}

///////////////////////////////////////////////////////////////////////////////////////////////////
INT  ValDi_ResumeTracing()
{
    DWORD bytesRet;

    if ((!ValDiHandle) || (ValDiHandle == INVALID_HANDLE_VALUE))
    {
        if (ValDi_init())
        {
            _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "%s", VALDI_ERROR_DEVICE_NOT_INITIALIZED);
            return -1;
        }
    }

    if (!DeviceIoControl(ValDiHandle, IOCTL_VALDI__IGDKMD_RESUME_MMIOWRITE_TRACING, NULL, 0, NULL, 0, &bytesRet, 0))
    {
        char buf[256]; FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), buf, 256, NULL);
        _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "ValDi [ValDi_ResumeTracing] failed: %s\n", buf);
        return -1;
    }


    return ValDi_VerifyState(VALDISTATE_TRACING_FLAG, VALDISTATE_TRACING_FLAG);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
INT   ValDi_SuspendTracing()
{
    DWORD bytesRet;

    if ((!ValDiHandle) || (ValDiHandle == INVALID_HANDLE_VALUE))
    {
        if (ValDi_init())
        {
            _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "%s", VALDI_ERROR_DEVICE_NOT_INITIALIZED);
            return -1;
        }
    }

    if (!DeviceIoControl(ValDiHandle, IOCTL_VALDI__IGDKMD_SUSPEND_MMIOWRITE_TRACING, NULL, 0, NULL, 0, &bytesRet, 0))
    {
        char buf[256]; FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), buf, 256, NULL);
        _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "ValDi [ValDi_SuspendTracing] failed: %s\n", buf);
        return -1;
    }

    return ValDi_VerifyState(0, VALDISTATE_TRACING_FLAG);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
INT   ValDi_FinalizeTracing()
{
    DWORD bytesRet;

    if ((!ValDiHandle) || (ValDiHandle == INVALID_HANDLE_VALUE))
    {
        if (ValDi_init())
        {
            _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "%s", VALDI_ERROR_DEVICE_NOT_INITIALIZED);
            return -1;
        }
    }

    if (!DeviceIoControl(ValDiHandle, IOCTL_VALDI__IGDKMD_FINALIZE_MMIOWRITE_TRACING, NULL, 0, NULL, 0, &bytesRet, 0))
    {
        char buf[256]; FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), buf, 256, NULL);
        _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "ValDi [ValDi_FinalizeTracing] failed: %s\n", buf);
        return -1;
    }

    return ValDi_VerifyState(0, VALDISTATE_TRACING_FLAG);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
INT   ValDi_RestartTracing()
{
    DWORD bytesRet;

    if ((!ValDiHandle) || (ValDiHandle == INVALID_HANDLE_VALUE))
    {
        if (ValDi_init())
        {
            _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "%s", VALDI_ERROR_DEVICE_NOT_INITIALIZED);
            return -1;
        }
    }

    if (!DeviceIoControl(ValDiHandle, IOCTL_VALDI__IGDKMD_RESTART_MMIOWRITE_TRACING, NULL, 0, NULL, 0, &bytesRet, 0))
    {
        char buf[256]; FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), buf, 256, NULL);
        _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "ValDi [ValDi_RestartTracing] failed: %s\n", buf);
        return -1;
    }

    return ValDi_VerifyState(VALDISTATE_TRACING_FLAG, VALDISTATE_TRACING_FLAG);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
INT   ValDi_SetPipeVisibility(ULONG pipeId, BOOLEAN enableFlag)
{
    DWORD bytesRet;

    if ((!ValDiHandle) || (ValDiHandle == INVALID_HANDLE_VALUE))
    {
        if (ValDi_init())
        {
            _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "%s", VALDI_ERROR_DEVICE_NOT_INITIALIZED);
            return -1;
        }
    }

    VALDI_SET_PIPE_VISIBILITY_IN spvIn;
    spvIn.pipeId = pipeId;
    spvIn.enableFlag = enableFlag;

    if (!DeviceIoControl(ValDiHandle, IOCTL_VALDI__SET_PIPE_VISIBILITY, &spvIn, sizeof(spvIn), NULL, 0, &bytesRet, 0))
    {
        char buf[256]; FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), buf, 256, NULL);
        _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "ValDi [ValDi_SetPipeVisibility] failed: %s\n", buf);
        return -1;
    }

    return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
INT ValDi_GetHookStats(PVALDI_HOOK_STATS hStatsPtr)
{
    DWORD bytesRet;

    if ((!ValDiHandle) || (ValDiHandle == INVALID_HANDLE_VALUE))
    {
        if (ValDi_init())
        {
            _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "%s", VALDI_ERROR_DEVICE_NOT_INITIALIZED);
            return -1;
        }
    }

    if (!DeviceIoControl(ValDiHandle, IOCTL_VALDI__GET_HOOK_STATS, NULL, 0, hStatsPtr, sizeof(VALDI_HOOK_STATS), &bytesRet, 0))
    {
        char buf[256]; FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), buf, 256, NULL);
        _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "ValDi [ValDi_GetHookStats] failed: %s\n", buf);
        return -1;
    }

    return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
INT   ValDi_InsertTxtMarker(const char* txt)
{
    DWORD bytesRet;
    VALDI_TXT_MARKER_IN txtM;

    strncpy(txtM.txtBuff, txt, VALDI_MAX_TXT_MARKER_LENGTH);

    if ((!ValDiHandle) || (ValDiHandle == INVALID_HANDLE_VALUE))
    {
        if (ValDi_init())
        {
            _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "%s", VALDI_ERROR_DEVICE_NOT_INITIALIZED);
            return -1;
        }
    }


    if (!DeviceIoControl(ValDiHandle, IOCTL_VALDI__INSERT_TXT_MARKER, &txtM, sizeof(VALDI_TXT_MARKER_IN), NULL, 0, &bytesRet, 0))
    {
        char buf[256]; FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), buf, 256, NULL);
        _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "ValDi [ValDi_SetPipeVisibility] failed: %s\n", buf);
        return -1;
    }

    return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
INT ValDi_EnableWatermarkCorruptions(PULONG pipeId)
{
    DWORD bytesRet;

    if ((!ValDiHandle) || (ValDiHandle == INVALID_HANDLE_VALUE))
    {
        if (ValDi_init())
        {
            _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "%s", VALDI_ERROR_DEVICE_NOT_INITIALIZED);
            return -1;
        }
    }


    if (!DeviceIoControl(ValDiHandle, IOCTL_VALDI__ENABLE_WM_CORRUPTION, pipeId, sizeof(ULONG), pipeId, sizeof(ULONG), &bytesRet, 0))
    {
        char buf[256]; FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), buf, 256, NULL);
        _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "ValDi [ValDi_SetPipeVisibility] failed: %s\n", buf);
        return -1;
    }

    return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
INT ValDi_DisableWatermarkCorruptions(PULONG pipeId)
{
    DWORD bytesRet;

    if ((!ValDiHandle) || (ValDiHandle == INVALID_HANDLE_VALUE))
    {
        if (ValDi_init())
        {
            _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "%s", VALDI_ERROR_DEVICE_NOT_INITIALIZED);
            return -1;
        }
    }


    if (!DeviceIoControl(ValDiHandle, IOCTL_VALDI__DISABLE_WM_CORRUPTION, pipeId, sizeof(ULONG), pipeId, sizeof(ULONG), &bytesRet, 0))
    {
        char buf[256]; FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), buf, 256, NULL);
        _snprintf_s(lastErrorStr, MAX_STR_ERROR_LENGTH, MAX_STR_ERROR_LENGTH, "ValDi [ValDi_SetPipeVisibility] failed: %s\n", buf);
        return -1;
    }

    return 0;
}