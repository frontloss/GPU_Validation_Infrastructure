﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace DPCD_RW
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            if (InstallIgfxBridge())
            {
                Application.Run(new DPCD_MainWindow());
            }
        }

        static private bool InstallIgfxBridge()
        {
            string filePath = "";
            string dllName = "IgfxExtBridge.dll";
            int osVersion = IntPtr.Size;
            switch (osVersion)
            {
                case 4:
                    filePath = Directory.GetCurrentDirectory() + "\\32_Bit_Libs\\" + dllName;
                    break;
                case 8:
                    filePath = Directory.GetCurrentDirectory() + "\\64_Bit_Libs\\" + dllName;
                    break;
                default:
                    MessageBox.Show("OS falvor not recognised:Exiting tool");
                    return false;
            }

            Process regIgfxExtBridge = new Process();
            regIgfxExtBridge.StartInfo.FileName = "regsvr32.exe";
            regIgfxExtBridge.StartInfo.Arguments = "/s " + filePath;
            regIgfxExtBridge.Start();
            System.Threading.Thread.Sleep(1000);
            return true;
        }
    }
}
