﻿namespace DPCD_RW
{
    partial class DPCD_MainWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_Address = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_Value = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_Read = new System.Windows.Forms.Button();
            this.btn_Write = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.cb_eDP = new System.Windows.Forms.CheckBox();
            this.cb_DP = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_B6 = new System.Windows.Forms.TextBox();
            this.tb_B5 = new System.Windows.Forms.TextBox();
            this.tb_B4 = new System.Windows.Forms.TextBox();
            this.tb_B3 = new System.Windows.Forms.TextBox();
            this.tb_B2 = new System.Windows.Forms.TextBox();
            this.tb_B1 = new System.Windows.Forms.TextBox();
            this.tb_B0 = new System.Windows.Forms.TextBox();
            this.tb_B7 = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tb_Address
            // 
            this.tb_Address.BackColor = System.Drawing.SystemColors.HighlightText;
            this.tb_Address.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.tb_Address.Location = new System.Drawing.Point(94, 80);
            this.tb_Address.Name = "tb_Address";
            this.tb_Address.Size = new System.Drawing.Size(103, 20);
            this.tb_Address.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 83);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "DPCD Address";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 122);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "DPCD Value";
            // 
            // tb_Value
            // 
            this.tb_Value.BackColor = System.Drawing.SystemColors.HighlightText;
            this.tb_Value.Location = new System.Drawing.Point(94, 119);
            this.tb_Value.Name = "tb_Value";
            this.tb_Value.Size = new System.Drawing.Size(103, 20);
            this.tb_Value.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 174);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Bit Map";
            // 
            // btn_Read
            // 
            this.btn_Read.Location = new System.Drawing.Point(40, 225);
            this.btn_Read.Name = "btn_Read";
            this.btn_Read.Size = new System.Drawing.Size(70, 26);
            this.btn_Read.TabIndex = 5;
            this.btn_Read.Text = "Read";
            this.btn_Read.UseVisualStyleBackColor = true;
            this.btn_Read.Click += new System.EventHandler(this.btn_Read_Click);
            // 
            // btn_Write
            // 
            this.btn_Write.Location = new System.Drawing.Point(156, 225);
            this.btn_Write.Name = "btn_Write";
            this.btn_Write.Size = new System.Drawing.Size(70, 26);
            this.btn_Write.TabIndex = 6;
            this.btn_Write.Text = "Write";
            this.btn_Write.UseVisualStyleBackColor = true;
            this.btn_Write.Click += new System.EventHandler(this.btn_Write_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 43);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Display Type";
            // 
            // cb_eDP
            // 
            this.cb_eDP.AutoSize = true;
            this.cb_eDP.Location = new System.Drawing.Point(94, 44);
            this.cb_eDP.Name = "cb_eDP";
            this.cb_eDP.Size = new System.Drawing.Size(47, 17);
            this.cb_eDP.TabIndex = 8;
            this.cb_eDP.Text = "eDP";
            this.cb_eDP.UseVisualStyleBackColor = true;
            this.cb_eDP.CheckedChanged += new System.EventHandler(this.cb_eDP_CheckedChanged);
            // 
            // cb_DP
            // 
            this.cb_DP.AutoSize = true;
            this.cb_DP.Location = new System.Drawing.Point(156, 44);
            this.cb_DP.Name = "cb_DP";
            this.cb_DP.Size = new System.Drawing.Size(41, 17);
            this.cb_DP.TabIndex = 9;
            this.cb_DP.Text = "DP";
            this.cb_DP.UseVisualStyleBackColor = true;
            this.cb_DP.CheckedChanged += new System.EventHandler(this.cb_DP_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.tb_B6);
            this.groupBox1.Controls.Add(this.tb_B5);
            this.groupBox1.Controls.Add(this.tb_B4);
            this.groupBox1.Controls.Add(this.tb_B3);
            this.groupBox1.Controls.Add(this.tb_B2);
            this.groupBox1.Controls.Add(this.tb_B1);
            this.groupBox1.Controls.Add(this.tb_B0);
            this.groupBox1.Controls.Add(this.tb_B7);
            this.groupBox1.Controls.Add(this.cb_DP);
            this.groupBox1.Controls.Add(this.cb_eDP);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.btn_Write);
            this.groupBox1.Controls.Add(this.btn_Read);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.tb_Value);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.tb_Address);
            this.groupBox1.Location = new System.Drawing.Point(22, 14);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(276, 274);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(92, 156);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(171, 13);
            this.label5.TabIndex = 18;
            this.label5.Text = "B7   B6   B5   B4   B3  B2   B1   B0";
            // 
            // tb_B6
            // 
            this.tb_B6.BackColor = System.Drawing.SystemColors.Info;
            this.tb_B6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_B6.Location = new System.Drawing.Point(116, 172);
            this.tb_B6.Name = "tb_B6";
            this.tb_B6.ReadOnly = true;
            this.tb_B6.Size = new System.Drawing.Size(15, 22);
            this.tb_B6.TabIndex = 17;
            // 
            // tb_B5
            // 
            this.tb_B5.BackColor = System.Drawing.SystemColors.Info;
            this.tb_B5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_B5.Location = new System.Drawing.Point(137, 172);
            this.tb_B5.Name = "tb_B5";
            this.tb_B5.ReadOnly = true;
            this.tb_B5.Size = new System.Drawing.Size(15, 22);
            this.tb_B5.TabIndex = 16;
            // 
            // tb_B4
            // 
            this.tb_B4.BackColor = System.Drawing.SystemColors.Info;
            this.tb_B4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_B4.Location = new System.Drawing.Point(158, 172);
            this.tb_B4.Name = "tb_B4";
            this.tb_B4.ReadOnly = true;
            this.tb_B4.Size = new System.Drawing.Size(15, 22);
            this.tb_B4.TabIndex = 15;
            // 
            // tb_B3
            // 
            this.tb_B3.BackColor = System.Drawing.SystemColors.Info;
            this.tb_B3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_B3.Location = new System.Drawing.Point(179, 172);
            this.tb_B3.Name = "tb_B3";
            this.tb_B3.ReadOnly = true;
            this.tb_B3.Size = new System.Drawing.Size(15, 22);
            this.tb_B3.TabIndex = 14;
            // 
            // tb_B2
            // 
            this.tb_B2.BackColor = System.Drawing.SystemColors.Info;
            this.tb_B2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_B2.Location = new System.Drawing.Point(200, 171);
            this.tb_B2.Name = "tb_B2";
            this.tb_B2.ReadOnly = true;
            this.tb_B2.Size = new System.Drawing.Size(15, 22);
            this.tb_B2.TabIndex = 13;
            // 
            // tb_B1
            // 
            this.tb_B1.BackColor = System.Drawing.SystemColors.Info;
            this.tb_B1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_B1.Location = new System.Drawing.Point(221, 172);
            this.tb_B1.Name = "tb_B1";
            this.tb_B1.ReadOnly = true;
            this.tb_B1.Size = new System.Drawing.Size(15, 22);
            this.tb_B1.TabIndex = 12;
            // 
            // tb_B0
            // 
            this.tb_B0.BackColor = System.Drawing.SystemColors.Info;
            this.tb_B0.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_B0.Location = new System.Drawing.Point(242, 172);
            this.tb_B0.Name = "tb_B0";
            this.tb_B0.ReadOnly = true;
            this.tb_B0.Size = new System.Drawing.Size(15, 22);
            this.tb_B0.TabIndex = 11;
            // 
            // tb_B7
            // 
            this.tb_B7.BackColor = System.Drawing.SystemColors.Info;
            this.tb_B7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_B7.Location = new System.Drawing.Point(95, 172);
            this.tb_B7.Name = "tb_B7";
            this.tb_B7.ReadOnly = true;
            this.tb_B7.Size = new System.Drawing.Size(15, 22);
            this.tb_B7.TabIndex = 10;
            // 
            // DPCD_MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(323, 314);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(339, 352);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(339, 352);
            this.Name = "DPCD_MainWindow";
            this.Text = "DPCD RW";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox tb_Address;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_Value;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_Read;
        private System.Windows.Forms.Button btn_Write;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox cb_eDP;
        private System.Windows.Forms.CheckBox cb_DP;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_B6;
        private System.Windows.Forms.TextBox tb_B5;
        private System.Windows.Forms.TextBox tb_B4;
        private System.Windows.Forms.TextBox tb_B3;
        private System.Windows.Forms.TextBox tb_B2;
        private System.Windows.Forms.TextBox tb_B1;
        private System.Windows.Forms.TextBox tb_B0;
        private System.Windows.Forms.TextBox tb_B7;

    }
}

