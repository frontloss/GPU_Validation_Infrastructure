﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Input;

using IgfxExtBridge_DotNet;
using System.IO;
using System.Diagnostics;

namespace DPCD_RW
{
    public partial class DPCD_MainWindow : Form
    {
        const uint IGFX_I2C_AUX_READ = 9;
        const uint IGFX_I2C_AUX_WRITE = 8;
        const uint IGFX_INVALID_AUX_DEVICE = 0x0043;
        const uint IGFX_INVALID_AUX_ADDRESS = 0x0044;
        const uint IGFX_INVALID_AUX_DATA_SIZE = 0x0045;
        const uint IGFX_AUX_DEFER = 0x0046;
        const uint IGFX_AUX_TIMEOUT = 0x0047;
        const uint size = 1;
        uint monitorID = 0;
        
        public DPCD_MainWindow()
        {
            InitializeComponent();
        }

        private void btn_Read_Click(object sender, EventArgs e)
        {
            if (!((cb_DP.CheckState == CheckState.Checked) || (cb_eDP.CheckState == CheckState.Checked)))
            {
                MessageBox.Show("Select a display");
                return;
            }
            if (tb_Address.Text == "")
            {
                MessageBox.Show("Enter address");
                return;
            }
            if(!(System.Text.RegularExpressions.Regex.IsMatch(tb_Address.Text, @"\A\b[0-9a-fA-F]+\b\Z")))
            {
                MessageBox.Show("Enter only hex value for address");
                return;
            }
            if (tb_Address.Text.Length != 5)
            {
                MessageBox.Show("Enter 5 digit DPCD address");
                return;
            }
            GetDPCDData();
        }
                
        public void GetDPCDData()
        {
            DisplayUtil dispUtil = new DisplayUtil();
            IGFX_ERROR_CODES errorCode = new IGFX_ERROR_CODES();
            string errorDesc = "";
            IGFX_AUX_INFO InData = new IGFX_AUX_INFO();

            InData.dwDeviceUID = monitorID;
            InData.dwOpType = IGFX_I2C_AUX_READ;
            InData.dwSize = size;
            InData.dwAddress = uint.Parse(tb_Address.Text, System.Globalization.NumberStyles.AllowHexSpecifier);

            dispUtil.GetAuxInfo(ref InData, out errorCode, out errorDesc);
            if (IGFX_ERROR_CODES.IGFX_SUCCESS == errorCode)
            {
                //Array.Copy(InData.Data, buffer, size);
                DisplayResults(InData.Data[0]);
                return;
            }
            else
            {
                if ((uint)errorCode == IGFX_INVALID_AUX_DEVICE)
                    MessageBox.Show("Invalid AUX device error. Please try again");
                else if ((uint)errorCode == IGFX_INVALID_AUX_ADDRESS)
                    MessageBox.Show("Invalid AUX address error. Please try again");
                else if ((uint)errorCode == IGFX_INVALID_AUX_DATA_SIZE)
                    MessageBox.Show("Invalid AUX data size error. Please try again");
                else if ((uint)errorCode == IGFX_AUX_DEFER)
                    MessageBox.Show("AUX defer error. Please try again");
                else if ((uint)errorCode == IGFX_AUX_TIMEOUT)
                    MessageBox.Show("AUX timeout error. Please try again");
                else
                    MessageBox.Show("Call FAILED. Please try again");

                return;
            }
        }

        private void DisplayResults(byte DPCDValue)
        {
            tb_Value.Text = DPCDValue.ToString("X");
            byte bitValue = 0;
            for (int i = 0; i <= 7; i++)
            {
                bitValue = (byte)((DPCDValue >> i) & 0x01);
                switch (i)
                {
                    case 0:
                        tb_B0.Text = bitValue.ToString();
                        break;
                    case 1:
                        tb_B1.Text = bitValue.ToString();
                        break;
                    case 2:
                        tb_B2.Text = bitValue.ToString();
                        break;
                    case 3:
                        tb_B3.Text = bitValue.ToString();
                        break;
                    case 4:
                        tb_B4.Text = bitValue.ToString();
                        break;
                    case 5:
                        tb_B5.Text = bitValue.ToString();
                        break;
                    case 6:
                        tb_B6.Text = bitValue.ToString();
                        break;
                    case 7:
                        tb_B7.Text = bitValue.ToString();
                        break;
                    default:
                        MessageBox.Show("Something's terrible has happened!!!");
                        break;
                }
            }

        }

        public void SetDPCDData()
        {
            DisplayUtil dispUtil = new DisplayUtil();
            IGFX_ERROR_CODES errorCode = new IGFX_ERROR_CODES();
            string errorDesc = "";
            IGFX_AUX_INFO OutData = new IGFX_AUX_INFO();
            byte[] buffer = new byte[1];
            buffer[0] = Byte.Parse(tb_Value.Text, System.Globalization.NumberStyles.AllowHexSpecifier);

            OutData.dwDeviceUID = monitorID;
            OutData.dwOpType = IGFX_I2C_AUX_WRITE;
            OutData.dwSize = size;
            OutData.dwAddress = UInt32.Parse(tb_Address.Text, System.Globalization.NumberStyles.AllowHexSpecifier);

            dispUtil.SetAuxInfo(ref OutData, out errorCode, out errorDesc);
            if (IGFX_ERROR_CODES.IGFX_SUCCESS == errorCode)
            {
                GetDPCDData();
                return;
            }
            else
            {
                if ((uint)errorCode == IGFX_INVALID_AUX_DEVICE)
                    MessageBox.Show("Invalid AUX device error. Please try again");
                else if ((uint)errorCode == IGFX_INVALID_AUX_ADDRESS)
                    MessageBox.Show("Invalid AUX address error. Please try again");
                else if ((uint)errorCode == IGFX_INVALID_AUX_DATA_SIZE)
                    MessageBox.Show("Invalid AUX data size error. Please try again");
                else if ((uint)errorCode == IGFX_AUX_DEFER)
                    MessageBox.Show("AUX defer error. Please try again");
                else if ((uint)errorCode == IGFX_AUX_TIMEOUT)
                    MessageBox.Show("AUX timeout error. Please try again");
                else
                    MessageBox.Show("Call FAILED. Please try again");

                return;
            }
        }

        private void cb_eDP_CheckedChanged(object sender, EventArgs e)
        {
            if (cb_eDP.CheckState == CheckState.Unchecked)
            {
                cb_DP.Enabled = true;
            }
            if (cb_eDP.CheckState == CheckState.Checked)
            {
                cb_DP.Enabled = false;
                monitorID = 4096;
            }
        }

        private void cb_DP_CheckedChanged(object sender, EventArgs e)
        {
            if (cb_DP.CheckState == CheckState.Unchecked)
            {
                cb_eDP.Enabled = true;
            }
            if (cb_DP.CheckState == CheckState.Checked)
            {
                cb_eDP.Enabled = false;
                monitorID = 256;
            }
        }

        private void btn_Write_Click(object sender, EventArgs e)
        {
            if (!((cb_DP.CheckState == CheckState.Checked) || (cb_eDP.CheckState == CheckState.Checked)))
            {
                MessageBox.Show("Select a display");
                return;
            }
            if (tb_Address.Text == "")
            {
                MessageBox.Show("Enter address");
                return;
            }
            if (!(System.Text.RegularExpressions.Regex.IsMatch(tb_Address.Text, @"\A\b[0-9a-fA-F]+\b\Z")))
            {
                MessageBox.Show("Enter only hex value for address");
                return;
            }
            if (tb_Address.Text.Length != 5)
            {
                MessageBox.Show("Enter 5 digit DPCD address");
                return;
            }
            if(tb_Value == null)
            {
                MessageBox.Show("Enter Value");
                return;
            }
            if (!(System.Text.RegularExpressions.Regex.IsMatch(tb_Value.Text, @"\A\b[0-9a-fA-F]+\b\Z")))
            {
                MessageBox.Show("Enter only hex value for DPCD value field");
                return;
            }
            if (tb_Value.Text.Length != 2)
            {
                MessageBox.Show("Enter 2 digit DPCD value to write");
                return;
            }

            SetDPCDData();
        }
    }
}
