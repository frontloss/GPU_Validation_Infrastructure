############################################################################################################
# \file
# \addtogroup PyLibs_ValDiInterface
# \brief Python internal library module to interact with OS CCD API's
# \ref ccdapi.py exposes below functions/ APIs:
# <ul>
# <li> @ref query_display_config   \n \copybrief query_display_config \n
# <li> @ref get_active_target_ids   \n \copybrief get_active_target_ids \n
# <li> @ref get_monitor_info        \n \copybrief get_monitor_info \n
# <li> @ref get_source_mode         \n \copybrief get_source_mode \n
# <br>
# </ul>
# \remarks For more informat about CCD API's refer below link
# https://msdn.microsoft.com/en-us/library/windows/hardware/hh406259(v=vs.85).aspx
# @author Beeresh
############################################################################################################


import logging
import unicodedata
from ccdapi_header import *


##
# @brief Internal function to get the QDC details
#
# @return dictionary of path_count, path_array, mode_count and mode_array
def query_display_config(query_mode='ACTIVE'):
    numPathArrayElements = ctypes.c_uint32()
    pNumPathArrayElements = ctypes.byref(numPathArrayElements)
    numModeInfoArrayElements = ctypes.c_uint32()
    pNumModeInfoArrayElements = ctypes.byref(numModeInfoArrayElements)

    errFlag = ctypes.windll.user32.GetDisplayConfigBufferSizes(QDC_ONLY_ACTIVE_PATHS, pNumPathArrayElements,
                                                               pNumModeInfoArrayElements)
    if errFlag != 0:
        logging.error('GetDisplayConfigBufferSizes failed (error ' + str(errFlag) + ')!')
        return None

    pPathInfoArray = (DISPLAYCONFIG_PATH_INFO * numPathArrayElements.value)()
    pModeInfoArray = (DISPLAYCONFIG_MODE_INFO * numModeInfoArrayElements.value)()

    errFlag = ctypes.windll.user32.QueryDisplayConfig(QDC_ONLY_ACTIVE_PATHS, pNumPathArrayElements, pPathInfoArray,
                                                      pNumModeInfoArrayElements, pModeInfoArray, None)
    if errFlag != 0:
        logging.error('QueryDisplayConfig failed (error ' + str(errFlag) + ')!')
        return None

    result = {'PATH_COUNT': numPathArrayElements.value,
               'MODE_COUNT': numModeInfoArrayElements.value,
               'PATHS': pPathInfoArray,
               'MODES': pModeInfoArray
               }

    return result


##
# @brief Return the list of targetid of the currently active displays
#
# @return List of targetids(integer)
def get_active_target_ids():
    target_ids = []

    result = query_display_config()
    path_count = result['PATH_COUNT']
    path_array = result['PATHS']

    for i in range(path_count):
        pathinfo = path_array[i]
        target_ids.append(pathinfo.targetInfo.id)

    return target_ids



##
# @brief Return the refresh rate for the given targetid
#
# @param[in] target_id representing the display
# @return float representing refresh rate or None
def get_refresh_rate(target_id):
    result = query_display_config()
    path_count = result['PATH_COUNT']
    path_array = result['PATHS']

    for i in range(path_count):
        pathinfo = path_array[i]
        current_targetid = pathinfo.targetInfo.id
        masked_targetid = current_targetid & 0xFFFFF

        if current_targetid == target_id or masked_targetid == target_id:
            rr = pathinfo.targetInfo.refreshRate.numerator / pathinfo.targetInfo.refreshRate.denominator
            return rr


    return None


##
# @brief Return the monitor details for given targetid
#
# @param[in] targetid representing the display
# @return object of DISPLAYCONFIG_TARGET_DEVICE_NAME
def get_monitor_info(target_id):
    monitor_info = None

    result = query_display_config()
    path_count = result['PATH_COUNT']
    path_array = result['PATHS']

    for i in range(path_count):
        pathinfo = path_array[i]
        current_targetid = pathinfo.targetInfo.id
        masked_targetid = current_targetid & 0xFFFFF

        if current_targetid == target_id or masked_targetid == target_id:
            header = DISPLAYCONFIG_DEVICE_INFO_HEADER()
            header.size = ctypes.sizeof(DISPLAYCONFIG_TARGET_DEVICE_NAME)
            header.type = DISPLAYCONFIG_DEVICE_INFO_GET_TARGET_NAME
            header.adapterId = pathinfo.targetInfo.adapterId
            header.id = pathinfo.targetInfo.id

            config = DISPLAYCONFIG_TARGET_DEVICE_NAME()
            config.header = header
            pHeader = ctypes.byref(config.header)
            errFlag = ctypes.windll.user32.DisplayConfigGetDeviceInfo(pHeader)
            if errFlag != 0:
                logging.error('DisplayConfigGetDeviceInfo failed (error ' + str(errFlag) + ')!')

            #monitor_path = unicodedata.normalize('NFKD', monitor_path).encode('ascii', 'ignore')
            monitor_info = config
    return monitor_info


##
# @brief Return the source mode information for given targetid
#
# @param[in] targetid representing the display
# @return object of DISPLAYCONFIG_SOURCE_MODE
def get_source_mode(target_id):
    source_mode = None

    result = query_display_config()
    mode_count = result['MODE_COUNT']
    modes = result['MODES']

    capture = False
    for idx in range(mode_count):
        current_mode = modes[idx]
        if current_mode.infoType == DISPLAYCONFIG_MODE_INFO_TYPE_Target:
            current_targetid = current_mode.id
            masked_targetid = current_targetid & 0xFFFFF

            if current_targetid == target_id or masked_targetid == target_id:
                capture = True

        if current_mode.infoType == DISPLAYCONFIG_MODE_INFO_TYPE_Source and capture:
            source_mode = current_mode.mode.sourceMode
            break

    return source_mode

if __name__ == "__main__":
    target_id = 265988
    val = get_monitor_info(target_id)
    print(val, type(val))

    get_source_mode(target_id)
    val = get_refresh_rate(target_id)
    refresh_rate = val
    custom_pattern = []
    PATTERN_COUNT = 5

    #10% compensation
    FLIP_SWING_IN_PERCENT = 4
    MEDIA_STACK_COMPENSATION = (refresh_rate * FLIP_SWING_IN_PERCENT/100)
    threshold_flips  = refresh_rate - MEDIA_STACK_COMPENSATION
    flip_count = int(threshold_flips * PATTERN_COUNT)

    print (refresh_rate, int(flip_count))
    for i in range(PATTERN_COUNT):
        custom_pattern.append(flip_count)
