############################################################################################################
# \file
# \addtogroup PyLibs_ValDiAPI
# \brief ValDi interface library to start and stop ValDi driver
# \ref valdi_api.py is a interface to ValDi driver
# <ul>
# <li> @ref start_tracing         	</li><br> @copybrief start_tracing
# <li> @ref stop_tracing         	</li><br> @copybrief stop_tracing
# <li> @ref get_vbt         	    </li><br> @copybrief get_vbt
# </li>
# </ul>
# @author Beeresh, Bharath
############################################################################################################

import glob, os, time, logging, datetime, shutil
import winreg
from subprocess import check_call, check_output
import subprocess

from Libs.Core.test_env.test_context import *
from Libs.Core.system_utility import *
from TalkToValDi import *
from Libs.Feature.display_engine.de_base.display_base import *
from Libs.Core.display_config.display_config import *

LEGACY_PRE_VALDI_BAT = os.path.join(TEST_STORE_FOLDER, r"Setup\ValDi\legacy_pre.bat")
YANGRA_PRE_VALDI_BAT = os.path.join(TEST_STORE_FOLDER, r"Setup\ValDi\yangra_pre.bat")
VALDI_LOG_STORE = r'C:\temp'

ROOT_FOLDER = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
LOGS_FOLDER = os.path.join(ROOT_FOLDER, "Logs")
PARSER_OUTPUT_FILE = os.path.join(LOGS_FOLDER, "crc_parser.out")


##
# Display Panel simulation port config
class _Port2PipeConfig(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ("PORT_INDX_1", ctypes.c_uint32, 4),  # 0 - 3
        ("PIPE_INDX_1", ctypes.c_uint32, 4),  # 4 - 7
        ("PORT_INDX_2", ctypes.c_uint32, 4),  # 8 - 11
        ("PIPE_INDX_2", ctypes.c_uint32, 4),  # 12 - 15
        ("PORT_INDX_3", ctypes.c_uint32, 4),  # 16 - 19
        ("PIPE_INDX_3", ctypes.c_uint32, 4),  # 20 - 23
        ("PORT_INDX_4", ctypes.c_uint32, 4),  # 24 - 27
        ("PIPE_INDX_4", ctypes.c_uint32, 4),  # 27 - 31
    ]


##
# Simulated Port configuration structure
class Port2PipeConfig(ctypes.Union):
    _anonymous_ = ("u",)
    _fields_ = [
        ("u", _Port2PipeConfig),
        ("Value", ctypes.c_uint32)]


def _check_valdi_binaries():
    if not os.path.exists(LOGS_FOLDER):
        os.makedirs(LOGS_FOLDER)
    system_utility = SystemUtility()
    if system_utility.is_ddrw():
        PRE_VALDI_BAT = YANGRA_PRE_VALDI_BAT
    else:
        PRE_VALDI_BAT = LEGACY_PRE_VALDI_BAT

    if not os.path.isfile(PRE_VALDI_BAT):
        error_msg = "%s file missing!!" % PRE_VALDI_BAT
        logging.error(error_msg)
        raise Exception(error_msg)


## Internal function to write Port2Pipe mapping details to ValDi driver
def __encode_port_2_pipe(port2pipe):
    dft_reg_path = r'SOFTWARE\Intel\Display'
    nibble_idx = 0
    DUMMY_PORT_NO = 99
    DWORD_SIZE = 4
    # Port base index value in Yangra
    PORT_BASE_INDEX = 11

    obj = Port2PipeConfig()
    obj.Value = 0
    portmap = obj.u
    for port_idx in sorted(port2pipe.keys()):
        pipe_idx = port2pipe[port_idx]
        # print(pipe_idx, port_idx)

        # Pack pipe, port nibble in the byte
        obj.Value |= pipe_idx << (DWORD_SIZE * (nibble_idx + 1))
        obj.Value |= (port_idx + PORT_BASE_INDEX) << (DWORD_SIZE * nibble_idx)

        # Increment two nibble
        nibble_idx += 2

    root_key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, dft_reg_path, 0, winreg.KEY_WRITE)
    # print(key, dword_data, type(key), type(dword_data))
    winreg.SetValueEx(root_key, "PORT2PIPECONFIG", 0, winreg.REG_DWORD, obj.Value)
    winreg.CloseKey(root_key)

    valdi_obj = ValDi()
    # Dummy call to load the updated registry data
    valdi_obj.HotPlugUnPlug(DUMMY_PORT_NO, False)
    valdi_obj.CloseHandle()

##
# Reset scrambler bit for DP panel < 1.2 version
def reset_scrambler():
    PANEL_CAPABILITY = 0xd

    # Alternative Scrambler Seed Reset(Bit 0) and (Frame capable)Bit 1
    ASSR_AND_FRAME_EN_CAPABLE_BITS = 3

    system_handle = SystemUtility()
    dispconfig = DisplayConfiguration()
    # Get the enumerated displays
    enumerated_displays = dispconfig.get_enumerated_display_info()
    edp_target_id = None
    reset = 1

    # Fetching target ID of eDP panel
    for index in range(enumerated_displays.Count):
        if CONNECTOR_PORT_TYPE(enumerated_displays.ConnectedDisplays[index].ConnectorNPortType).name == 'DP_A':
            edp_target_id = enumerated_displays.ConnectedDisplays[index].TargetID

    if edp_target_id is not None:
        # Reading 0x00000 register offset to determine eDP panel version
        # dpcd_read_flag, dpcd_value = system_handle.dpcd_read(0x00000, edp_target_id)
        # version 1.0 == 0x10 -> Not supported
        # version 1.1 == 0x11 -> Not supported
        # version 1.2 == 0x12 -> supported
        # if dpcd_read_flag:
        # panel_version = dpcd_value[0]
        # logging.info("panel version / dpcd value = %s" % hex(panel_version))
        # if 0 < panel_version < 0x11:
        #     reset = 0

        read_flag, ctype_dpcd_value = system_handle.dpcd_read(PANEL_CAPABILITY, edp_target_id)
        if ctype_dpcd_value:
            dpcd_value = ctype_dpcd_value[0]

            if not dpcd_value & ASSR_AND_FRAME_EN_CAPABLE_BITS:
                reset = 0

    logging.debug("setting scrambler register value to %s" % reset)
    # Registry key parameters
    hkey = "HKEY_LOCAL_MACHINE"
    registry_path = "HKEY_LOCAL_MACHINE\\SOFTWARE\\Intel\\Display"
    key_name = "ScramblerReset"
    key_type = enum.REG_DWORD
    key_value = reset
    try:
        ret_status = system_handle.write_registry(reg_path=registry_path, reg_name=key_name,
                                                  reg_datatype=enum.DWORD, reg_data_list= [key_value])
    except:
        logging.debug("ScramblerReset registry key not present")

##
# @brief Function to start ValDi logger
#
# Sends start command to ValDi client; which will install ValDi driver and
# initializes the logger
#
# @param[in] self reference to the instantiated object
def install_valdi():
    system_utility = SystemUtility()
    if system_utility.is_ddrw():
        PRE_VALDI_BAT = YANGRA_PRE_VALDI_BAT
    else:
        PRE_VALDI_BAT = LEGACY_PRE_VALDI_BAT

    reset_scrambler()

    _check_valdi_binaries()
    try:
        output = check_output('sc query ValDi', shell=True)
        if 'RUNNING' in output:
            # make ValDi persistent across boot
            valdi_boot_persistent()
            return True
    except:
        logging.debug("ValDi service is not installed")

    # Call pre.bat to install ValDi driver
    check_call(PRE_VALDI_BAT, shell=True)
    # sleep buffer for valdi installation and function patching
    time.sleep(5)
    # Check again to ensure ValDi service is running
    output = check_output('sc query ValDi', shell=True)
    if 'RUNNING' not in output:
        logging.error("ValDi installation failed")
        return False

    # make ValDi persistent across boot
    valdi_boot_persistent()

    # Remove stale parser file
    if os.path.exists(PARSER_OUTPUT_FILE):
        os.remove(PARSER_OUTPUT_FILE)

    return True


##
# @brief Function to start ValDi logger
#
# Sends start command to ValDi client; which will install ValDi driver and
# initializes the logger
#
# @param[in] self reference to the instantiated object
def start_tracing():
    system_handle = SystemUtility()
    if system_handle.is_ddrw():
        port2pipe_dict = get_port_to_pipe(by_index=True)
        __encode_port_2_pipe(port2pipe_dict)
        time.sleep(1)

    if os.path.exists(VALDI_LOG_STORE):
        os.chdir(VALDI_LOG_STORE)
        for file in glob.glob("*.valdi"):
            os.remove(file)

    valdi_api = ValDi()
    status = valdi_api.restartTracing()
    return status


##
# @brief Function to stop tracing in ValDi
#
# Sends stop command to ValDi client; which will stop logging and generates
# logs files. ValDi might generate multiple log files based on logging period,
# hence stitching is required to unify log files into single file. Assumption made
# that glob.glob will provide file in ascending order
#
# @param[in] self reference to the instantiated object
# @return unified log file name
def stop_tracing():
    try:
        if not os.path.exists(VALDI_LOG_STORE):
            os.makedirs(VALDI_LOG_STORE)

        valdi_api = ValDi()
        status = valdi_api.finalizeTracing()
        status = valdi_api.suspendTracing()
        time.sleep(2)
        cmd = "move /Y c:\\*.valdi %s" % (VALDI_LOG_STORE)
        subprocess.call(cmd, shell=True)
        os.chdir(VALDI_LOG_STORE)
        with open(PARSER_OUTPUT_FILE, 'w') as outputfile:
            for filepath in glob.glob("*.valdi"):
                with open(filepath) as valdi_tracelog:
                    for line in valdi_tracelog:
                        outputfile.write(line)
    except Exception as e:
        logging.error(e)
    finally:
        # Returning to current working directory to root folder
        os.chdir(ROOT_FOLDER)


TRACE_FILES_BACKUP = "C:\\trace_files"


def backup_trace_files():
    # backup folder creation
    if not os.path.exists(TRACE_FILES_BACKUP):
        os.makedirs(TRACE_FILES_BACKUP)

    try:
        new_dir = os.path.join(TRACE_FILES_BACKUP, datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S'))
        if not os.path.exists(new_dir):
            os.makedirs(new_dir)

        os.chdir(VALDI_LOG_STORE)
        for trace_file in glob.glob("*.valdi"):
            shutil.copy2(trace_file, new_dir)

        os.chdir(LOGS_FOLDER)
        for log_file in glob.glob("*.log"):
            shutil.copy2(log_file, new_dir)
    except Exception as e:
        logging.error(e)
    finally:
        # Returning to current working directory to root folder
        os.chdir(ROOT_FOLDER)


##
# @brief API to make ValDi driver persistent across boot
#
# @param[in] negative = True -> ValDi is installed OnDemand
#                     = False -> ValDi starts on boot
# Note: This action requires a system reboot to take effect
def valdi_boot_persistent(negative=False):
    if negative:
        cmd = 'sc config ValDi start= demand'
        logging.info("ValDi is installed on demand")
    else:
        logging.info("ValDi is made persistent across boot")
        cmd = 'sc config ValDi start= boot'

    subprocess.call(cmd, shell=True)
