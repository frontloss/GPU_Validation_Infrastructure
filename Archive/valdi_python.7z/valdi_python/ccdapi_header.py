'''
Name: CCDApi_Header
Desc: Header file for CCD Api's
'''
from ctypes import *
import ctypes


DISPLAYCONFIG_SOURCE_IN_USE = 0x00000001

DISPLAY_DEVICE_ATTACHED_TO_DESKTOP = 0x00000001
DISPLAY_DEVICE_MULTI_DRIVER        = 0x00000002
DISPLAY_DEVICE_PRIMARY_DEVICE      = 0x00000004
DISPLAY_DEVICE_MIRRORING_DRIVER    = 0x00000008
DISPLAY_DEVICE_VGA_COMPATIBLE      = 0x00000010
DISPLAY_DEVICE_REMOVABLE           = 0x00000020
DISPLAY_DEVICE_MODESPRUNED         = 0x08000000
DISPLAY_DEVICE_REMOTE              = 0x04000000
DISPLAY_DEVICE_DISCONNECT          = 0x02000000
DISPLAY_DEVICE_ACTIVE              = 0x00000001
DISPLAY_DEVICE_ATTACHED            = 0x00000002



QDC_ZERO = 0x0
QDC_ALL_PATHS  = 0x00000001
QDC_ONLY_ACTIVE_PATHS =0x00000002
QDC_DATABASE_CURRENT = 0x00000004
QDC_VIRTUAL_MODE_AWARE = 0x00000008




DISPLAYCONFIG_ROTATION_IDENTITY = 1
DISPLAYCONFIG_ROTATION_ROTATE90 = 2
DISPLAYCONFIG_ROTATION_ROTATE180 = 3
DISPLAYCONFIG_ROTATION_ROTATE270 = 4
DISPLAYCONFIG_ROTATION_FORCE_UINT32 = 0xFFFFFFFF


DISPLAYCONFIG_OUTPUT_TECHNOLOGY_HD15 = 0
DISPLAYCONFIG_OUTPUT_TECHNOLOGY_SVIDEO = 1
DISPLAYCONFIG_OUTPUT_TECHNOLOGY_COMPOSITE_VIDEO = 2
DISPLAYCONFIG_OUTPUT_TECHNOLOGY_COMPONENT_VIDEO = 3
DISPLAYCONFIG_OUTPUT_TECHNOLOGY_DVI = 4
DISPLAYCONFIG_OUTPUT_TECHNOLOGY_HDMI = 5
DISPLAYCONFIG_OUTPUT_TECHNOLOGY_LVDS = 6
DISPLAYCONFIG_OUTPUT_TECHNOLOGY_D_JPN = 8
DISPLAYCONFIG_OUTPUT_TECHNOLOGY_SDI = 9
DISPLAYCONFIG_OUTPUT_TECHNOLOGY_DISPLAYPORT_EXTERNAL = 10
DISPLAYCONFIG_OUTPUT_TECHNOLOGY_DISPLAYPORT_EMBEDDED = 11
DISPLAYCONFIG_OUTPUT_TECHNOLOGY_UDI_EXTERNAL = 12
DISPLAYCONFIG_OUTPUT_TECHNOLOGY_UDI_EMBEDDED = 13
DISPLAYCONFIG_OUTPUT_TECHNOLOGY_SDTVDONGLE = 14
DISPLAYCONFIG_OUTPUT_TECHNOLOGY_INTERNAL = 0x80000000
DISPLAYCONFIG_OUTPUT_TECHNOLOGY_FORCE_UINT32 = 0xFFFFFFFF


SDC_ZERO = 0
SDC_TOPOLOGY_INTERNAL = 0X00000001
SDC_TOPOLOGY_CLONE = 0X00000002
SDC_TOPOLOGY_EXTEND = 0X00000004
SDC_TOPOLOGY_EXTERNAL = 0X00000008
SDC_TOPOLOGY_SUPPLIED = 0X00000010
SDC_USE_SUPPLIED_DISPLAY_CONFIG = 0X00000020
SDC_VALIDATE = 0X00000040
SDC_APPLY = 0X00000080
SDC_NOOPTIMIZATION = 0X00000100
SDC_SAVETODATABASE = 0X00000200
SDC_ALLOW_CHANGES = 0X00000400
SDC_PATHPERSISTIFREQUIRED = 0X00000800
SDC_FORCEMODEENUMERATION = 0X00001000
SDC_ALLOWPATHORDERCHANGES = 0X00002000
SDC_USEDATABASECURRENT = SDC_TOPOLOGY_INTERNAL | SDC_TOPOLOGY_CLONE | SDC_TOPOLOGY_EXTEND | SDC_TOPOLOGY_EXTERNAL


DisplayConfigFlags_Zero = 0x0
DisplayConfigFlags_PathActive = 0x00000001


DisplayConfigTargetStatus_Zero = 0x0
DisplayConfigTargetStatus_InUse = 0x00000001
DisplayConfigTargetStatus_FORCIBLE = 0x00000002
DisplayConfigTargetStatus_ForcedAvailabilityBoot = 0x00000004
DisplayConfigTargetStatus_ForcedAvailabilityPath = 0x00000008
DisplayConfigTargetStatus_ForcedAvailabilitySystem = 0x00000010



DISPLAYCONFIG_SCALING_IDENTITY = 1
DISPLAYCONFIG_SCALING_CENTERED = 2
DISPLAYCONFIG_SCALING_STRETCHED = 3
DISPLAYCONFIG_SCALING_ASPECTRATIO_CENTEREDMAX = 4
DISPLAYCONFIG_SCALING_CUSTOM = 5
DISPLAYCONFIG_SCALING_PREFERRED = 128
DISPLAYCONFIG_SCALING_FORCE_UINT32 = 0xFFFFFFFF


DISPLAYCONFIG_PIXELFORMAT_ZERO = 0
DISPLAYCONFIG_PIXELFORMAT_8BPP = 1
DISPLAYCONFIG_PIXELFORMAT_16BPP = 2
DISPLAYCONFIG_PIXELFORMAT_24BPP = 3
DISPLAYCONFIG_PIXELFORMAT_32BPP = 4
DISPLAYCONFIG_PIXELFORMAT_NONGDI = 5
DISPLAYCONFIG_PIXELFORMAT_FORCE_UINT32 = 0xffffffff



DISPLAYCONFIG_SCANLINE_ORDERING_PROGRESSIVE = 1
DISPLAYCONFIG_SCANLINE_ORDERING_INTERLACED = 2
DISPLAYCONFIG_SCANLINE_ORDERING_INTERLACED_UPPERFIELDFIRST = DISPLAYCONFIG_SCANLINE_ORDERING_INTERLACED
DISPLAYCONFIG_SCANLINE_ORDERING_INTERLACED_LOWERFIELDFIRST = 3
DISPLAYCONFIG_SCANLINE_ORDERING_FORCE_UINT32 = 0xFFFFFFFF


DISPLAYCONFIG_MODE_INFO_TYPE_Zero = 0
DISPLAYCONFIG_MODE_INFO_TYPE_Source = 1
DISPLAYCONFIG_MODE_INFO_TYPE_Target = 2
DISPLAYCONFIG_MODE_INFO_TYPE_ForceUint32 = 0xFFFFFFFF


D3DmdtVideoSignalStandard_Uninitialized = 0
D3DmdtVideoSignalStandard_VesaDmt = 1
D3DmdtVideoSignalStandard_VesaGtf = 2
D3DmdtVideoSignalStandard_VesaCvt = 3
D3DmdtVideoSignalStandard_Ibm = 4
D3DmdtVideoSignalStandard_Apple = 5
D3DmdtVideoSignalStandard_NtscM = 6
D3DmdtVideoSignalStandard_NtscJ = 7
D3DmdtVideoSignalStandard_Ntsc443 = 8
D3DmdtVideoSignalStandard_PalB = 9
D3DmdtVideoSignalStandard_PalB1 = 10
D3DmdtVideoSignalStandard_PalG = 11
D3DmdtVideoSignalStandard_PalH = 12
D3DmdtVideoSignalStandard_PalI = 13
D3DmdtVideoSignalStandard_PalD = 14
D3DmdtVideoSignalStandard_PalN = 15
D3DmdtVideoSignalStandard_PalNc = 16
D3DmdtVideoSignalStandard_SecamB = 17
D3DmdtVideoSignalStandard_SecamD = 18
D3DmdtVideoSignalStandard_SecamG = 19
D3DmdtVideoSignalStandard_SecamH = 20
D3DmdtVideoSignalStandard_SecamK = 21
D3DmdtVideoSignalStandard_SecamK1 = 22
D3DmdtVideoSignalStandard_SecamL = 23
D3DmdtVideoSignalStandard_SecamL1 = 24
D3DmdtVideoSignalStandard_Eia861 = 25
D3DmdtVideoSignalStandard_Eia861A = 26
D3DmdtVideoSignalStandard_Eia861B = 27
D3DmdtVideoSignalStandard_PalK = 28
D3DmdtVideoSignalStandard_PalK1 = 29
D3DmdtVideoSignalStandard_PalL = 30
D3DmdtVideoSignalStandard_PalM = 31
D3DmdtVideoSignalStandard_Other = 255

DISPLAYCONFIG_DEVICE_INFO_GET_SOURCE_NAME                 = 1,
DISPLAYCONFIG_DEVICE_INFO_GET_TARGET_NAME                 = 2,
DISPLAYCONFIG_DEVICE_INFO_GET_TARGET_PREFERRED_MODE       = 3,
DISPLAYCONFIG_DEVICE_INFO_GET_ADAPTER_NAME                = 4,
DISPLAYCONFIG_DEVICE_INFO_SET_TARGET_PERSISTENCE          = 5,
DISPLAYCONFIG_DEVICE_INFO_GET_TARGET_BASE_TYPE            = 6,
DISPLAYCONFIG_DEVICE_INFO_GET_SUPPORT_VIRTUAL_RESOLUTION  = 7,
DISPLAYCONFIG_DEVICE_INFO_SET_SUPPORT_VIRTUAL_RESOLUTION  = 8,
DISPLAYCONFIG_DEVICE_INFO_FORCE_UINT32                    = 0xFFFFFFFF






'''
def dump(obj):    
    for k,v in obj.__class__.__dict__.items():        
        print k ,v
        if hasattr(v,'__class__.__dict__'):
            dump(v)
'''

class LUID(ctypes.LittleEndianStructure):
    _fields_ = [
        ('LowPart', ctypes.c_uint32),
        ('HighPart', ctypes.c_uint32),
    ]


class DISPLAYCONFIG_RATIONAL(ctypes.LittleEndianStructure):
    _fields_ = [
        ('numerator', ctypes.c_uint32),
        ('denominator', ctypes.c_uint32),
    ]


class DISPLAYCONFIG_PATH_SOURCE_INFO(ctypes.LittleEndianStructure):
    _fields_ = [
        ("adapterId", LUID),
        ("id", ctypes.c_uint32),
        ("modeInfoIdx", ctypes.c_uint32),
        ("statusFlags", ctypes.c_uint32),
    ]


class DISPLAYCONFIG_PATH_TARGET_INFO (ctypes.LittleEndianStructure):
    _fields_ = [
        ("adapterId", LUID),
        ("id", ctypes.c_uint32),
        ("modeInfoIdx", ctypes.c_uint32),
        ("outputTechnology", ctypes.c_uint32),
        ("rotation", ctypes.c_uint32),
        ("scaling", ctypes.c_uint32),
        ("refreshRate", DISPLAYCONFIG_RATIONAL),
        ("scanLineOrdering", ctypes.c_uint32),
        ("targetAvailable", ctypes.c_uint),
        ("statusFlags", ctypes.c_uint32),
    ]


class DISPLAYCONFIG_PATH_INFO(ctypes.LittleEndianStructure):
    _fields_ = [
        ("sourceInfo", DISPLAYCONFIG_PATH_SOURCE_INFO ),
        ("targetInfo", DISPLAYCONFIG_PATH_TARGET_INFO  ),
        ("flags", ctypes.c_uint32 ) ]



class RECTL(ctypes.LittleEndianStructure):
    _fields_ = [
        ("left", ctypes.c_long),
        ("top", ctypes.c_long),
        ("right", ctypes.c_long),
        ("bottom", ctypes.c_long),
        ]



class POINTL(ctypes.LittleEndianStructure):
    _fields_ = [
        ("x", ctypes.c_int),
        ("y", ctypes.c_int),
        ]


class DISPLAYCONFIG_DESKTOP_IMAGE_INFO(ctypes.LittleEndianStructure):
    _fields_ = [
                ("PathSourceSize", POINTL),
                ("DesktopImageRegion", RECTL),
                ("DesktopImageClip", RECTL),
            ]


class DISPLAYCONFIG_2DREGION(ctypes.LittleEndianStructure):
        _fields_ = [
            ("cx", ctypes.c_uint32),
            ("cy", ctypes.c_uint32),
        ]


 
class DisplayConfigVideoSignalInfo(ctypes.LittleEndianStructure):
        _fields_ = [
                ("pixelRate", ctypes.c_uint64),
                ("hSyncFreq", DISPLAYCONFIG_RATIONAL),
                ("vSyncFreq", DISPLAYCONFIG_RATIONAL),
                ("activeSize", DISPLAYCONFIG_2DREGION),
                ("totalSize", DISPLAYCONFIG_2DREGION),
                ("videoStandard", ctypes.c_uint32),
                ("scanLineOrdering", ctypes.c_uint32),
            ]

        def __str__(self):
            value_list = (self.pixelRate, self.videoStandard, self.scanLineOrdering)
            strValue = ("pixelRate=%d videoStandard=%d scanLineOrdering=%d"%(value_list))
            return strValue



class DISPLAYCONFIG_TARGET_MODE(ctypes.LittleEndianStructure):
    _fields_ = [
        ("targetVideoSignalInfo", DisplayConfigVideoSignalInfo),
    ]
        

class DISPLAYCONFIG_SOURCE_MODE(ctypes.LittleEndianStructure):
    _fields_ = [
        ("width", ctypes.c_uint32),
        ("height", ctypes.c_uint32),
        ("pixelFormat", ctypes.c_uint32),
        ("position", POINTL),
    ]


class DISPLAYCONFIG_MODE_INFO_UNION( ctypes.Union ):
    _fields_ = [
        ("targetMode", DISPLAYCONFIG_TARGET_MODE),
        ("sourceMode", DISPLAYCONFIG_SOURCE_MODE),
      #  ("desktopImageInfo", DISPLAYCONFIG_DESKTOP_IMAGE_INFO)
    ]
        

class DISPLAYCONFIG_MODE_INFO(ctypes.LittleEndianStructure):
    _fields_ = [
        ("infoType",  ctypes.c_uint32),
        ("id", ctypes.c_uint32),
        ("adapterId", LUID),
        ("mode", DISPLAYCONFIG_MODE_INFO_UNION)
        ]


#DisplayConfigGetDeviceInfo specific data structure

DISPLAYCONFIG_DEVICE_INFO_GET_SOURCE_NAME                 = 1
DISPLAYCONFIG_DEVICE_INFO_GET_TARGET_NAME                 = 2
DISPLAYCONFIG_DEVICE_INFO_GET_TARGET_PREFERRED_MODE       = 3
DISPLAYCONFIG_DEVICE_INFO_GET_ADAPTER_NAME                = 4
DISPLAYCONFIG_DEVICE_INFO_SET_TARGET_PERSISTENCE          = 5
DISPLAYCONFIG_DEVICE_INFO_GET_TARGET_BASE_TYPE            = 6
DISPLAYCONFIG_DEVICE_INFO_GET_SUPPORT_VIRTUAL_RESOLUTION  = 7
DISPLAYCONFIG_DEVICE_INFO_SET_SUPPORT_VIRTUAL_RESOLUTION  = 8
DISPLAYCONFIG_DEVICE_INFO_FORCE_UINT32                    = 0xFFFFFFFF


CCHDEVICENAME = 32


class DISPLAYCONFIG_DEVICE_INFO_HEADER(ctypes.LittleEndianStructure):
    _fields_ = [
        ("type",  ctypes.c_uint32),
        ("size", ctypes.c_uint32),
        ("adapterId", LUID),
        ("id", ctypes.c_uint32)
    ]



class DISPLAYCONFIG_SOURCE_DEVICE_NAME(ctypes.LittleEndianStructure):
    _fields_ = [
        ("header", DISPLAYCONFIG_DEVICE_INFO_HEADER),
        ("viewGdiDeviceName",  ctypes.c_wchar * CCHDEVICENAME)
    ]


class  DISPLAYCONFIG_TARGET_DEVICE_NAME_FLAGS_UNION(ctypes.LittleEndianStructure):
    _fields_ = [
            ("friendlyNameFromEdid", ctypes.c_uint8, 1 ),  # 0 
            ("friendlyNameForced", ctypes.c_uint8, 1 ),  # 1
            ("edidIdsValid", ctypes.c_uint8, 1 ),  # 2
            ("reserved", ctypes.c_uint32, 28 ),  # 3 to 31
        ]

    def __str__(self):
        value_list = (self.friendlyNameFromEdid, self.friendlyNameForced, self.edidIdsValid)
        strValue = ("friendlyNameFromEdid=%d friendlyNameForced=%d edidIdsValid=%d")%(value_list)
        return strValue



class  DISPLAYCONFIG_TARGET_DEVICE_NAME_FLAGS(ctypes.Union):
    _anonymous_ = ("u",)
    _fields_ = [
        ("u", DISPLAYCONFIG_TARGET_DEVICE_NAME_FLAGS_UNION),
        ("value", ctypes.c_uint32)
    ]


class  DISPLAYCONFIG_TARGET_DEVICE_NAME(ctypes.LittleEndianStructure):
    _fields_ = [
        ("header", DISPLAYCONFIG_DEVICE_INFO_HEADER),
        ("flags", c_uint32),
        ("outputTechnology", ctypes.c_uint32),
        ("edidManufactureId", ctypes.c_uint16),
        ("edidProductCodeId", ctypes.c_uint16),
        ("connectorInstance", ctypes.c_uint32),
        ("monitorFriendlyDeviceName",  ctypes.c_wchar * 64),
        ("monitorDevicePath",  ctypes.c_wchar * 128),
    ]

    def __str__(self):
        value_list=(self.flags, self.outputTechnology, self.edidManufactureId, self.edidProductCodeId, self.connectorInstance, self.monitorFriendlyDeviceName, self.monitorDevicePath)
        strValue = "flags=%s outputTechnology=%d edidManufactureId=%d edidProductCodeId=%d connectorInstance=%d monitorFriendlyDeviceName=%s monitorDevicePath=%s"%(value_list)
        return strValue



class  DISPLAYCONFIG_TARGET_PREFERRED_MODE(ctypes.LittleEndianStructure):
    _fields_ = [
        ("header", DISPLAYCONFIG_DEVICE_INFO_HEADER),
        ("width", ctypes.c_uint32),
        ("height", ctypes.c_uint32),
        ("targetMode", DISPLAYCONFIG_TARGET_MODE),
    ]

    def __str__(self):
        value_list = (self.width, self.height)
        strValue = ("%dx%d", value_list)
        return strValue


class  DISPLAYCONFIG_ADAPTER_NAME(ctypes.LittleEndianStructure):
    _fields_ = [
        ("header", DISPLAYCONFIG_DEVICE_INFO_HEADER),
        ("adapterDevicePath", ctypes.c_wchar * 128)
    ]



class  DISPLAYCONFIG_SUPPORT_VIRTUAL_RESOLUTION(ctypes.LittleEndianStructure):
    _fields_ = [
        ("header", DISPLAYCONFIG_DEVICE_INFO_HEADER),
        ("value", ctypes.c_uint32)
    ]

class  DISPLAY_DEVICEA(ctypes.LittleEndianStructure):
    _fields_ = [
        ("cb", ctypes.c_uint32),
        ("DeviceName", ctypes.c_char * 32),
        ("DeviceString", ctypes.c_char * 128),
        ("StateFlags", ctypes.c_uint32),
        ("DeviceID", ctypes.c_char * 128),
        ("DeviceKey", ctypes.c_char * 128)
    ]

class  DEVMODEA(ctypes.LittleEndianStructure):
    _fields_ = [
        ("dmDeviceName", ctypes.c_char * 32),
        ("dmSpecVersion", ctypes.c_uint16),
        ("dmDriverVersion", ctypes.c_uint16),
        ("dmSize", ctypes.c_uint16),
        ("dmDriverExtra", ctypes.c_uint16),
        ("dmFields", ctypes.c_uint32),
        ("dmPositionX", ctypes.c_int32),
        ("dmPositionY", ctypes.c_int32),
        ("dmDisplayOrientation", ctypes.c_uint32),
        ("dmDisplayFixedOutput", ctypes.c_uint32),
        ("dmColor", ctypes.c_int16),
        ("dmDuplex", ctypes.c_int16),
        ("dmYResolution", ctypes.c_int16),
        ("dmTTOption", ctypes.c_int16),
        ("dmCollate", ctypes.c_int16),
        ("dmFormName", ctypes.c_char * 32),
        ("dmLogPixels", ctypes.c_uint16),
        ("dmBitsPerPel", ctypes.c_uint32),
        ("dmPelsWidth", ctypes.c_uint32),
        ("dmPelsHeight", ctypes.c_uint32),
        ("dmDisplayFlags", ctypes.c_uint32),
        ("dmDisplayFrequency", ctypes.c_uint32),
#if (WINVER >= 0x0400)
        ("dmICMMethod", ctypes.c_uint32),
        ("dmICMIntent", ctypes.c_uint32),
        ("dmMediaType", ctypes.c_uint32),
        ("dmDitherType", ctypes.c_uint32),
        ("dmReserved1", ctypes.c_uint32),
        ("dmReserved2", ctypes.c_uint32),
#if (WINVER >= 0x0500) || (_WIN32_WINNT >= 0x0400)
        ("dmPanningWidth", ctypes.c_uint32),
        ("dmPanningHeight", ctypes.c_uint32)
#endif 
#endif 
    ]


class DISPLAYCONFIG_DEVICE_INFO_HEADER(ctypes.LittleEndianStructure):
  _fields_ = [
        ("type",ctypes.c_uint32), # DISPLAYCONFIG_DEVICE_INFO_TYPE
        ("size", ctypes.c_uint32),
        ("adapterId", LUID),
        ("id", ctypes.c_uint32),
    ]


class DISPLAYCONFIG_TARGET_DEVICE_NAME(ctypes.LittleEndianStructure):
  _fields_ = [
        ("header", DISPLAYCONFIG_DEVICE_INFO_HEADER),
        ("flags", ctypes.c_uint32), # DISPLAYCONFIG_TARGET_DEVICE_NAME_FLAGS
        ("outputTechnology", ctypes.c_uint32), #DISPLAYCONFIG_VIDEO_OUTPUT_TECHNOLOGY
        ("edidManufactureId", ctypes.c_uint16),
      ("edidProductCodeId", ctypes.c_uint16),
      ("connectorInstance", ctypes.c_uint32),
      ("monitorFriendlyDeviceName", ctypes.c_wchar * 64),
      ("monitorDevicePath", ctypes.c_wchar * 128),
    ]




DM_POSITION =           0x00000020L
DM_BITSPERPEL =         0x00040000L
DM_PELSWIDTH =          0x00080000L
DM_PELSHEIGHT =         0x00100000L
DM_DISPLAYFLAGS =       0x00200000L
DM_DISPLAYFREQUENCY =   0x00400000L
DM_DISPLAYFIXEDOUTPUT = 0x20000000L

DM_INTERLACED =         0x00000002L

DMDFO_DEFAULT =   0
DMDFO_STRETCH =   1
DMDFO_CENTER =    2

