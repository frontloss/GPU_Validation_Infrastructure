############################################################################################################
# @file
# @addtogroup PyLibs_VideoPlayer
# @brief Python helper library to launch video file 
# @remarks 
#
# @ref vaideoplayer.py exposes below functions/ APIs:
# <ul>
# <li><b>playvideo</b></li>
# <li><b>closevideo</b></li>
# <li><b>enum_display_monitors</b></li>
# <br>
# </ul>

# @author Beeresh
############################################################################################################

import time
import win32api, win32con
import subprocess
import ctypes
from win32gui import (
     EnumWindows,
     GetClassName,
     GetWindowText,
     PostMessage,
     SetWindowPos,
)


from ctypes import (
     windll,
     c_int,
     c_uint,
     c_long,
     c_ulong,
     c_double,
     POINTER,
     Structure,
     WINFUNCTYPE,
)


##
# @brief Window rectangle structure used for win32 api's
class RECT(Structure):
     _fields_ = [
         ('left', c_long),
         ('top', c_long),
         ('right', c_long),
         ('bottom', c_long)
     ]

     def dump(self):
         return map(int, (self.left, self.top, self.right, self.bottom))


##
# @brief MontorInfo structure used in win32 api's
class MONITORINFO(ctypes.Structure):
  _fields_ = [
    ('cbSize', ctypes.c_ulong),
    ('rcMonitor', RECT),
    ('rcWork', RECT),
    ('dwFlags', ctypes.c_ulong)
    ]


MonitorEnumProc = WINFUNCTYPE(c_int, c_ulong, c_ulong, POINTER(RECT),
c_double)


##
# @brief enum_display_minotors returns list of connected monitor info
def enum_display_monitors():
     results = []
     handles = []
     def _callback(monitor, dc, rect, data):
         results.append(rect.contents.dump())
         handles.append(monitor)
         return 1
     callback = MonitorEnumProc(_callback)
     temp = windll.user32.EnumDisplayMonitors(0, 0, callback, 0)
     return results, handles


def get_coordinates(monitor_index):
    screen_coordinates, handles = enum_display_monitors()
    idx = 0
    for screen in screen_coordinates:
        x = screen[0]
        y = screen[1]
        width = screen[0] - screen[2]
        height = screen[1] - screen[3]
        width = abs(width)
        height = abs(height)
        #print(x, y, width, height)
        if idx == monitor_index:
            return x, y, width, height
        idx += 1

    return None, None, None, None

##
# @brief enum_windows returns list of windows
def enum_windows():
    results = []
    def _handler(hwnd, results):
            results.append((hwnd, GetWindowText(hwnd), GetClassName(hwnd)))
    EnumWindows(_handler, results)
    return results


##
# @brief mouse_doubleclick mimics mouse double click event at x,y co-ordinates
def mouse_doubleclick(x, y):
    win32api.SetCursorPos((x,y))
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, x, y, 0, 0)
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, x, y, 0, 0)
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, x, y, 0, 0)
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, x, y, 0, 0)


##
# @brief Helper function to close windows handle
# 
# @param[in] hwnd - window handle
def closevideo(hwnd):
    PostMessage(hwnd, win32con.WM_CLOSE, 0, 0)
    cmd = 'taskkill /IM "Video.UI.exe" /F'
    subprocess.call(cmd, shell = True)


# @return windows handle to media player window
def playvideo(media_file_name, monitor_idx):
    LAUNCH_WARM_UP_TIME_IN_SECS = 2
    WINDOW_MOVE_LATENCY_IN_SECS = 2
    WINDOW_RESIZE_LATENCY_IN_SECS = 2

    # Do not change the call sequence of get_coordinates and win32api.ShellExecute.
    # get_coordinates return empty list when ShellExecute execute prior to it.
    x, y, width, height = get_coordinates(monitor_idx)
    win32api.ShellExecute(None, "open", media_file_name, None, None, win32con.SW_SHOW)
    time.sleep(LAUNCH_WARM_UP_TIME_IN_SECS)

    for window_handle, window_title, cls in enum_windows():
        # The media window title is different for Win8, RS1, RS2
        if window_title in ["Windows Media Player", "Movies & TV", "Films & TV"]:
            SetWindowPos(window_handle, None, x, y, width, height, 0)
            time.sleep(WINDOW_MOVE_LATENCY_IN_SECS)

            cursor_x = x + (width/2)
            cursor_y = y + (height/2)
            mouse_doubleclick(cursor_x, cursor_y)

            time.sleep(WINDOW_RESIZE_LATENCY_IN_SECS)
            return window_handle
    return None


if __name__ == "__main__":
    hwnd = playvideo("crc.mp4", 1)
    time.sleep(20)
    closevideo(hwnd)
