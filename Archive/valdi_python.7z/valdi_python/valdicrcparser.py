############################################################################################################
# \file
# \addtogroup PyLibs_ValDiInterface
# @brief Python parser to analyze ValDi trace file for CRC patterns
# @remarks 
#
# @ref valdicrcparser.py exposes below functions/ APIs:
# <ul>
# <li><b>qualifier API</b></li><br>
# </ul>

# @author Beeresh
############################################################################################################


import collections
import logging
import os
import sys, shutil


##
# KeyValue class used in find_average function
class KeyValue(object):

    def __init__(self, key, value):
        self.key = key
        self.value = value



##
# ValDiCRCParser class exposes python APIs to analyze ValDi trace file for CRC patterns
# @brief
class ValDiCRCParser(object):

    ##
    # @brief Constructor for ValDiHelper
    #     
    def __init__(self, filename):
        self.filename = filename
        self.start_processing = False
        self.end_processing = False
        self.pre_process_lines = []
        if not os.path.exists(self.filename):
            msg = "Trace file does not exists %s"%filename
            #raise Exception(msg)


    # @brief Function to qualify individual line in the trace file
    #
    # @param[in] self reference to the instantiated object
    # @param[in] line - current line in the file
    def parse_line_crc(self, line):
        if not "PIPEPORTCRC" in line:
            return

        data = [x.strip() for x in line.split(';')]
        self.pre_process_lines.append(data)


    # @brief Internal function to rollup consecutive CRC values with CRC value as key and Count as value pair
    #
    # @param[in] current_key current CRC value to check with the top of the stack for rollup
    # @param[in] crcs is list of CRCs values
    # @param[in] continous_frame_threshold is an integer to qualify minimum occurence as a pattern
    # return crcs list with updated occurrence
    def rollup_crcs(self, current_key, crcs, continous_frame_threshold):
        if len(crcs) > 0:
            stack_top = crcs.pop()

            if current_key == stack_top.key:
                stack_top.value += 1
                crcs.append(stack_top)
            else:
                if (stack_top.value >= continous_frame_threshold):
                    crcs.append(stack_top)

                new_obj = KeyValue(current_key, 1)
                crcs.append(new_obj)
        else:
            new_obj = KeyValue(current_key, 1)
            crcs.append(new_obj)

        return crcs


    # @brief Function to parse trace file for CRC dumps
    #
    # @param[in] self reference to the instantiated object
    # @param[in] continous_frame_threshold - discard frames if does not match threshold
    def process_lines(self, continous_frame_threshold = 0):
        #=========================================================================================
        # ['7862374516', '0', '2', 'PIPEPORTCRC 0', '24f2dae9', '0', 'f5d8bc41', '1', 'ffff', '']
        #     0           1    2      3               4          5      6         7     8      9
        #=========================================================================================

        # Checking the difference between adjacent [0]index values

        last_timestamp = 0
        pipe_crcs = []
        port_crcs = []
        MAX_PORTS = 5

        for i in range(MAX_PORTS):
            pipe_crcs.append([])
            port_crcs.append([])

        for line in self.pre_process_lines:
            if line[0].isdigit() is False:
                continue

            current_timestamp = int(line[0])
            # Assuming that there will be no two consecutive error messages
            delta = current_timestamp - last_timestamp

            if last_timestamp == 0:
                delta = 0
            last_timestamp = current_timestamp

            '''
            if (delta > 17000):
                logging.debug('Diff more than 17,000, i.e. %s between value @ line %s and %s'%(delta, last_timestamp, current_timestamp))
            if (delta < 15000):
                logging.debug('Diff less than 15,000, i.e. %s between value @ line %s and %s'%(delta, last_timestamp, current_timestamp))
            '''

            # Creating a dictionary by combining [4]index and [6]index element as keys in dict.
            # The value in the dict will be the count of these keys.
            if line[5] not in ['0', '1', '2', '3', '4']:
                continue

            pipe_idx = int(line[3].replace("PIPEPORTCRC ",""))
            pipe_crc = line[4]
            port_idx = int(line[5])
            port_crc = line[6]

            crcs = port_crcs[port_idx]
            port_crcs[port_idx] = self.rollup_crcs(port_crc, crcs, continous_frame_threshold)

            crcs = pipe_crcs[pipe_idx]
            pipe_crcs[pipe_idx] = self.rollup_crcs(pipe_crc, crcs, continous_frame_threshold)
        return port_crcs, pipe_crcs
  


    # @brief Top level API to parse the CRC dumps from trace file
    #
    # @param[in] self reference to the instantiated object
    def parse(self):
        '''
        Printing the Output to File instead of console
        '''
        with open(self.filename, 'r') as f:
            lines = f.readlines()

        for line in lines:
            if not "PIPEPORTCRC" in line:
                continue

            data = [x.strip() for x in line.split(';')]
            self.pre_process_lines.append(data)

        return self.process_lines()


##
# @brief Helper function to qualify the input CRC values with reference 
# CRC pattern
# 
# 
# @param[in] port_crcs values of particular port
# @param[in] reference_pattern is list of flip count packed as pattern
# @return returns pattern match result and processed CRC patterns
def qualifier(port_crcs, reference_pattern):
    #How it works: 
    # Step1 : Iterate through the list of the CRC set
    # Step2 : Inside the loop check for pattern occurrence w.r.t reference_pattern 
    # Step3 : If the matched count is equal to the length of reference pattern, then
    #         the given CRC set is qualified for particular port
    found = False
    matched_list = []
    pattern_match = 0
    current = 0

    if reference_pattern is None:
        logging.error("Invalid reference pattern")
        print("Invalid reference pattern")
        return found, pattern_match

    pattern_length = len(reference_pattern)
    if pattern_length == 0:
        logging.error("Invalid reference pattern")
        print("Invalid reference pattern--------------")
        return found, pattern_match

    for crc in port_crcs:
        if len(matched_list) > 0:
            stack_top = matched_list.pop()
            if current == pattern_length:
                pattern_match = pattern_match + 1
                found = True
                break

            if (stack_top.value >= reference_pattern[current]):
                #logging.info("index=%d crc=%s current flips=%s and reference flips=%s"%(current, stack_top.key, stack_top.value, reference_pattern[current]))
                matched_list.append(stack_top)
                current = len(matched_list)
        matched_list.append(crc)

    return found, matched_list


#ULT
if __name__ == '__main__':
    log_file = 'out.txt'

    rootLogger = logging.getLogger()
    rootLogger.setLevel(logging.INFO)

    ## 
    # Handler for Logging into File
    fileHandler = logging.FileHandler(log_file, mode = 'w')
    rootLogger.addHandler(fileHandler)

    ##
    # Handler for Logging onto Console
    consoleHandler = logging.StreamHandler()
    rootLogger.addHandler(consoleHandler)

    if len(sys.argv) == 2:
        trace_file = sys.argv[1]
        trace_file = os.path.join (os.getcwd(), trace_file)
        logging.info("Parse trace file %s"%(trace_file))

        parser = ValDiCRCParser(trace_file)        
        port_crc_set, pipe_crc_set = parser.parse()
        logging.info("Qualify file %s with %s crcs set"%(trace_file, len(port_crc_set)))

        results = {}
        for i in range(len(port_crc_set)):
            port_crcs = port_crc_set[i]
            pattern_match, result_set = qualifier(port_crcs, [240, 240, 240, 240, 240])

            if pattern_match:
                logging.info("Qualification PASSED for CRC data for PipePort %d" % (i))
                pattern_index = 0
                for pair in result_set:
                    logging.info("Pattern-%s [%s] flipped %s times expected %s flips" % (
                    pattern_index , pair.key, pair.value, [240, 240, 240, 240, 240][pattern_index]))
                    pattern_index = pattern_index + 1
                results[i] = True
            else:
                logging.info("Qualification FAILED for CRC data for PipePort %d" % (i))
                logging.info("=============================================")
                logging.info("| Pipe Index | %-20s |  Flips|"%("Pipe, Port CRC"))
                logging.info("=============================================")

                for crc in port_crcs:
                    logging.info("| Pipe:%-5s | %-20s | %-5s |"%(i, crc.key, crc.value))
                logging.info("=============================================")
                results[i] = False

            logging.info("\n\n\n")

        for key, value in results.items():
            logging.info("CRC verification for pipe %s %s"%(key, value))

        shutil.copy("out.txt", trace_file.replace("valdi", "log"))        
   