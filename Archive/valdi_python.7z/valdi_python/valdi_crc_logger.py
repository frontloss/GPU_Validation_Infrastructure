############################################################################################################
# \file
# \addtogroup PyLibs_ValDiInterface
# \brief Python wrapper helper module providing ComputeCRC API for  CRC verification
# \remarks Below steps to be followed to capture CRC logs.
# <ul>
# <li> Clear old logs
# <li> Triggers stimuli
# <li> Wait for stimuli to complete
# <li> Dumps validation driver logs
# <li> Stitches multiple logs into single log file
# <li> Parses final log file and returns tuple with status and list of crc values
# </ul>

# \ref valdi_crc_logger.py exposes below functions/ APIs:
# <ul>
# <li> @ref play_video_test_pattern         \n \copybrief play_video_test_pattern \n
# <li> @ref play_directx_app_test_pattern   \n \copybrief play_directx_app_test_pattern \n
# <li> @ref ComputeCRC                      \n \copybrief ComputeCRC \n
# <br>
# </ul>

# @author Beeresh
############################################################################################################


import glob, os, traceback
import time, logging
import ccdapi

from subprocess import Popen
from Libs.Core.test_env.test_environment import TestEnvironment
from Libs.Core.display_config.display_config import *
from Libs.Core.valdi.valdicrcparser import *
from Libs.Core.valdi.videoplayer import playvideo, closevideo
import Libs.Core.valdi.valdi_api as valdi_interface
from Libs.Feature.display_engine.de_base.display_base import *
from Libs.Core.system_utility import *

CRC_FAIL = False
CRC_PASS = True
CRC_NO_LOG = None


##
# @brief Helper function to launch Video playback based stimuli
# 
# Launch media player with provided input video file
# 
# @param[in] video_file is complete path of video file
# @param[in] monitor display index
def play_video_test_pattern(video_file, monitor_idx):
    delay = 50
    # Introduced sleep to stabilize the ValDi service and video start
    time.sleep(5)
    hwnd = playvideo(video_file, monitor_idx)
    time.sleep(delay)
    closevideo(hwnd)


##
# @brief Helper function to launch DIRECTX app based stimuli
# 
# Launch DirectX app based stimuli
# 
# @param[in] filename is complete path of stimuli binary
# @param[in] monitor display index
# @return tuple of CRC list and pattern match result
def play_directx_app_test_pattern(filename, monitor_idx=0):
    delay = 50
    # Introduced sleep to stabilize the ValDi service and directx start
    time.sleep(5)
    # appHandle = subprocess.call(cmd, shell=True)
    appHandle = Popen([filename, str(monitor_idx), "0"])
    time.sleep(delay)
    try:
        appHandle.kill()
    except:
        pass


##
# @brief Internal function to launch the stimuli
#
# @param[in] targetid where stimuli needs to be launched, currently this API works only for video
# @param[in] stimuli type to be launched
# @return True or False
def run_stimuli(targetid, stimuli='VIDEO', custom_video='crc.mp4'):
    status = False
    video = custom_video
    CRC_BIN = os.path.join(TEST_STORE_FOLDER, "CRC")
    stimuli = stimuli.upper()

    monitor_mode = ccdapi.get_source_mode(targetid)
    monitor_info = ccdapi.get_monitor_info(targetid)

    if monitor_info is None or monitor_mode is None:
        logging.error("Could not find targetId: %s" % (targetid))
        return status

    if custom_video == 'NONE':
        video = 'crc.mp4'
    logging.info("CRC stimuli %s:%s started on %s [%s] having %d x %d at (%d, %d) " % (stimuli, video,
                                                                                       monitor_info.monitorFriendlyDeviceName,
                                                                                       targetid,
                                                                                       monitor_mode.width,
                                                                                       monitor_mode.height,
                                                                                       monitor_mode.position.x,
                                                                                       monitor_mode.position.y))

    target_idx = 0
    active_targetids = ccdapi.get_active_target_ids()
    for idx in range(len(active_targetids)):
        if active_targetids[idx] == targetid:
            target_idx = idx
            break

    valdi_interface.start_tracing()
    if stimuli == "VIDEO":
        filename = os.path.join(CRC_BIN, video)
        play_video_test_pattern(filename, monitor_idx=target_idx)
    else:
        filename = os.path.join(CRC_BIN, "CRCStimuli.exe")
        play_directx_app_test_pattern(filename, monitor_idx=target_idx)
    valdi_interface.stop_tracing()
    status = True
    return status


##
# @brief Internal functino to computer flip pattern based on RR
#
# @param[in] targetid where stimuli needs to be launched, currently this API works only for video
# @return List of flip counts for each pattern
def get_flip_pattern(target_id):
    # Number of distinct frames
    PATTERN_COUNT = 5

    # Number of seconds single pattern played
    PATTERN_UNIT_TIME_IN_SECS = 5

    # 4% compensation for SW stack in OS for decoding content
    FLIP_SWING_IN_PERCENT = 4

    # Get refresh rate for the given targetid
    refresh_rate = ccdapi.get_refresh_rate(target_id)

    '''
    QDC api fails to return refresh rate during CLONE or TILED display config
    for non primary display target ID's
    '''
    if not refresh_rate:
        refresh_rate = 30
    elif refresh_rate > 60:
        '''
        During HDMI CRC integration it was found that few test instances apply
        panel RR > 60Hz, but the stimuli DirectXApp has a limitation of 60Hz
        and below. Hence capping the refresh rate to 60Hz
        '''
        refresh_rate = 60

    per_pattern_flip_count = refresh_rate * PATTERN_UNIT_TIME_IN_SECS
    SW_STACK_COMPENSATION = (per_pattern_flip_count * FLIP_SWING_IN_PERCENT / 100)
    threshold_flips = per_pattern_flip_count - SW_STACK_COMPENSATION
    threshold_flips = int(threshold_flips)
    flip_pattern = []
    for i in range(PATTERN_COUNT):
        flip_pattern.append(threshold_flips)

    return flip_pattern


##
# @brief Function to form a dictionary of {target ID : Flip pattern}
#
# @param[in] targetid_port_map : Map of all connected targets and their port names
# @return Dictionary with (key: Target ID) (value: Flip pattern) of all connected targets
def flip_patterns(targetid_port_map):
    result_map = dict()
    for current_targetId, port_name in targetid_port_map.items():
        result_map[current_targetId] = get_flip_pattern(current_targetId)
    return result_map


##
# @brief API to launch stimuli and verify the CRC log. In the case of
#  video playback based, the video will be launched on all the active display
#  monitors and verifies CRC patterns.
#
# @param[in] stimuli type to be launched
# @param[in] targetid where stimuli needs to be launched
# @param[in] custom_pattern User provided pattern to be used for qualifying the CRC set
# @return True if CRC pattern matched else False
def ComputeCRC(stimuli="DIRECTXAPP", targetid=None, custom_pattern=None, custom_video='crc.mp4'):
    verification_status = False
    valdi_interface.install_valdi()

    active_target_ids = ccdapi.get_active_target_ids()
    # Start preparing interested target list for CRC verification
    interested_target = get_port_targetid_map(reverse=True)

    # Removing target id's which are not active from our interested targets
    interested_target = {target_id: port_name for target_id, port_name in interested_target.items() if
                         target_id in active_target_ids}
    logging.info("Interested targets = %s" % interested_target)

    if not bool(interested_target):
        logging.warning("Skipping CRC verification, connected panel list is empty!!")
        verification_status = True
        return verification_status

    # Generate flip pattern based on refresh rate
    target_flip_patterns = flip_patterns(interested_target)

    # Get current config and port list
    disp_config = DisplayConfiguration()
    config, port_type_list, display_and_adapter_info_list = disp_config.get_current_display_configuration_ex()
    no_of_displays = len(port_type_list)
    logging.info("Config = %s and port_type_list = %s" % (config, port_type_list))

    # Evaluate interested ports based on the targetid parameter
    if targetid and targetid > 0:
        interested_port = interested_target[targetid]
    else:
        interested_port = None

    '''
    For ClONE config running stimuli only once is sufficient to evaluate
    blankout or flickers on all other connected displays
    '''
    if config == "CLONE":
        # Get targetid if not provided
        for current_targetId, port_name in interested_target.items():
            monitor_mode = ccdapi.get_source_mode(current_targetId)
            monitor_info = ccdapi.get_monitor_info(current_targetId)
            if monitor_info and monitor_mode:
                targetid = current_targetId
                break

    # If targetid is provided then prune interested_targets
    if targetid and targetid > 0:
        port_name = interested_target[targetid]
        interested_target = dict()
        interested_target[targetid] = port_name
    # End of interested target list preparation

    '''
    Due to limitation from OS to move Media Player windows across the display in EXTENDED config
    mode, overriding stimuli to DIRECTXAPP for extended mode
    '''
    if config == "EXTENDED":
        stimuli = "DIRECTXAPP"
    stimuli = stimuli.upper()

    # Run Stimuli on all the interested targets and perform CRC verification for the interested ports
    try:
        crc_pass_set = dict()
        for current_targetId, port_name in interested_target.items():
            run_stimuli(current_targetId, stimuli, custom_video)

            # Prepare parser to combine the trace files and generate single unified trace file
            parser = ValDiCRCParser(valdi_interface.PARSER_OUTPUT_FILE)

            # Get the port and pipe CRC result set from parser
            port_crc_set, pipe_crc_set = parser.parse()

            # On Gen10 platform port CRC generation is not consistent, hence qualifying pipe crcs in
            # place of port CRC's
            platform = None
            gfx_display_hwinfo = SystemInfo().get_gfx_display_hardwareinfo()
            # WA : currently test are execute on single platform. so loop break after 1 st iteration.
            # once Enable MultiAdapter remove the break statement.
            for i in range(len(gfx_display_hwinfo)):
                platform = str(gfx_display_hwinfo[i].DisplayAdapterName).upper()
                break
            if platform in ['GLK', 'CNL', 'ICLLP']:
                port_crc_set = pipe_crc_set

            logging.info("Qualify file %s with %s crcs set" % (valdi_interface.PARSER_OUTPUT_FILE, len(port_crc_set)))

            if interested_port:
                port_name = interested_port

            # In GEN10 there is know HW bug w.r.t PORT CRC due to audio data island packet
            if platform in ['GLK', 'CNL']:
                port2pipe = get_port_to_pipe()
                pipe_name = port2pipe[port_name]
                idx = ord(pipe_name[-1:]) - ord('A')
            else:
                idx = ord(port_name[-1:]) - ord('A')

            port_crcs = port_crc_set[idx]

            if custom_pattern is None:
                flip_pattern = target_flip_patterns[current_targetId]
            else:
                flip_pattern = custom_pattern
            pattern_match, result_set = qualifier(port_crcs, flip_pattern)

            if pattern_match:
                logging.info("Qualification PASSED for CRC data for %s" % port_name)
                pattern_index = 0
                for pair in result_set:
                    args_tuple = (pattern_index, pair.key, pair.value, flip_pattern[pattern_index])
                    logging.info("Pattern-%s [%s] flipped %s times expected %s flips" % args_tuple)
                    pattern_index = pattern_index + 1
                logging.info("=============================================")
                logging.info("\n")

                crc_pass_set[port_name] = result_set
                verification_status = True
            else:
                # In case of clone, mapping of targetid are not straight forward, hence defer
                # the failure case until parsing of all sets
                logging.info("\n")
                logging.info("%s qualification FAILED for pattern %s" % (port_name, flip_pattern))
                logging.info("=============================================")
                logging.info(" %-20s |  Flips|" % ("Pipe, Port CRC"))
                logging.info("=============================================")
                for crc in port_crcs:
                    logging.info(" %-20s | %-5s |" % (crc.key, crc.value))
                logging.info("=============================================")

                if custom_pattern:
                    flip_pattern = target_flip_patterns[current_targetId]
                    pattern_match, result_set = qualifier(port_crcs, flip_pattern)

                    if pattern_match:
                        logging.warning("%s qualification PASSED for default pattern %s" % (port_name, flip_pattern))

    except Exception as e:
        verification_status = False
        traceback.print_exc(file=sys.stdout)
        logging.error("Exception occurred!!")
        logging.error(e)

    if verification_status:
        logging.info("CRC verification PASSED")
    else:
        logging.error("CRC verification FAILED")

    # Enable trace file backups only for DEBUG mode
    if logging.getLogger().isEnabledFor(logging.DEBUG):
        # Flush the logs
        [h_weak_ref().flush() for h_weak_ref in logging._handlerList]

        # Back the logs
        valdi_interface.backup_trace_files()

    valdi_interface.stop_tracing()
    return verification_status


if __name__ == '__main__':
    EDP = 265988
    DP = 200195
    # DP = 224795
    TestEnvironment.initialize()
    for i in range(50):
        result = ComputeCRC(targetid=DP)
        if not result:
            break

    '''
    targetid = 200195
    result = ComputeCRC(targetid=targetid)
    print("ComputerCRC with targetid [%s] = %s" % (targetid, result))

    targetid = 265981
    pattern = [150,150,150,150,150]
    result = ComputeCRC(targetid=targetid, custom_pattern=pattern)
    print("ComputerCRC with targetid [%s] and custom pattern [%s] = %s" % (targetid,pattern, result))
    '''
